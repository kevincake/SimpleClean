package cn.com.opda.android.clearmaster.adapter;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.Color;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.TextView;
import cn.com.opda.android.clearmaster.R;
import cn.com.opda.android.clearmaster.custom.CustomDialog2;
import cn.com.opda.android.clearmaster.impl.CheckedListener;
import cn.com.opda.android.clearmaster.impl.SelectListener;
import cn.com.opda.android.clearmaster.model.AppItem;
import cn.com.opda.android.clearmaster.model.ClearItem;
import cn.com.opda.android.clearmaster.utils.FormatUtils;

/**
 * 
 * 深度清理适配器
 * 
 * @author 庄宏岩
 * 
 */
public class Adapter4DepthClear extends BaseAdapter {
	private ArrayList<AppItem> mClearItems;
	private LayoutInflater mLayoutInflater;
	private Context mContext;
	private SelectListener selectListener;
	private CheckedListener checkedListener;

	public Adapter4DepthClear(Context mContext, ArrayList<AppItem> mClearItems) {
		this.mClearItems = mClearItems;
		this.mContext = mContext;
		mLayoutInflater = LayoutInflater.from(mContext);
	}

	public void setSelectListener(SelectListener selectListener) {
		this.selectListener = selectListener;
	}

	@Override
	public int getCount() {
		return mClearItems.size();
	}

	@Override
	public Object getItem(int position) {
		return mClearItems.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	public void remove(ClearItem clearItem) {
		mClearItems.remove(clearItem);
		notifyDataSetChanged();
	}

	public void setAllChecked(boolean isChecked) {
		for (AppItem clearItem : mClearItems) {
			clearItem.setChecked(isChecked);
		}
		notifyDataSetChanged();
	}

	/**
	 * 获取选中的条目
	 * 
	 * @return
	 */
	public ArrayList<AppItem> getSelecteList() {
		ArrayList<AppItem> clearItems = new ArrayList<AppItem>();
		for (AppItem clearItem : mClearItems) {
			if (clearItem.isChecked()) {
				clearItems.add(clearItem);
			}
		}
		return clearItems;
	}

	public void updateSelectDepthSize() {
		long size = 0;
		int checkedSize = 0;
		for (AppItem clearItem : mClearItems) {
			if (clearItem.isChecked()) {
				size += clearItem.getCodeSize();
				checkedSize++;
			}
		}
		selectListener.selectSize(size);

		if (checkedListener != null) {
			if (checkedSize == 0) {
				checkedListener.nothingChecked();
			} else if (checkedSize == getCount()) {
				checkedListener.allChecked(checkedSize);
			} else {
				checkedListener.someChecked(checkedSize);
			}
		}
		
	}

	public ArrayList<AppItem> getList() {
		return mClearItems;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		final Holder mHolder;
		if (convertView == null) {
			convertView = mLayoutInflater.inflate(R.layout.listview_depth_clear_item, null);
			mHolder = new Holder();
			mHolder.depth_item_name_textview = (TextView) convertView.findViewById(R.id.depth_item_name_textview);
			mHolder.depth_item_size_textview = (TextView) convertView.findViewById(R.id.depth_item_size_textview);
			mHolder.depth_item_path_textview = (TextView) convertView.findViewById(R.id.depth_item_path_textview);
			mHolder.depth_item_checked_imageview = (CheckBox) convertView.findViewById(R.id.depth_item_checked_imageview);
			convertView.setTag(mHolder);
		} else {
			mHolder = (Holder) convertView.getTag();
		}

		final AppItem clearItem = mClearItems.get(position);

		mHolder.depth_item_name_textview.setText(clearItem.getName());
		mHolder.depth_item_size_textview.setText(FormatUtils.formatBytesInByte(clearItem.getCodeSize()));
		mHolder.depth_item_path_textview.setText(clearItem.getFilePath());
		mHolder.depth_item_checked_imageview.setChecked(clearItem.isChecked());
		mHolder.depth_item_checked_imageview.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if(mHolder.depth_item_checked_imageview.isChecked()){
					String fileType = getDepthFileType(clearItem);
					if(TextUtils.isEmpty(fileType)){
						clearItem.setChecked(!clearItem.isChecked());
						updateSelectDepthSize();
					}else{
						mHolder.depth_item_checked_imageview.setChecked(false);
						final CustomDialog2 customDialog = new CustomDialog2(mContext);
						customDialog.setDialogIcon(R.drawable.dialog_icon_warning);
						String str = mContext.getString(R.string.clear_depth_checked_tips, fileType);
						SpannableStringBuilder style = new SpannableStringBuilder(str);
						style.setSpan(new ForegroundColorSpan(Color.RED), str.indexOf(fileType), str.indexOf(fileType)+ fileType.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
						style.setSpan(new ForegroundColorSpan(Color.RED), str.indexOf("无法恢复"), str.indexOf("无法恢复")+ "无法恢复".length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
						customDialog.setMessage(style);
						
						
						customDialog.setButton2("选中", new OnClickListener() {

							@Override
							public void onClick(View v) {
								customDialog.dismiss();
								clearItem.setChecked(true);
								mHolder.depth_item_checked_imageview.setChecked(true);
								updateSelectDepthSize();
							}
						});
						customDialog.setButton1(R.string.dialog_button_cancel, new OnClickListener() {
							
							@Override
							public void onClick(View v) {
								customDialog.dismiss();
								clearItem.setChecked(false);
								mHolder.depth_item_checked_imageview.setChecked(false);
								updateSelectDepthSize();
							}
						});
						customDialog.show();
					}
				
				}else{
					clearItem.setChecked(!clearItem.isChecked());
					updateSelectDepthSize();
				}
			}
		});
		return convertView;
	}

	private class Holder {
		private TextView depth_item_name_textview;
		private TextView depth_item_size_textview;
		private TextView depth_item_path_textview;
		private CheckBox depth_item_checked_imageview;
	}

	public void remove(int position) {
		mClearItems.remove(position);
		notifyDataSetChanged();
	}
	private String getDepthFileType(AppItem appItem2) {
		String str = "";
		if(appItem2.isIncludeAudio()){
			str+="音频";
		}
		if(appItem2.isIncludeEBook()){
			if(TextUtils.isEmpty(str)){
				str+="电子书";
			}else{
				str+="/电子书";
			}
		}
		if(appItem2.isIncludeObb()){
			if(TextUtils.isEmpty(str)){
				str+="游戏数据包";
			}else{
				str+="/游戏数据包";
			}
		}
		return str;
	}

	public void setCheckListener(CheckedListener checkedListener) {
		this.checkedListener = checkedListener;
	}

}
