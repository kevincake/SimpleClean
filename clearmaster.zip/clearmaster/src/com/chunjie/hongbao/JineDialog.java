package com.chunjie.hongbao;

import java.util.Random;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.TextView;
import cn.com.opda.android.clearmaster.R;

public class JineDialog extends Dialog {
	
	private Context mContext;

	protected JineDialog(Context context, boolean cancelable,
			OnCancelListener cancelListener) {
		super(context, cancelable, cancelListener);
		this.mContext = context;
		// TODO Auto-generated constructor stub
	}
	public JineDialog(Context context, int theme){
		super(context, theme);
		this.mContext = context;
	}



	public  JineDialog(Context context) {
		super(context);
		this.mContext = context;
	}
	android.view.View.OnClickListener mls;
	private TextView hongbao_jine;
	private TextView install_context_tishi;

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.dialog_jinehongbao);
		hongbao_jine = (TextView)findViewById(R.id.hongbao_jine);
		install_context_tishi = (TextView)findViewById(R.id.install_context_tishi);
		String packname = SharePreUtil.getNeedPackage(mContext);
		if(!TextUtils.isEmpty(packname)){
			if(SharePreUtil.tenxunshouguanPackname.equals(packname)){
				install_context_tishi.setText("安装手机管家领取红包");
			}else if(SharePreUtil.yingyongbaoPackname.equals(packname)){
				install_context_tishi.setText("安装应用宝领取红包");
			}
			
		}
		
		int jine = new Random().nextInt(10)+5;
		float j = ((	float )jine)/10f;
		hongbao_jine.setText( j +" 元");
		findViewById(R.id.download_yingyongbao).setOnClickListener(mls);
	}
	public void setBtnOnclickListener(android.view.View.OnClickListener ls) {
		mls = ls;
	}
}
