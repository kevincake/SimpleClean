package cn.com.opda.android.clearmaster.adapter;

import java.util.ArrayList;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Message;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import cn.com.opda.android.clearmaster.R;
import cn.com.opda.android.clearmaster.UninstallChongfuApp;
import cn.com.opda.android.clearmaster.custom.CustomDialog2;
import cn.com.opda.android.clearmaster.custom.IOSProgressDialog;
import cn.com.opda.android.clearmaster.model.AppItem;
import cn.com.opda.android.clearmaster.model.VerboseApp;
import cn.com.opda.android.clearmaster.utils.AppManagerUtils;
import cn.com.opda.android.clearmaster.utils.DrawableUtils;
import cn.com.opda.android.clearmaster.utils.FormatUtils;
import cn.com.opda.android.clearmaster.utils.MarketDownLoadUtils;
import cn.com.opda.android.clearmaster.utils.Terminal;

/**
 * @author 庄宏岩
 * 
 */
public class Adapter4ChongFuApp extends BaseExpandableListAdapter {
	private ArrayList<VerboseApp> mVerboseApps;
	private Context mContext;
	private IOSProgressDialog iosProgressDialog;
	private LayoutInflater inflater;
	private AppItem uninstallAppItem;
	private UninstallChongfuApp chongfuactivity;

	public Adapter4ChongFuApp(Context context, ArrayList<VerboseApp> verboseApps, UninstallChongfuApp chongfuactivity) {
		this.mVerboseApps = verboseApps;
		this.mContext = context;
		this.chongfuactivity = chongfuactivity;
		inflater = LayoutInflater.from(mContext);
	}

	public AppItem getUninstallAppItem() {
		return uninstallAppItem;
	}

	protected void uninstallApp(final AppItem appItem) {
		iosProgressDialog = new IOSProgressDialog(mContext, R.string.app_uninstall_loading);
		iosProgressDialog.show();
		new Thread(new Runnable() {

			@Override
			public void run() {
				boolean b = Terminal.uninstallUserApp(appItem);
				if (b) {
					handler.sendEmptyMessageDelayed(1, 2000);
				} else {
					handler.sendEmptyMessage(0);
				}
			}
		}).start();
	}

	Handler handler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			switch (msg.what) {
			case 0:
				iosProgressDialog.dismiss();
				Toast.makeText(mContext, R.string.app_uninstall_failed, Toast.LENGTH_SHORT).show();
				break;
			case 1:
				iosProgressDialog.dismiss();
				Toast.makeText(mContext, R.string.app_uninstall_succeed, Toast.LENGTH_SHORT).show();
				removeAppItem(uninstallAppItem);
				chongfuactivity.update();
				handler.sendEmptyMessageDelayed(4, 1000);
				break;
			case 2:
				iosProgressDialog.dismiss();
				Toast.makeText(mContext, R.string.verbose_app_fix_succeed, Toast.LENGTH_SHORT).show();
				chongfuactivity.update();
				break;
			case 3:
				iosProgressDialog.dismiss();
				Toast.makeText(mContext, R.string.verbose_app_fix_failed, Toast.LENGTH_SHORT).show();
				break;
			case 4:
				showXiufuMarket();
			default:
				break;
			}
		}

	};

	class Holder {

		private ImageView chongfu_icon_imageview;
		private TextView chongfu_type_textview;
		private TextView chongfu_prompt_textview;
		private ImageView chongfu_arrow_button;
		
//		private ImageView chongfu_icon1;
//		private ImageView chongfu_icon2;
//		private ImageView chongfu_icon3;
		
		private ImageView app_chongfu_item_icon_imageview;
		private TextView app_chongfu_item_appname_textview;
		public TextView app_chongfu_item_size_textview;
		public CheckBox app_chongfu_uninstall_item_checkbox;
		
		
	}


	public void showXiufuMarket() {
		final SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(mContext);
		boolean checked = sp.getBoolean("market_xiufu", false);
		if (!checked) {
			if (MarketDownLoadUtils.isShow(mContext)) {
				if (!MarketDownLoadUtils.marketInstall(mContext)) {
					if (!MarketDownLoadUtils.donwloading) {
						if (MarketDownLoadUtils.finish && !MarketDownLoadUtils.error) {
							final CustomDialog2 customDialog = new CustomDialog2(mContext);
							customDialog.setDialogIcon(R.drawable.dialog_icon_warning);
							customDialog.setMessage("您手机中的电子市场可能被劫持，点击进行修复");
							CheckBox checkBox = new CheckBox(mContext);
							checkBox.setText(R.string.next_not_tips);
							checkBox.setTextColor(mContext.getResources().getColor(R.color.secondary_textcolor));
							checkBox.setButtonDrawable(R.drawable.checkbox_circle_background);
							checkBox.setOnCheckedChangeListener(new OnCheckedChangeListener() {

								@Override
								public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
									sp.edit().putBoolean("market_xiufu", isChecked).commit();
								}
							});
							customDialog.setView(checkBox);
							customDialog.setButton2("修复", new OnClickListener() {

								@Override
								public void onClick(View v) {
									customDialog.dismiss();
									if (Terminal.isRoot(mContext)) {
										iosProgressDialog = new IOSProgressDialog(mContext, "修复中");
										iosProgressDialog.setCancelable(false);
										iosProgressDialog.setCanceledOnTouchOutside(false);
										iosProgressDialog.show();
										new Thread(new Runnable() {
											@Override
											public void run() {
												boolean b = Terminal.installApp(MarketDownLoadUtils.filePath);
												if (b) {
													handler.sendEmptyMessage(2);
													sp.edit().putBoolean("market_xiufu", true).commit();
												} else {
													handler.sendEmptyMessage(3);
												}
											}
										}).start();

									} else {
										AppManagerUtils.openInstaller(mContext, MarketDownLoadUtils.filePath);
										sp.edit().putBoolean("market_xiufu", true).commit();
									}
								}
							});
							customDialog.setButton1(R.string.dialog_button_cancel, null);
							customDialog.show();

						}
					}
				} else {
					sp.edit().putBoolean("market_xiufu", true).commit();
				}
			}
		}
	}

	@Override
	public int getGroupCount() {
		return mVerboseApps.size();
	}

	@Override
	public int getChildrenCount(int groupPosition) {
		return mVerboseApps.get(groupPosition).getAppItems().size();
	}

	@Override
	public Object getGroup(int groupPosition) {
		return mVerboseApps.get(groupPosition);
	}

	@Override
	public Object getChild(int groupPosition, int childPosition) {
		return mVerboseApps.get(groupPosition).getAppItems().get(childPosition);
	}

	@Override
	public long getGroupId(int groupPosition) {
		return groupPosition;
	}

	@Override
	public long getChildId(int groupPosition, int childPosition) {
		return childPosition;
	}

	@Override
	public boolean hasStableIds() {
		return false;
	}
	
	@Override
	public View getGroupView(int groupPosition, boolean isExpanded,
			View convertView, ViewGroup parent) {
		final Holder mHolder;
		if (convertView == null) {
			inflater = LayoutInflater.from(mContext);
			convertView = inflater.inflate(R.layout.listview_chongfu_group_item_layout, null);
			mHolder = new Holder();
			mHolder.chongfu_type_textview = (TextView) convertView.findViewById(R.id.chongfu_type_textview);
			mHolder.chongfu_prompt_textview = (TextView) convertView.findViewById(R.id.chongfu_prompt_textview);
			mHolder.chongfu_icon_imageview = (ImageView) convertView.findViewById(R.id.chongfu_icon_imageview);
			mHolder.chongfu_arrow_button = (ImageView) convertView.findViewById(R.id.chongfu_arrow_button);
			
//			mHolder.chongfu_icon1 = (ImageView) convertView.findViewById(R.id.chongfu_icon1);
//			mHolder.chongfu_icon2 = (ImageView) convertView.findViewById(R.id.chongfu_icon2);
//			mHolder.chongfu_icon3 = (ImageView) convertView.findViewById(R.id.chongfu_icon3);
			
			convertView.setTag(mHolder);
		} else {
			mHolder = (Holder) convertView.getTag();
		}
		final VerboseApp mVerboseApp = mVerboseApps.get(groupPosition);
		mHolder.chongfu_type_textview.setText(mVerboseApp.getName());
		mHolder.chongfu_icon_imageview.setImageBitmap(DrawableUtils.drawFolderBitmap(mContext, mVerboseApp));
		final ArrayList<AppItem> appItems = mVerboseApp.getAppItems();
		if (appItems != null && appItems.size() > 0) {
			if (appItems.size() >= 2) {
//				mHolder.chongfu_icon1.setVisibility(View.VISIBLE);
//				mHolder.chongfu_icon2.setVisibility(View.VISIBLE);
//				mHolder.chongfu_icon3.setVisibility(View.INVISIBLE);
				mHolder.chongfu_arrow_button.setVisibility(View.VISIBLE);
				mHolder.chongfu_prompt_textview.setText(R.string.verbose_app_more_tips);
				mHolder.chongfu_prompt_textview.setTextColor(mContext.getResources().getColor(R.color.black));
//				mHolder.chongfu_icon1.setBackgroundDrawable(appItems.get(0).getAppIcon());
//				mHolder.chongfu_icon2.setBackgroundDrawable(appItems.get(1).getAppIcon());
//				if(appItems.size() >= 3){
//					mHolder.chongfu_icon3.setVisibility(View.VISIBLE);
//					mHolder.chongfu_icon3.setBackgroundDrawable(appItems.get(2).getAppIcon());
//				}
			} else {
				mHolder.chongfu_prompt_textview.setText(R.string.verbose_app_good_tips);
				mHolder.chongfu_prompt_textview.setTextColor(mContext.getResources().getColor(R.color.black));
				mHolder.chongfu_arrow_button.setVisibility(View.INVISIBLE);
//				mHolder.chongfu_icon1.setVisibility(View.INVISIBLE);
//				mHolder.chongfu_icon2.setVisibility(View.INVISIBLE);
//				mHolder.chongfu_icon3.setVisibility(View.INVISIBLE);
			}
		} else {
			mHolder.chongfu_prompt_textview.setVisibility(View.VISIBLE);
			if (mVerboseApp.isFinish()) {
				mHolder.chongfu_prompt_textview.setText(R.string.verbose_app_null_tips);
				mHolder.chongfu_prompt_textview.setTextColor(mContext.getResources().getColor(R.color.chongfu_list_no_text_color));
			} else {
				mHolder.chongfu_prompt_textview.setText(R.string.verbose_app_scanning);
				mHolder.chongfu_prompt_textview.setTextColor(mContext.getResources().getColor(R.color.black));
			}
			mHolder.chongfu_arrow_button.setVisibility(View.INVISIBLE);
//			mHolder.chongfu_icon1.setVisibility(View.INVISIBLE);
//			mHolder.chongfu_icon2.setVisibility(View.INVISIBLE);
//			mHolder.chongfu_icon3.setVisibility(View.INVISIBLE);
		}
		if(isExpanded){
			mHolder.chongfu_arrow_button.setBackgroundResource(R.drawable.verbose_arrow_down);
        }else{
        	mHolder.chongfu_arrow_button.setBackgroundResource(R.drawable.verbose_arrow_up);
        } 
		return convertView;
	}

	@Override
	public View getChildView(int groupPosition, int childPosition,
			boolean isLastChild, View convertView, ViewGroup parent) {
		final Holder mHolder;
		if (convertView == null) {
			LayoutInflater inflater = LayoutInflater.from(mContext);
			convertView = inflater.inflate(R.layout.listview_chongfu_child_item_layout, null);
			mHolder = new Holder();
			mHolder.app_chongfu_item_icon_imageview = (ImageView) convertView.findViewById(R.id.app_chongfu_item_icon_imageview);
			mHolder.app_chongfu_item_appname_textview = (TextView) convertView.findViewById(R.id.app_chongfu_item_appname_textview);
			mHolder.app_chongfu_item_size_textview = (TextView) convertView.findViewById(R.id.app_chongfu_item_size_textview);
			mHolder.app_chongfu_uninstall_item_checkbox = (CheckBox) convertView.findViewById(R.id.app_chongfu_uninstall_item_checkbox);

			convertView.setTag(mHolder);
		} else {
			mHolder = (Holder) convertView.getTag();
		}
		final AppItem mAppItem = mVerboseApps.get(groupPosition).getAppItems().get(childPosition);
		mHolder.app_chongfu_item_icon_imageview.setImageDrawable(mAppItem.getAppIcon());
		mHolder.app_chongfu_item_appname_textview.setText(mAppItem.getAppName());
		mHolder.app_chongfu_item_size_textview.setText(FormatUtils.formatBytesInByte(mAppItem.getCodeSize()));
		
		mHolder.app_chongfu_uninstall_item_checkbox.setChecked(mAppItem.isChecked());
		mHolder.app_chongfu_uninstall_item_checkbox.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				mAppItem.setChecked(mHolder.app_chongfu_uninstall_item_checkbox.isChecked());
				notifyDataSetChanged();
			}
		});
		
		convertView.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if (mHolder.app_chongfu_uninstall_item_checkbox.isChecked()) {
					mHolder.app_chongfu_uninstall_item_checkbox.setChecked(false);
				} else {
					mHolder.app_chongfu_uninstall_item_checkbox.setChecked(true);
				}
				mAppItem.setChecked(mHolder.app_chongfu_uninstall_item_checkbox.isChecked());
				notifyDataSetChanged();
			}
		});
		
//		mHolder.app_uninstall_item_button.setOnClickListener(new OnClickListener() {
//
//			@Override
//			public void onClick(View v) {
//				if (customDialog != null) {
//					customDialog.dismiss();
//				}
//				uninstallAppItem = mAppItem;
//				if (Terminal.isRoot(mContext)) {
//					uninstallApp(mAppItem);
//				} else {
//					AppManagerUtils.openUninstaller(mContext, mAppItem.getAppPackage());
//				}
//			}
//		});
		return convertView;
	}

	@Override
	public boolean isChildSelectable(int groupPosition, int childPosition) {
		return true;
	}
	
	
	public ArrayList<AppItem> getSelectChongFuList() {
		ArrayList<AppItem> appItems = new ArrayList<AppItem>();
		for (int i = 0; i < mVerboseApps.size(); i++) {
			if (mVerboseApps.get(i).getAppItems()!= null && mVerboseApps.get(i).getAppItems().size() >= 2){
				for (AppItem appItem : mVerboseApps.get(i).getAppItems()) {
					if (appItem.isChecked()) {
						appItems.add(appItem);
					}
				}
			}
		}
		return appItems;
	}
	
	public void removeAppItem(AppItem uninstallAppItem2) {
		for (VerboseApp verboseApp : mVerboseApps) {
			ArrayList<AppItem> appItems = verboseApp.getAppItems();

			if (appItems != null) {
				for (int i = 0; i < appItems.size(); i++) {
					if (appItems.get(i).getAppPackage().equals(uninstallAppItem2.getAppPackage())) {
						appItems.remove(i);
						notifyDataSetChanged();
						break;
					}
				}
			}
		}
	}

}
