package cn.com.opda.android.clearmaster.custom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

/**
 * 内存使用情况圆饼图
 * @author 庄宏岩
 *
 */
public class CustomMemoryChart extends View {
	private float appProgress;
	private float mediaProgress;
	private float otherProgress;
	private Paint bgPaint, avilPaint, appPaint, mediaPaint, otherPaint, whitePaint;
	public static int avilColor = 0xff0091ff;
	public static int appColor = 0xffff5534;
	public static int mediaColor = 0xfff4c20d;
	public static int otherColor = 0xff48dc6b;

	public CustomMemoryChart(Context context) {
		super(context);
		init();
	}

	public CustomMemoryChart(Context context, AttributeSet attrs) {
		super(context, attrs);
		init();
	}

	public CustomMemoryChart(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		init();
	}

	private void init() {

		bgPaint = new Paint();
		bgPaint.setAntiAlias(true);
		bgPaint.setColor(0xffe6e9ed);

		avilPaint = new Paint();
		avilPaint.setAntiAlias(true);
		avilPaint.setColor(avilColor);

		appPaint = new Paint();
		appPaint.setAntiAlias(true);
		appPaint.setColor(appColor);

		mediaPaint = new Paint();
		mediaPaint.setAntiAlias(true);
		mediaPaint.setColor(mediaColor);

		otherPaint = new Paint();
		otherPaint.setAntiAlias(true);
		otherPaint.setColor(otherColor);

		whitePaint = new Paint();
		whitePaint.setAntiAlias(true);
		whitePaint.setColor(Color.WHITE);
	}

	public void setAppProgress(float appProgress) {
		this.appProgress = appProgress;
		if (this.appProgress > 0 && this.appProgress < 1) {
			this.appProgress = 1.0f;
		}
		invalidate();
	}

	public void setMediaProgress(float mediaProgress) {
		this.mediaProgress = mediaProgress;
		if (this.mediaProgress > 0 && this.mediaProgress < 1) {
			this.mediaProgress = 1.0f;
		}
		invalidate();
	}

	public void setOtherProgress(float otherProgress) {
		this.otherProgress = otherProgress;
		if (this.otherProgress > 0 && this.otherProgress < 1) {
			this.otherProgress = 1.0f;
		}
		invalidate();
	}

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		RectF oval = new RectF(0, 0, getWidth(), getHeight());
		RectF oval2 = new RectF(15, 15, getWidth() - 15, getHeight() - 15);

		canvas.drawArc(oval, 0, 360, true, bgPaint);
		canvas.drawArc(oval2, 0, 360, true, avilPaint);
		canvas.drawArc(oval2, -0.5f, 0.5f, true, whitePaint);

		canvas.drawArc(oval2, 0, 360 * (otherProgress + mediaProgress) / 100, true, otherPaint);

		canvas.drawArc(oval2, 360 * (otherProgress + mediaProgress) / 100 - 0.5f, 0.5f, true, whitePaint);

		canvas.drawArc(oval2, 0, 360 * mediaProgress / 100, true, mediaPaint);

		canvas.drawArc(oval2, 360 * (mediaProgress) / 100 - 0.5f, 0.5f, true, whitePaint);

		canvas.drawArc(oval2, 360 * (otherProgress + mediaProgress) / 100, 360 * (appProgress) / 100, true, appPaint);

		canvas.drawArc(oval2, 360 * (otherProgress + mediaProgress + appProgress) / 100 - 0.5f, 0.5f, true, whitePaint);
		// canvas.drawArc(oval3, 0, 360, true, bgPaint);
	}

}
