package cn.com.opda.android.clearmaster.utils;

import java.util.HashMap;

import android.content.Context;

import com.umeng.analytics.MobclickAgent;

public class CustomEventCommit {
	public static final String button_disable_click = "button_disable_click";
	public static final String button_process_click = "button_process_click";
	public static final String button_laji_click = "button_laji_click";
	public static final String button_shendu_click = "button_shendu_click";
	public static final String user_app_uninstall = "user_app_uninstall";
	public static final String system_app_uninstall = "system_app_uninstall";
	public static final String haoziyuan_app_uninstall = "haoziyuan_app_uninstall";
	public static final String verbose_app_uninstall = "verbose_app_uninstall";
	public static final String verbose_ad_install = "verbose_ad_install";
	public static final String recyle_app_install = "recyle_app_install";
	public static final String button_calllog_click = "button_calllog_click";
	public static final String button_sms_hide = "button_sms_hide";
	public static final String button_allsms_delete = "button_allsms_delete";
	public static final String button_sms_restore = "button_sms_restore";
	public static final String button_hidesms_delete = "button_hidesms_delete";
	public static final String button_pic_hide = "button_pic_hide";
	public static final String button_video_hide = "button_video_hide";
	public static final String button_comment = "button_comment";
	public static final String dialog_comment_alert_count = "dialog_comment_alert_count";
	public static final String dialog_comment_count = "dialog_comment_count";
	public static final String result_ad_show = "result_ad_show";
	public static void commit(Context mContext,String event,String appName) {

		DLog.i("debug", "commit event : " + event + " appName: " + appName);
		HashMap<String, String> hashMap = new HashMap<String, String>();
		hashMap.put("appname", appName);
		MobclickAgent.onEvent(mContext, event, hashMap);

	}
	public static void commit(Context mContext,String event) {
		MobclickAgent.onEvent(mContext, event);
		
	}

}
