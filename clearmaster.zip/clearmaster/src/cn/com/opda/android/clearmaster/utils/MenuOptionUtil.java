package cn.com.opda.android.clearmaster.utils;

import java.io.File;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Resources.NotFoundException;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;
import android.widget.Toast;
import cn.com.opda.android.clearmaster.R;
import cn.com.opda.android.clearmaster.SettingsActivity;
import cn.com.opda.android.clearmaster.custom.CustomDialog2;

/**
 * 菜单工具类
 * 
 * @author 庄宏岩
 * 
 */
public class MenuOptionUtil {
	/**
	 * 反馈
	 * 
	 * @param context
	 */
	public static final void feedBack(Context context) {
//		Uri uri = Uri.parse("mailto:");
//		Intent intent = new Intent(Intent.ACTION_SENDTO, uri);
//		intent.putExtra(Intent.EXTRA_EMAIL, new String[] { "feedback@dashi.com" });
//		try {
//			PackageManager packageManager = context.getPackageManager();
//			PackageInfo packageInfo = packageManager.getPackageInfo(context.getPackageName(), 0);
//			intent.putExtra(Intent.EXTRA_SUBJECT,
//					context.getString(R.string.Mail_subject, packageInfo.applicationInfo.loadLabel(packageManager) + packageInfo.versionName));
//			intent.putExtra(
//					android.content.Intent.EXTRA_TEXT,
//					context.getString(R.string.Mail_body, Build.VERSION.RELEASE, Build.MODEL, packageInfo.applicationInfo.loadLabel(packageManager)
//							+ packageInfo.versionName));
//			try {
//				context.startActivity(intent);
//			} catch (Exception e) {
//				e.printStackTrace();
//				Toast.makeText(context, R.string.open_mail_error, Toast.LENGTH_SHORT).show();
//			}
//		} catch (NameNotFoundException e) {
//			e.printStackTrace();
//		}
	}

	/**
	 * 软件分享
	 * 
	 * @param context
	 */
	public static void share(Context context) {
		try {
			Intent intent = new Intent(Intent.ACTION_SEND);
			intent.setType("text/plain");
			intent.putExtra(Intent.EXTRA_TEXT, context.getResources().getString(R.string.softshare_send_content));
			intent.putExtra(Intent.EXTRA_SUBJECT, context.getResources().getString(R.string.softshare_mail_title));
			context.startActivity(Intent.createChooser(intent, context.getResources().getString(R.string.softshare_title)));
		} catch (NotFoundException e) {
			Toast.makeText(context, R.string.share_error, Toast.LENGTH_SHORT).show();
			e.printStackTrace();
		}

	}
	/**
	 * 分享清理结果
	 * @param context
	 */
	public static void shareCleanResult(Activity context) {
		try {
			Intent intent = new Intent(Intent.ACTION_SEND);
			intent.setType("text/plain");
			intent.putExtra(Intent.EXTRA_TEXT, context.getResources().getString(R.string.clean_end_share_content));
			intent.putExtra(Intent.EXTRA_SUBJECT, context.getResources().getString(R.string.clean_end_share_title));
			File file = DeviceInfoUtils.getScreenPic(context);
            Uri uri = Uri.fromFile(file);
            intent.putExtra(Intent.EXTRA_STREAM, uri);
			context.startActivity(Intent.createChooser(intent, context.getResources().getString(R.string.softshare_title)));
		} catch (NotFoundException e) {
			Toast.makeText(context, R.string.share_error, Toast.LENGTH_SHORT).show();
			e.printStackTrace();
		}
		
	}

	/**
	 * 进入官网
	 * 
	 * @param context
	 */
	public static void web(Context context) {
		Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.dashi.com"));
		context.startActivity(intent);
	}

	/**
	 * 关于页面
	 * 
	 * @param context
	 */
	public static void about(Context context) {
		// context.startActivity(new Intent(context, AboutActivity.class));
	}

	/**
	 * 弹出框关于页面
	 * 
	 * @param context
	 */
	public static void aboutDialog(final Context context) {
		final CustomDialog2 customDialog = new CustomDialog2(context);
		View view = LayoutInflater.from(context).inflate(R.layout.dialog_about, null);
		TextView about_version = (TextView) view.findViewById(R.id.about_version);
		try {
			PackageManager packageManager = context.getPackageManager();
			PackageInfo packageInfo = packageManager.getPackageInfo(context.getPackageName(), 0);
			about_version.setText("版本: " + packageInfo.versionName);
		} catch (NameNotFoundException e) {
			about_version.setVisibility(View.GONE);
			e.printStackTrace();
		}
		customDialog.setView(view);
		customDialog.setButton1(R.string.dialog_button_ok, null);
		customDialog.setButton2(R.string.menu_praise, new OnClickListener() {

			@Override
			public void onClick(View v) {
				customDialog.dismiss();
				try {
					Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=pname:" + context.getPackageName()));
					context.startActivity(i);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		customDialog.show();
	}

	public static void set(Context mContext) {
		mContext.startActivity(new Intent(mContext, SettingsActivity.class));
	}

}
