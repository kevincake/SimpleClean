//package cn.com.opda.android.clearmaster.dao;
//
//import android.content.Context;
//import android.database.sqlite.SQLiteDatabase;
//import android.database.sqlite.SQLiteOpenHelper;
//
//public class DBCleanUpOpenHelper extends SQLiteOpenHelper {
//
//	private final static String SqLiteName = "filepath.db";
//	public final static int mversion = 316;
//
//	public DBCleanUpOpenHelper(Context context) {
//		super(context, SqLiteName, null, mversion);
//	}
//
//	@Override
//	public void onCreate(SQLiteDatabase db) {
//		db.execSQL("create table if not exists softdetail (_id INTEGER  primary key autoincrement, softChinesename TEXT,softEnglishname TEXT,apkname TEXT,filepath TEXT)");
//		db.execSQL("create table if not exists cache (_id INTEGER  primary key autoincrement, package TEXT,cn_name TEXT,en_name TEXT,filepath TEXT)");
//	}
//
//	@Override
//	public void onUpgrade(SQLiteDatabase db, int arg1, int arg2) {
//		onCreate(db);
//	}
//
//}
