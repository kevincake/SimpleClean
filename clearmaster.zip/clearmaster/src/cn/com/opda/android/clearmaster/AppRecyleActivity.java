package cn.com.opda.android.clearmaster;

import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import cn.com.opda.android.clearmaster.adapter.Adapter4AppRecyle;
import cn.com.opda.android.clearmaster.model.AppItem;
import cn.com.opda.android.clearmaster.utils.BannerUtils;
import cn.com.opda.android.clearmaster.utils.Constants;
import cn.com.opda.android.clearmaster.utils.DLog;

import com.umeng.analytics.MobclickAgent;

/**
 * 回收站页面
 * 
 * @author 庄宏岩
 * 
 */
public class AppRecyleActivity extends BaseActivity {
	private Adapter4AppRecyle mAdapter4PreAppIninstall;
	private boolean stop;
	private Context mContext;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_app_recyle_layout);
		BannerUtils.setTitle(this, R.string.activity_title_recyle);
		BannerUtils.initBackButton(this);
		mContext = AppRecyleActivity.this;
		stop = false;
		if (Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState())) {
			new ApkManagmentAsyncTask().execute();
		} else {
			TextView app_install_tips_textview = (TextView) findViewById(R.id.app_install_tips_textview);
			findViewById(R.id.app_install_listview).setVisibility(View.GONE);
			app_install_tips_textview.setText(R.string.memory_tips_sd_nohave);
			app_install_tips_textview.setVisibility(View.VISIBLE);
		}
	}

	private class ApkManagmentAsyncTask extends AsyncTask<Void, AppItem, Integer> {
		private ArrayList<AppItem> mApkModelList;
		private ListView mAppInstallListView;

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			if (mApkModelList == null) {
				mApkModelList = new ArrayList<AppItem>();
			} else {
				mApkModelList.clear();
			}
			mAppInstallListView = (ListView) findViewById(R.id.app_install_listview);
			mAdapter4PreAppIninstall = new Adapter4AppRecyle(mContext, mApkModelList);
			mAdapter4PreAppIninstall.setApp_install_listview(mAppInstallListView);
			TextView app_install_tips_textview = (TextView) findViewById(R.id.app_install_tips_textview);
			mAdapter4PreAppIninstall.setApp_install_tips_textview(app_install_tips_textview);
			mAppInstallListView.setAdapter(mAdapter4PreAppIninstall);
		}

		@Override
		protected Integer doInBackground(Void... arg0) {
			File[] sdcardfiles = new File(Constants.SYSTEM_BACKUP_PATH).listFiles();
			if (sdcardfiles != null) {
				for (File file : sdcardfiles) {
					if (stop) {
						break;
					}
					ergodicFiles(file, 0);
				}
			}
			return null;
		}

		@Override
		protected void onPostExecute(Integer result) {
			super.onPostExecute(result);
			DLog.i("debug", "scaning apk end");
			if (mApkModelList != null && mApkModelList.size() == 0) {
				TextView app_install_tips_textview = (TextView) findViewById(R.id.app_install_tips_textview);
				findViewById(R.id.app_install_listview).setVisibility(View.GONE);
				app_install_tips_textview.setText(R.string.recyle_not_scan_app);
				app_install_tips_textview.setVisibility(View.VISIBLE);
			}
		}

		@Override
		protected void onProgressUpdate(AppItem... values) {
			if (values[0] != null) {
				mApkModelList.add(values[0]);
				DLog.i("debug", values[0].getAppName() + "---" + values[0].getFilePath());
				mAdapter4PreAppIninstall.notifyDataSetChanged();
			}
			super.onProgressUpdate(values);
		}

		/**
		 * 遍历file
		 */
		public void ergodicFiles(File file, int counter) {
			if (file.isFile() && !file.isHidden()) {
				String fileName = file.getName();

				if (fileName != null && fileName.length() != 0) {
					if (fileName.endsWith(".apk")) {
						AppItem model = new AppItem();
						model.setAppName(file.getName());
						model.setFilePath(file.getAbsolutePath());
						if (fillApkModel(model)) {
							model.setOdexPath(model.getFilePath().replace(".apk", ".odex"));
							publishProgress(model);
						}
					}
				}

			} else { // 如果不是文件那么继续遍历子文件夹中的内容
				if (counter == 3)
					return;
				else {
					File[] fileArr = file.listFiles();
					if (fileArr != null && fileArr.length != 0) {
						for (File mFile : fileArr) {
							ergodicFiles(mFile, counter++);
						}
					}
				}

			}

		}
	}

	/**
	 * 获取未安装的apk信息
	 * 
	 * @param ctx
	 * @param apkPath
	 * @return
	 */
	public boolean fillApkModel(AppItem info) {
		String filepath = info.getFilePath();
		File file = new File(filepath);
		if (file == null || !file.exists()) {
			return false;
		}
		info.setCodePath(filepath);
		info.setCodeSize(file.length());
		String PATH_PackageParser = "android.content.pm.PackageParser";
		String PATH_AssetManager = "android.content.res.AssetManager";
		try {
			// 反射得到pkgParserCls对象并实例化,有参数
			Class<?> pkgParserCls = Class.forName(PATH_PackageParser);
			Class<?>[] typeArgs = null;
			Object[] valueArgs = null;
			Object pkgParser = null;
			try {
				typeArgs = new Class<?>[] { String.class };
				Constructor<?> pkgParserCt = pkgParserCls.getConstructor(typeArgs);
				valueArgs = new Object[] { filepath };
				pkgParser = pkgParserCt.newInstance(valueArgs);
			} catch (Exception e1) {
				Constructor<?> pkgParserCt = pkgParserCls.getConstructor();
				pkgParser = pkgParserCt.newInstance();
			}
			if (pkgParser == null) {
				return false;
			}

			// 从pkgParserCls类得到parsePackage方法
			Object pkgParserPkg = null;
			try {
				DisplayMetrics metrics = new DisplayMetrics();
				metrics.setToDefaults();// 这个是与显示有关的, 这边使用默认
				typeArgs = new Class<?>[] { File.class, String.class, DisplayMetrics.class, int.class };
				Method pkgParser_parsePackageMtd = pkgParserCls.getDeclaredMethod("parsePackage", typeArgs);
				valueArgs = new Object[] { new File(filepath), filepath, metrics, 0 };
				// 执行pkgParser_parsePackageMtd方法并返回
				pkgParserPkg = pkgParser_parsePackageMtd.invoke(pkgParser, valueArgs);
			} catch (Exception e1) {
				typeArgs = new Class<?>[] { File.class, int.class };
				Method pkgParser_parsePackageMtd = pkgParserCls.getDeclaredMethod("parsePackage", typeArgs);
				valueArgs = new Object[] { new File(filepath), 0 };
				// 执行pkgParser_parsePackageMtd方法并返回
				pkgParserPkg = pkgParser_parsePackageMtd.invoke(pkgParser, valueArgs);
			}

			// 从返回的对象得到名为"applicationInfo"的字段对象
			if (pkgParserPkg == null) {
				return false;
			}
			Field appInfoFld = pkgParserPkg.getClass().getDeclaredField("applicationInfo");

			// 从对象"pkgParserPkg"得到字段"appInfoFld"的值
			if (appInfoFld.get(pkgParserPkg) == null) {
				return false;
			}
			ApplicationInfo applicationInfo = (ApplicationInfo) appInfoFld.get(pkgParserPkg);

			// 反射得到assetMagCls对象并实例化,无参
			Class<?> assetMagCls = Class.forName(PATH_AssetManager);
			Object assetMag = assetMagCls.newInstance();
			// 从assetMagCls类得到addAssetPath方法
			typeArgs = new Class[1];
			typeArgs[0] = String.class;
			Method assetMag_addAssetPathMtd = assetMagCls.getDeclaredMethod("addAssetPath", typeArgs);
			valueArgs = new Object[1];
			valueArgs[0] = filepath;
			// 执行assetMag_addAssetPathMtd方法
			assetMag_addAssetPathMtd.invoke(assetMag, valueArgs);

			// 得到Resources对象并实例化,有参数
			Resources res = getResources();
			typeArgs = new Class[3];
			typeArgs[0] = assetMag.getClass();
			typeArgs[1] = res.getDisplayMetrics().getClass();
			typeArgs[2] = res.getConfiguration().getClass();
			Constructor<Resources> resCt = Resources.class.getConstructor(typeArgs);
			valueArgs = new Object[3];
			valueArgs[0] = assetMag;
			valueArgs[1] = res.getDisplayMetrics();
			valueArgs[2] = res.getConfiguration();
			res = (Resources) resCt.newInstance(valueArgs);

			// 读取apk文件的信息
			if (applicationInfo != null) {
				if (applicationInfo.icon != 0) {// 图片存在，则读取相关信息
					Drawable icon = res.getDrawable(applicationInfo.icon);// 图标
					info.setAppIcon(icon);
				}
				if (applicationInfo.labelRes != 0) {
					String neme = (String) res.getText(applicationInfo.labelRes);// 名字
					info.setAppName(neme);
				} else {
					String apkName = file.getName();
					info.setAppName(apkName.substring(0, apkName.lastIndexOf(".")));
				}
				String pkgName = applicationInfo.packageName;// 包名
				info.setAppPackage(pkgName);
			} else {
				return false;
			}
			PackageManager pm = getPackageManager();
			PackageInfo packageInfo = pm.getPackageArchiveInfo(filepath, PackageManager.GET_ACTIVITIES);
			if (packageInfo != null) {
				info.setAppVersion(packageInfo.versionName);// 版本号
				info.setAppVersionCode(packageInfo.versionCode);// 版本码
			}
			PackageManager packageManager = getPackageManager();
			PackageInfo mPackageInfo = null;
			try {
				mPackageInfo = packageManager.getPackageInfo(info.getAppPackage(), 0);
			} catch (NameNotFoundException e) {
			}
			if (mPackageInfo != null) {
				if (info.getAppVersionCode() > mPackageInfo.versionCode) {
					info.setAppVersion(getString(R.string.app_install_version_hight_tip));
				} else {
					return false;
				}
			} else {
				info.setAppVersion(getString(R.string.app_not_install_tip));
			}
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	protected void onResume() {
		super.onResume();
		MobclickAgent.onResume(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		MobclickAgent.onPause(this);
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		stop = true;
	}
}
