package cn.com.opda.android.clearmaster;

import java.util.ArrayList;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Toast;
import cn.com.opda.android.clearmaster.custom.CustomDialog2;
import cn.com.opda.android.clearmaster.utils.FileUtils;
import cn.com.opda.android.clearmaster.utils.FormatUtils;

import com.umeng.analytics.MobclickAgent;

/**
 * 残留文件清理弹出提示类
 * @author 庄宏岩
 *
 */
public class ClearRemainFileActivity extends Activity {
	private ArrayList<String> files;
	private long size;
	private String name;
	private CustomDialog2 customDialog;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		files = getIntent().getStringArrayListExtra("files");
		size = getIntent().getLongExtra("size", 0);
		name = getIntent().getStringExtra("name");
		if(Build.VERSION.SDK_INT>=11){
			setFinishOnTouchOutside(false);
		}
		showClearDialog();
	}

	private void showClearDialog() {
		customDialog = new CustomDialog2(this);
		customDialog.setDialogIcon(R.drawable.dialog_icon_tips);
		customDialog.setCancelable(false);
		String fileSize = FormatUtils.formatBytesInByte(size);
		String str = getString(R.string.depth_file_clear_tips, name,fileSize);
		SpannableStringBuilder style = new SpannableStringBuilder(str);
		style.setSpan(new ForegroundColorSpan(Color.BLUE), str.indexOf(name), str.indexOf(name)+ name.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
		style.setSpan(new ForegroundColorSpan(Color.BLUE), str.indexOf(fileSize), str.indexOf(fileSize)+ fileSize.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
		
		customDialog.setMessage(style);
		customDialog.setButton1(R.string.dialog_button_cancel, new OnClickListener() {

			@Override
			public void onClick(View v) {
				customDialog.dismiss();
				finish();
			}
		});
		customDialog.setButton2(R.string.quick_clear_button, new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (files != null) {
					FileUtils.deleteFileByList(files);
				}
				Toast.makeText(ClearRemainFileActivity.this, getString(R.string.clear_end_tips, FormatUtils.formatBytesInByte(size)), Toast.LENGTH_SHORT).show();
				customDialog.dismiss();
				finish();
			}
		});
		customDialog.setOnCancelListener(new OnCancelListener() {
			@Override
			public void onCancel(DialogInterface dialog) {
				finish();
			}
		});
		customDialog.show();
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		switch (keyCode) {
		case KeyEvent.KEYCODE_BACK:
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		MobclickAgent.onResume(this);
	}



	@Override
	protected void onPause() {
		super.onPause();
		MobclickAgent.onPause(this);
	}
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		if (customDialog != null) {
			try {
				customDialog.dismiss();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}
