package cn.com.opda.android.clearmaster;

import java.util.ArrayList;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import cn.com.opda.android.clearmaster.model.AppItem;
import cn.com.opda.android.clearmaster.utils.BannerUtils;
import cn.com.opda.android.clearmaster.utils.PinYinUtils;

import com.umeng.analytics.MobclickAgent;

public class SoftwareManager extends BaseActivity implements OnClickListener {
	private int currIndex = 0;// 当前页卡编号
	private TextView viewpager_tab1, viewpager_tab2, viewpager_tab3;
	private Context mContext;
	private SoftwareUninstallActivity softwareUninstallActivity;
	private SoftwareInstallActivity softwareInstallActivity;
	private SoftwareMoveActivity softwareMoveActivity;

	private LinearLayout ll_search_view;
	private EditText et_search;
	private ImageView iv_search_close, iv_search;
	private boolean showSeachIc = true;
	private ImageView banner_back_imageview;
	private LinearLayout view_container;

	private Handler mManagerHandler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case 1:
				iv_search.setVisibility(View.GONE);
				ll_search_view.setVisibility(View.GONE);
				break;

			case 2:
				iv_search.setVisibility(View.VISIBLE);
				ll_search_view.setVisibility(View.GONE);
				break;
			default:
				break;
			}
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mContext = SoftwareManager.this;
		setContentView(R.layout.activity_software_manager);
		BannerUtils.setTitle(this, "软件管理");
		BannerUtils.initBackButton(this);
		initViewAndEvent();
		initTextView();
		initViewContainer();
	}

	private void initViewAndEvent() {
		ll_search_view = (LinearLayout) findViewById(R.id.ll_search_view);
		et_search = (EditText) findViewById(R.id.et_search);
		iv_search_close = (ImageView) findViewById(R.id.iv_search_close);
		iv_search_close.setOnClickListener(this);
		iv_search = (ImageView) findViewById(R.id.banner_about_imageview);

		iv_search.setVisibility(View.VISIBLE);
		iv_search.setImageResource(R.drawable.search_icon);
		iv_search.setOnClickListener(this);
		et_search.addTextChangedListener(mTextWatchernew);

		banner_back_imageview = (ImageView) findViewById(R.id.banner_back_imageview);
		banner_back_imageview.setOnClickListener(this);

		view_container = (LinearLayout) findViewById(R.id.view_container);
	}

	/**
	 * 初始化头标
	 */
	private void initTextView() {
		viewpager_tab1 = (TextView) findViewById(R.id.viewpager_tab1);
		viewpager_tab2 = (TextView) findViewById(R.id.viewpager_tab2);
		viewpager_tab3 = (TextView) findViewById(R.id.viewpager_tab3);

		viewpager_tab1.setOnClickListener(this);
		viewpager_tab2.setOnClickListener(this);
		viewpager_tab3.setOnClickListener(this);
	}

	/**
	 * 初始化ViewPager
	 */
	private void initViewContainer() {
		softwareUninstallActivity = new SoftwareUninstallActivity(mContext, R.layout.activity_software_uninstall, mManagerHandler);
		softwareUninstallActivity.initData();
		softwareInstallActivity = new SoftwareInstallActivity(mContext, R.layout.activity_software_install);
		softwareMoveActivity = new SoftwareMoveActivity(mContext, R.layout.activity_software_move);

		viewpager_tab1.setTextColor(getResources().getColor(R.color.white));
		viewpager_tab2.setTextColor(getResources().getColor(R.color.tab_blue_color));
		viewpager_tab3.setTextColor(getResources().getColor(R.color.tab_blue_color));

		LayoutParams layoutParams = (LayoutParams) view_container.getLayoutParams();
		layoutParams.height = LayoutParams.FILL_PARENT;
		layoutParams.width = LayoutParams.FILL_PARENT;
		view_container.addView(softwareUninstallActivity.getView(),layoutParams);

	}

	private TextWatcher mTextWatchernew = new TextWatcher() {

		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
			// 当输入框里面的值为空，更新为原来的列表，否则为过滤数据列表
			filterData();

		}

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
		}

		@Override
		public void afterTextChanged(Editable s) {
		}
	};

	/**
	 * 根据输入框中的值来过滤数据并更新ListView
	 * 
	 * @param filterStr
	 */
	private void filterData() {
		String filterStr = null;
		if (et_search != null) {
			filterStr = et_search.getText().toString();
		}
		ArrayList<AppItem> filterDateList = new ArrayList<AppItem>();

		if (TextUtils.isEmpty(filterStr)) {
			updateListviewData();
			softwareUninstallActivity.getNoResultView().setVisibility(View.GONE);
		} else {
			filterDateList.clear();
			if (softwareUninstallActivity.getPageType().equals(getResources().getString(R.string.uninstall_user_app))) {
				for (AppItem sortModel : softwareUninstallActivity.getUserApps()) {
					String name = sortModel.getAppName();
					String charName = PinYinUtils.CnToSpell(name).toUpperCase();
					if (name.indexOf(filterStr) != -1 || charName.indexOf(filterStr.toUpperCase()) != -1) {
						filterDateList.add(sortModel);
					}
				}
				softwareUninstallActivity.updateUserAdapter(filterDateList);
				softwareUninstallActivity.notifyUserAdapter();
			} else {

				for (AppItem sortModel : softwareUninstallActivity.getSystemApps()) {
					String name = sortModel.getAppName();
					String charName = PinYinUtils.CnToSpell(name).toUpperCase();
					if (name.indexOf(filterStr) != -1 || charName.indexOf(filterStr.toUpperCase()) != -1) {
						filterDateList.add(sortModel);
					}
				}
				softwareUninstallActivity.updateSystemAdapter(filterDateList);
				softwareUninstallActivity.notifySystemAdapter();

			}
			if (filterDateList.size() <= 0) {
				showNodateText();
			} else {
				softwareUninstallActivity.getNoResultView().setVisibility(View.GONE);
			}
		}
	}

	private void showNodateText() {
		((TextView) softwareUninstallActivity.getNoResultView()).setText(R.string.no_search_app_date);
		softwareUninstallActivity.getNoResultView().setVisibility(View.VISIBLE);
	}

	private void updateListviewData() {
		if (softwareUninstallActivity.getPageType().equals(getResources().getString(R.string.uninstall_user_app))) {
			softwareUninstallActivity.updateUserAdapter();
		} else {
			softwareUninstallActivity.updateSystemAdapter();
		}
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.viewpager_tab1:
			if (currIndex != 0) {
				currIndex = 0;
				viewpager_tab1.setTextColor(getResources().getColor(R.color.white));
				viewpager_tab2.setTextColor(getResources().getColor(R.color.tab_blue_color));
				viewpager_tab3.setTextColor(getResources().getColor(R.color.tab_blue_color));
				softwareUninstallActivity.initData();
				if (softwareUninstallActivity.getPageType().equals(getResources().getString(R.string.uninstall_user_app))
						|| softwareUninstallActivity.getPageType().equals(getResources().getString(R.string.uninstall_system_app))) {
					iv_search.setVisibility(View.VISIBLE);
					ll_search_view.setVisibility(View.GONE);
				} else {
					iv_search.setVisibility(View.GONE);
					ll_search_view.setVisibility(View.GONE);
				}
				view_container.removeAllViews();
				LayoutParams layoutParams = (LayoutParams) view_container.getLayoutParams();
				layoutParams.height = LayoutParams.FILL_PARENT;
				layoutParams.width = LayoutParams.FILL_PARENT;
				view_container.addView(softwareUninstallActivity.getView(),layoutParams);
			}
			break;
		case R.id.viewpager_tab2:
			if (currIndex != 1) {
				currIndex = 1;
				viewpager_tab1.setTextColor(getResources().getColor(R.color.tab_blue_color));
				viewpager_tab3.setTextColor(getResources().getColor(R.color.tab_blue_color));
				viewpager_tab2.setTextColor(getResources().getColor(R.color.white));
				softwareInstallActivity.initData();
				et_search.setText("");
				iv_search.setVisibility(View.GONE);
				ll_search_view.setVisibility(View.GONE);
				view_container.removeAllViews();
				LayoutParams layoutParams = (LayoutParams) view_container.getLayoutParams();
				layoutParams.height = LayoutParams.FILL_PARENT;
				layoutParams.width = LayoutParams.FILL_PARENT;
				view_container.addView(softwareInstallActivity.getView(),layoutParams);
			}
			break;
		case R.id.viewpager_tab3:
			if (currIndex != 2) {
				currIndex = 2;
				viewpager_tab1.setTextColor(getResources().getColor(R.color.tab_blue_color));
				viewpager_tab2.setTextColor(getResources().getColor(R.color.tab_blue_color));
				viewpager_tab3.setTextColor(getResources().getColor(R.color.white));
				softwareMoveActivity.initData();
				et_search.setText("");
				iv_search.setVisibility(View.GONE);
				ll_search_view.setVisibility(View.GONE);
				view_container.removeAllViews();
				LayoutParams layoutParams = (LayoutParams) view_container.getLayoutParams();
				layoutParams.height = LayoutParams.FILL_PARENT;
				layoutParams.width = LayoutParams.FILL_PARENT;
				view_container.addView(softwareMoveActivity.getView(),layoutParams);
			}
			break;

		case R.id.iv_search_close:
			et_search.setText("");
			break;
		case R.id.banner_about_imageview:// 本界面的搜索按钮
			ll_search_view.setVisibility(View.VISIBLE);
			iv_search.setVisibility(View.GONE);
			showSeachIc = false;
			break;
		case R.id.banner_back_imageview:
			if (showSeachIc) {
				finish();
				overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
			} else {
				ll_search_view.setVisibility(View.GONE);
				iv_search.setVisibility(View.VISIBLE);
				et_search.setText("");
				showSeachIc = true;
				// 用于隐藏输入法键盘
				((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(this.getCurrentFocus().getWindowToken(),
						InputMethodManager.HIDE_NOT_ALWAYS);
			}
			break;
		default:
			break;
		}
	}

	@Override
	protected void onResume() {
		super.onResume();
		MobclickAgent.onResume(this);
		softwareInstallActivity.onResume();
		softwareUninstallActivity.onResume();
	}

	@Override
	protected void onPause() {
		super.onPause();
		MobclickAgent.onPause(this);
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		softwareInstallActivity.onDestroy();
		softwareUninstallActivity.onDestroy();
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			if (showSeachIc == true) {
				finish();
				overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
				return true;
			} else {
				ll_search_view.setVisibility(View.GONE);
				iv_search.setVisibility(View.VISIBLE);
				et_search.setText("");
				showSeachIc = true;
				return true;
			}
		}
		return super.onKeyDown(keyCode, event);
	}

}
