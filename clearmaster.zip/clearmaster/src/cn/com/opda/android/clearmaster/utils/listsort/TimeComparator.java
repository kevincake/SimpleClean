package cn.com.opda.android.clearmaster.utils.listsort;

import java.util.Comparator;

import cn.com.opda.android.clearmaster.model.AppItem;

public class TimeComparator implements Comparator<AppItem>{

	@Override
	public int compare(AppItem o1, AppItem o2) {
		long num1 = o1.getInstallTime();
		long num2 = o2.getInstallTime();
		if (num1 < num2) {
			return 1;
		} else if (num1 == num2) {
			return 0;
		} else if (num1 > num2) {
			return -1;
		}
		return 0;
	
	}

}
