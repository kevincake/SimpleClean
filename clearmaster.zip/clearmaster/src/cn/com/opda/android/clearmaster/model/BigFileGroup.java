package cn.com.opda.android.clearmaster.model;

import java.util.ArrayList;

import android.graphics.drawable.Drawable;

public class BigFileGroup {
	public static final int type_audio = 0;
	public static final int type_video = 1;
	public static final int type_doc = 2;
	public static final int type_other = 3;
	
	private String typeName;
	private int type;
	private Drawable typeIcon;
	private long size;
	private ArrayList<BigFileItem> bigFileItems;
	private boolean checked;
	public String getTypeName() {
		return typeName;
	}
	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public Drawable getTypeIcon() {
		return typeIcon;
	}
	public void setTypeIcon(Drawable typeIcon) {
		this.typeIcon = typeIcon;
	}
	public long getSize() {
		return size;
	}
	public void setSize(long size) {
		this.size = size;
	}
	public ArrayList<BigFileItem> getBigFileItems() {
		return bigFileItems;
	}
	public void setBigFileItems(ArrayList<BigFileItem> bigFileItems) {
		this.bigFileItems = bigFileItems;
	}
	public boolean isChecked() {
		return checked;
	}
	public void setChecked(boolean checked) {
		this.checked = checked;
	} 
	
	
}
