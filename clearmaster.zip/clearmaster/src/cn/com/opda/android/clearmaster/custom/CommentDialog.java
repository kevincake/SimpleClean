package cn.com.opda.android.clearmaster.custom;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import cn.com.opda.android.clearmaster.R;
import cn.com.opda.android.clearmaster.utils.CustomEventCommit;

/**
 * 自定义好评界面
 * @author 庄宏岩
 *
 */
public class CommentDialog implements OnClickListener {

	private Dialog dialog;
	private View view;
	private Context mContext;
	
	

	public CommentDialog(Context context) {
		dialog = new Dialog(context, R.style.custom_dialog);
		view = View.inflate(context, R.layout.comment_dialog, null);
		mContext = context;
	}

	public void setCancelable(boolean flag) {
		dialog.setCancelable(flag);
	}

	public void setOnCancelListener(OnCancelListener listener) {
		dialog.setOnCancelListener(listener);
	}
	
	

	public View getView() {
		return view;
	}

	public void show() {
		CustomEventCommit.commit(mContext, CustomEventCommit.dialog_comment_alert_count);
		Button button_cancel = (Button) view.findViewById(R.id.button_cancel);
		Button button_ok = (Button) view.findViewById(R.id.button_ok);
		
		button_ok.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				CustomEventCommit.commit(mContext, CustomEventCommit.dialog_comment_count);
				try {
					Uri uri = Uri.parse("market://search?q=pname:" + mContext.getPackageName());
					Intent it = new Intent("android.intent.action.VIEW", uri);
					mContext.startActivity(it);
				} catch (Exception e) {
					e.printStackTrace();
				}
				dialog.dismiss();
			}
		});
		
		button_cancel.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				dialog.dismiss();
			}
		});
		
		
		dialog.setContentView(view);
		dialog.show();
	}

	public void dismiss() {
		dialog.dismiss();
	}

	@Override
	public void onClick(View v) {
		dismiss();
	}

	public Window getWindow() {
		return dialog.getWindow();
	}

}
