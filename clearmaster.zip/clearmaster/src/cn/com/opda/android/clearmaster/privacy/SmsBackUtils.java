package cn.com.opda.android.clearmaster.privacy;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import cn.com.opda.android.clearmaster.utils.Constants;
import cn.com.opda.android.clearmaster.utils.DLog;

public class SmsBackUtils {

	private Context mcontext;
	private String strUriInbox = "content://sms";
	private Uri uriSms;

	public SmsBackUtils(Context context) {
		this.mcontext = context;
		uriSms = Uri.parse(strUriInbox);
	}

	/**
	 * 获取所有的短信内容
	 * 
	 * @return
	 */
	public List<SmsBackUpInfo> getSmsInformation() {
		List<SmsBackUpInfo> templist = new ArrayList<SmsBackUpInfo>();
		Cursor c = mcontext.getContentResolver().query(uriSms, null, null, null, Constants.SMS_date + " ASC");
		if (c != null) {
			while (c.moveToNext()) {
				SmsBackUpInfo info = new SmsBackUpInfo();
				info.setAddress(c.getString(c.getColumnIndex("address")));
				info.setDate(c.getString(c.getColumnIndex(Constants.SMS_date)));
				info.setBody(c.getString(c.getColumnIndex(Constants.SMS_body)));
				info.setType(c.getInt(c.getColumnIndex(Constants.SMS_type)));
				info.setThread_id(c.getInt(c.getColumnIndex(Constants.SMS_thread_id)));
				info.setId(c.getInt(c.getColumnIndex(Constants.SMS_ID)));
				info.setRead(c.getInt(c.getColumnIndex(Constants.SMS_read)));
				info.setStatus(c.getInt(c.getColumnIndex(Constants.SMS_status)));
				templist.add(info);
			}
		}
		return templist;
	}

	/**
	 * 还原短信
	 * 
	 * @param infolist
	 */
	public void recoverSmsInformation(SmsBackUpInfo info) {
		if (info != null) {
			insertValue(info);
		}

	}

	/**
	 * 插入短信数据库
	 * 
	 * @param info
	 */

	public void insertValue(SmsBackUpInfo info) {
		DLog.i("SmsBackUtils", "insertValue");
		ContentValues values = new ContentValues();
		values.put("address", info.getAddress());
		values.put("body", info.getBody());
		values.put("date", info.getDate());
		values.put("type", info.getType());
		values.put("read", 1);
		mcontext.getContentResolver().insert(uriSms, values);
	}

}
