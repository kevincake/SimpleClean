package cn.com.opda.android.clearmaster.dao;

import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import cn.com.opda.android.clearmaster.model.AppItem;
import cn.com.opda.android.clearmaster.utils.BaseJsonUtil;
import cn.com.opda.android.clearmaster.utils.DLog;

/**
 * 应用启动日期数据库
 * 
 * @author 庄宏岩
 * 
 */
public class AppStartUpDBUtils extends BaseJsonUtil {
	private static final String TAG = "debug";

	public AppStartUpDBUtils(Context context) {
		super(context);
	}

	/**
	 * @param info
	 * @param context
	 *            把信息保存到数据库
	 */
	public static void save(Context context, String packageName, long lastStartTime) {
		AppUsageStatisticsDBOpenHelper tdbOpenHelper = new AppUsageStatisticsDBOpenHelper(context);
		SQLiteDatabase db = tdbOpenHelper.getWritableDatabase();
		Cursor cursor = db.rawQuery("select * from startup where packagename = ?", new String[] { packageName });
		try {
			if (cursor == null || cursor.getCount() == 0) {
				db.execSQL("insert into startup (packagename,count,lasttime) values(?,?,?)", new Object[] { packageName, 1, lastStartTime });
				DLog.i(TAG, "save()");
			} else {
				cursor.moveToFirst();
				int count = cursor.getInt(1);
				db.execSQL("update startup set count=?,lasttime=? where packagename=?", new Object[] { count + 1, lastStartTime, packageName });
				DLog.i(TAG, "update()");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (cursor != null) {
				cursor.close();
			}
			db.close();
			tdbOpenHelper.close();
		}

	}

	/**
	 * @param info
	 * @param context
	 *            从数据库中删除某条数据
	 */
	public static void delete(Context context, String packageName) {
		AppUsageStatisticsDBOpenHelper tdbOpenHelper = new AppUsageStatisticsDBOpenHelper(context);
		SQLiteDatabase db = tdbOpenHelper.getWritableDatabase();
		db.execSQL("delete from startup where packagename=?", new Object[] { packageName });
		DLog.i(TAG, "delete()");
		db.close();
		tdbOpenHelper.close();
	}

	/**
	 * @param context
	 * @return 从数据库中获取所有数据并返回一个集合
	 */
	public static void getLastStartTime(Context context, AppItem appItem) {
		AppUsageStatisticsDBOpenHelper tdbOpenHelper = new AppUsageStatisticsDBOpenHelper(context);
		SQLiteDatabase db = tdbOpenHelper.getWritableDatabase();
		Cursor cursor = db.rawQuery("select * from startup where packagename=?", new String[] { appItem.getAppPackage() });
		try {
			if (cursor != null && cursor.getCount() > 0) {
				cursor.moveToFirst();
				appItem.setStartCount(cursor.getInt(1));
				appItem.setLastStartTime(cursor.getLong(2));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if (cursor != null) {
				cursor.close();
			}
			db.close();
			tdbOpenHelper.close();
		}
	}

}
