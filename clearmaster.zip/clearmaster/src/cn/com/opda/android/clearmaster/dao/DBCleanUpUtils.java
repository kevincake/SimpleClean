//package cn.com.opda.android.clearmaster.dao;
//
//import java.util.ArrayList;
//
//import android.content.Context;
//import android.database.Cursor;
//import android.database.SQLException;
//import android.database.sqlite.SQLiteDatabase;
//import android.util.Log;
//import cn.com.opda.android.clearmaster.model.ClearItem;
//import cn.com.opda.android.clearmaster.utils.BaseJsonUtil;
//
///**
// * 深度清理数据库操作类
// * @author 庄宏岩
// *
// */
//public class DBCleanUpUtils extends BaseJsonUtil {
//	private static final String TAG = "db";
//
//	public DBCleanUpUtils(Context context) {
//		super(context);
//	}
//
//	/**
//	 * @param info
//	 * @param context
//	 *            把信息保存到数据库
//	 */
//	public static void save(Context context, ClearItem info) {
//		DBCleanUpOpenHelper tdbOpenHelper = new DBCleanUpOpenHelper(context);
//		SQLiteDatabase db = tdbOpenHelper.getWritableDatabase();
//		Cursor cursor = db.rawQuery("select * from softdetail where filepath = ?", new String[] { info.getFilePath() });
//		try {
//			if (cursor == null || cursor.getCount() == 0) {
//				db.execSQL("insert into softdetail (softChinesename,softEnglishname,apkname,filepath) values(?,?,?,?)",
//						new Object[] { info.getCname(), info.getEname(), info.getPackageName(), info.getFilePath() });
//				Log.i(TAG, "save()");
//			} else {
//				Log.i(TAG, "data is exists");
//			}
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}finally{
//			if (cursor != null) {
//				cursor.close();
//			}
//			db.close();
//			tdbOpenHelper.close();
//		}
//	}
//
//	/**
//	 * @param info
//	 * @param context
//	 *            从数据库中删除某条数据
//	 */
//	public static void delete(Context context, int id) {
//		DBCleanUpOpenHelper tdbOpenHelper = new DBCleanUpOpenHelper(context);
//		SQLiteDatabase db = tdbOpenHelper.getWritableDatabase();
//		db.execSQL("delete from softdetail where _id=?", new Object[] { id });
//
//		Log.i(TAG, "delete()");
//
//		db.close();
//		tdbOpenHelper.close();
//	}
//
//	/**
//	 * @param info
//	 * @param context
//	 *            更新数据库中的某条数据
//	 */
//	public static void update(Context context, ClearItem info, int id) {
//
//		String sql = "update softdetail set softChinesename=?,softEnglishname=?,apkname=?,filepath=? where _id=?";
//
//		DBCleanUpOpenHelper tdbOpenHelper = new DBCleanUpOpenHelper(context);
//		SQLiteDatabase db = tdbOpenHelper.getWritableDatabase();
//
//		db.execSQL(sql, new Object[] { info.getCname(), info.getEname(), info.getPackageName(), info.getFilePath(), id });
//		db.close();
//		tdbOpenHelper.close();
//	}
//
//	/**
//	 * @param context
//	 * @return 从数据库中获取所有数据并返回一个集合
//	 */
//	public static ArrayList<ClearItem> get(Context context) {
//		ArrayList<ClearItem> list = new ArrayList<ClearItem>();
//		DBCleanUpOpenHelper tdbOpenHelper = new DBCleanUpOpenHelper(context);
//		SQLiteDatabase db = tdbOpenHelper.getWritableDatabase();
//		Cursor cursor = db.rawQuery("select * from softdetail ", null);
//		try {
//			if (cursor != null) {
//				while (cursor.moveToNext()) {
//					ClearItem info = new ClearItem();
//					info.setCname(cursor.getString(1));
//					info.setEname(cursor.getString(2));
//					info.setPackageName(cursor.getString(3));
//					info.setFilePath(cursor.getString(4));
//					list.add(info);
//				}
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		}finally{
//			if (cursor != null) {
//				cursor.close();
//			}
//			db.close();
//			tdbOpenHelper.close();
//		}
//
//		return list;
//	}
//
//	/**
//	 * 
//	 * @param aPackageName
//	 * @param context
//	 * @return 返回查询数据的列表
//	 */
//	public static ArrayList<ClearItem> GetDataByPackageName(final String aPackageName, Context context) {
//		DBCleanUpOpenHelper tdbOpenHelper = new DBCleanUpOpenHelper(context);
//		SQLiteDatabase db = tdbOpenHelper.getWritableDatabase();
//		Cursor cursor = db.rawQuery("select * from softdetail where apkname like '%" + aPackageName +"%'", new String[] {});
//		ArrayList<ClearItem> list = new ArrayList<ClearItem>();
//		try {
//			if (cursor != null) {
//				while (cursor.moveToNext()) {
//					ClearItem clearItem = new ClearItem();
//					clearItem.setCname(cursor.getString(1));
//					clearItem.setEname(cursor.getString(2));
//					clearItem.setPackageName(cursor.getString(3));
//					clearItem.setFilePath(cursor.getString(4));
//					list.add(clearItem);
//				}
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		}finally{
//			if (cursor != null) {
//				cursor.close();
//			}
//			db.close();
//			tdbOpenHelper.close();
//		}
//		return list;
//	}
//}
