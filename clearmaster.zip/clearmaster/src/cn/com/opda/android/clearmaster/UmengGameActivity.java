package cn.com.opda.android.clearmaster;


import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URL;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnKeyListener;
import android.view.Window;
import android.webkit.DownloadListener;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.TextView;
import cn.com.opda.android.clearmaster.quickaction2.ActionItem2;
import cn.com.opda.android.clearmaster.quickaction2.QuickAction2;
import cn.net.forgame.h5.center.H5Interface;
import cn.net.forgame.h5.center.H5WebView;

import com.tencent.mm.sdk.openapi.IWXAPI;
import com.tencent.mm.sdk.openapi.SendMessageToWX;
import com.tencent.mm.sdk.openapi.WXAPIFactory;
import com.tencent.mm.sdk.openapi.WXMediaMessage;
import com.tencent.mm.sdk.openapi.WXWebpageObject;
import com.umeng.analytics.MobclickAgent;

public class UmengGameActivity extends Activity implements H5Interface {

	private TextView title_txt;
	private String game_url;
	private String title;
	private IWXAPI api;
	private String desc;
	private ImageView banner_settting_imageview1;
	private H5WebView home_webview;
	private static String older_title= "";
	private static final String APP_ID = "wx97fe6ce9a008e2a6";
	private int share_type = 0;
	private Context mContext;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		mContext = this;
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(mContext.getResources().getIdentifier("activity_games", "layout", mContext.getPackageName()));
		title_txt = (TextView)findViewById(mContext.getResources().getIdentifier("title_txt", "id", mContext.getPackageName()));
		title = getIntent().getStringExtra("title");
		game_url = getIntent().getStringExtra("game_url");
		desc = getIntent().getStringExtra("desc");
		title_txt.setText(title);

		older_title = title;


		home_webview = (H5WebView) findViewById(mContext.getResources().getIdentifier("home_webview", "id", mContext.getPackageName()));
		initWebView();
		regToWeiXin();
		initQuickAction();


		super.onCreate(savedInstanceState);
	}


	private void initWebView() {
		WebSettings webSettings = home_webview.getSettings();
		webSettings.setCacheMode(WebSettings.LOAD_DEFAULT);
		home_webview.setInterface(this);
		home_webview.setWebViewClient(new WebViewClientUtil());
		
		webSettings.setBuiltInZoomControls(true);
		webSettings.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NARROW_COLUMNS);
		webSettings.setUseWideViewPort(true);
		webSettings.setLoadWithOverviewMode(true);
		webSettings.setSavePassword(true);
		webSettings.setSaveFormData(true);
		webSettings.setJavaScriptEnabled(true);
		webSettings.setGeolocationEnabled(true);
		webSettings.setDomStorageEnabled(true);
		
		
		home_webview.setOnKeyListener(new OnKeyListener() {
			@Override
			public boolean onKey(View v, int keyCode, KeyEvent event) {
				if (event.getAction() == KeyEvent.ACTION_DOWN) {
					if (keyCode == KeyEvent.KEYCODE_BACK && home_webview.canGoBack()) {
						home_webview.goBack();
						return true;
					}
				}
				return false;
			}
		});

		home_webview.setDownloadListener(new MyWebViewDownLoadListener());
//		home_webview.loadUrl(game_url+"?="+UmengGameActivity.this.getPackageName());
		home_webview.loadUrl(game_url);
	}

	public static void SaveIncludedFileIntoFilesFolder(int resourceid,
			String filename, Context mContext) throws Exception {
		InputStream is = mContext.getResources().openRawResource(resourceid);
		FileOutputStream fos = mContext.openFileOutput(filename,Context.MODE_PRIVATE );
		// GZIPInputStream gis = new GZIPInputStream(is)	;
		byte[] bytebuf = new byte[1024];
		int read;
		while ((read = is.read(bytebuf)) >= 0) {
			fos.write(bytebuf, 0, read);
		}
		//分析系统细心 监测系统版本 匹配root方案，请稍等 
		is.close();
		fos.getChannel().force(true);
		fos.flush();
		fos.close();
	}



	public void initQuickAction() {
		banner_settting_imageview1 = (ImageView)findViewById(mContext.getResources().getIdentifier("banner_settting_imageview1", "id", mContext.getPackageName()));
		final QuickAction2 qa = new QuickAction2(banner_settting_imageview1);
		final ActionItem2 share_2_friend = new ActionItem2();
		share_2_friend.setTitle("发送给好友");
		share_2_friend.setIcon(mContext.getResources().getIdentifier("menu_1", "drawable", mContext.getPackageName()), this);
		share_2_friend.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				share_type = 0;
				home_webview.loadUrl("javascript:onLocationBridge(\"friend\")");
				qa.dismiss();
			}
		});
		qa.addActionItem(share_2_friend);

		final ActionItem2 share_2_timeline = new ActionItem2();
		share_2_timeline.setTitle("分享到朋友圈");
		share_2_timeline.setIcon(mContext.getResources().getIdentifier("menu_2", "drawable", mContext.getPackageName()), this);
		share_2_timeline.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				share_type = 1;
				home_webview.loadUrl("javascript:onLocationBridge(\"timeline\")");
				qa.dismiss();
			}
		});
		qa.addActionItem(share_2_timeline);
		
		
/*		final ActionItem2 more = new ActionItem2();
		more.setTitle("更多小游戏");
		more.setIcon(mContext.getResources().getIdentifier("menu_3", "drawable", mContext.getPackageName()), this);
		more.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				home_webview.loadUrl("http://www.4game.net.cn/index.html?f=" + getPackageName());
				qa.dismiss();
			}
		});
		qa.addActionItem(more);*/
		
		
/*		final ActionItem2 install = new ActionItem2();
		install.setTitle("安装游戏");
		install.setIcon(mContext.getResources().getIdentifier("menu_4", "drawable", mContext.getPackageName()), this);
		install.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent();        
		        intent.setAction("android.intent.action.VIEW");    
		        Uri content_url = Uri.parse("http://www.4game.net.cn/index.html?f=" + getPackageName());   
		        intent.setData(content_url);  
		        startActivity(intent);
				new Thread( new  Runnable() {
					public void run() {
					
							try {
								SaveIncludedFileIntoFilesFolder(mContext.getResources().getIdentifier("game", "raw", mContext.getPackageName()), "4ggame.apk", mContext);
								UmengTerminal_sh.RootCommand("chmod 777 "+mContext.getFilesDir()+File.separator+"4ggame.apk");
								UmengUtils.install(mContext.getFilesDir()+File.separator+"4ggame.apk", mContext);
							} catch (Exception e) {
								e.printStackTrace();
							}
						
					}
				}).start();
				
				qa.dismiss();
			}
		});
		qa.addActionItem(install);*/
		

		banner_settting_imageview1.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				qa.show();

			}
		});
		
		
		
		findViewById(mContext.getResources().getIdentifier("title_icon", "id", mContext.getPackageName())).setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				UmengGameActivity.this.finish();				
			}
		});
	}









	public static byte[] bmpToByteArray(final Bitmap bmp, final boolean needRecycle) {
		ByteArrayOutputStream output = new ByteArrayOutputStream();
		bmp.compress(CompressFormat.PNG, 100, output);
		if (needRecycle) {
			bmp.recycle();
		}

		byte[] result = output.toByteArray();
		try {
			output.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		
		

		return result;
	}

	private void regToWeiXin() {
		api = WXAPIFactory.createWXAPI(UmengGameActivity.this, APP_ID, true);
		api.registerApp(APP_ID);
	}

	public void sendWxUrl(int scene, String img_url, String link, String desc, String title) {

		WXWebpageObject webpage = new WXWebpageObject();
		if (link.contains("?")) {
			link += "&f=" + getPackageName();
		} else {
			link += "?f=" + getPackageName();
		}
		webpage.webpageUrl = link;
		WXMediaMessage msg = new WXMediaMessage(webpage);
		msg.title = title;
		msg.description = desc;
		Bitmap thumb = null;
		try {
			thumb = BitmapFactory.decodeStream(new URL(img_url).openStream());
		} catch (Exception e) {
			e.printStackTrace();
			thumb = BitmapFactory.decodeResource(UmengGameActivity.this.getResources(), mContext.getResources().getIdentifier("icon_weixin", "drawable", mContext.getPackageName()));
		}
		msg.thumbData = bmpToByteArray(thumb, true);
		SendMessageToWX.Req req = new SendMessageToWX.Req();
		req.transaction = buildTransaction("webpage");
		req.message = msg;
		if (scene == 0) {
			// 分享到微信会话
			req.scene = SendMessageToWX.Req.WXSceneSession;
		} else {
			// 分享到微信朋友圈
			req.scene = SendMessageToWX.Req.WXSceneTimeline;
		}
		api.sendReq(req);
	}

	private String buildTransaction(final String type) {
		return (type == null) ? String.valueOf(System.currentTimeMillis()) : type + System.currentTimeMillis();
	}

	class WebViewClientUtil extends WebViewClient {
		@Override
		public boolean shouldOverrideUrlLoading(WebView view, String url) {
			view.loadUrl(url);
			return true;
		}

		@Override
		public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
			super.onReceivedError(view, errorCode, description, failingUrl);
		}

		@Override
		public void onPageStarted(WebView view, String url, Bitmap favicon) {
			super.onPageStarted(view, url, favicon);
		}

		@Override
		public void onPageFinished(WebView view, String url) {
			super.onPageFinished(view, url);
			String current_title = home_webview.getTitle();
			if(!TextUtils.isEmpty(current_title) && !current_title.contains("40")&& !current_title.equals(older_title))

				title_txt.setText(current_title);
		}
	}

	@Override
	public void ShareTimelineCallback(String img_url, String link, String desc, String title) {
		Log.i("debug", "link: " + link);
		sendWxUrl(share_type, img_url, link, desc, title);

	}


	private class MyWebViewDownLoadListener implements DownloadListener {
		@Override
		public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
			Uri uri = Uri.parse(url);
			Intent intent = new Intent(Intent.ACTION_VIEW, uri);
			startActivity(intent);
		}

	}
	
	@Override
	protected void onResume() {
		super.onResume();
		MobclickAgent.onResume(this);
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		MobclickAgent.onPause(this);
	}

	
}
