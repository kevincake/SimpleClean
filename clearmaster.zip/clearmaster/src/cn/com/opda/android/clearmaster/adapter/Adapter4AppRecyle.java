package cn.com.opda.android.clearmaster.adapter;

import java.util.List;

import android.content.Context;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import cn.com.opda.android.clearmaster.R;
import cn.com.opda.android.clearmaster.custom.IOSProgressDialog;
import cn.com.opda.android.clearmaster.model.AppItem;
import cn.com.opda.android.clearmaster.utils.AppManagerUtils;
import cn.com.opda.android.clearmaster.utils.CustomEventCommit;
import cn.com.opda.android.clearmaster.utils.RecommendUtils;
import cn.com.opda.android.clearmaster.utils.Terminal;

/**
 * @author 庄宏岩
 * 
 */
public class Adapter4AppRecyle extends BaseAdapter {
	private List<AppItem> mApkModelList;
	private Context mContext;
	private ListView app_install_listview;
	private TextView app_install_tips_textview;

	public Adapter4AppRecyle(Context context, List<AppItem> mApkModelList) {
		this.mApkModelList = mApkModelList;
		this.mContext = context;
	}

	@Override
	public int getCount() {
		return mApkModelList.size();
	}

	@Override
	public Object getItem(int position) {
		return mApkModelList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	public List<AppItem> getList() {
		return mApkModelList;
	}

	public void setApp_install_listview(ListView app_install_listview) {
		this.app_install_listview = app_install_listview;
	}

	public void setApp_install_tips_textview(TextView app_install_tips_textview) {
		this.app_install_tips_textview = app_install_tips_textview;
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		final Holder mHolder;
		if (convertView == null) {
			LayoutInflater inflater = LayoutInflater.from(mContext);
			convertView = inflater.inflate(R.layout.listview_app_recyle_item_layout, null);
			mHolder = new Holder();
			mHolder.app_install_item_appname_textview = (TextView) convertView.findViewById(R.id.app_install_item_appname_textview);
			mHolder.app_install_item_appversion_textview = (TextView) convertView.findViewById(R.id.app_install_item_appversion_textview);
			mHolder.app_install_item_icon_imageview = (ImageView) convertView.findViewById(R.id.app_install_item_icon_imageview);
			mHolder.app_install_item_install_button = (Button) convertView.findViewById(R.id.app_install_item_install_button);
			convertView.setTag(mHolder);
		} else {
			mHolder = (Holder) convertView.getTag();
		}
		final AppItem apkModel = mApkModelList.get(position);
		mHolder.app_install_item_appname_textview.setText(apkModel.getAppName());
		mHolder.app_install_item_appversion_textview.setText(apkModel.getAppVersion());
		mHolder.app_install_item_icon_imageview.setImageDrawable(apkModel.getAppIcon());
		mHolder.app_install_item_install_button.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				CustomEventCommit.commit(mContext, CustomEventCommit.recyle_app_install);
				if (Terminal.isRoot(mContext)) {
					new RestroreTask(apkModel).execute();
				} else {
					RecommendUtils.recommentRootMaster(mContext,"由于您的设备尚未获取ROOT权限，暂时无法还原系统应用。推荐使用ROOT成功率极高的一键ROOT大师快速获取权限");
				}
			}
		});
		return convertView;
	}

	private class RestroreTask extends AsyncTask<Void, Void, Integer> {
		private AppItem mApkModel;
		private IOSProgressDialog iosProgressDialog;

		public RestroreTask(AppItem mApkModel) {
			this.mApkModel = mApkModel;
			iosProgressDialog = new IOSProgressDialog(mContext, R.string.recyle_restore_app_loading);
		}

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			iosProgressDialog.show();
		}

		@Override
		protected Integer doInBackground(Void... arg0) {
			boolean b = AppManagerUtils.restoreApp(mApkModel);
			if (b) {
				return 1;
			}
			return 0;
		}

		@Override
		protected void onPostExecute(Integer result) {
			super.onPostExecute(result);
			iosProgressDialog.cancel();
			if (result == 1) {
				mApkModelList.remove(mApkModel);
				notifyDataSetChanged();
				Toast.makeText(mContext, R.string.recyle_restore_app_succeed, Toast.LENGTH_SHORT).show();

				if (mApkModelList.size() == 0) {
					if (app_install_listview != null && app_install_tips_textview != null) {
						app_install_listview.setVisibility(View.GONE);
						app_install_tips_textview.setText(R.string.recyle_not_scan_app);
						app_install_tips_textview.setVisibility(View.VISIBLE);
					}
				}
			} else {
				Toast.makeText(mContext, R.string.recyle_restore_app_failed, Toast.LENGTH_SHORT).show();
			}

		}

	}

	class Holder {
		private ImageView app_install_item_icon_imageview; // apk头像
		private Button app_install_item_install_button; // 安装按钮
		private TextView app_install_item_appname_textview; // apk名字
		private TextView app_install_item_appversion_textview; // 版本信息

	}
}
