package cn.com.opda.android.clearmaster.adapter;
import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import cn.com.opda.android.clearmaster.R;
import cn.com.opda.android.clearmaster.custom.CustomDialog2;
import cn.com.opda.android.clearmaster.custom.MarqueeTextView;
import cn.com.opda.android.clearmaster.model.VerboseAdInfo;
import cn.com.opda.android.clearmaster.utils.CustomEventCommit;
import cn.com.opda.android.clearmaster.utils.VerboseAppDownload;

public class Adapter4AdApp extends BaseAdapter {
	private ArrayList<VerboseAdInfo> mAppItems;
	private Context mContext;
	private CustomDialog2 customDialog;

	public Adapter4AdApp(Context context, ArrayList<VerboseAdInfo> mAppItems) {
		this.mAppItems = mAppItems;
		this.mContext = context;
	}

	@Override
	public int getCount() {
		return mAppItems.size();
	}

	@Override
	public Object getItem(int position) {
		return mAppItems.get(position);
	}

	public ArrayList<VerboseAdInfo> getList() {
		return mAppItems;
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		final Holder mHolder;
		if (convertView == null) {
			LayoutInflater inflater = LayoutInflater.from(mContext);
			convertView = inflater.inflate(
					R.layout.listview_verboseadapp_item_layout, parent,false);
			mHolder = new Holder();
			mHolder.app_icon_imageview = (ImageView) convertView
					.findViewById(R.id.app_item_icon_imageview);
			mHolder.app_item_appname_textview = (TextView) convertView
					.findViewById(R.id.app_item_appname_textview);
			mHolder.app_item_summary_textview = (MarqueeTextView) convertView
					.findViewById(R.id.app_item_summary_textview);
			mHolder.app_install_item_button = (Button) convertView
					.findViewById(R.id.app_install_item_button);
			convertView.setTag(mHolder);
		} else {
			mHolder = (Holder) convertView.getTag();
		}
		final VerboseAdInfo mAppItem = mAppItems.get(position);
		if(mAppItem.getIcon()!=null){
			mHolder.app_icon_imageview.setImageBitmap(mAppItem.getIcon());
		}else{
			mHolder.app_icon_imageview.setImageResource(android.R.drawable.sym_def_app_icon);
		}
		mHolder.app_item_appname_textview.setText(mAppItem.getAppName());
		mHolder.app_item_summary_textview.setText(mAppItem.getSummary());
		mHolder.app_install_item_button
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						CustomEventCommit.commit(mContext, CustomEventCommit.verbose_ad_install);
						if (customDialog != null) {
							customDialog.dismiss();
						}
						VerboseAppDownload appDownload = new VerboseAppDownload(
								mContext);
						appDownload.setAppName(mAppItem.getAppName());
						appDownload.setPackageName(mAppItem.getPackageName());
						appDownload.setDownloadurl(mAppItem.getApkUrl());
						appDownload.setAppIcon(mAppItem.getIcon());
						appDownload.createNotify();
						appDownload.startDownloadApp();
						Toast.makeText(mContext, R.string.ad_stardonwload_tips,
								Toast.LENGTH_SHORT).show();
					}
				});
		return convertView;
	}
	
	class Holder {

		
		private ImageView app_icon_imageview;
		private TextView app_item_appname_textview;
		private MarqueeTextView app_item_summary_textview;
		private Button app_install_item_button;
		
		
	}
}