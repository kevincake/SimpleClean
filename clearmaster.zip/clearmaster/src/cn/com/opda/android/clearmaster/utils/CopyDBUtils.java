package cn.com.opda.android.clearmaster.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import cn.com.opda.android.clearmaster.dao.news.DBAppCacheOpenHelper;
import cn.com.opda.android.clearmaster.dao.news.DBAppFolderOpenHelper;

/**
 * 拷贝数据库
 * @author 庄宏岩
 *
 */
public class CopyDBUtils {
	private Context context;
	private String DBNAME1 = "app_folder.db";
	private String DBNAME2 = "app_cache.db";
	private String DBNAME3 = "app_ad.db";

	public CopyDBUtils(Context context) {
		this.context = context;
	}

	public void copyDB() {
		File file = context.getDatabasePath(DBNAME1);
		File fileDir = file.getParentFile();
		SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
		int dbVersion = sp.getInt("app_folder_version", 0);
		if (!file.exists()) {
			try {
				fileDir.mkdirs();
				CopyFile(file,DBNAME1);
				sp.edit().putInt("app_folder_version", DBAppFolderOpenHelper.mversion).commit();
			} catch (IOException e) {

			}
		} else {
			try {
				if (dbVersion < DBAppFolderOpenHelper.mversion) {
					CopyFile(file,DBNAME1);
					sp.edit().putInt("app_folder_version", DBAppFolderOpenHelper.mversion).commit();
				}
			} catch (Exception e) {
				
			}

		}
		copyDB2();

	}
	
	public void copyDB2() {
		File file = context.getDatabasePath(DBNAME2);
		File fileDir = file.getParentFile();
		SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
		int dbVersion = sp.getInt("app_cache_version", 0);
		if (!file.exists()) {
			try {
				fileDir.mkdirs();
				CopyFile(file,DBNAME2);
				sp.edit().putInt("app_cache_version", DBAppCacheOpenHelper.mversion).commit();
			} catch (IOException e) {

			}
		} else {
			try {
				if (dbVersion < DBAppCacheOpenHelper.mversion) {
					CopyFile(file,DBNAME2);
					sp.edit().putInt("app_cache_version", DBAppCacheOpenHelper.mversion).commit();
				}
			} catch (Exception e) {
				
			}

		}
		
		copyDB3();
	}
	
	public void copyDB3() {
		File file = context.getDatabasePath(DBNAME3);
		File fileDir = file.getParentFile();
		SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
		int dbVersion = sp.getInt("app_ad_version", 0);
		if (!file.exists()) {
			try {
				fileDir.mkdirs();
				CopyFile(file,DBNAME3);
				sp.edit().putInt("app_ad_version", DBAppCacheOpenHelper.mversion).commit();
			} catch (IOException e) {
				
			}
		} else {
			try {
				if (dbVersion < DBAppCacheOpenHelper.mversion) {
					CopyFile(file,DBNAME3);
					sp.edit().putInt("app_ad_version", DBAppCacheOpenHelper.mversion).commit();
				}
			} catch (Exception e) {
				
			}
			
		}
		
	}


	public void CopyFile(File file,String name) throws IOException {
		InputStream myInput = context.getAssets().open(name);
		OutputStream myOutput = new FileOutputStream(file);
		byte[] buffer = new byte[1024];
		int length;
		while ((length = myInput.read(buffer)) > 0) {
			myOutput.write(buffer, 0, length);
		}
		myOutput.flush();
		myOutput.close();
		myInput.close();
	}
}
