package cn.com.opda.android.clearmaster.model;

public class SmsInfo {
	private int _id; // id号码
	private int thread_id; // 会话id号
	private String address; // 短信目的地号码
	private String person; // 在联系人中相对的id
	private String date; // 发送的时间
	private int read; // 短信是否被读
	private int status; // 短信的状态
	private int type; // 短信的类型，1为别人发送给自己的，2为自己发送的
	private String body; // 信息的内容
	private boolean isChecked; // 附加属性 作为listView时是否被选中
	private String name; // 名字
	public int get_id() {
		return _id;
	}
	public void set_id(int _id) {
		this._id = _id;
	}
	public int getThread_id() {
		return thread_id;
	}
	public void setThread_id(int thread_id) {
		this.thread_id = thread_id;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPerson() {
		return person;
	}
	public void setPerson(String person) {
		this.person = person;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public int getRead() {
		return read;
	}
	public void setRead(int read) {
		this.read = read;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}
	public boolean isChecked() {
		return isChecked;
	}
	public void setChecked(boolean isChecked) {
		this.isChecked = isChecked;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	
}
