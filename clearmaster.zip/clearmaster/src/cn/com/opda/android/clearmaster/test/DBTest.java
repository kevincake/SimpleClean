package cn.com.opda.android.clearmaster.test;

import java.util.ArrayList;

import android.test.AndroidTestCase;
import cn.com.opda.android.clearmaster.dao.news.DBAppCacheUtils;
import cn.com.opda.android.clearmaster.dao.news.DBAppFolderUtils;
import cn.com.opda.android.clearmaster.model.ClearItem;
import cn.com.opda.android.clearmaster.utils.DesUtils;
import cn.com.opda.android.clearmaster.utils.HASH;

public class DBTest extends AndroidTestCase {
	public void testMain() {
		//加密数据库
//		ArrayList<ClearItem> clearItems = DBAppFolderUtils.old_get(mContext, "zh");
//		for(ClearItem clearItem : clearItems){
//			try {
//				clearItem.setMd5Path(DesUtils.encryptDES(clearItem.getFilePath(), DesUtils.getKey3()));
//				clearItem.setMd5PackageName(DesUtils.encryptDES(clearItem.getPackageName(), DesUtils.getKey3()));
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
//			
//		}
//		DBAppFolderUtils.update(mContext, clearItems);
//		
//		ArrayList<ClearItem> clearItems2 = DBAppCacheUtils.getInstance(getContext()).old_get(mContext, "zh");
//		for(ClearItem clearItem : clearItems2){
//			try {
//				clearItem.setMd5Path(DesUtils.encryptDES(clearItem.getFilePath(), DesUtils.getKey3()));
//				clearItem.setMd5PackageName(HASH.md5sum(clearItem.getPackageName()+"_zz"));
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
//			
//		}
//		DBAppCacheUtils.getInstance(getContext()).update(mContext, clearItems2);
//		DBAppCacheUtils.getInstance(getContext()).close();
		
		
		//解密数据库
//		ArrayList<ClearItem> clearItems = DBAppFolderUtils.get(mContext, "zh");
//		for(ClearItem clearItem : clearItems){
//			try {
//				clearItem.setMd5Path(clearItem.getFilePath());
//				clearItem.setFilePath(DesUtils.encryptDES(clearItem.getFilePath(), DesUtils.getKey3()));
//				clearItem.setMd5PackageName(clearItem.getPackageName());
//				clearItem.setPackageName(DesUtils.encryptDES(clearItem.getPackageName(), DesUtils.getKey3()));
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
//			
//		}
//		DBAppFolderUtils.update(mContext, clearItems);
//		
//		
//		
//		ArrayList<ClearItem> clearItems2 = DBAppCacheUtils.getInstance(getContext()).getAll(mContext, "zh");
//		for(ClearItem clearItem : clearItems2){
//			try {
//				clearItem.setMd5Path(clearItem.getFilePath());
//				clearItem.setFilePath(DesUtils.encryptDES(clearItem.getFilePath(), DesUtils.getKey3()));
//				clearItem.setMd5PackageName(clearItem.getPackageName());
//				clearItem.setPackageName(DesUtils.encryptDES(clearItem.getPackageName(), DesUtils.getKey3()));
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
//			
//		}
//		DBAppCacheUtils.getInstance(getContext()).update(mContext, clearItems2);
//		DBAppCacheUtils.getInstance(getContext()).close();
		
	}
}
