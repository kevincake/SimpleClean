package cn.com.opda.android.clearmaster.dao;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBApkPathListOpenHelper extends SQLiteOpenHelper {

	private final static String SqLiteName = "apkpath.db";
	private final static int mversion = 1;

	public DBApkPathListOpenHelper(Context context) {
		super(context, SqLiteName, null, mversion);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		db.execSQL("create table if not exists apkpath (path TEXT)");
		db.execSQL("create table if not exists logpath (path TEXT)");
		db.execSQL("create table if not exists bigfilepath (path TEXT)");
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int arg1, int arg2) {
		onCreate(db);
	}

}
