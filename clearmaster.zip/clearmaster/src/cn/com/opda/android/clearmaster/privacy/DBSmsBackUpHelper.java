package cn.com.opda.android.clearmaster.privacy;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Base64;
import cn.com.opda.android.clearmaster.utils.Constants;

public class DBSmsBackUpHelper {

	private final String SmsSqLiteName = Constants.FILE_SMSBACKUP;
	private SQLiteDatabase db;
	private static DBSmsBackUpHelper dbhelper = null;

	public static DBSmsBackUpHelper getInstance() {
		if (dbhelper == null)
			dbhelper = new DBSmsBackUpHelper();
		return dbhelper;
	}

	/**
	 * 创建并打开数据库
	 * 
	 * @param newversion
	 */
	public synchronized void openOrCreateDb(int newversion) {
		db = SQLiteDatabase.openOrCreateDatabase(getDatabasePath(SmsSqLiteName), null);
		int version = db.getVersion();
		if (version != newversion) {
			db.execSQL("drop table if exists smsbackdetail");
			db.execSQL("create table if not exists smsbackdetail (_id INTEGER  primary key autoincrement, thread_id INTEGER,address TEXT,date TEXT,body TEXT,read TEXT,status TEXT,type INTEGER)");
			db.setVersion(newversion);
		}
	}

	/**
	 * 加入备份数据库
	 * 
	 * @param infolist
	 */
	public synchronized void addBackUp(List<SmsBackUpInfo> infolist) {

		for (int i = 0; i < infolist.size(); i++) {
			SmsBackUpInfo info = infolist.get(i);
			info.setBody(Base64.encodeToString(info.getBody().getBytes(), Base64.DEFAULT));
			db.execSQL("insert into smsbackdetail (thread_id,address,date,body,read,status,type) values(?,?,?,?,?,?,?)", new Object[] { info.getThread_id(),
					info.getAddress(), info.getDate(), info.getBody(), info.getRead(), info.getStatus(), info.getType() });
		}

	}

	public synchronized void addBackUp(SmsBackUpInfo info) {
		info.setBody(Base64.encodeToString(info.getBody().getBytes(), Base64.DEFAULT));
		db.execSQL("insert into smsbackdetail(thread_id,address,date,body,read,status,type) values(?,?,?,?,?,?,?)",
				new Object[] { info.getThread_id(), info.getAddress(), info.getDate(), info.getBody(), info.getRead(), info.getStatus(), info.getType() });
	}

	/**
	 * 根据短信的id删除信息
	 */
	public synchronized void deleteBackupSmsById(Context context, int id) {
		db.execSQL("delete from smsbackdetail where _id=?", new Object[] { id+"" });
	}

	/**
	 * 根据短信的id删除信息
	 */
	public synchronized void deleteBackupSmsByList(Context context, ArrayList<SmsBackUpInfo> backUpInfos) {
		for (SmsBackUpInfo smsBackUpInfo : backUpInfos) {
			db.execSQL("delete from smsbackdetail where _id=?", new Object[] { smsBackUpInfo.getId()+"" });
		}
	}

	/**
	 * 阅读备份数据库
	 * 
	 * @return
	 */
	public synchronized ArrayList<SmsBackUpInfo> readBackUpInfolist() {
		ArrayList<SmsBackUpInfo> list = new ArrayList<SmsBackUpInfo>();
		Cursor cursor = db.rawQuery("select * from smsbackdetail order by date DESC", null);
		if (cursor != null) {
			while (cursor.moveToNext()) {
				SmsBackUpInfo info = new SmsBackUpInfo();
				info.setId(cursor.getInt(0));
				info.setThread_id(cursor.getInt(1));
				info.setAddress(cursor.getString(2));
				info.setDate(cursor.getString(3));

				try {
					info.setBody(new String(Base64.decode(cursor.getString(4), Base64.DEFAULT), "utf-8").toString());
				} catch (Exception e) {
				}
				info.setRead(cursor.getInt(5));
				info.setStatus(cursor.getInt(6));
				info.setType(cursor.getInt(7));
				list.add(info);
			}
			cursor.close();
		}
		return list;
	}

	public synchronized int getCount() {
		Cursor cursor = db.rawQuery("select count(*) from smsbackdetail ", null);
		cursor.moveToFirst();
		int num = cursor.getInt(0);
		cursor.close();
		return num;
	}

	/**
	 * 关闭数据库
	 */
	public synchronized void closeDb() {
		if (db != null)
			db.close();
	}

	/**
	 * 创建数据库路径
	 * 
	 * @param name
	 * @return
	 */
	public synchronized File getDatabasePath(String name) {
		File f = new File(Constants.BACKUP_DIR_PATH);
		if (!f.exists()) {
			f.mkdirs();
		}
		return new File(f, name);
	}

}
