package cn.com.opda.android.clearmaster;

import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;
import android.preference.PreferenceManager;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import cn.com.opda.android.clearmaster.adapter.Adapter4UninstallApp;
import cn.com.opda.android.clearmaster.custom.CustomActivity;
import cn.com.opda.android.clearmaster.custom.CustomDialog2;
import cn.com.opda.android.clearmaster.custom.IOSProgressDialog;
import cn.com.opda.android.clearmaster.impl.SelectListener;
import cn.com.opda.android.clearmaster.model.AppItem;
import cn.com.opda.android.clearmaster.utils.AppManagerUtils;
import cn.com.opda.android.clearmaster.utils.ClearUtils;
import cn.com.opda.android.clearmaster.utils.CodeSizeComparator;
import cn.com.opda.android.clearmaster.utils.Constants;
import cn.com.opda.android.clearmaster.utils.CustomEventCommit;
import cn.com.opda.android.clearmaster.utils.DLog;
import cn.com.opda.android.clearmaster.utils.DrawableUtils;
import cn.com.opda.android.clearmaster.utils.Terminal;

public class UninstallSystemApp extends CustomActivity implements OnClickListener {
	private ListView app_uninstall_system_listview;
	private Adapter4UninstallApp mSystemAppUninstallAdapter;
	private String[] keepApps = { "com.android.launcher", "com.android.phone", "android", "com.google.android.gsf", "com.android.systemui" };
	private long freeMemory;
	private IOSProgressDialog mIosProgressDialog;
	private Button clear_button;
	private TextView tv_search_result;
	private AppItem uninstallApp;
	private ArrayList<AppItem> systemApps = new ArrayList<AppItem>();
	private boolean init;
	private boolean stop;
	private LinearLayout recycle_title_layout;

	public UninstallSystemApp(Context context, int resId, SoftwareUninstallActivity softwareUninstallActivity) {
		super(context, resId);
		initViewAndEvent();
	}

	private void initViewAndEvent() {
		app_uninstall_system_listview = (ListView) findViewById(R.id.app_uninstall_system_listview);
		tv_search_result = (TextView) findViewById(R.id.tv_search_result);
		clear_button = (Button) findViewById(R.id.clear_button);
		clear_button.setOnClickListener(this);
		recycle_title_layout = (LinearLayout) findViewById(R.id.recycle_title_layout);
		recycle_title_layout.setOnClickListener(this);
	}

	@Override
	public void onResume() {

	}

	@Override
	public void initData() {
		if (!init) {
			init = true;
			new GetRecyleApk().start();
			new GetAppListTask().execute();
		}
	}

	public void initData(ArrayList<AppItem> systemApps) {
		if (!init) {
			init = true;
			new GetRecyleApk().start();
			this.systemApps = systemApps;
			mSystemAppUninstallAdapter = new Adapter4UninstallApp(mContext, systemApps, mHandler);
			mSystemAppUninstallAdapter.setSelectListener(new SelectListener() {

				@Override
				public void selectSize(long size) {

				}
			});

			app_uninstall_system_listview.setAdapter(mSystemAppUninstallAdapter);
			showTipsDialog();
		}
	}

	private class GetAppListTask extends AsyncTask<Void, AppItem, Integer> {

		@Override
		protected void onPreExecute() {

			mIosProgressDialog = new IOSProgressDialog(mContext, R.string.loading);
			mIosProgressDialog.setCancelable(false);
			mIosProgressDialog.setCanceledOnTouchOutside(false);
			mIosProgressDialog.show();

		}

		@Override
		protected Integer doInBackground(Void... params) {
			PackageManager pm = mContext.getPackageManager();
			List<PackageInfo> installedAppList = pm.getInstalledPackages(0);
			for (int i = 0; i < installedAppList.size(); i++) {
				if (stop) {
					break;
				}
				PackageInfo packageInfo = installedAppList.get(i);
				ApplicationInfo info = packageInfo.applicationInfo;
				String sourceDir = info.sourceDir;
				if (sourceDir != null) {
					if (info.packageName.equals(mContext.getPackageName())) {
						continue;
					}
					if (isKeepApp(info.packageName)) {
						continue;
					}
					boolean flag = false;
					if ((info.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0) {
						flag = true;
					} else if ((info.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
						flag = true;
					}
					if (!flag) {
						AppItem appItem = new AppItem();
						appItem.setAppPackage(info.packageName);
						appItem.setAppName(info.loadLabel(pm).toString());
						appItem.setApplicationInfo(info);
						String dir = info.publicSourceDir;
						appItem.setInstallTime(new File(dir).lastModified());

						appItem.setCodePath(sourceDir);
						appItem.setCodeSize(new File(sourceDir).length());
						if (sourceDir.contains(".apk")) {
							appItem.setOdexPath(sourceDir.replace(".apk", ".odex"));
						}
						appItem.setSystemApp(true);
						appItem.setUserApp(false);
						if (isInBlack(appItem.getAppPackage())) {
							appItem.setKeep(true);
						}
						systemApps.add(appItem);
					}
				}
			}
			return null;

		}

		@Override
		protected void onProgressUpdate(AppItem... values) {
			super.onProgressUpdate(values);
		}

		@Override
		protected void onPostExecute(Integer result) {
			super.onPostExecute(result);
			Collections.sort(systemApps, new CodeSizeComparator());
			mIosProgressDialog.dismiss();
			mSystemAppUninstallAdapter = new Adapter4UninstallApp(mContext, systemApps, mHandler);
			mSystemAppUninstallAdapter.setSelectListener(new SelectListener() {

				@Override
				public void selectSize(long size) {

				}
			});

			app_uninstall_system_listview.setAdapter(mSystemAppUninstallAdapter);
			showTipsDialog();
		}

		public boolean isKeepApp(String packageName) {
			for (String string : keepApps) {
				if (string.equals(packageName)) {
					return true;
				}
			}
			return false;
		}
	}

	public void showTipsDialog() {
		final SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(mContext);
		if (!sp.getBoolean("uninstall_tip", false)) {
			final CustomDialog2 customDialog = new CustomDialog2(mContext);
			customDialog.setDialogIcon(R.drawable.dialog_icon_warning);
			customDialog.setMessage(R.string.uninstall_system_app_tips);
			customDialog.setButton2(R.string.dialog_button_ok, new OnClickListener() {

				@Override
				public void onClick(View v) {
					sp.edit().putBoolean("uninstall_tip", true).commit();
					customDialog.dismiss();
				}
			});
			customDialog.show();
		}

	}

	public boolean isInBlack(String packageName) {
		if (packageName.startsWith("com.android") || packageName.startsWith("com.google") || packageName.startsWith("com.htc")
				|| packageName.startsWith("android") || packageName.startsWith("com.sonyericsson") || packageName.startsWith("com.adobe")
				|| packageName.startsWith("com.huawei") || packageName.startsWith("com.cyanogenmod") || packageName.startsWith("com.miui")
				|| packageName.startsWith("com.facebook") || packageName.startsWith("com.xiaomi") || packageName.startsWith("com.qualcomm")
				|| packageName.startsWith("com.mediatek") || packageName.startsWith("com.lenovo") || packageName.startsWith("com.samsung")
				|| packageName.startsWith("com.motorola") || packageName.startsWith("com.zte") || packageName.startsWith("com.meizu")
				|| packageName.startsWith("com.twitter") || packageName.startsWith("com.lg") || packageName.startsWith("com.sony")
				|| packageName.startsWith("com.rockchip") || packageName.startsWith("com.spreadtrum") || packageName.startsWith("com.asus")
				|| packageName.startsWith("com.dell") || packageName.startsWith("com.philips") || packageName.startsWith("com.haier")
				|| packageName.startsWith("com.aigo") || packageName.startsWith("com.sharp") || packageName.startsWith("com.oppo")
				|| packageName.startsWith("com.10moons") || packageName.startsWith("com.nvidia") || packageName.startsWith("com.nook")
				|| packageName.startsWith("com.lephone") || packageName.startsWith("com.hisense") || packageName.startsWith("com.opda")
				|| packageName.startsWith("cn.opda") || packageName.startsWith("cn.com.opda") || packageName.startsWith("com.dashi")
				|| packageName.startsWith("com.sec") || packageName.contains(".launcher")) {
			return true;
		}

		return false;
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.recycle_title_layout:
			mContext.startActivity(new Intent(mContext, AppRecyleActivity.class));
			break;
		case R.id.clear_button:
			CustomEventCommit.commit(mContext, CustomEventCommit.system_app_uninstall);
			uninstallApp(mSystemAppUninstallAdapter.getSelectList());
			break;
		default:
			break;
		}

	}

	private void uninstallApp(ArrayList<AppItem> apps) {
		freeMemory = 0;
		final ArrayList<AppItem> appItems = apps;
		if (appItems != null && appItems.size() > 0) {
			mIosProgressDialog = new IOSProgressDialog(mContext, R.string.app_uninstall_loading);
			mIosProgressDialog.setCancelable(false);
			mIosProgressDialog.setCanceledOnTouchOutside(false);
			mIosProgressDialog.show();
			new Thread(new Runnable() {

				@Override
				public void run() {
					for (int i = 0; i < appItems.size(); i++) {
						AppItem appItem = appItems.get(i);
						boolean b = false;
						if (appItem.isSystemApp()) {
							if (AppManagerUtils.backupApp(appItem)) {
								b = Terminal.uninstallSystemApp(appItem);
							}
						} else {
							b = Terminal.uninstallUserApp(appItem);
						}
						if (b) {
							freeMemory += appItem.getCodeSize();
							uninstallApp = appItem;
							Message message = new Message();
							message.what = 1;
							message.arg1 = appItems.size();
							message.arg2 = i + 1;
							mHandler.sendMessage(message);
						}
					}

					Message message = new Message();
					message.what = 0;
					message.arg1 = appItems.size();
					message.arg2 = appItems.size();
					mHandler.sendMessageDelayed(message, 200);
				}
			}).start();
		} else {
			Toast.makeText(mContext, R.string.clear_select_null, Toast.LENGTH_SHORT).show();
		}
	}

	Handler mHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			switch (msg.what) {
			case 0:
				mIosProgressDialog.dismiss();
				Toast.makeText(mContext, R.string.uninstall_end_recyle_tips, Toast.LENGTH_SHORT).show();
				ClearUtils.setDayClearSize(mContext, freeMemory);
				ClearUtils.setHistoryClearSize(mContext, freeMemory);
				new GetRecyleApk().start();
				break;
			case 1:
				Toast.makeText(mContext, mContext.getString(R.string.app_uninstall_succeed_toast, uninstallApp.getAppName()), Toast.LENGTH_SHORT).show();
				if (uninstallApp.isSystemApp()) {
					mSystemAppUninstallAdapter.removeApp(uninstallApp);
				}
				clear_button.setText(getString(R.string.one_uninstall_button));
				break;
			case 110:
				if (mSystemAppUninstallAdapter.getSelectList().size() == 0) {
					clear_button.setText(getString(R.string.one_uninstall_button));
				} else {
					clear_button.setText(getString(R.string.one_uninstall_button) +" ("+ mSystemAppUninstallAdapter.getSelectList().size() + ")");
				}
				break;

			default:
				break;
			}
		}
	};

	public void notifySystemAdapter() {
		if (mSystemAppUninstallAdapter != null) {
			mSystemAppUninstallAdapter.notifyDataSetChanged();
		}
	}

	public void updateSystemAdapter() {
		if (mSystemAppUninstallAdapter != null) {
			mSystemAppUninstallAdapter.updateListView(systemApps);
		}
	}

	public void updateSystemAdapter(ArrayList<AppItem> filterDateList) {
		if (mSystemAppUninstallAdapter != null) {
			mSystemAppUninstallAdapter.updateListView(filterDateList);
		}
	}

	public ArrayList<AppItem> getSystemApps() {
		return systemApps;
	}

	public View getNoResultView() {
		return tv_search_result;

	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		stop = true;
	}

	private class GetRecyleApk extends Thread {
		private ArrayList<AppItem> mApkModelList;

		public GetRecyleApk() {
			if (mApkModelList == null) {
				mApkModelList = new ArrayList<AppItem>();
			} else {
				mApkModelList.clear();
			}
		}

		@Override
		public void run() {
			super.run();
			File[] sdcardfiles = new File(Constants.SYSTEM_BACKUP_PATH).listFiles();
			if (sdcardfiles != null) {
				for (File file : sdcardfiles) {
					if (stop) {
						break;
					}
					String fileName = file.getName();
					if (fileName != null && fileName.length() != 0) {
						if (fileName.endsWith(".apk")) {
							AppItem model = new AppItem();
							model.setAppName(file.getName());
							model.setFilePath(file.getAbsolutePath());
							if (fillApkModel(model)) {
								if (model.getAppIcon() != null) {
									mApkModelList.add(model);
								}
								if (mApkModelList.size() >= 4) {
									handler.sendEmptyMessage(0);
									return;
								}
							}
						}
					}
				}
			}
			handler.sendEmptyMessage(0);
		}

		Handler handler = new Handler() {

			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				DLog.i("debug", "system app :  " + mApkModelList.size());
				Bitmap bitmap = DrawableUtils.drawFolderBitmap(mContext, mApkModelList);
				ImageView recyle_icon_imageview = (ImageView) findViewById(R.id.recyle_icon_imageview);
				recyle_icon_imageview.setImageBitmap(bitmap);
			}

		};
	}

	/**
	 * 获取未安装的apk信息
	 * 
	 * @param ctx
	 * @param apkPath
	 * @return
	 */
	public boolean fillApkModel(AppItem info) {
		String filepath = info.getFilePath();
		File file = new File(filepath);
		if (file == null || !file.exists()) {
			return false;
		}
		info.setCodePath(filepath);
		info.setCodeSize(file.length());
		String PATH_PackageParser = "android.content.pm.PackageParser";
		String PATH_AssetManager = "android.content.res.AssetManager";
		try {
			// 反射得到pkgParserCls对象并实例化,有参数
			Class<?> pkgParserCls = Class.forName(PATH_PackageParser);
			Class<?>[] typeArgs = null;
			Object[] valueArgs = null;
			Object pkgParser = null;
			try {
				typeArgs = new Class<?>[] { String.class };
				Constructor<?> pkgParserCt = pkgParserCls.getConstructor(typeArgs);
				valueArgs = new Object[] { filepath };
				pkgParser = pkgParserCt.newInstance(valueArgs);
			} catch (Exception e1) {
				Constructor<?> pkgParserCt = pkgParserCls.getConstructor();
				pkgParser = pkgParserCt.newInstance();
			}
			if (pkgParser == null) {
				return false;
			}

			// 从pkgParserCls类得到parsePackage方法
			Object pkgParserPkg = null;
			try {
				DisplayMetrics metrics = new DisplayMetrics();
				metrics.setToDefaults();// 这个是与显示有关的, 这边使用默认
				typeArgs = new Class<?>[] { File.class, String.class, DisplayMetrics.class, int.class };
				Method pkgParser_parsePackageMtd = pkgParserCls.getDeclaredMethod("parsePackage", typeArgs);
				valueArgs = new Object[] { new File(filepath), filepath, metrics, 0 };
				// 执行pkgParser_parsePackageMtd方法并返回
				pkgParserPkg = pkgParser_parsePackageMtd.invoke(pkgParser, valueArgs);
			} catch (Exception e1) {
				typeArgs = new Class<?>[] { File.class, int.class };
				Method pkgParser_parsePackageMtd = pkgParserCls.getDeclaredMethod("parsePackage", typeArgs);
				valueArgs = new Object[] { new File(filepath), 0 };
				// 执行pkgParser_parsePackageMtd方法并返回
				pkgParserPkg = pkgParser_parsePackageMtd.invoke(pkgParser, valueArgs);
			}

			// 从返回的对象得到名为"applicationInfo"的字段对象
			if (pkgParserPkg == null) {
				return false;
			}
			Field appInfoFld = pkgParserPkg.getClass().getDeclaredField("applicationInfo");

			// 从对象"pkgParserPkg"得到字段"appInfoFld"的值
			if (appInfoFld.get(pkgParserPkg) == null) {
				return false;
			}
			ApplicationInfo applicationInfo = (ApplicationInfo) appInfoFld.get(pkgParserPkg);

			// 反射得到assetMagCls对象并实例化,无参
			Class<?> assetMagCls = Class.forName(PATH_AssetManager);
			Object assetMag = assetMagCls.newInstance();
			// 从assetMagCls类得到addAssetPath方法
			typeArgs = new Class[1];
			typeArgs[0] = String.class;
			Method assetMag_addAssetPathMtd = assetMagCls.getDeclaredMethod("addAssetPath", typeArgs);
			valueArgs = new Object[1];
			valueArgs[0] = filepath;
			// 执行assetMag_addAssetPathMtd方法
			assetMag_addAssetPathMtd.invoke(assetMag, valueArgs);

			// 得到Resources对象并实例化,有参数
			Resources res = mContext.getResources();
			typeArgs = new Class[3];
			typeArgs[0] = assetMag.getClass();
			typeArgs[1] = res.getDisplayMetrics().getClass();
			typeArgs[2] = res.getConfiguration().getClass();
			Constructor<Resources> resCt = Resources.class.getConstructor(typeArgs);
			valueArgs = new Object[3];
			valueArgs[0] = assetMag;
			valueArgs[1] = res.getDisplayMetrics();
			valueArgs[2] = res.getConfiguration();
			res = (Resources) resCt.newInstance(valueArgs);

			// 读取apk文件的信息
			if (applicationInfo != null) {
				if (applicationInfo.icon != 0) {// 图片存在，则读取相关信息
					Drawable icon = res.getDrawable(applicationInfo.icon);// 图标
					info.setAppIcon(icon);
					return true;
				}
			} else {
				return false;
			}
			return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

}
