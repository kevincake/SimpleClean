package cn.com.opda.android.clearmaster;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;

/**
 * 
 * Activity 基类
 * @author 庄宏岩
 *
 */
public class BaseActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);  
	}
	
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {

		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			finish();
			overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
			return true;
		}

		return super.onKeyDown(keyCode, event);
	}
	
}
