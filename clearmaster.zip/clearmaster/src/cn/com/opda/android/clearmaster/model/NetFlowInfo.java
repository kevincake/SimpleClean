package cn.com.opda.android.clearmaster.model;

import android.graphics.drawable.Drawable;

public class NetFlowInfo {
	private String appName;
	private String packageName;
	private byte[]Icon;
	private long flow;
	private int uid;
	private long tempFlow;
	private Drawable drawable;
	
	
	public Drawable getDrawable() {
		return drawable;
	}
	public void setDrawable(Drawable drawable) {
		this.drawable = drawable;
	}
	public long getTempFlow() {
		return tempFlow;
	}
	public void setTempFlow(long tempFlow) {
		this.tempFlow = tempFlow;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getPackageName() {
		return packageName;
	}
	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}
	public byte[] getIcon() {
		return Icon;
	}
	public void setIcon(byte[] icon) {
		Icon = icon;
	}
	public long getFlow() {
		return flow;
	}
	public void setFlow(long flow) {
		this.flow = flow;
	}
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public void setAppIcon(Drawable loadIcon) {
		this.drawable = loadIcon;
	}
	
}	
