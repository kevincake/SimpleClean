package cn.com.opda.android.clearmaster;

import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import cn.com.opda.android.clearmaster.adapter.Adapter4AutoBootManager;
import cn.com.opda.android.clearmaster.custom.CustomTextView;
import cn.com.opda.android.clearmaster.custom.WaterWaveCustomView;
import cn.com.opda.android.clearmaster.model.BootStartApp;
import cn.com.opda.android.clearmaster.model.GroupItem;
import cn.com.opda.android.clearmaster.model.ReceiverInfo;
import cn.com.opda.android.clearmaster.utils.BannerUtils;

import com.umeng.analytics.MobclickAgent;

/**
 * @author 庄宏岩
 * 
 */
public class AutoBootManager extends BaseActivity {
	private boolean stop;
	private ExpandableListView auto_boot_listview;
	private int appCount;
	private CustomTextView header_memory_textview;
	private WaterWaveCustomView header_waterwave_view;
	private TextView header_unit_textview,header_tips_textview,header_content_textview;
	
	private TextView scan_textview;
	private RelativeLayout progress_layout;
	private int totalCount = 10;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_auto_boot_manager);
		BannerUtils.initBackButton(this);
		BannerUtils.setTitle(this, "自启管理");
		initViewAndEvent();
		new GetAppThread().start();
	}

	private void initViewAndEvent() {
		auto_boot_listview = (ExpandableListView) findViewById(R.id.auto_boot_listview);

		header_memory_textview = (CustomTextView) findViewById(R.id.header_memory_textview);
		header_waterwave_view = (WaterWaveCustomView) findViewById(R.id.header_waterwave_view);
		header_unit_textview = (TextView) findViewById(R.id.header_unit_textview);
		header_unit_textview.setText("个应用");
		header_tips_textview = (TextView) findViewById(R.id.header_tips_textview);
		header_tips_textview.setText("后台自启");
		header_content_textview = (TextView) findViewById(R.id.header_content_textview);
		header_content_textview.setText("自启动应用会消耗电量和流量");
		header_content_textview.setVisibility(View.VISIBLE);
		
		progress_layout = (RelativeLayout) findViewById(R.id.progress_layout);
		scan_textview = (TextView) findViewById(R.id.scan_textview);
	}

	private class GetAppThread extends Thread {
		private ArrayList<BootStartApp> enables = new ArrayList<BootStartApp>();
		private ArrayList<BootStartApp> disables = new ArrayList<BootStartApp>();
		private ArrayList<GroupItem> groups = new ArrayList<GroupItem>();
		private ArrayList<ArrayList<BootStartApp>> childs = new ArrayList<ArrayList<BootStartApp>>();
		private Adapter4AutoBootManager mAdapter4BootStartApp;

		public GetAppThread() {
			GroupItem groupItem = new GroupItem();
			groupItem.setTitle("允许自启的应用");
			groupItem.setIcon(getResources().getDrawable(R.drawable.auto_start_enable));
			groups.add(groupItem);

			groupItem = new GroupItem();
			groupItem.setTitle("禁止自启的应用");
			groupItem.setIcon(getResources().getDrawable(R.drawable.auto_start_disable));
			groups.add(groupItem);

			childs.add(enables);
			childs.add(disables);

			mAdapter4BootStartApp = new Adapter4AutoBootManager(AutoBootManager.this, groups, childs);
			auto_boot_listview.setAdapter(mAdapter4BootStartApp);
		}

		@Override
		public void run() {
			super.run();
			List<ApplicationInfo> installedAppList = getPackageManager().getInstalledApplications(PackageManager.GET_UNINSTALLED_PACKAGES);
			if (installedAppList != null) {
				PackageManager pm = getPackageManager();
				for (ApplicationInfo appInfo : installedAppList) {
					if (stop) {
						break;
					}
					String sourceDir = appInfo.sourceDir;

					boolean flag = false;
					if ((appInfo.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0) {
						flag = true;
					} else if ((appInfo.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
						flag = true;
					}

					if (flag && sourceDir != null) {
						if (!getPackageName().equalsIgnoreCase(appInfo.packageName)) {
							Message message = new Message();
							message.what = 1;
							message.obj = appInfo.loadLabel(pm).toString();
							handler.sendMessage(message);
							BootStartApp bootStartApp = readReceiver(appInfo.sourceDir);
							if (bootStartApp != null) {

								bootStartApp.setIcon(appInfo.loadIcon(pm));
								bootStartApp.setLableName(appInfo.loadLabel(pm).toString());
								bootStartApp.setPackageName(appInfo.packageName);
								bootStartApp.setButtonstate(getButtonState(bootStartApp.getReceivers()));
								if (bootStartApp.isButtonstate()) {
									enables.add(bootStartApp);
									appCount++;
									handler.sendEmptyMessage(0);
								} else {
									disables.add(bootStartApp);
								}

							}

						}
					}
				}
			}
			handler.sendEmptyMessage(2);

		}

		private boolean getButtonState(List<ReceiverInfo> receiverInfoList) {
			for (ReceiverInfo receiverInfo : receiverInfoList) {
				if (receiverInfo.isEnable()) {
					return true;
				}
			}
			return false;
		}

		Handler handler = new Handler() {

			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				switch (msg.what) {
				case 0:
					header_memory_textview.setText(appCount + "");
					float f = appCount * 100f / totalCount;
					header_waterwave_view.setWaterLevel(f);
					header_waterwave_view.startWave();
					break;
				case 1:
					scan_textview.setText(getString(R.string.clear_scanning, (String) msg.obj));
					scan_textview.setVisibility(View.VISIBLE);
					break;
				case 2:
					if (enables.size() == 0 && disables.size() == 0) {
						TextView auto_boot_manager_tips_textview = (TextView) findViewById(R.id.auto_boot_manager_tips_textview);
						auto_boot_manager_tips_textview.setText("没有开机启动的应用,手机状态良好");
						auto_boot_manager_tips_textview.setVisibility(View.VISIBLE);
						auto_boot_listview.setVisibility(View.GONE);
					} else {
						auto_boot_listview.expandGroup(0);
					}

					progress_layout.setVisibility(View.GONE);
					break;

				default:
					break;
				}
			}

		};
	}

	private BootStartApp readReceiver(final String apkPath) {
		if (apkPath == null)
			return null;
		File file = new File(apkPath);
		if (file.exists()) {
			BootStartApp bootStartApp = new BootStartApp();
			String PATH_PackageParser = "android.content.pm.PackageParser";
			// 反射得到pkgParserCls对象并实例化,有参数
			try {
				// 反射得到pkgParserCls对象并实例化,有参数
				Class<?> pkgParserCls = Class.forName(PATH_PackageParser);
				Class<?>[] typeArgs = null;
				Object[] valueArgs = null;
				Object pkgParser = null;
				try {
					typeArgs = new Class<?>[] { String.class };
					Constructor<?> pkgParserCt = pkgParserCls.getConstructor(typeArgs);
					valueArgs = new Object[] { apkPath };
					pkgParser = pkgParserCt.newInstance(valueArgs);
				} catch (Exception e1) {
					Constructor<?> pkgParserCt = pkgParserCls.getConstructor();
					pkgParser = pkgParserCt.newInstance();
				}
				if (pkgParser == null) {
					return null;
				}

				// 从pkgParserCls类得到parsePackage方法
				Object pkgParserPkg = null;
				try {
					DisplayMetrics metrics = new DisplayMetrics();
					metrics.setToDefaults();// 这个是与显示有关的, 这边使用默认
					typeArgs = new Class<?>[] { File.class, String.class, DisplayMetrics.class, int.class };
					Method pkgParser_parsePackageMtd = pkgParserCls.getDeclaredMethod("parsePackage", typeArgs);
					valueArgs = new Object[] { new File(apkPath), apkPath, metrics, 0 };
					// 执行pkgParser_parsePackageMtd方法并返回
					pkgParserPkg = pkgParser_parsePackageMtd.invoke(pkgParser, valueArgs);
				} catch (Exception e1) {
					typeArgs = new Class<?>[] { File.class, int.class };
					Method pkgParser_parsePackageMtd = pkgParserCls.getDeclaredMethod("parsePackage", typeArgs);
					valueArgs = new Object[] { new File(apkPath), 0 };
					// 执行pkgParser_parsePackageMtd方法并返回
					pkgParserPkg = pkgParser_parsePackageMtd.invoke(pkgParser, valueArgs);
				}

				// 从返回的对象得到名为"applicationInfo"的字段对象
				if (pkgParserPkg != null) {
					Field PkgParserActivityFld = pkgParserPkg.getClass().getDeclaredField("receivers");
					ArrayList<ReceiverInfo> autoStartReceivers = new ArrayList<ReceiverInfo>();
					ArrayList<String> receiverClass = new ArrayList<String>();
					ArrayList<Object> PkgParserActivitys = (ArrayList<Object>) PkgParserActivityFld.get(pkgParserPkg);
					for (int i = 0; i < PkgParserActivitys.size(); i++) {
						Object receiver = PkgParserActivitys.get(i);
						if (receiver != null) {
							Field IntentsFld = receiver.getClass().getField("intents");
							ArrayList<Object> intents = (ArrayList<Object>) IntentsFld.get(receiver);
							Field ActivityInfoFld = receiver.getClass().getDeclaredField("info");
							ActivityInfo activityInfo = (ActivityInfo) ActivityInfoFld.get(receiver);
							if (intents != null && intents.size() > 0) {
								for (int j = 0; j < intents.size(); j++) {
									Object mActivityIntentInfo = intents.get(j);
									if (mActivityIntentInfo != null) {
										Method countActions_method = mActivityIntentInfo.getClass().getMethod("countActions");
										int size = (Integer) countActions_method.invoke(mActivityIntentInfo);
										for (int k = 0; k < size; k++) {
											Method getAction_method = mActivityIntentInfo.getClass().getMethod("getAction", int.class);
											final String action = (String) getAction_method.invoke(mActivityIntentInfo, k);
											if (Intent.ACTION_BOOT_COMPLETED.equals(action)) {
												ReceiverInfo mReceiverInfo = new ReceiverInfo();
												mReceiverInfo.setClassName(activityInfo.name);
												int component_enabled_state = get_component_enabled_state(activityInfo.packageName, activityInfo.name);
												switch (component_enabled_state) {
												case PackageManager.COMPONENT_ENABLED_STATE_DISABLED:
													mReceiverInfo.setEnable(false);
													break;
												case PackageManager.COMPONENT_ENABLED_STATE_DEFAULT:
												case PackageManager.COMPONENT_ENABLED_STATE_ENABLED:
												default:
													mReceiverInfo.setEnable(true);
													break;
												}
												bootStartApp.setBootStart(true);
												if (!receiverClass.contains(mReceiverInfo.getClassName())) {
													autoStartReceivers.add(mReceiverInfo);
													receiverClass.add(mReceiverInfo.getClassName());
												}
											} else if (Intent.ACTION_USER_PRESENT.equals(action) || ConnectivityManager.CONNECTIVITY_ACTION.equals(action)
													|| WifiManager.WIFI_STATE_CHANGED_ACTION.equals(action) || "android.net.wifi.STATE_CHANGED".equals(action)) {
												ReceiverInfo mReceiverInfo = new ReceiverInfo();
												mReceiverInfo.setClassName(activityInfo.name);
												int component_enabled_state = get_component_enabled_state(activityInfo.packageName, activityInfo.name);
												switch (component_enabled_state) {
												case PackageManager.COMPONENT_ENABLED_STATE_DISABLED:
													mReceiverInfo.setEnable(false);
													break;
												case PackageManager.COMPONENT_ENABLED_STATE_DEFAULT:
												case PackageManager.COMPONENT_ENABLED_STATE_ENABLED:
												default:
													mReceiverInfo.setEnable(true);
													break;
												}
												bootStartApp.setBackgroundStart(true);
												if (!receiverClass.contains(mReceiverInfo.getClassName())) {
													autoStartReceivers.add(mReceiverInfo);
													receiverClass.add(mReceiverInfo.getClassName());
												}
											}
										}

									}
								}
							}
						}
					}
					if (autoStartReceivers.size() > 0) {
						bootStartApp.setReceivers(autoStartReceivers);
						return bootStartApp;
					}
					return null;
				}
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}
		return null;
	}

	public void updateCount(boolean add) {
		if (add) {
			appCount++;
		} else {
			appCount--;
		}
		header_memory_textview.setText(appCount + "");
	}

	/**
	 * @param context
	 * @param packageName
	 * @param className
	 * 
	 * @return PackageManager.COMPONENT_ENABLED_STATE_DEFAULT = 0
	 *         PackageManager.COMPONENT_ENABLED_STATE_ENABLED = 1
	 *         PackageManager.COMPONENT_ENABLED_STATE_DISABLED = 2
	 */
	private int get_component_enabled_state(final String packageName, final String className) {
		try {
			return getPackageManager().getComponentEnabledSetting(new ComponentName(packageName, className));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return PackageManager.COMPONENT_ENABLED_STATE_DEFAULT;
	}

	@Override
	protected void onResume() {
		super.onResume();
		MobclickAgent.onResume(this);
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		stop = true;
		header_waterwave_view.stoptWave();
	}

	@Override
	protected void onPause() {
		super.onPause();
		MobclickAgent.onPause(this);
	}
}
