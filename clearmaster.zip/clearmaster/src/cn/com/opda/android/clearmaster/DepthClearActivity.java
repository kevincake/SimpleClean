package cn.com.opda.android.clearmaster;

import java.io.File;
import java.io.FileFilter;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.IPackageStatsObserver;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.PackageStats;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.os.RemoteException;
import android.preference.PreferenceManager;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.TranslateAnimation;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnChildClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import cn.com.opda.android.clearmaster.adapter.Adapter4ApkClear;
import cn.com.opda.android.clearmaster.adapter.Adapter4BigFileGroup;
import cn.com.opda.android.clearmaster.adapter.Adapter4CacheClear;
import cn.com.opda.android.clearmaster.adapter.Adapter4DepthClear;
import cn.com.opda.android.clearmaster.adapter.Adapter4ResultAd;
import cn.com.opda.android.clearmaster.custom.CustomDialog2;
import cn.com.opda.android.clearmaster.custom.CustomDialog3;
import cn.com.opda.android.clearmaster.custom.CustomExpandListView;
import cn.com.opda.android.clearmaster.custom.CustomListView;
import cn.com.opda.android.clearmaster.custom.CustomTextView;
import cn.com.opda.android.clearmaster.custom.WaterWaveCustomView;
import cn.com.opda.android.clearmaster.dao.CacheWhiteListUtils;
import cn.com.opda.android.clearmaster.dao.DBApkPathUtils;
import cn.com.opda.android.clearmaster.dao.DBBigFilePathUtils;
import cn.com.opda.android.clearmaster.dao.DBLogPathUtils;
import cn.com.opda.android.clearmaster.dao.news.DBAppCacheUtils;
import cn.com.opda.android.clearmaster.dao.news.DBAppFolderUtils;
import cn.com.opda.android.clearmaster.impl.CheckedListener;
import cn.com.opda.android.clearmaster.impl.SelectListener;
import cn.com.opda.android.clearmaster.model.AdInfo;
import cn.com.opda.android.clearmaster.model.AppItem;
import cn.com.opda.android.clearmaster.model.BaseItem;
import cn.com.opda.android.clearmaster.model.BigFileGroup;
import cn.com.opda.android.clearmaster.model.BigFileItem;
import cn.com.opda.android.clearmaster.model.ClearItem;
import cn.com.opda.android.clearmaster.model.GroupItem;
import cn.com.opda.android.clearmaster.model.ToolboxAd;
import cn.com.opda.android.clearmaster.quickaction2.ActionItem2;
import cn.com.opda.android.clearmaster.quickaction2.QuickAction2;
import cn.com.opda.android.clearmaster.utils.AppDownload;
import cn.com.opda.android.clearmaster.utils.AppManagerUtils;
import cn.com.opda.android.clearmaster.utils.BannerUtils;
import cn.com.opda.android.clearmaster.utils.CacheComparator;
import cn.com.opda.android.clearmaster.utils.ClearUtils;
import cn.com.opda.android.clearmaster.utils.CodeSizeComparator;
import cn.com.opda.android.clearmaster.utils.Constants;
import cn.com.opda.android.clearmaster.utils.CopyDBUtils;
import cn.com.opda.android.clearmaster.utils.CustomEventCommit;
import cn.com.opda.android.clearmaster.utils.DLog;
import cn.com.opda.android.clearmaster.utils.DensityUtil;
import cn.com.opda.android.clearmaster.utils.FileUtils;
import cn.com.opda.android.clearmaster.utils.FormatUtils;
import cn.com.opda.android.clearmaster.utils.MemoryUtils;
import cn.com.opda.android.clearmaster.utils.MenuOptionUtil;
import cn.com.opda.android.clearmaster.utils.StringUtil;
import cn.com.opda.android.clearmaster.utils.Terminal;
import cn.com.opda.android.clearmaster.utils.ToolboxAdUtils;

import com.lib.statistics.StatisticsUtils;
import com.umeng.analytics.MobclickAgent;

/**
 * 深度清理页面
 * 
 * @author 庄宏岩
 * 
 */
public class DepthClearActivity extends Activity implements OnClickListener, OnChildClickListener, OnItemClickListener {
	private long totalCacheSize;
	private long totalDepthSize;
	private long totalApkSize;
	private long totalLogSize;
	private long totalBigFileSize;
	private long selectCacheSize;
	private long selectDepthSize;
	private long selectApkSize;
	private long selectLogSize;
	private long selectBigFileSize;
	private Context mContext;
	private TextView scan_textview;
	private Adapter4CacheClear mAdapter4CacheClear;
	private CustomExpandListView cache_clear_expandlistview, apk_clear_expandlistview;
	private LinearLayout cache_clear_expandlistview_layout, apk_clear_expandlistview_layout;
	private LinearLayout depth_clear_listview_layout, bigfile_clear_listview_layout;
	private TextView cache_size_textview;
	private TextView depth_size_textview;
	private TextView apk_size_textview;
	private TextView log_size_textview, log_count_textview;
	private TextView bigfile_size_textview;
	private ProgressBar cache_scan_progressbar, depth_scan_progressbar, apk_scan_progressbar;
	private ProgressBar log_scan_progressbar, bigfile_scan_progressbar;
	private LinearLayout log_content_layout;
	private CheckBox log_checked_imageview;
	private ImageView log_duigou_imageview, apk_duigou_imageview, cache_duigou_imageview, depth_duigou_imageview, bigfile_duigou_imageview;
	private LinearLayout result_page;
	private RelativeLayout list_page;
	private boolean stop = false;
	private final String SDCARDPATH = Environment.getExternalStorageDirectory().toString();
	// apk过滤列表
	private final String[] EXCEPTPATH = { StringUtil.link(SDCARDPATH, "/gameloft/"), StringUtil.link(SDCARDPATH, "/OpenRecovery/"),
			StringUtil.link(SDCARDPATH, "/LOST.DIR/"), StringUtil.link(SDCARDPATH, "/Android/obb/"), StringUtil.link(SDCARDPATH, "/Android/data/"),
			StringUtil.link(SDCARDPATH, "/clearmaster_zds/systembackup/"), StringUtil.link(SDCARDPATH, "/.expand") };
	private ArrayList<String> logList = new ArrayList<String>();
	private boolean end;
	private Adapter4DepthClear mAdapter4DepthClear;
	private Adapter4ApkClear mAdapter4ApkClear;
	private Adapter4BigFileGroup mAdapter4BigFileClear;
	private Button clear_button;
	private LinearLayout cache_title_layout, depth_title_layout, apk_title_layout, log_title_layout, bigfile_title_layout;
	private LinearLayout cache_layout, depth_layout, apk_layout, log_layout, bigfile_layout;
	private RelativeLayout progress_layout;
	private boolean from_notify;
	private List<PackageInfo> mAllPackageInfos;
	private boolean apkPathInit;
	private HashSet<String> apkCollectionPaths;
	private HashSet<String> bigfileCollectionPaths;
	private HashSet<String> logCollectionPaths;

	private long totalMemory = (long) (5.0 * 1024 * 1024 * 1024);
	private String audio_form = ".rmvb.mp3.avi.rm.mpg.mpeg.mpeg4.mpeg2.wmv.mov.mp4.3gp.flv.ogg.wav.wma.flac.ape";
	private String ebook_form = ".txt.chm.pdf.doc.epub.umd";

	private CustomTextView header_memory_textview;
	private WaterWaveCustomView header_waterwave_view;
	private TextView header_unit_textview, header_tips_textview, header_content_textview;
	private CheckBox depth_group_checkbox, bigfile_group_checkbox, cache_group_checkbox, log_group_checkbox, apk_group_checkbox;
	private boolean daily_finish;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		from_notify = getIntent().getBooleanExtra("from_notify", false);
		daily_finish = getIntent().getBooleanExtra("daily_finish", false);
		if (!from_notify) {
			overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
		}
		setContentView(R.layout.activity_depth_clear);
		mContext = DepthClearActivity.this;
		BannerUtils.setTitle(this, R.string.depth_page_title);
		initBackButton();
		initViewAndEvent();
		clear_button.setText(R.string.stop_scan_button);
		if (!new File(getFilesDir(), "RemoteTools.jar").exists()) {
			String fileName = "RemoteTools_low.jar";
			if (Build.VERSION.SDK_INT >= 17) {
				fileName = "RemoteTools.jar";
			} else {
				fileName = "RemoteTools_low.jar";
			}
			FileUtils.copyAssetFile(mContext, fileName);
		}
		new GetCacheThread().start();
		new GetDepthThread().start();
		new GetApkThread().start();

		initAdView();
		initADListView();
		initResultImageView();
	}

	private void initViewAndEvent() {
		progress_layout = (RelativeLayout) findViewById(R.id.progress_layout);

		scan_textview = (TextView) findViewById(R.id.scan_textview);
		clear_button = (Button) findViewById(R.id.clear_button);
		clear_button.setOnClickListener(this);

		header_memory_textview = (CustomTextView) findViewById(R.id.header_memory_textview);
		header_waterwave_view = (WaterWaveCustomView) findViewById(R.id.header_waterwave_view);
		header_unit_textview = (TextView) findViewById(R.id.header_unit_textview);
		header_tips_textview = (TextView) findViewById(R.id.header_tips_textview);
		header_content_textview = (TextView) findViewById(R.id.header_content_textview);
		header_tips_textview.setText("可清理");

		cache_title_layout = (LinearLayout) findViewById(R.id.cache_title_layout);
		cache_title_layout.setOnClickListener(this);
		cache_title_layout.setClickable(false);
		cache_size_textview = (TextView) findViewById(R.id.cache_size_textview);
		cache_scan_progressbar = (ProgressBar) findViewById(R.id.cache_scan_progressbar);

		depth_title_layout = (LinearLayout) findViewById(R.id.depth_title_layout);
		depth_title_layout.setOnClickListener(this);
		depth_title_layout.setClickable(false);
		depth_size_textview = (TextView) findViewById(R.id.depth_size_textview);
		depth_scan_progressbar = (ProgressBar) findViewById(R.id.depth_scan_progressbar);

		bigfile_title_layout = (LinearLayout) findViewById(R.id.bigfile_title_layout);
		bigfile_title_layout.setOnClickListener(this);
		bigfile_title_layout.setClickable(false);
		bigfile_size_textview = (TextView) findViewById(R.id.bigfile_size_textview);
		bigfile_scan_progressbar = (ProgressBar) findViewById(R.id.bigfile_scan_progressbar);

		apk_title_layout = (LinearLayout) findViewById(R.id.apk_title_layout);
		apk_title_layout.setOnClickListener(this);
		apk_title_layout.setClickable(false);
		apk_size_textview = (TextView) findViewById(R.id.apk_size_textview);
		apk_scan_progressbar = (ProgressBar) findViewById(R.id.apk_scan_progressbar);

		log_title_layout = (LinearLayout) findViewById(R.id.log_title_layout);
		log_title_layout.setOnClickListener(this);
		log_title_layout.setClickable(false);
		log_size_textview = (TextView) findViewById(R.id.log_size_textview);
		log_scan_progressbar = (ProgressBar) findViewById(R.id.log_scan_progressbar);
		log_count_textview = (TextView) findViewById(R.id.log_count_textview);
		log_checked_imageview = (CheckBox) findViewById(R.id.log_checked_imageview);
		log_content_layout = (LinearLayout) findViewById(R.id.log_content_layout);

		log_duigou_imageview = (ImageView) findViewById(R.id.log_duigou_imageview);
		apk_duigou_imageview = (ImageView) findViewById(R.id.apk_duigou_imageview);
		cache_duigou_imageview = (ImageView) findViewById(R.id.cache_duigou_imageview);
		depth_duigou_imageview = (ImageView) findViewById(R.id.depth_duigou_imageview);
		bigfile_duigou_imageview = (ImageView) findViewById(R.id.bigfile_duigou_imageview);

		depth_group_checkbox = (CheckBox) findViewById(R.id.depth_group_checkbox);
		apk_group_checkbox = (CheckBox) findViewById(R.id.apk_group_checkbox);
		log_group_checkbox = (CheckBox) findViewById(R.id.log_group_checkbox);
		cache_group_checkbox = (CheckBox) findViewById(R.id.cache_group_checkbox);
		bigfile_group_checkbox = (CheckBox) findViewById(R.id.bigfile_group_checkbox);

		result_page = (LinearLayout) findViewById(R.id.result_page);
		list_page = (RelativeLayout) findViewById(R.id.list_page);
		ImageView share_imageview = (ImageView) findViewById(R.id.share_imageview);
		share_imageview.setOnClickListener(this);

		cache_clear_expandlistview_layout = (LinearLayout) findViewById(R.id.cache_clear_expandlistview_layout);
		apk_clear_expandlistview_layout = (LinearLayout) findViewById(R.id.apk_clear_expandlistview_layout);
		depth_clear_listview_layout = (LinearLayout) findViewById(R.id.depth_clear_listview_layout);
		bigfile_clear_listview_layout = (LinearLayout) findViewById(R.id.bigfile_clear_listview_layout);

		cache_layout = (LinearLayout) findViewById(R.id.cache_layout);
		depth_layout = (LinearLayout) findViewById(R.id.depth_layout);
		apk_layout = (LinearLayout) findViewById(R.id.apk_layout);
		bigfile_layout = (LinearLayout) findViewById(R.id.bigfile_layout);
		log_layout = (LinearLayout) findViewById(R.id.log_layout);
	}

	private void initResultImageView() {
		ImageView result_icon_imageview = (ImageView) findViewById(R.id.result_icon_imageview);
		int r = (int) (Math.random() * 5);
		int resId = R.drawable.result_page_icon_1;
		switch (r) {
		case 0:
			resId = R.drawable.result_page_icon_2;
			break;
		case 1:
			resId = R.drawable.result_page_icon_3;
			break;
		case 2:
			resId = R.drawable.result_page_icon_4;
			break;
		case 3:
			resId = R.drawable.result_page_icon_5;
			break;

		default:
			break;
		}
		result_icon_imageview.setImageResource(resId);
	}

	public void initBackButton() {
		ImageView banner_back_imageview = (ImageView) findViewById(R.id.banner_back_imageview);
		banner_back_imageview.setVisibility(View.VISIBLE);
		banner_back_imageview.setOnClickListener(this);
		TextView banner_title_textview = (TextView) findViewById(R.id.banner_title_textview);
		banner_title_textview.setOnClickListener(this);
		findViewById(R.id.back_imageview).setOnClickListener(this);
		findViewById(R.id.back_title).setOnClickListener(this);
	}

	class GetCacheThread extends Thread {
		private ArrayList<AppItem> systemCacheList;
		private GroupItem groupItem;
		private ArrayList<GroupItem> groupList = new ArrayList<GroupItem>();
		private ArrayList<ArrayList<AppItem>> childList = new ArrayList<ArrayList<AppItem>>();// 子列表
		private long startTime;

		public GetCacheThread() {
			systemCacheList = new ArrayList<AppItem>();
		}

		@Override
		public void run() {
			super.run();
			new CopyDBUtils(mContext).copyDB();
			startTime = System.currentTimeMillis();
			PackageManager pm = getPackageManager();
			if (mAllPackageInfos == null) {
				mAllPackageInfos = pm.getInstalledPackages(0);
			}
			if (mAllPackageInfos != null && mAllPackageInfos.size() > 0) {
				int packageSize = mAllPackageInfos.size();
				ArrayList<String> keeps = CacheWhiteListUtils.getAllList(mContext);
				for (int i = 0; i < packageSize; i++) {
					if (stop) {
						break;
					}
					PackageInfo packageInfo = mAllPackageInfos.get(i);
					if (packageInfo == null) {
						continue;
					}
					final ApplicationInfo applicationInfo = packageInfo.applicationInfo;
					if (applicationInfo == null) {
						continue;
					}
					if (applicationInfo.packageName.equals(getPackageName())) {
						continue;
					}
					final String sourceDir = applicationInfo.sourceDir;
					if (sourceDir != null) {
						final String appName = applicationInfo.loadLabel(pm).toString();
						Message message = new Message();
						message.what = 1;
						Bundle bundle = new Bundle();
						bundle.putString("name", appName);
						bundle.putInt("progress", i + 1);
						bundle.putInt("max", packageSize);
						message.setData(bundle);
						handler.sendMessage(message);

						final AppItem appItem = new AppItem();
						appItem.setAppPackage(applicationInfo.packageName);
						if (!keeps.contains(appItem.getAppPackage())) {

							ArrayList<ClearItem> clearItems = DBAppCacheUtils.getInstance(mContext).get(mContext, applicationInfo.packageName, getLanguage());

							if (clearItems != null && clearItems.size() > 0) {
								ArrayList<AppItem> cacheList = new ArrayList<AppItem>();
								boolean groupChecked = true;
								for (ClearItem clearItem : clearItems) {
									if (stop) {
										break;
									}
									File file = new File(Constants.SDCARD_PATH, clearItem.getFilePath());
									if (file != null && file.exists()) {
										AppItem cacheItem = new AppItem();
										cacheItem.setCacheSize(FileUtils.getFileSize(file));
										if (cacheItem.getCacheSize() > 0) {
											cacheItem.setFilePath(file.getAbsolutePath());
											cacheItem.setApplicationInfo(applicationInfo);
											cacheItem.setAppName(clearItem.getName());
											if(clearItem.isChecked()){
												cacheItem.setChecked(true);
											}else{
												groupChecked = false;
												cacheItem.setChecked(false);
											}
											totalCacheSize += cacheItem.getCacheSize();
											cacheList.add(cacheItem);
											message = new Message();
											bundle = new Bundle();
											bundle.putString("name", appItem.getAppName());
											bundle.putLong("memory", appItem.getCacheSize());
											message.setData(bundle);
											message.what = 0;
											handler.sendMessage(message);
										}
									}
								}
								if (cacheList.size() > 0) {
									appItem.setGroup(true);
									appItem.setApplicationInfo(applicationInfo);
									appItem.setAppName(appName);

									GroupItem mGroupItem = new GroupItem();
									mGroupItem.setApplicationInfo(applicationInfo);
									mGroupItem.setCount(cacheList.size());
									mGroupItem.setTitle(appItem.getAppName());
									mGroupItem.setChecked(groupChecked);
									groupList.add(mGroupItem);
									childList.add(cacheList);
									handler.sendEmptyMessage(0);
								}
							}

						}

						if (!Terminal.isRoot(mContext) || !keeps.contains(appItem.getAppPackage())) {
							try {
								final CountDownLatch countDownLatch = new CountDownLatch(1);
								Method getPackageSizeInfo = pm.getClass().getMethod("getPackageSizeInfo", String.class, IPackageStatsObserver.class);
								getPackageSizeInfo.invoke(pm, appItem.getAppPackage(), new IPackageStatsObserver.Stub() {
									public void onGetStatsCompleted(PackageStats pStats, boolean succeeded) throws RemoteException {
										if (pStats != null) {
											if (Build.VERSION.SDK_INT >= 11) {
												appItem.setCacheSize(pStats.cacheSize + pStats.externalCacheSize);
											} else {
												appItem.setCacheSize(pStats.cacheSize);
											}
											if (Build.VERSION.SDK_INT > 16) {
												if (appItem.getCacheSize() > 0 && appItem.getCacheSize() != 12288) {
													appItem.setApplicationInfo(applicationInfo);
													appItem.setAppName(appName);
													appItem.setGroup(false);
													appItem.setChecked(false);
													totalCacheSize += appItem.getCacheSize();
													systemCacheList.add(appItem);
													Message message = new Message();
													message.what = 0;
													handler.sendMessage(message);
												}
											} else {
												if (appItem.getCacheSize() > 0) {
													appItem.setApplicationInfo(applicationInfo);
													appItem.setAppName(appName);
													appItem.setGroup(false);
													appItem.setChecked(false);
													totalCacheSize += appItem.getCacheSize();
													systemCacheList.add(appItem);
													Message message = new Message();
													message.what = 0;
													handler.sendMessage(message);
												}
											}
										}
										countDownLatch.countDown();
									}
								});
								countDownLatch.await();
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					}
				}
			}
			if (systemCacheList.size() > 0) {
				groupItem = new GroupItem();
				groupItem.setTitle(getString(R.string.system_cache_title));
				groupItem.setCount(systemCacheList.size());
				groupItem.setIcon(getResources().getDrawable(R.drawable.system_cache_icon));
				if (Terminal.isRoot(mContext)) {
					groupItem.setChecked(true);
					for (AppItem clearItem : systemCacheList) {
						clearItem.setChecked(true);
					}
				} else {
					groupItem.setChecked(false);
				}
				Collections.sort(systemCacheList, new CacheComparator());
				groupList.add(0, groupItem);
				childList.add(0, systemCacheList);
			}
			DLog.i("debug", "缓存扫描时间: " + (System.currentTimeMillis() - startTime) + "毫秒");
			DBAppCacheUtils.getInstance(mContext).close();
			handler.sendEmptyMessage(2);
		}

		Handler handler = new Handler() {

			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				Bundle bundle = null;
				switch (msg.what) {
				case 0:
					updateTotalSize();
					break;
				case 1:
					bundle = msg.getData();
					scan_textview.setText(getString(R.string.clear_scanning, bundle.getString("name")));
					scan_textview.setVisibility(View.VISIBLE);
					break;
				case 2:
					cache_clear_expandlistview = (CustomExpandListView) findViewById(R.id.cache_clear_expandlistview);
					cache_clear_expandlistview.setGroupIndicator(null);
					cache_clear_expandlistview.setOnChildClickListener(DepthClearActivity.this);
					mAdapter4CacheClear = new Adapter4CacheClear(mContext, groupList, childList);
					mAdapter4CacheClear.setCheckListener(new CheckedListener() {

						@Override
						public void someChecked(int count) {
							cache_group_checkbox.setChecked(false);
						}

						@Override
						public void nothingChecked() {
							cache_group_checkbox.setChecked(false);
						}

						@Override
						public void allChecked(int count) {
							cache_group_checkbox.setChecked(true);
						}
					});
					mAdapter4CacheClear.setSelectListener(new SelectListener() {

						@Override
						public void selectSize(long size) {
							selectCacheSize = size;
							updateSelectSize();
						}
					});
					cache_clear_expandlistview.setAdapter(mAdapter4CacheClear);
					mAdapter4CacheClear.updateSelectCacheSize();
					cache_scan_progressbar.setVisibility(View.GONE);
					cache_duigou_imageview.setVisibility(View.VISIBLE);
					updateTotalSize();
					checkEnd();
					break;
				default:
					break;
				}
			}

		};

	}

	class GetDepthThread extends Thread {
		private ArrayList<AppItem> mClearItems;
		private CustomListView depth_clear_listview;
		private long startTime;

		public GetDepthThread() {
			if (mClearItems == null) {
				mClearItems = new ArrayList<AppItem>();
			} else {
				mClearItems.clear();
			}
		}

		@Override
		public void run() {
			super.run();
			new CopyDBUtils(mContext).copyDB();
			startTime = System.currentTimeMillis();
			if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
				if (mAllPackageInfos == null) {
					mAllPackageInfos = getPackageManager().getInstalledPackages(0);
				}
				ArrayList<ClearItem> clearItems = DBAppFolderUtils.get(mContext, getLanguage());
				int tAppCount = mAllPackageInfos.size();
				int tSoftCount = clearItems.size();

				for (int i = 0; i < tSoftCount; i++) {
					if (stop) {
						break;
					}
					File file = new File(Constants.SDCARD_PATH, clearItems.get(i).getFilePath());
					if (file == null || !file.exists()) {
						continue;
					}
					Message message = new Message();
					message.what = 1;
					Bundle bundle = new Bundle();
					bundle.putString("name", file.getAbsolutePath());
					bundle.putInt("progress", i + 1);
					bundle.putInt("max", tSoftCount);
					message.setData(bundle);
					handler.sendMessage(message);

					for (int j = 0; j < tAppCount; j++) {
						if (stop) {
							return;
						}
						if (!clearItems.get(i).getPackageName().contains(",")) {
							if (clearItems.get(i).getPackageName().equals(mAllPackageInfos.get(j).packageName))
								break;
						} else {
							String[] packages = clearItems.get(i).getPackageName().split(",");
							boolean flag = false;
							for (String packageName : packages) {
								if (packageName.equals(mAllPackageInfos.get(j).packageName)) {
									flag = true;
									break;
								}
							}
							if (flag) {
								break;
							}
						}
						if (j == tAppCount - 1) {
							AppItem appItem = new AppItem();
							appItem.setName(clearItems.get(i).getName());
							appItem.setFilePath(file.getAbsolutePath());
							appItem.setCodeSize(GetFileSizeLongByPath(file.getAbsolutePath()));
							appItem.setAppPackage(clearItems.get(i).getPackageName());
							totalDepthSize += appItem.getCodeSize();
							mClearItems.add(appItem);

							checkFile(file, appItem);

							message = new Message();
							bundle = new Bundle();
							bundle.putString("name", appItem.getAppName());
							bundle.putLong("memory", appItem.getCodeSize());
							message.setData(bundle);
							message.what = 0;
							handler.sendMessage(message);
						}
					}
				}
			}
			if (mClearItems != null && mClearItems.size() > 0) {
				Collections.sort(mClearItems, new CodeSizeComparator());
			}
			DLog.i("debug", "残留文件扫描时间: " + (System.currentTimeMillis() - startTime) + "毫秒");
			handler.sendEmptyMessage(2);
		}

		Handler handler = new Handler() {

			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				Bundle bundle = null;
				switch (msg.what) {
				case 0:
					updateTotalSize();
					break;
				case 1:
					bundle = msg.getData();
					scan_textview.setText(getString(R.string.clear_scanning, bundle.getString("name")));
					scan_textview.setVisibility(View.VISIBLE);
					break;
				case 2:
					depth_clear_listview = (CustomListView) findViewById(R.id.depth_clear_listview);
					mAdapter4DepthClear = new Adapter4DepthClear(mContext, mClearItems);
					mAdapter4DepthClear.setCheckListener(new CheckedListener() {

						@Override
						public void someChecked(int count) {
							depth_group_checkbox.setChecked(false);
						}

						@Override
						public void nothingChecked() {
							depth_group_checkbox.setChecked(false);
						}

						@Override
						public void allChecked(int count) {
							depth_group_checkbox.setChecked(true);
						}
					});
					mAdapter4DepthClear.setSelectListener(new SelectListener() {

						@Override
						public void selectSize(long size) {
							selectDepthSize = size;
							updateSelectSize();
						}
					});
					depth_clear_listview.setAdapter(mAdapter4DepthClear);
					depth_clear_listview.setOnItemClickListener(DepthClearActivity.this);

					mAdapter4DepthClear.updateSelectDepthSize();

					depth_scan_progressbar.setVisibility(View.GONE);
					depth_duigou_imageview.setVisibility(View.VISIBLE);
					updateTotalSize();
					checkEnd();
					break;
				default:
					break;
				}
			}

		};

		public long GetFileSizeLongByPath(final String path) {
			File file = new File(path);
			return getFileSize(file);
		}

		public long getFileSize(File f) {
			long size = 0;
			if (f != null && f.isDirectory() && f.exists()) {
				File flist[] = f.listFiles();
				if (flist != null) {
					for (int j = 0; j < flist.length; j++) {

						if (flist[j].isDirectory()) {
							size = size + getFileSize(flist[j]);
						} else {
							size = size + flist[j].length();
						}
					}

				}
			}
			return size;
		}

	}

	class GetApkThread extends Thread {
		private ArrayList<AppItem> unInstallApks;
		private ArrayList<AppItem> installApks;
		private ArrayList<GroupItem> groupList = new ArrayList<GroupItem>();
		private ArrayList<ArrayList<AppItem>> childList = new ArrayList<ArrayList<AppItem>>();// 子列表
		private ArrayList<BigFileGroup> bigFiles = new ArrayList<BigFileGroup>();
		private ArrayList<BigFileItem> audioFiles = new ArrayList<BigFileItem>();
		private ArrayList<BigFileItem> videoFiles = new ArrayList<BigFileItem>();
		private ArrayList<BigFileItem> docFiles = new ArrayList<BigFileItem>();
		private ArrayList<BigFileItem> otherFiles = new ArrayList<BigFileItem>();
		private CustomListView bigfile_clear_listview;
		private long startTime;
		private JSONObject suffixJsonObject = null;
		private String audioSuffix = ".mp3.wma.ogg.aac.wav.flac.ape";
		private String videoSuffix = ".flv.avi.wmv.vob.mp4.mkv.mov";
		private String docSuffix = ".doc.xls.ppt.docx.xlsx.pptx.pdf";

		public GetApkThread() {

			SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(mContext);
			apkPathInit = sp.getBoolean("apkPathInit", false);
			String suffix_json = sp.getString("suffix_json", null);
			if (TextUtils.isEmpty(suffix_json)) {
				suffixJsonObject = new JSONObject();
			} else {
				try {
					suffixJsonObject = new JSONObject(suffix_json);
				} catch (JSONException e) {
					e.printStackTrace();
				}
			}
			if (installApks == null) {
				installApks = new ArrayList<AppItem>();
			} else {
				installApks.clear();
			}
			if (unInstallApks == null) {
				unInstallApks = new ArrayList<AppItem>();
			} else {
				unInstallApks.clear();
			}

			GroupItem groupItem = new GroupItem();
			groupItem.setTitle(getString(R.string.app_type_install));
			groupItem.setChecked(true);
			groupItem.setIcon(getResources().getDrawable(R.drawable.install_icon));
			groupList.add(groupItem);

			groupItem = new GroupItem();
			groupItem.setTitle(getString(R.string.app_type_uninstall));
			groupItem.setChecked(false);
			groupItem.setIcon(getResources().getDrawable(R.drawable.uninstall_icon));
			groupList.add(groupItem);

			childList.add(installApks);
			childList.add(unInstallApks);
		}

		@Override
		public void run() {
			super.run();
			startTime = System.currentTimeMillis();

			if (apkPathInit) {
				ArrayList<String> apkPathList = DBApkPathUtils.getApkPathList(mContext);
				if (apkPathList != null && apkPathList.size() > 0) {
					for (int i = 0; i < apkPathList.size(); i++) {
						File file = new File(SDCARDPATH, apkPathList.get(i));
						Message message = new Message();
						message.what = 1;
						Bundle bundle = new Bundle();
						bundle.putString("name", file.getAbsolutePath());
						message.setData(bundle);
						handler.sendMessage(message);
						if (stop) {
							break;
						}
						listApkFile(file);
					}
				}

				ArrayList<String> bigFilePathList = DBBigFilePathUtils.getBigFilePathList(mContext);
				if (bigFilePathList != null && bigFilePathList.size() > 0) {
					for (int i = 0; i < bigFilePathList.size(); i++) {
						File file = new File(SDCARDPATH, bigFilePathList.get(i));
						Message message = new Message();
						message.what = 1;
						Bundle bundle = new Bundle();
						bundle.putString("name", file.getAbsolutePath());
						message.setData(bundle);
						handler.sendMessage(message);
						if (stop) {
							break;
						}
						listBigFile(file);
					}
				}

				ArrayList<String> logPathList = DBLogPathUtils.getLogPathList(mContext);
				if (logPathList != null && logPathList.size() > 0) {
					for (int i = 0; i < logPathList.size(); i++) {
						File file = new File(SDCARDPATH, logPathList.get(i));
						Message message = new Message();
						message.what = 1;
						Bundle bundle = new Bundle();
						bundle.putString("name", file.getAbsolutePath());
						message.setData(bundle);
						handler.sendMessage(message);
						if (stop) {
							break;
						}
						listLogFile(file);
					}
				}

				File file = new File(SDCARDPATH);
				Message message = new Message();
				message.what = 1;
				Bundle bundle = new Bundle();
				bundle.putString("name", file.getAbsolutePath());
				message.setData(bundle);
				handler.sendMessage(message);
				listFilePath(file);

			} else {
				File[] sdcardfiles = new File(SDCARDPATH).listFiles();
				if (sdcardfiles != null && sdcardfiles.length > 0) {
					for (int i = 0; i < sdcardfiles.length; i++) {
						if (stop) {
							break;
						}
						File file = sdcardfiles[i];
						Message message = new Message();
						message.what = 1;
						Bundle bundle = new Bundle();
						bundle.putString("name", file.getAbsolutePath());
						bundle.putInt("progress", i + 1);
						bundle.putInt("max", sdcardfiles.length);
						message.setData(bundle);
						handler.sendMessage(message);
						ergodicFiles(file);
					}
				}
			}

			if (audioFiles.size() > 0) {
				BigFileGroup bigFileGroup = new BigFileGroup();
				bigFileGroup.setChecked(false);
				bigFileGroup.setType(BigFileGroup.type_audio);
				bigFileGroup.setTypeIcon(getResources().getDrawable(R.drawable.group_icon_audio));
				bigFileGroup.setTypeName("音乐");
				bigFileGroup.setBigFileItems(audioFiles);
				long size = 0;
				for (BigFileItem bigFileItem : audioFiles) {
					size += bigFileItem.getSize();
				}
				bigFileGroup.setSize(size);
				bigFiles.add(bigFileGroup);
			}

			if (videoFiles.size() > 0) {
				BigFileGroup bigFileGroup = new BigFileGroup();
				bigFileGroup.setChecked(false);
				bigFileGroup.setType(BigFileGroup.type_video);
				bigFileGroup.setTypeIcon(getResources().getDrawable(R.drawable.group_icon_video));
				bigFileGroup.setTypeName("视频");
				bigFileGroup.setBigFileItems(videoFiles);
				long size = 0;
				for (BigFileItem bigFileItem : videoFiles) {
					size += bigFileItem.getSize();
				}
				bigFileGroup.setSize(size);
				bigFiles.add(bigFileGroup);
			}

			if (docFiles.size() > 0) {
				BigFileGroup bigFileGroup = new BigFileGroup();
				bigFileGroup.setChecked(false);
				bigFileGroup.setType(BigFileGroup.type_doc);
				bigFileGroup.setTypeIcon(getResources().getDrawable(R.drawable.group_icon_doc));
				bigFileGroup.setTypeName("文档");
				bigFileGroup.setBigFileItems(docFiles);
				long size = 0;
				for (BigFileItem bigFileItem : docFiles) {
					size += bigFileItem.getSize();
				}
				bigFileGroup.setSize(size);
				bigFiles.add(bigFileGroup);
			}
			if (otherFiles.size() > 0) {
				BigFileGroup bigFileGroup = new BigFileGroup();
				bigFileGroup.setChecked(false);
				bigFileGroup.setType(BigFileGroup.type_other);
				bigFileGroup.setTypeIcon(getResources().getDrawable(R.drawable.group_icon_other));
				bigFileGroup.setTypeName("其他");
				bigFileGroup.setBigFileItems(otherFiles);
				long size = 0;
				for (BigFileItem bigFileItem : otherFiles) {
					size += bigFileItem.getSize();
					bigFileItem.setChecked(false);
				}
				bigFileGroup.setSize(size);
				bigFiles.add(bigFileGroup);
			}

			if (installApks != null && installApks.size() > 0) {
				Collections.sort(installApks, new CodeSizeComparator());
			}
			if (unInstallApks != null || unInstallApks.size() > 0) {
				Collections.sort(unInstallApks, new CodeSizeComparator());
			}
			DLog.i("debug", "apk扫描时间: " + (System.currentTimeMillis() - startTime) + "毫秒");
			handler.sendEmptyMessage(2);
		}

		Handler handler = new Handler() {

			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				Bundle bundle = null;
				switch (msg.what) {
				case 0:
					updateTotalSize();
					break;
				case 1:
					bundle = msg.getData();
					scan_textview.setText(getString(R.string.clear_scanning, bundle.getString("name")));
					scan_textview.setVisibility(View.VISIBLE);
					break;
				case 2:
					apk_clear_expandlistview = (CustomExpandListView) findViewById(R.id.apk_clear_expandlistview);
					apk_clear_expandlistview.setGroupIndicator(null);
					apk_clear_expandlistview.setOnChildClickListener(DepthClearActivity.this);

					bigfile_clear_listview = (CustomListView) findViewById(R.id.bigfile_clear_listview);

					mAdapter4ApkClear = new Adapter4ApkClear(mContext, groupList, childList);
					mAdapter4ApkClear.setCheckListener(new CheckedListener() {

						@Override
						public void someChecked(int count) {
							apk_group_checkbox.setChecked(false);
						}

						@Override
						public void nothingChecked() {
							apk_group_checkbox.setChecked(false);
						}

						@Override
						public void allChecked(int count) {
							apk_group_checkbox.setChecked(true);
						}
					});
					mAdapter4ApkClear.setSelectListener(new SelectListener() {

						@Override
						public void selectSize(long size) {
							selectApkSize = size;
							updateSelectSize();
						}
					});
					apk_clear_expandlistview.setAdapter(mAdapter4ApkClear);

					mAdapter4BigFileClear = new Adapter4BigFileGroup(mContext, bigFiles);
					mAdapter4BigFileClear.setCheckListener(new CheckedListener() {

						@Override
						public void someChecked(int count) {
							bigfile_group_checkbox.setChecked(false);
						}

						@Override
						public void nothingChecked() {
							bigfile_group_checkbox.setChecked(false);
						}

						@Override
						public void allChecked(int count) {
							bigfile_group_checkbox.setChecked(true);
						}
					});
					mAdapter4BigFileClear.setSelectListener(new SelectListener() {

						@Override
						public void selectSize(long size) {
							selectBigFileSize = size;
							updateSelectSize();
						}
					});
					bigfile_clear_listview.setAdapter(mAdapter4BigFileClear);
					bigfile_clear_listview.setOnItemClickListener(DepthClearActivity.this);

					mAdapter4ApkClear.updateSelectApkSize();

					apk_scan_progressbar.setVisibility(View.GONE);
					apk_duigou_imageview.setVisibility(View.VISIBLE);

					bigfile_scan_progressbar.setVisibility(View.GONE);
					bigfile_duigou_imageview.setVisibility(View.VISIBLE);

					if (logList.size() == 0) {
						log_checked_imageview.setChecked(false);
					} else {
						log_checked_imageview.setChecked(true);
					}
					log_scan_progressbar.setVisibility(View.GONE);
					log_duigou_imageview.setVisibility(View.VISIBLE);
					log_checked_imageview.setOnClickListener(DepthClearActivity.this);
					updateTotalSize();
					checkEnd();

					if (!apkPathInit) {
						new Thread(new Runnable() {
							public void run() {
								if (apkCollectionPaths != null && apkCollectionPaths.size() > 0) {
									Iterator<String> iterator = apkCollectionPaths.iterator();
									ArrayList<String> paths = new ArrayList<String>();
									while (iterator.hasNext()) {
										paths.add(iterator.next());
									}
									try {
										DBApkPathUtils.save(getApplicationContext(), paths);
									} catch (Exception e) {
										e.printStackTrace();
									}
								}

								if (bigfileCollectionPaths != null && bigfileCollectionPaths.size() > 0) {
									Iterator<String> iterator = bigfileCollectionPaths.iterator();
									ArrayList<String> paths = new ArrayList<String>();
									while (iterator.hasNext()) {
										paths.add(iterator.next());
									}
									try {
										DBBigFilePathUtils.save(getApplicationContext(), paths);
									} catch (Exception e) {
										e.printStackTrace();
									}
								}

								if (logCollectionPaths != null && logCollectionPaths.size() > 0) {
									Iterator<String> iterator = logCollectionPaths.iterator();
									ArrayList<String> paths = new ArrayList<String>();
									while (iterator.hasNext()) {
										paths.add(iterator.next());
									}
									try {
										DBLogPathUtils.save(getApplicationContext(), paths);
									} catch (Exception e) {
										e.printStackTrace();
									}
								}

								SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
								sp.edit().putBoolean("apkPathInit", true).commit();
							}
						}).start();
					}
					break;

				default:
					break;
				}
			}

		};

		/**
		 * 遍历file
		 */
		public void ergodicFiles(File file) {
			if (file.isFile() && !file.isHidden()) {
				String fileName = file.getName();

				if (fileName != null && fileName.length() != 0) {
					if (fileName.endsWith(".apk")) {
						AppItem appItem = new AppItem();
						appItem.setAppName(file.getName());
						appItem.setFilePath(file.getAbsolutePath());
						if (fillApkModel(appItem)) {
							totalApkSize += appItem.getCodeSize();
							if (appItem.isInstall()) {
								installApks.add(appItem);
								groupList.get(0).setCount(installApks.size());
							} else {
								unInstallApks.add(appItem);
								groupList.get(1).setCount(unInstallApks.size());
							}
							Message message = new Message();
							Bundle bundle = new Bundle();
							bundle.putString("name", appItem.getAppName());
							bundle.putLong("memory", appItem.getCodeSize());
							message.setData(bundle);
							message.what = 0;
							handler.sendMessage(message);
							if (!apkPathInit) {
								addApkCollectionPath(appItem.getFilePath());
							}
						} else {
							appItem.setAppName(getString(R.string.apk_not_full));
							appItem.setChecked(true);
							appItem.setInstall(false);
							appItem.setCodeSize(file.length());
							appItem.setAppIcon(getResources().getDrawable(android.R.drawable.sym_def_app_icon));
							totalApkSize += appItem.getCodeSize();
							if (appItem.isInstall()) {
								installApks.add(appItem);
								groupList.get(0).setCount(installApks.size());
							} else {
								unInstallApks.add(appItem);
								groupList.get(1).setCount(unInstallApks.size());
							}
							Message message = new Message();
							Bundle bundle = new Bundle();
							bundle.putString("name", appItem.getAppName());
							bundle.putLong("memory", appItem.getCodeSize());
							message.setData(bundle);
							message.what = 0;
							handler.sendMessage(message);
							if (!apkPathInit) {
								addApkCollectionPath(appItem.getFilePath());
							}
						}
					} else if (fileName.endsWith(".log")) {
						logList.add(file.getAbsolutePath());
						totalLogSize += file.length();
						selectLogSize += file.length();
						handler.sendEmptyMessage(0);
						if (!apkPathInit) {
							addLogCollectionPath(file.getAbsolutePath());
						}
					} else {
						String suffixName = "";
						if (fileName.contains(".")) {
							suffixName = fileName.substring(fileName.lastIndexOf("."));
						}
						if (!suffixJsonObject.optString("suffix_type").contains(suffixName) && file.length() >= 10 * 1024 * 1024) {
							BigFileItem appItem = new BigFileItem();
							appItem.setName(file.getName());
							appItem.setPath(file.getAbsolutePath());
							appItem.setChecked(false);
							appItem.setSize(file.length());

							if (audioSuffix.contains(suffixName)) {
								audioFiles.add(appItem);
							} else if (videoSuffix.contains(suffixName)) {
								videoFiles.add(appItem);
							} else if (docSuffix.contains(suffixName)) {
								docFiles.add(appItem);
							} else {
								otherFiles.add(appItem);
							}
							totalBigFileSize += file.length();
							Message message = new Message();
							Bundle bundle = new Bundle();
							bundle.putString("name", appItem.getName());
							bundle.putLong("memory", appItem.getSize());
							message.setData(bundle);
							message.what = 0;
							handler.sendMessage(message);
							if (!apkPathInit) {
								addBigFileCollectionPath(file.getAbsolutePath());
							}
						}
					}
				}
			} else { // 如果不是文件那么继续遍历子文件夹中的内容
				for (String exceptDir : EXCEPTPATH) {
					if (exceptDir.equals(StringUtil.link(file.getAbsolutePath(), "/"))) {
						DLog.i("debug", StringUtil.link("exceptDir :", file.getAbsolutePath()));
						return;
					}
				}
				File[] fileArr = file.listFiles();
				if (fileArr != null && fileArr.length != 0) {
					for (File mFile : fileArr) {
						if (stop) {
							break;
						}
						ergodicFiles(mFile);
					}
				}

			}

		}

		/**
		 * 遍历file
		 */
		public void listFilePath(File path) {
			if (path.isDirectory()) {
				File[] files = path.listFiles();
				if (files != null) {
					for (File file : files) {
						String fileName = file.getName();
						if (fileName != null && fileName.length() != 0) {
							if (fileName.endsWith(".apk")) {

								AppItem appItem = new AppItem();
								appItem.setAppName(file.getName());
								appItem.setFilePath(file.getAbsolutePath());
								if (fillApkModel(appItem)) {
									totalApkSize += appItem.getCodeSize();
									if (appItem.isInstall()) {
										installApks.add(appItem);
										groupList.get(0).setCount(installApks.size());
									} else {
										unInstallApks.add(appItem);
										groupList.get(1).setCount(unInstallApks.size());
									}
									Message message = new Message();
									Bundle bundle = new Bundle();
									bundle.putString("name", appItem.getAppName());
									bundle.putLong("memory", appItem.getCodeSize());
									message.setData(bundle);
									message.what = 0;
									handler.sendMessage(message);
									if (!apkPathInit) {
										addApkCollectionPath(appItem.getFilePath());
									}
								} else {
									appItem.setAppName(getString(R.string.apk_not_full));
									appItem.setChecked(true);
									appItem.setInstall(false);
									appItem.setCodeSize(file.length());
									appItem.setAppIcon(getResources().getDrawable(android.R.drawable.sym_def_app_icon));
									totalApkSize += appItem.getCodeSize();
									if (appItem.isInstall()) {
										installApks.add(appItem);
										groupList.get(0).setCount(installApks.size());
									} else {
										unInstallApks.add(appItem);
										groupList.get(1).setCount(unInstallApks.size());
									}
									Message message = new Message();
									Bundle bundle = new Bundle();
									bundle.putString("name", appItem.getAppName());
									bundle.putLong("memory", appItem.getCodeSize());
									message.setData(bundle);
									message.what = 0;
									handler.sendMessage(message);
								}
							} else if (fileName.endsWith(".log")) {
								logList.add(file.getAbsolutePath());
								totalLogSize += file.length();
								selectLogSize += file.length();
								handler.sendEmptyMessage(0);
							} else {
								String suffixName = "";
								if (fileName.contains(".")) {
									suffixName = fileName.substring(fileName.lastIndexOf("."));
								}
								if (!suffixJsonObject.optString("suffix_type").contains(suffixName) && file.length() >= 10 * 1024 * 1024) {
									BigFileItem appItem = new BigFileItem();
									appItem.setName(file.getName());
									appItem.setPath(file.getAbsolutePath());
									appItem.setChecked(false);
									appItem.setSize(file.length());

									if (audioSuffix.contains(suffixName)) {
										audioFiles.add(appItem);
									} else if (videoSuffix.contains(suffixName)) {
										videoFiles.add(appItem);
									} else if (docSuffix.contains(suffixName)) {
										docFiles.add(appItem);
									} else {
										otherFiles.add(appItem);
									}
									totalBigFileSize += file.length();
									Message message = new Message();
									Bundle bundle = new Bundle();
									bundle.putString("name", appItem.getName());
									bundle.putLong("memory", appItem.getSize());
									message.setData(bundle);
									message.what = 0;
									handler.sendMessage(message);
								}
							}

						}
					}
				}
			}
		}

		/**
		 * 遍历apk file
		 */
		public void listApkFile(File path) {
			if (path.isDirectory()) {
				File[] files = path.listFiles(new FileFilter() {

					@Override
					public boolean accept(File pathname) {
						if (pathname.getName().endsWith(".apk")) {
							return true;
						}
						return false;
					}
				});
				if (files != null) {
					for (File file : files) {
						String fileName = file.getName();
						if (fileName != null && fileName.length() != 0) {
							AppItem appItem = new AppItem();
							appItem.setAppName(file.getName());
							appItem.setFilePath(file.getAbsolutePath());
							if (fillApkModel(appItem)) {
								totalApkSize += appItem.getCodeSize();
								if (appItem.isInstall()) {
									installApks.add(appItem);
									groupList.get(0).setCount(installApks.size());
								} else {
									unInstallApks.add(appItem);
									groupList.get(1).setCount(unInstallApks.size());
								}
								Message message = new Message();
								Bundle bundle = new Bundle();
								bundle.putString("name", appItem.getAppName());
								bundle.putLong("memory", appItem.getCodeSize());
								message.setData(bundle);
								message.what = 0;
								handler.sendMessage(message);
								if (!apkPathInit) {
									addApkCollectionPath(appItem.getFilePath());
								}
							} else {
								appItem.setAppName(getString(R.string.apk_not_full));
								appItem.setChecked(true);
								appItem.setInstall(false);
								appItem.setCodeSize(file.length());
								appItem.setAppIcon(getResources().getDrawable(android.R.drawable.sym_def_app_icon));
								totalApkSize += appItem.getCodeSize();
								if (appItem.isInstall()) {
									installApks.add(appItem);
									groupList.get(0).setCount(installApks.size());
								} else {
									unInstallApks.add(appItem);
									groupList.get(1).setCount(unInstallApks.size());
								}
								Message message = new Message();
								Bundle bundle = new Bundle();
								bundle.putString("name", appItem.getAppName());
								bundle.putLong("memory", appItem.getCodeSize());
								message.setData(bundle);
								message.what = 0;
								handler.sendMessage(message);
							}
						}
					}
				}
			}
		}

		/**
		 * 遍历big file
		 */
		public void listBigFile(File path) {
			if (path.isDirectory()) {
				File[] files = path.listFiles();
				if (files != null) {
					for (File file : files) {
						if(file.isDirectory()){
							continue;
						}
						String suffixName = "";
						String fileName = file.getName();
						if (fileName.contains(".")) {
							suffixName = fileName.substring(fileName.lastIndexOf("."));
						}
						if (!suffixJsonObject.optString("suffix_type").contains(suffixName) && file.length() >= 10 * 1024 * 1024) {
							BigFileItem appItem = new BigFileItem();
							appItem.setName(file.getName());
							appItem.setPath(file.getAbsolutePath());
							appItem.setChecked(false);
							appItem.setSize(file.length());

							if (audioSuffix.contains(suffixName)) {
								audioFiles.add(appItem);
							} else if (videoSuffix.contains(suffixName)) {
								videoFiles.add(appItem);
							} else if (docSuffix.contains(suffixName)) {
								docFiles.add(appItem);
							} else {
								otherFiles.add(appItem);
							}
							totalBigFileSize += file.length();
							Message message = new Message();
							Bundle bundle = new Bundle();
							bundle.putString("name", appItem.getName());
							bundle.putLong("memory", appItem.getSize());
							message.setData(bundle);
							message.what = 0;
							handler.sendMessage(message);
						}
					}
				}
			}
		}

		/**
		 * 遍历log file
		 */
		public void listLogFile(File path) {
			if (path.isDirectory()) {
				File[] files = path.listFiles(new FileFilter() {

					@Override
					public boolean accept(File pathname) {
						if (pathname.getName().endsWith(".log")) {
							return true;
						}
						return false;
					}
				});
				if (files != null) {
					for (File file : files) {
						logList.add(file.getAbsolutePath());
						totalLogSize += file.length();
						selectLogSize += file.length();
						handler.sendEmptyMessage(0);
					}
				}

			}
		}

		public boolean fillApkModel(AppItem info) {
			String filepath = info.getFilePath();
			File file = new File(filepath);
			if (file == null || !file.exists()) {
				return false;
			}
			info.setCodePath(filepath);
			info.setCodeSize(file.length());
			String PATH_PackageParser = "android.content.pm.PackageParser";
			String PATH_AssetManager = "android.content.res.AssetManager";
			try {
				// 反射得到pkgParserCls对象并实例化,有参数
				Class<?> pkgParserCls = Class.forName(PATH_PackageParser);
				Class<?>[] typeArgs = null;
				Object[] valueArgs = null;
				Object pkgParser = null;
				try {
					typeArgs = new Class<?>[] { String.class };
					Constructor<?> pkgParserCt = pkgParserCls.getConstructor(typeArgs);
					valueArgs = new Object[] { filepath };
					pkgParser = pkgParserCt.newInstance(valueArgs);
				} catch (Exception e1) {
					Constructor<?> pkgParserCt = pkgParserCls.getConstructor();
					pkgParser = pkgParserCt.newInstance();
				}
				if (pkgParser == null) {
					return false;
				}

				// 从pkgParserCls类得到parsePackage方法
				Object pkgParserPkg = null;
				try {
					DisplayMetrics metrics = new DisplayMetrics();
					metrics.setToDefaults();// 这个是与显示有关的, 这边使用默认
					typeArgs = new Class<?>[] { File.class, String.class, DisplayMetrics.class, int.class };
					Method pkgParser_parsePackageMtd = pkgParserCls.getDeclaredMethod("parsePackage", typeArgs);
					valueArgs = new Object[] { new File(filepath), filepath, metrics, 0 };
					// 执行pkgParser_parsePackageMtd方法并返回
					pkgParserPkg = pkgParser_parsePackageMtd.invoke(pkgParser, valueArgs);
				} catch (Exception e1) {
					typeArgs = new Class<?>[] { File.class, int.class };
					Method pkgParser_parsePackageMtd = pkgParserCls.getDeclaredMethod("parsePackage", typeArgs);
					valueArgs = new Object[] { new File(filepath), 0 };
					// 执行pkgParser_parsePackageMtd方法并返回
					pkgParserPkg = pkgParser_parsePackageMtd.invoke(pkgParser, valueArgs);
				}
				// 从返回的对象得到名为"applicationInfo"的字段对象
				if (pkgParserPkg == null) {
					return false;
				}
				Field appInfoFld = pkgParserPkg.getClass().getDeclaredField("applicationInfo");

				// 从对象"pkgParserPkg"得到字段"appInfoFld"的值
				if (appInfoFld.get(pkgParserPkg) == null) {
					return false;
				}
				ApplicationInfo applicationInfo = (ApplicationInfo) appInfoFld.get(pkgParserPkg);

				// 反射得到assetMagCls对象并实例化,无参
				Class<?> assetMagCls = Class.forName(PATH_AssetManager);
				Object assetMag = assetMagCls.newInstance();
				// 从assetMagCls类得到addAssetPath方法
				typeArgs = new Class[1];
				typeArgs[0] = String.class;
				Method assetMag_addAssetPathMtd = assetMagCls.getDeclaredMethod("addAssetPath", typeArgs);
				valueArgs = new Object[1];
				valueArgs[0] = filepath;
				// 执行assetMag_addAssetPathMtd方法
				assetMag_addAssetPathMtd.invoke(assetMag, valueArgs);

				// 得到Resources对象并实例化,有参数
				Resources res = getResources();
				typeArgs = new Class[3];
				typeArgs[0] = assetMag.getClass();
				typeArgs[1] = res.getDisplayMetrics().getClass();
				typeArgs[2] = res.getConfiguration().getClass();
				Constructor<Resources> resCt = Resources.class.getConstructor(typeArgs);
				valueArgs = new Object[3];
				valueArgs[0] = assetMag;
				valueArgs[1] = res.getDisplayMetrics();
				valueArgs[2] = res.getConfiguration();
				res = (Resources) resCt.newInstance(valueArgs);

				// 读取apk文件的信息
				if (applicationInfo != null) {
					if (applicationInfo.icon != 0) {// 图片存在，则读取相关信息
						Drawable icon = res.getDrawable(applicationInfo.icon);// 图标
						if (icon != null) {
							info.setAppIcon(icon);
						} else {
							info.setAppIcon(mContext.getResources().getDrawable(android.R.drawable.sym_def_app_icon));
						}
					}
					if (applicationInfo.labelRes != 0) {
						String neme = (String) res.getText(applicationInfo.labelRes);// 名字
						info.setAppName(neme);
					} else {
						String apkName = file.getName();
						info.setAppName(apkName.substring(0, apkName.lastIndexOf(".")));
					}
					String pkgName = applicationInfo.packageName;// 包名
					info.setAppPackage(pkgName);
				} else {
					return false;
				}

				PackageManager packageManager = getPackageManager();
				PackageInfo packageInfo = null;
				try {
					packageInfo = packageManager.getPackageInfo(info.getAppPackage(), 0);
				} catch (NameNotFoundException e) {
				}
				if (packageInfo != null) {
					info.setInstall(true);
					info.setChecked(true);
				} else {
					info.setInstall(false);
					info.setChecked(false);
				}
				return true;
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
		}

	}

	private void updateListView() {
		if (mAdapter4CacheClear != null && mAdapter4CacheClear.getGroupCount() == 0) {
			cache_clear_expandlistview_layout.setVisibility(View.GONE);
			cache_title_layout.setClickable(false);
		}

		if (mAdapter4DepthClear != null && mAdapter4DepthClear.getCount() == 0) {
			depth_clear_listview_layout.setVisibility(View.GONE);
			depth_title_layout.setClickable(false);
		}
		if (mAdapter4ApkClear != null && mAdapter4ApkClear.getGroupCount() == 0) {
			apk_clear_expandlistview_layout.setVisibility(View.GONE);
			apk_title_layout.setClickable(false);
		}

	}

	public void updateSelectSize() {
		if (end) {
			header_content_textview.setVisibility(View.VISIBLE);
			header_content_textview.setText(getString(R.string.clear_select_memory_size,
					FormatUtils.formatBytesInByte(selectCacheSize + selectDepthSize + selectApkSize + selectLogSize + selectBigFileSize)));
		}
	}

	public long getAllSelectSize() {

		return selectCacheSize + selectDepthSize + selectApkSize + selectLogSize + selectBigFileSize;
	}

	private void updateTotalSize() {
		long totalSize = totalApkSize + totalCacheSize + totalDepthSize + totalLogSize + totalBigFileSize;
		String size = FormatUtils.formatBytesInByte2(totalSize);
		header_memory_textview.setText(size.substring(0, size.length() - 2));
		header_unit_textview.setText(size.substring(size.length() - 2, size.length()));

		cache_size_textview.setText(FormatUtils.formatBytesInByte(totalCacheSize));
		apk_size_textview.setText(FormatUtils.formatBytesInByte(totalApkSize));
		depth_size_textview.setText(FormatUtils.formatBytesInByte(totalDepthSize));
		log_size_textview.setText(FormatUtils.formatBytesInByte(totalLogSize));
		bigfile_size_textview.setText(FormatUtils.formatBytesInByte(totalBigFileSize));

		float f = totalSize * 100f / totalMemory;
		header_waterwave_view.setWaterLevel(f);
		header_waterwave_view.startWave();
	}

	private void checkEnd() {
		boolean b = true;
		if (cache_duigou_imageview.getVisibility() == View.GONE) {
			b = false;
		}
		if (depth_duigou_imageview.getVisibility() == View.GONE) {
			b = false;
		}
		if (log_duigou_imageview.getVisibility() == View.GONE) {
			b = false;
		}
		if (apk_duigou_imageview.getVisibility() == View.GONE) {
			b = false;
		}
		if (bigfile_duigou_imageview.getVisibility() == View.GONE) {
			b = false;
		}
		if (b) {
			progress_layout.setVisibility(View.GONE);

			clear_button.setText(R.string.one_clear_button);
			end = true;
			updateSelectSize();

			depth_group_checkbox.setVisibility(View.VISIBLE);
			bigfile_group_checkbox.setVisibility(View.VISIBLE);
			cache_group_checkbox.setVisibility(View.VISIBLE);
			log_group_checkbox.setVisibility(View.VISIBLE);
			apk_group_checkbox.setVisibility(View.VISIBLE);

			depth_group_checkbox.setOnClickListener(this);
			bigfile_group_checkbox.setOnClickListener(this);
			cache_group_checkbox.setOnClickListener(this);
			log_group_checkbox.setOnClickListener(this);
			apk_group_checkbox.setOnClickListener(this);

			cache_size_textview.setVisibility(View.VISIBLE);
			cache_size_textview.setText(FormatUtils.formatBytesInByte(totalCacheSize));
			cache_duigou_imageview.setVisibility(View.GONE);
			if (mAdapter4CacheClear != null && mAdapter4CacheClear.getGroupCount() > 0) {
				cache_clear_expandlistview_layout.setVisibility(View.VISIBLE);
				cache_title_layout.setClickable(true);
			} else {
				cache_title_layout.setClickable(false);
			}

			depth_size_textview.setVisibility(View.VISIBLE);
			depth_size_textview.setText(FormatUtils.formatBytesInByte(totalDepthSize));
			depth_duigou_imageview.setVisibility(View.GONE);
			if (mAdapter4DepthClear != null && mAdapter4DepthClear.getCount() > 0) {
				depth_clear_listview_layout.setVisibility(View.VISIBLE);
				depth_title_layout.setClickable(true);
			} else {
				depth_title_layout.setClickable(false);
			}

			apk_size_textview.setVisibility(View.VISIBLE);
			apk_size_textview.setText(FormatUtils.formatBytesInByte(totalApkSize));
			apk_duigou_imageview.setVisibility(View.GONE);
			if (mAdapter4ApkClear != null && mAdapter4ApkClear.getGroupCount() > 0) {
				apk_clear_expandlistview_layout.setVisibility(View.VISIBLE);
				apk_title_layout.setClickable(true);
			} else {
				apk_title_layout.setClickable(false);
			}

			bigfile_size_textview.setVisibility(View.VISIBLE);
			bigfile_size_textview.setText(FormatUtils.formatBytesInByte(totalBigFileSize));
			bigfile_duigou_imageview.setVisibility(View.GONE);

			if (mAdapter4BigFileClear != null && mAdapter4BigFileClear.getCount() > 0) {
				bigfile_clear_listview_layout.setVisibility(View.VISIBLE);
				bigfile_title_layout.setClickable(true);
			} else {
				bigfile_title_layout.setClickable(false);
			}

			log_count_textview.setText("" + logList.size());
			log_size_textview.setVisibility(View.VISIBLE);
			log_size_textview.setText(FormatUtils.formatBytesInByte(totalLogSize));
			log_duigou_imageview.setVisibility(View.GONE);

			if (logList != null && logList.size() > 0) {
				log_content_layout.setVisibility(View.VISIBLE);
				log_title_layout.setClickable(true);
				log_group_checkbox.setChecked(true);
			} else {
				log_title_layout.setClickable(false);
				log_group_checkbox.setChecked(false);
			}

			if ((totalCacheSize + totalApkSize + totalDepthSize + totalLogSize + totalBigFileSize) == 0) {
				// list_page.setVisibility(View.GONE);
				// result_page.setVisibility(View.VISIBLE);
				// findViewById(R.id.yiqingli_textview).setVisibility(View.GONE);
				// TextView result_clear_size_textview = (TextView)
				// findViewById(R.id.result_clear_size_textview);
				// result_clear_size_textview.setText(R.string.depth_clear_end_null);
				// TODO
			}
		}
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.clear_button:
			if (clear_button.getText().equals(getString(R.string.stop_scan_button))) {
				stop = true;
				clear_button.setText(R.string.scan_button_stoping);
			} else if (clear_button.getText().equals(getString(R.string.one_clear_button))) {
				CustomEventCommit.commit(mContext, CustomEventCommit.button_shendu_click);
				boolean b = false;
				if (mAdapter4CacheClear != null && mAdapter4CacheClear.getSelectClearList().size() > 0) {
					b = true;
				}
				if (mAdapter4CacheClear != null && mAdapter4CacheClear.getGroupCount() > 0 && ((GroupItem) mAdapter4CacheClear.getGroup(0)).isChecked()) {
					b = true;
				}

				if (mAdapter4ApkClear != null && mAdapter4ApkClear.getSelectApkList().size() > 0) {
					b = true;
				}

				if (mAdapter4DepthClear != null && mAdapter4DepthClear.getSelecteList().size() > 0) {
					b = true;
				}

				if (mAdapter4BigFileClear != null && mAdapter4BigFileClear.getSelecteList().size() > 0) {
					b = true;
				}

				if (log_checked_imageview.isChecked()) {
					b = true;
				}

				if (b) {
					depth_group_checkbox.setVisibility(View.GONE);
					bigfile_group_checkbox.setVisibility(View.GONE);
					cache_group_checkbox.setVisibility(View.GONE);
					log_group_checkbox.setVisibility(View.GONE);
					apk_group_checkbox.setVisibility(View.GONE);

					clear_button.setClickable(false);
					clear_button.setText("正在清理");
					if (mAdapter4CacheClear != null) {
						for (int i = 0; i < mAdapter4CacheClear.getGroupCount(); i++) {
							cache_clear_expandlistview.collapseGroup(i);
						}
					}
					if (mAdapter4ApkClear != null) {
						for (int i = 0; i < mAdapter4ApkClear.getGroupCount(); i++) {
							apk_clear_expandlistview.collapseGroup(i);
						}
					}

					if (cache_clear_expandlistview_layout != null) {
						cache_clear_expandlistview_layout.setVisibility(View.GONE);
					}
					if (depth_clear_listview_layout != null) {
						depth_clear_listview_layout.setVisibility(View.GONE);
					}
					if (apk_clear_expandlistview_layout != null) {
						apk_clear_expandlistview_layout.setVisibility(View.GONE);
					}
					if (log_content_layout != null) {
						log_content_layout.setVisibility(View.GONE);
					}
					if (bigfile_clear_listview_layout != null) {
						bigfile_clear_listview_layout.setVisibility(View.GONE);
					}

					cache_size_textview.setVisibility(View.GONE);
					cache_scan_progressbar.setVisibility(View.VISIBLE);

					apk_size_textview.setVisibility(View.GONE);
					apk_scan_progressbar.setVisibility(View.VISIBLE);

					depth_size_textview.setVisibility(View.GONE);
					depth_scan_progressbar.setVisibility(View.VISIBLE);

					log_size_textview.setVisibility(View.GONE);
					log_scan_progressbar.setVisibility(View.VISIBLE);

					bigfile_size_textview.setVisibility(View.GONE);
					bigfile_scan_progressbar.setVisibility(View.VISIBLE);

					new Thread(new Runnable() {

						@Override
						public void run() {
							clearAll();
						}
					}).start();
				} else {
					Toast.makeText(mContext, R.string.clear_select_null, Toast.LENGTH_SHORT).show();
				}
			}
			break;
		case R.id.cache_title_layout:
			cache_clear_expandlistview_layout.setVisibility(cache_clear_expandlistview_layout.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
			break;
		case R.id.depth_title_layout:
			depth_clear_listview_layout.setVisibility(depth_clear_listview_layout.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
			break;
		case R.id.apk_title_layout:
			apk_clear_expandlistview_layout.setVisibility(apk_clear_expandlistview_layout.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
			break;
		case R.id.log_title_layout:
			log_content_layout.setVisibility(log_content_layout.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
			break;
		case R.id.bigfile_title_layout:
			bigfile_clear_listview_layout.setVisibility(bigfile_clear_listview_layout.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
			break;
		case R.id.share_imageview:
			MenuOptionUtil.shareCleanResult(this);
			break;
		case R.id.back_title:
		case R.id.banner_title_textview:
		case R.id.banner_back_imageview:
		case R.id.back_imageview:
			if (from_notify) {
				startActivity(new Intent(this, MainClearActivity.class));
				finish();
				overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
			} else {
				if (result_page.getVisibility() == View.VISIBLE && daily_finish) {
					Intent intent = new Intent(this, MainClearActivity.class);
					intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(intent);
				}
				finish();
				overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
			}
			break;
		case R.id.log_checked_imageview:
			log_group_checkbox.setChecked(log_checked_imageview.isChecked());
			if (log_checked_imageview.isChecked()) {
				selectLogSize = totalLogSize;
				log_checked_imageview.setChecked(true);
			} else {
				selectLogSize = 0;
				log_checked_imageview.setChecked(false);
			}
			updateSelectSize();
			break;
		case R.id.log_group_checkbox:
			log_checked_imageview.setChecked(log_group_checkbox.isChecked());
			if (log_checked_imageview.isChecked()) {
				selectLogSize = totalLogSize;
				log_checked_imageview.setChecked(true);
			} else {
				selectLogSize = 0;
				log_checked_imageview.setChecked(false);
			}
			updateSelectSize();
			break;
		case R.id.cache_group_checkbox:
			mAdapter4CacheClear.setAllChecked(cache_group_checkbox.isChecked());
			break;
		case R.id.depth_group_checkbox:
			mAdapter4DepthClear.setAllChecked(depth_group_checkbox.isChecked());
			break;
		case R.id.bigfile_group_checkbox:
			mAdapter4BigFileClear.setAllChecked(bigfile_group_checkbox.isChecked());
			break;
		case R.id.apk_group_checkbox:
			mAdapter4ApkClear.setAllChecked(apk_group_checkbox.isChecked());
			break;
		default:
			break;
		}
	}

	protected void clearAll() {

		ArrayList<AppItem> appItems = (mAdapter4CacheClear != null ? mAdapter4CacheClear.getSelectClearList() : new ArrayList<AppItem>());
		if (Terminal.isRoot(mContext)) {
			String packages = "";
			for (int i = 0; i < appItems.size(); i++) {
				AppItem appItem = appItems.get(i);
				Message message = new Message();
				message.what = 1;
				Bundle bundle = new Bundle();
				bundle.putString("name", appItem.getAppName());
				bundle.putInt("progress", i + 1);
				bundle.putInt("max", appItems.size());
				message.setData(bundle);
				mHandler.sendMessage(message);
				if (!TextUtils.isEmpty(appItem.getFilePath())) {
					FileUtils.deleteFileByPath(appItem.getFilePath());
				} else {
					if (i == 0) {
						packages += appItem.getAppPackage();
					} else {
						packages += ("," + appItem.getAppPackage());
					}
				}
			}
			if (packages.length() > 0) {
				AppManagerUtils.clearAppCache(mContext, packages);
			}
		} else {
			for (int i = 0; i < appItems.size(); i++) {
				AppItem appItem = appItems.get(i);
				Message message = new Message();
				message.what = 1;
				Bundle bundle = new Bundle();
				bundle.putString("name", appItem.getAppName());
				bundle.putInt("progress", i + 1);
				bundle.putInt("max", appItems.size());
				message.setData(bundle);
				mHandler.sendMessage(message);
				FileUtils.deleteFileByPath(appItem.getFilePath());
			}
			if (mAdapter4CacheClear != null && mAdapter4CacheClear.getGroupCount() > 0) {
				GroupItem groupItem = (GroupItem) mAdapter4CacheClear.getGroup(0);
				if (groupItem.getTitle().equals(getString(R.string.system_cache_title)) && groupItem.isChecked()) {
					MemoryUtils.clearAllCache(mContext);
				}
			}
		}
		try {
			Thread.sleep(200);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		Message message = new Message();
		message.arg1 = 0;
		message.what = 3;
		mHandler.sendMessage(message);

		appItems = (mAdapter4DepthClear != null ? mAdapter4DepthClear.getSelecteList() : new ArrayList<AppItem>());

		for (int i = 0; i < appItems.size(); i++) {
			message = new Message();
			message.what = 1;
			Bundle bundle = new Bundle();
			bundle.putString("name", appItems.get(i).getFilePath());
			bundle.putInt("progress", i + 1);
			bundle.putInt("max", appItems.size());
			message.setData(bundle);
			mHandler.sendMessage(message);
			FileUtils.deleteFileByPath(appItems.get(i).getFilePath());
		}
		try {
			Thread.sleep(300);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		message = new Message();
		message.arg1 = 1;
		message.what = 3;
		mHandler.sendMessage(message);

		appItems = (mAdapter4ApkClear != null ? mAdapter4ApkClear.getSelectApkList() : new ArrayList<AppItem>());

		for (int i = 0; i < appItems.size(); i++) {
			message = new Message();
			message.what = 1;
			Bundle bundle = new Bundle();
			bundle.putString("name", appItems.get(i).getFilePath());
			bundle.putInt("progress", i + 1);
			bundle.putInt("max", appItems.size());
			message.setData(bundle);
			mHandler.sendMessage(message);
			FileUtils.deleteFileByPath(appItems.get(i).getFilePath());
		}
		try {
			Thread.sleep(300);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		message = new Message();
		message.arg1 = 2;
		message.what = 3;
		mHandler.sendMessage(message);

		ArrayList<BigFileItem> bigFileItems = (mAdapter4BigFileClear != null ? mAdapter4BigFileClear.getSelecteList() : new ArrayList<BigFileItem>());

		for (int i = 0; i < bigFileItems.size(); i++) {
			message = new Message();
			message.what = 1;
			Bundle bundle = new Bundle();
			bundle.putString("name", bigFileItems.get(i).getPath());
			bundle.putInt("progress", i + 1);
			bundle.putInt("max", bigFileItems.size());
			message.setData(bundle);
			mHandler.sendMessage(message);
			FileUtils.deleteFileByPath(bigFileItems.get(i).getPath());
		}
		try {
			Thread.sleep(300);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		message = new Message();
		message.arg1 = 3;
		message.what = 3;
		mHandler.sendMessage(message);

		if (log_checked_imageview.isChecked()) {
			if (logList != null && logList.size() > 0) {
				FileUtils.deleteFileByList(logList);
			}
		}
		try {
			Thread.sleep(300);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		message = new Message();
		message.arg1 = 4;
		message.what = 3;
		mHandler.sendMessage(message);

		mHandler.sendEmptyMessage(2);
	}

	Handler mHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			switch (msg.what) {
			case 1:
				progress_layout.setVisibility(View.VISIBLE);
				Bundle bundle = msg.getData();
				scan_textview.setText(getString(R.string.clear_loading, bundle.getString("name")));
				scan_textview.setVisibility(View.VISIBLE);
				break;
			case 2:
				Animation animation = AnimationUtils.loadAnimation(mContext, R.anim.slide_out_left);
				Animation animation2 = AnimationUtils.loadAnimation(mContext, R.anim.slide_in_right);
				list_page.startAnimation(animation);
				result_page.startAnimation(animation2);
				list_page.setVisibility(View.GONE);
				result_page.setVisibility(View.VISIBLE);

				ClearUtils.setDayClearSize(mContext, getAllSelectSize());
				ClearUtils.setHistoryClearSize(mContext, getAllSelectSize());

				TextView thistime_clear_memory_textview = (TextView) findViewById(R.id.thistime_clear_memory_textview);
				TextView thistime_clear_unit_textview = (TextView) findViewById(R.id.thistime_clear_unit_textview);

				String size = FormatUtils.formatBytesInByte2(getAllSelectSize());
				thistime_clear_memory_textview.setText(size.substring(0, size.length() - 2));
				thistime_clear_unit_textview.setText(size.substring(size.length() - 2, size.length()));

				TextView total_clear_memory_textview = (TextView) findViewById(R.id.total_clear_memory_textview);
				TextView total_clear_unit_textview = (TextView) findViewById(R.id.total_clear_unit_textview);

				String totalSize = FormatUtils.formatBytesInByte2(ClearUtils.getHistoryClearSize(mContext));
				total_clear_memory_textview.setText(totalSize.substring(0, totalSize.length() - 2));
				total_clear_unit_textview.setText(totalSize.substring(totalSize.length() - 2, totalSize.length()));
				break;
			case 3:

				switch (msg.arg1) {
				case 0:
					startDeleteAnim(cache_layout);
					totalCacheSize -= selectCacheSize;
					updateTotalSize();
					break;
				case 1:
					startDeleteAnim(depth_layout);
					totalDepthSize -= selectDepthSize;
					updateTotalSize();
					break;
				case 2:
					startDeleteAnim(apk_layout);
					totalApkSize -= selectApkSize;
					updateTotalSize();
					break;
				case 3:
					startDeleteAnim(bigfile_layout);
					totalBigFileSize -= selectBigFileSize;
					updateTotalSize();
					break;
				case 4:
					startDeleteAnim(log_layout);
					totalLogSize -= selectLogSize;
					updateTotalSize();
					mHandler.sendEmptyMessageDelayed(2, 300);
					break;
				default:
					break;
				}
				break;
			default:
				break;
			}
		}
	};

	private void startDeleteAnim(final View view) {
		Animation animation = getDeleteAnim();
		animation.setAnimationListener(new AnimationListener() {

			@Override
			public void onAnimationStart(Animation animation) {

			}

			@Override
			public void onAnimationRepeat(Animation animation) {

			}

			@Override
			public void onAnimationEnd(Animation animation) {
				view.setVisibility(View.GONE);
			}
		});
		view.startAnimation(animation);
	}

	private AnimationSet getDeleteAnim() {
		AnimationSet set = new AnimationSet(true);
		Animation animation = new AlphaAnimation(1.0f, 0.5f);
		animation.setDuration(500);
		set.addAnimation(animation);

		animation = new TranslateAnimation(Animation.RELATIVE_TO_SELF, 0.0f, Animation.RELATIVE_TO_SELF, -1.0f, Animation.RELATIVE_TO_SELF, 0.0f,
				Animation.RELATIVE_TO_SELF, -1.0f);
		animation.setDuration(500);
		set.addAnimation(animation);
		set.setFillAfter(true);
		return set;
	}

	@Override
	public boolean onChildClick(ExpandableListView parent, View v, final int groupPosition, final int childPosition, long id) {
		switch (parent.getId()) {
		case R.id.cache_clear_expandlistview:
			final AppItem appItem = (AppItem) mAdapter4CacheClear.getChild(groupPosition, childPosition);
			if (TextUtils.isEmpty(appItem.getFilePath())) {
				final QuickAction2 qa = new QuickAction2(v);
				ActionItem2 clearCache = new ActionItem2();
				clearCache.setTitle(getString(R.string.trash_clear_cache_button));
				clearCache.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						qa.dismiss();
						if (Terminal.isRoot(mContext)) {
							AppManagerUtils.clearAppCache(mContext, appItem.getAppPackage());
							mAdapter4CacheClear.remove(appItem, groupPosition, childPosition);
							mAdapter4CacheClear.notifyDataSetChanged();
							mAdapter4CacheClear.updateSelectCacheSize();
							totalCacheSize -= appItem.getCacheSize();
							ClearUtils.setDayClearSize(mContext, appItem.getCacheSize());
							ClearUtils.setHistoryClearSize(mContext, appItem.getCacheSize());
							updateTotalSize();
							updateSelectSize();
							updateListView();
						} else {
							AppManagerUtils.openInstalledDetail(mContext, appItem.getAppPackage());
						}
					}
				});

				if (Terminal.isRoot(mContext)) {
					ActionItem2 addWhite = new ActionItem2();
					addWhite.setTitle(getString(R.string.process_keepapp_button));
					addWhite.setOnClickListener(new OnClickListener() {
						@Override
						public void onClick(View v) {
							qa.dismiss();
							CacheWhiteListUtils.save(mContext, appItem.getAppPackage());
							mAdapter4CacheClear.remove(appItem, groupPosition, childPosition);
							mAdapter4CacheClear.notifyDataSetChanged();
							mAdapter4CacheClear.updateSelectCacheSize();
							totalCacheSize -= appItem.getCacheSize();
							updateTotalSize();
							updateSelectSize();
							updateListView();
						}
					});
					qa.addActionItem(addWhite);
				}

				qa.addActionItem(clearCache);
				qa.show();
			} else {
				// final SharedPreferences sp =
				// PreferenceManager.getDefaultSharedPreferences(mContext);
				// boolean checked = sp.getBoolean("daily_tips_checked", false);
				// if (!checked) {
				// final CustomDialog2 customDialog = new
				// CustomDialog2(mContext);
				// customDialog.setDialogIcon(R.drawable.dialog_icon_question);
				// customDialog.setMessage(R.string.clear_depth_clear_tips);
				// CheckBox checkBox = new CheckBox(mContext);
				// checkBox.setText(R.string.next_not_tips);
				// checkBox.setTextColor(getResources().getColor(R.color.secondary_textcolor));
				// checkBox.setButtonDrawable(R.drawable.checkbox_background);
				// checkBox.setOnCheckedChangeListener(new
				// OnCheckedChangeListener() {
				//
				// @Override
				// public void onCheckedChanged(CompoundButton buttonView,
				// boolean isChecked) {
				// sp.edit().putBoolean("daily_tips_checked",
				// isChecked).commit();
				// }
				// });
				// customDialog.setView(checkBox);
				// customDialog.setButton2(R.string.clear_depth_button_delete,
				// new OnClickListener() {
				//
				// @Override
				// public void onClick(View v) {
				// customDialog.dismiss();
				// DLog.i("debug", appItem.getFilePath());
				// FileUtils.deleteFileByPath(appItem.getFilePath());
				// mAdapter4CacheClear.remove(appItem, groupPosition,
				// childPosition);
				// mAdapter4CacheClear.notifyDataSetChanged();
				// mAdapter4CacheClear.updateSelectCacheSize();
				// totalCacheSize -= appItem.getCacheSize();
				// ClearUtils.setDayClearSize(mContext, appItem.getCacheSize());
				// ClearUtils.setHistoryClearSize(mContext,
				// appItem.getCacheSize());
				// updateTotalSize();
				// updateSelectSize();
				// updateListView();
				// }
				// });
				// customDialog.setButton1(R.string.dialog_button_cancel, null);
				// customDialog.show();
				// } else {
				// FileUtils.deleteFileByPath(appItem.getFilePath());
				// mAdapter4CacheClear.remove(appItem, groupPosition,
				// childPosition);
				// mAdapter4CacheClear.notifyDataSetChanged();
				// mAdapter4CacheClear.updateSelectCacheSize();
				// totalCacheSize -= appItem.getCacheSize();
				// ClearUtils.setDayClearSize(mContext, appItem.getCacheSize());
				// ClearUtils.setHistoryClearSize(mContext,
				// appItem.getCacheSize());
				// updateTotalSize();
				// updateSelectSize();
				// updateListView();
				// }
				final CustomDialog3 customDialog3 = new CustomDialog3(mContext);
				customDialog3.setTitle(appItem.getAppName());
				customDialog3.setIcon(appItem.getAppIcon());
				View dialog_view_process = LayoutInflater.from(mContext).inflate(R.layout.dialog_cache_item, null);
				TextView cache_memory_textview = (TextView) dialog_view_process.findViewById(R.id.cache_memory_textview);
				TextView cache_path_textview = (TextView) dialog_view_process.findViewById(R.id.cache_path_textview);
				cache_memory_textview.setText("大小: " + FormatUtils.formatBytesInByte(appItem.getCacheSize()));
				cache_path_textview.setText("路径: " + appItem.getFilePath());

				customDialog3.setView(dialog_view_process);
				customDialog3.setButton1("取消", null);
				customDialog3.setButton2("清理", new OnClickListener() {

					@Override
					public void onClick(View v) {
						customDialog3.dismiss();
						FileUtils.deleteFileByPath(appItem.getFilePath());
						mAdapter4CacheClear.remove(appItem, groupPosition, childPosition);
						mAdapter4CacheClear.notifyDataSetChanged();
						mAdapter4CacheClear.updateSelectCacheSize();
						totalCacheSize -= appItem.getCacheSize();
						ClearUtils.setDayClearSize(mContext, appItem.getCacheSize());
						ClearUtils.setHistoryClearSize(mContext, appItem.getCacheSize());
						updateTotalSize();
						updateSelectSize();
						updateListView();
					}
				});
				customDialog3.show();
			}
			break;
		case R.id.apk_clear_expandlistview:
			// AppItem appItem2 = (AppItem)
			// mAdapter4ApkClear.getChild(groupPosition, childPosition);
			// appItem2.setChecked(!appItem2.isChecked());
			// mAdapter4ApkClear.notifyDataSetChanged();
			// mAdapter4ApkClear.updateSelectApkSize();

			final AppItem appItem2 = (AppItem) mAdapter4ApkClear.getChild(groupPosition, childPosition);
			final QuickAction2 qa = new QuickAction2(v);
			ActionItem2 install = new ActionItem2();
			install.setTitle(getString(R.string.recyle_restore_app_button));
			install.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					qa.dismiss();
					AppManagerUtils.openInstaller(mContext, appItem2.getFilePath());
				}
			});
			qa.addActionItem(install);
			ActionItem2 delete = new ActionItem2();
			delete.setTitle(getString(R.string.trash_clear_delete_button));
			delete.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					qa.dismiss();
					FileUtils.deleteFileByPath(appItem2.getFilePath());
					mAdapter4ApkClear.remove(groupPosition, childPosition);
					mAdapter4ApkClear.updateSelectApkSize();
					totalApkSize -= appItem2.getCodeSize();
					ClearUtils.setDayClearSize(mContext, appItem2.getCodeSize());
					ClearUtils.setHistoryClearSize(mContext, appItem2.getCodeSize());
					updateTotalSize();
					updateSelectSize();
				}
			});
			qa.addActionItem(delete);
			qa.show();
			break;
		default:
			break;
		}

		return true;
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
		switch (parent.getId()) {
		case R.id.depth_clear_listview:
			final AppItem appItem = (AppItem) parent.getItemAtPosition(position);
			final SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(mContext);
			boolean checked = sp.getBoolean("depth_tips_checked", false);
			if (!checked) {
				final CustomDialog2 customDialog = new CustomDialog2(mContext);
				String fileType = getDepthFileType(appItem);
				if (TextUtils.isEmpty(fileType)) {
					customDialog.setMessage(R.string.clear_depth_clear_tips);
					customDialog.setDialogIcon(R.drawable.dialog_icon_question);
				} else {
					customDialog.setDialogIcon(R.drawable.dialog_icon_warning);
					String str = getString(R.string.clear_depth_clear_tips_2, fileType);
					SpannableStringBuilder style = new SpannableStringBuilder(str);
					style.setSpan(new ForegroundColorSpan(Color.RED), str.indexOf(fileType), str.indexOf(fileType) + fileType.length(),
							Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
					style.setSpan(new ForegroundColorSpan(Color.RED), str.indexOf("无法恢复"), str.indexOf("无法恢复") + "无法恢复".length(),
							Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
					customDialog.setMessage(style);
				}
				CheckBox checkBox = new CheckBox(mContext);
				checkBox.setText(R.string.next_not_tips);
				checkBox.setTextColor(getResources().getColor(R.color.secondary_textcolor));
				checkBox.setButtonDrawable(R.drawable.checkbox_circle_background);
				checkBox.setOnCheckedChangeListener(new OnCheckedChangeListener() {

					@Override
					public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
						sp.edit().putBoolean("depth_tips_checked", isChecked).commit();
					}
				});
				customDialog.setView(checkBox);
				customDialog.setButton2(R.string.clear_depth_button_delete, new OnClickListener() {

					@Override
					public void onClick(View v) {
						customDialog.dismiss();
						FileUtils.deleteFileByPath(appItem.getFilePath());
						mAdapter4DepthClear.remove(position);
						mAdapter4DepthClear.notifyDataSetChanged();
						mAdapter4DepthClear.updateSelectDepthSize();
						totalDepthSize -= appItem.getCodeSize();
						ClearUtils.setDayClearSize(mContext, appItem.getCodeSize());
						ClearUtils.setHistoryClearSize(mContext, appItem.getCodeSize());
						updateSelectSize();
						updateTotalSize();
						updateListView();
					}
				});
				customDialog.setButton1(R.string.dialog_button_cancel, null);
				customDialog.show();
			} else {
				FileUtils.deleteFileByPath(appItem.getFilePath());
				mAdapter4DepthClear.remove(position);
				mAdapter4DepthClear.notifyDataSetChanged();
				mAdapter4DepthClear.updateSelectDepthSize();
				totalDepthSize -= appItem.getCodeSize();
				ClearUtils.setDayClearSize(mContext, appItem.getCodeSize());
				ClearUtils.setHistoryClearSize(mContext, appItem.getCodeSize());
				updateSelectSize();
				updateTotalSize();
				updateListView();
			}
			break;
		case R.id.bigfile_clear_listview:
			BigFileGroup bigFileGroup = (BigFileGroup) parent.getItemAtPosition(position);
			Intent intent = new Intent(mContext, BigFileDetailActivity.class);
			Bundle bundle = new Bundle();
			bundle.putSerializable("list", bigFileGroup.getBigFileItems());
			bundle.putString("title", bigFileGroup.getTypeName());
			bundle.putInt("position", position);
			intent.putExtras(bundle);
			startActivityForResult(intent, 101);
			break;
		default:
			break;
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		ArrayList<BigFileItem> bigFileItems = (ArrayList<BigFileItem>) data.getSerializableExtra("list");
		int position = data.getIntExtra("position", 0);
		mAdapter4BigFileClear.updateList(bigFileItems, position);

	}

	private String getDepthFileType(AppItem appItem2) {
		String str = "";
		if (appItem2.isIncludeAudio()) {
			str += "音频";
		}
		if (appItem2.isIncludeEBook()) {
			if (TextUtils.isEmpty(str)) {
				str += "电子书";
			} else {
				str += "/电子书";
			}
		}
		if (appItem2.isIncludeObb()) {
			if (TextUtils.isEmpty(str)) {
				str += "游戏数据包";
			} else {
				str += "/游戏数据包";
			}
		}
		return str;
	}

	/**
	 * 收集apk path
	 * 
	 * @param path
	 */
	private void addApkCollectionPath(String path) {
		String sdPath = Constants.SDCARD_PATH;
		File apkFile = new File(path);

		String parentPath = apkFile.getParent();
		if (sdPath.equals(parentPath)) {
			return;
		}
		parentPath = parentPath.substring(parentPath.indexOf(sdPath) + sdPath.length(), parentPath.length());
		if (apkCollectionPaths == null) {
			apkCollectionPaths = new HashSet<String>();
		}
		apkCollectionPaths.add(parentPath);
	}

	/**
	 * 收集大文件 path
	 * 
	 * @param path
	 */
	private void addBigFileCollectionPath(String path) {
		String sdPath = Constants.SDCARD_PATH;
		File apkFile = new File(path);

		String parentPath = apkFile.getParent();
		if (sdPath.equals(parentPath)) {
			return;
		}
		parentPath = parentPath.substring(parentPath.indexOf(sdPath) + sdPath.length(), parentPath.length());
		if (bigfileCollectionPaths == null) {
			bigfileCollectionPaths = new HashSet<String>();
		}
		bigfileCollectionPaths.add(parentPath);
	}

	/**
	 * 收集日志 path
	 * 
	 * @param path
	 */
	private void addLogCollectionPath(String path) {
		String sdPath = Constants.SDCARD_PATH;
		File apkFile = new File(path);

		String parentPath = apkFile.getParent();
		if (sdPath.equals(parentPath)) {
			return;
		}
		parentPath = parentPath.substring(parentPath.indexOf(sdPath) + sdPath.length(), parentPath.length());
		if (logCollectionPaths == null) {
			logCollectionPaths = new HashSet<String>();
		}
		logCollectionPaths.add(parentPath);
	}

	private float lastY;
	private boolean lock = false;
	private boolean isOpen = true;
	private int result_layout_height_px;
	private ListView more_tools_listview;
	private int mFirstItemPosY;
	private LinearLayout result_layout;
	private ImageView ad_cursor_imageview;

	private void initAdView() {
		LinearLayout ad_cursor_layout = (LinearLayout) findViewById(R.id.ad_cursor_layout);
		ad_cursor_imageview = (ImageView) findViewById(R.id.ad_cursor_imageview);

		result_layout = (LinearLayout) findViewById(R.id.result_layout);
		more_tools_listview = (ListView) findViewById(R.id.more_tools_listview);

		LayoutParams resultLayoutParams = (LayoutParams) result_layout.getLayoutParams();
		DisplayMetrics dm = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(dm);
		int screenHeight = dm.heightPixels;

		/**** 获取状态栏高度 ****/
		int statusBarHeight = 0;
		Class<?> c = null;
		Object obj = null;
		Field field = null;
		try {
			c = Class.forName("com.android.internal.R$dimen");
			obj = c.newInstance();
			field = c.getField("status_bar_height");
			int x = Integer.parseInt(field.get(obj).toString());
			statusBarHeight = getResources().getDimensionPixelSize(x);
		} catch (Exception e1) {
			e1.printStackTrace();
			statusBarHeight = 0;
		}

		int ad_layout_height_px = DensityUtil.dip2px(mContext, 80 + 48 + 48) + statusBarHeight;
		result_layout_height_px = screenHeight - ad_layout_height_px;

		resultLayoutParams.height = result_layout_height_px;
		result_layout.setLayoutParams(resultLayoutParams);

		more_tools_listview.setOnTouchListener(new OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()) {
				case MotionEvent.ACTION_DOWN:
					lastY = event.getRawY();
					break;
				case MotionEvent.ACTION_UP:
					lastY = 0;
					break;
				case MotionEvent.ACTION_MOVE:
					if (!lock) {
						if (isOpen) {
							if (event.getRawY() - lastY <= -5) {
								lock = true;
								close();
							}
						} else {
							if (mFirstItemPosY == 0) {
								if (event.getRawY() - lastY >= 10) {
									lock = true;
									open();
								}
							}
						}
					}
					break;

				default:
					break;
				}
				return false;
			}
		});

		ad_cursor_layout.setOnTouchListener(new OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()) {
				case MotionEvent.ACTION_DOWN:
					lastY = event.getRawY();
					break;
				case MotionEvent.ACTION_UP:
					lastY = 0;
					break;
				case MotionEvent.ACTION_MOVE:
					if (!lock) {
						if (isOpen) {
							if (event.getRawY() - lastY <= -5) {
								lock = true;
								close();
							}
						} else {
							if (mFirstItemPosY == 0) {
								if (event.getRawY() - lastY >= 5) {
									lock = true;
									open();
								}
							}
						}
					}
					break;

				default:
					break;
				}
				return true;
			}
		});

		more_tools_listview.setOnScrollListener(new OnScrollListener() {

			@Override
			public void onScrollStateChanged(AbsListView view, int scrollState) {
				switch (scrollState) {
				case OnScrollListener.SCROLL_STATE_TOUCH_SCROLL:
					break;
				case OnScrollListener.SCROLL_STATE_IDLE: //
					View v = view.getChildAt(0);
					mFirstItemPosY = (v == null) ? 0 : v.getTop();
					break;
				}

			}

			@Override
			public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

			}
		});

		more_tools_listview.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

				BaseItem mBaseItem = (BaseItem) parent.getItemAtPosition(position);

				PackageInfo packageInfo = null;
				try {
					packageInfo = mContext.getPackageManager().getPackageInfo(mBaseItem.getPackageName(), 0);
				} catch (NameNotFoundException e) {
					e.printStackTrace();
				}
				if (packageInfo != null) {
					StatisticsUtils.commitEvent(mContext, mBaseItem.getName(), mBaseItem.getPackageName(), StatisticsUtils.AdType_ruanjianneizhi,
							StatisticsUtils.AdEvent_open);
					mContext.startActivity(mContext.getPackageManager().getLaunchIntentForPackage(mBaseItem.getPackageName()));
				} else {
					if (!mBaseItem.isDownload()) {
						StatisticsUtils.commitEvent(mContext, mBaseItem.getName(), mBaseItem.getPackageName(), StatisticsUtils.AdType_ruanjianneizhi,
								StatisticsUtils.AdEvent_show);
						AppDownload appDownload = new AppDownload(mContext);
						appDownload.setDownloadurl(mBaseItem.getApkUrl());
						appDownload.setAppName(mBaseItem.getName());
						appDownload.setPackageName(mBaseItem.getPackageName());
						appDownload.setAppIcon(mBaseItem.getIcon());
						appDownload.createNotify();
						appDownload.startDownloadApp();
						Toast.makeText(mContext, mBaseItem.getName() + mContext.getString(R.string.ad_stardonwload_tips), Toast.LENGTH_SHORT).show();
						mBaseItem.setDownload(true);
					}
				}

			}

		});
		startCursorUpAnim();

	}

	public void open() {
		final LayoutParams layoutParams = (LayoutParams) result_layout.getLayoutParams();
		new Thread(new Runnable() {

			@Override
			public void run() {
				for (int i = 1; i < 26; i++) {
					final int f = i;
					runOnUiThread(new Runnable() {

						@Override
						public void run() {
							layoutParams.height = (int) (result_layout_height_px * (1.0f * (f / 25f)));
							result_layout.setLayoutParams(layoutParams);
							result_layout.invalidate();
							if (f == 25) {
								more_tools_listview.setAdapter(adsAdapter);
								more_tools_listview.setSelection(0);
								TextView back_title = (TextView) findViewById(R.id.back_title);
								back_title.setText(R.string.clear_end_title);
								startCursorUpAnim();
							}
						}
					});
					try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				lock = false;
				isOpen = true;

			}
		}).start();
	}

	public void close() {
		final LayoutParams layoutParams = (LayoutParams) result_layout.getLayoutParams();
		new Thread(new Runnable() {

			@Override
			public void run() {
				for (int i = 1; i < 26; i++) {
					final int f = i;
					runOnUiThread(new Runnable() {

						@Override
						public void run() {
							layoutParams.height = (int) (result_layout_height_px * (1 - 1.0f * (f / 25f)));
							result_layout.setLayoutParams(layoutParams);
							result_layout.invalidate();
							if (f == 25) {
								TextView back_title = (TextView) findViewById(R.id.back_title);
								back_title.setText("更多功能");
								startCursorDownAnim();
								CustomEventCommit.commit(mContext, CustomEventCommit.result_ad_show);
							}
						}
					});
					try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				lock = false;
				isOpen = false;
			}
		}).start();
	}

	private void startCursorUpAnim() {
		ad_cursor_imageview.clearAnimation();
		ad_cursor_imageview.setImageResource(R.drawable.ad_cursor_up);
		Animation animation = AnimationUtils.loadAnimation(mContext, R.anim.cursor_up);
		animation.setStartOffset(100);
		ad_cursor_imageview.startAnimation(animation);
	}

	private void startCursorDownAnim() {
		ad_cursor_imageview.clearAnimation();
		ad_cursor_imageview.setImageResource(R.drawable.ad_cursor_down);
		Animation animation = AnimationUtils.loadAnimation(mContext, R.anim.cursor_down);
		animation.setStartOffset(100);
		ad_cursor_imageview.startAnimation(animation);
	}

	private void clearCursorAnim() {
		ad_cursor_imageview.clearAnimation();
	}

	private Adapter4ResultAd adsAdapter;

	private void initADListView() {
		ArrayList<BaseItem> mBaseItems = new ArrayList<BaseItem>();

		adsAdapter = new Adapter4ResultAd(mContext, mBaseItems);
		more_tools_listview.setAdapter(adsAdapter);

		SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(mContext);
		String toolbox_ad_json = sp.getString("result_ad_json", null);
		if (toolbox_ad_json != null) {
			ArrayList<ToolboxAd> toolboxAds = ToolboxAdUtils.getAdInfo(toolbox_ad_json);
			new GetAdsThread(toolboxAds).start();
		} else {
			new GetAdsThread(null).start();
		}
	}

	/**
	 * 获取广告列表
	 * 
	 * @author 庄宏岩
	 * 
	 */
	private class GetAdsThread extends Thread {
		private ArrayList<ToolboxAd> toolboxAds;
		private ArrayList<BaseItem> mBaseItems;

		public GetAdsThread(ArrayList<ToolboxAd> toolboxAds) {
			this.toolboxAds = toolboxAds;
			mBaseItems = new ArrayList<BaseItem>();
		}

		@Override
		public void run() {
			super.run();

			if (toolboxAds == null) {
				toolboxAds = ToolboxAdUtils.getResultAdInfo(mContext);
			}
			if (toolboxAds != null) {
				for (int i = 0; i < toolboxAds.size(); i++) {
					final BaseItem baseItem = new BaseItem();
					ToolboxAd toolboxAd = toolboxAds.get(i);
					AdInfo adInfo = getRandomAd(toolboxAd);
					PackageManager pm = mContext.getPackageManager();
					PackageInfo packageInfo = null;
					try {
						packageInfo = pm.getPackageInfo(adInfo.getPackageName(), 0);
					} catch (NameNotFoundException e) {
					}
					if (packageInfo != null) {
						adInfo = getNotInstallAd(toolboxAd);
					}
					baseItem.setName(adInfo.getAppName());
					baseItem.setPackageName(adInfo.getPackageName());
					baseItem.setDesc(adInfo.getContent());
					baseItem.setApkUrl(adInfo.getApkUrl());
					baseItem.setTitle(adInfo.getTitle());
					baseItem.setDetailUrl(adInfo.getDetailUrl());
					baseItem.setType(3);
					baseItem.setSize(adInfo.getSize());
					baseItem.setImageUrl(adInfo.getImageUrl());
					baseItem.setHtml5(adInfo.isHtml5());
					baseItem.setGameUrl(adInfo.getGameUrl());
					mBaseItems.add(baseItem);
				}
			}
			mHandler.sendEmptyMessage(1);
		}

		Handler mHandler = new Handler() {

			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				switch (msg.what) {
				case 1:
					if (mBaseItems != null && mBaseItems.size() > 0) {
						adsAdapter.getList().addAll(mBaseItems);
						adsAdapter.notifyDataSetChanged();
					} else {
						LayoutParams resultLayoutParams = (LayoutParams) result_layout.getLayoutParams();
						resultLayoutParams.height = LayoutParams.FILL_PARENT;
						result_layout.setLayoutParams(resultLayoutParams);
					}
					break;
				default:
					break;
				}

			}

		};
	}

	public AdInfo getRandomAd(ToolboxAd toolboxAd) {
		int r = (int) (Math.random() * 10 + 1);
		ArrayList<AdInfo> adInfos = toolboxAd.getAdInfos();
		if (adInfos != null && adInfos.size() > 0) {
			for (AdInfo adInfo : adInfos) {
				if (r >= adInfo.getWeight_l() && r <= adInfo.getWeight_r()) {
					return adInfo;
				}
			}
		}
		return null;
	}

	public AdInfo getNotInstallAd(ToolboxAd toolboxAd) {
		ArrayList<AdInfo> adInfos = toolboxAd.getAdInfos();
		PackageManager pm = mContext.getPackageManager();
		if (adInfos != null && adInfos.size() > 0) {
			for (AdInfo adInfo : adInfos) {
				PackageInfo packageInfo = null;
				try {
					packageInfo = pm.getPackageInfo(adInfo.getPackageName(), 0);
				} catch (NameNotFoundException e) {
				}
				if (packageInfo == null) {
					return adInfo;
				}

			}
			return adInfos.get(0);
		}
		return null;
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		stop = true;
		header_waterwave_view.stoptWave();
		clearCursorAnim();
	}

	@Override
	protected void onResume() {
		MobclickAgent.onResume(this);
		super.onResume();
	}

	@Override
	protected void onPause() {
		MobclickAgent.onPause(this);
		super.onPause();
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {

		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			if (from_notify) {
				startActivity(new Intent(this, MainClearActivity.class));
				finish();
				overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
			} else {
				if (result_page.getVisibility() == View.VISIBLE && daily_finish) {
					Intent intent = new Intent(this, MainClearActivity.class);
					intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(intent);
				}
				finish();
				overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
			}
			return true;
		}

		return super.onKeyDown(keyCode, event);
	}

	private void checkFile(File file, AppItem appItem) {
		if (file.isDirectory()) {
			File files[] = file.listFiles();
			if (files != null) {
				for (File f : files) {
					if (stop) {
						break;
					}
					if (f.isDirectory()) {
						checkFile(f, appItem);
					} else {
						if (f.getName().lastIndexOf(".") != -1) {
							String suffix = f.getName().substring(f.getName().lastIndexOf("."));
							if (suffix != null) {
								suffix = suffix.toLowerCase();
							}
							if (".obb".equals(suffix)) {
								appItem.setIncludeObb(true);
								continue;
							}
							if (audio_form.contains(suffix)) {
								appItem.setIncludeAudio(true);
								continue;
							}
							if (ebook_form.contains(suffix)) {
								appItem.setIncludeEBook(true);
								continue;
							}
						}
					}
				}
			}
		} else {
			if (file.getName().lastIndexOf(".") != -1) {
				String suffix = file.getName().substring(file.getName().lastIndexOf("."));
				if (suffix != null) {
					suffix = suffix.toLowerCase();
				}
				if (".obb".equals(suffix)) {
					appItem.setIncludeObb(true);
				}
				if (audio_form.contains(suffix)) {
					appItem.setIncludeAudio(true);
				}
				if (ebook_form.contains(suffix)) {
					appItem.setIncludeEBook(true);
				}
			}
		}
	}

	private String getLanguage() {
		String language = Locale.getDefault().getLanguage();
		// String country = Locale.getDefault().getCountry();
		if ("zh".equals(language)) {
			return "zh";
		} else if ("en".equals(language)) {
			return "en";
		}
		return "en";
	}
}
