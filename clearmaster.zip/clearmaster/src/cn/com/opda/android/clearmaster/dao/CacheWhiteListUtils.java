package cn.com.opda.android.clearmaster.dao;

import java.util.ArrayList;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.preference.PreferenceManager;
import android.util.Log;
import cn.com.opda.android.clearmaster.utils.BaseJsonUtil;

/**
 * 白名单数据库操作类
 * 
 * @author 庄宏岩
 * 
 */
public class CacheWhiteListUtils extends BaseJsonUtil {
	private static final String TAG = "db";
	private static final String[] whites = { "com.baidu.browser.apps", "com.tencent.mtt", "uc.UCMobile", "com.ijinshan.browser", "com.oupeng.browser",
			"com.oupeng.mini.android", "com.android.chrome", "org.mozilla.firefox", "com.mx.browser", "com.sohu.sohuvideo", "com.storm.smart",
			"com.youku.phone", "com.funshion.video.mobile", "com.funshion.video", "com.qiyi.video", "com.meitu.meipaimv", "com.pplive.androidphone",
			"com.tencent.qqlive", "com.letv.android.client", "com.tencent.qqmusic", "com.kugou.android", "com.sds.android.ttpod", "cn.kuwo.player",
			"com.ting.mp3.android", "com.duomi.android", "com.yibasan.lizhifm", "com.yinyuetai.ui", "fm.xiami.main", "com.chaozh.iReaderFree",
			"com.tadu.android", "com.shuqi.controller", "com.qidian.QDReader", "com.qq.reader", "com.ss.android.article.news", "qsbk.app",
			"com.zhihu.daily.android", "com.anyview", "com.nd.android.pandareader", "com.baidu.BaiduMap", "com.baidu.navi", "com.autonavi.minimap",
			"com.autonavi.xmgd.navigator", "com.funcity.taxi.passenger", "com.sdu.didi.psnger", "com.Qunar", "ctrip.android.view" };

	public CacheWhiteListUtils(Context context) {
		super(context);
	}

	/**
	 * @param info
	 * @param context
	 *            把信息保存到数据库
	 */
	public static void save(Context context, String info) {
		DBCacheWhiteListOpenHelper tdbOpenHelper = new DBCacheWhiteListOpenHelper(context);
		SQLiteDatabase db = tdbOpenHelper.getWritableDatabase();
		try {
			db.execSQL("insert into cache_whitelist (packagename) values(?)", new Object[] { info });
			Log.i(TAG, "save()");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			db.close();
			tdbOpenHelper.close();
		}
	}

	/**
	 * @param info
	 * @param context
	 *            把信息保存到数据库
	 */
	public static void saveAll(Context context, String[] infos) {
		DBCacheWhiteListOpenHelper tdbOpenHelper = new DBCacheWhiteListOpenHelper(context);
		SQLiteDatabase db = tdbOpenHelper.getWritableDatabase();
		try {
			for (String info : infos) {

				db.execSQL("insert into cache_whitelist (packagename) values(?)", new Object[] { info });
				Log.i(TAG, "save()");

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			db.close();
			tdbOpenHelper.close();
		}
	}

	/**
	 * @param info
	 * @param context
	 *            从数据库中删除某条数据
	 */
	public static void delete(Context context, String packageName) {
		DBCacheWhiteListOpenHelper tdbOpenHelper = new DBCacheWhiteListOpenHelper(context);
		SQLiteDatabase db = tdbOpenHelper.getWritableDatabase();
		try {
			db.execSQL("delete from cache_whitelist where packagename=?", new Object[] { packageName });
			Log.i(TAG, "delete()");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			db.close();
			tdbOpenHelper.close();
		}
	}

	/**
	 * @param context
	 * @return 从数据库中获取所有数据并返回一个集合
	 */
	public static ArrayList<String> getAllList(Context context) {
		ArrayList<String> list = new ArrayList<String>();
		DBCacheWhiteListOpenHelper tdbOpenHelper = new DBCacheWhiteListOpenHelper(context);
		SQLiteDatabase db = tdbOpenHelper.getWritableDatabase();
		Cursor cursor = db.rawQuery("select * from cache_whitelist ", null);
		try {
			if (cursor != null) {
				while (cursor.moveToNext()) {
					list.add(cursor.getString(0));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (cursor != null) {
				cursor.close();
			}
			db.close();
			tdbOpenHelper.close();
		}
		return list;
	}

	public static void initDB(Context mContext) {
		final SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(mContext);
		if (!sp.getBoolean("initCacheWhiteDB", false)) {
			saveAll(mContext, whites);
			sp.edit().putBoolean("initCacheWhiteDB", true).commit();
		}
	}
}
