package cn.com.opda.android.clearmaster.dao;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class AppUsageStatisticsDBOpenHelper extends SQLiteOpenHelper {

	private final static String SqLiteName = "app_usage.db";
	private final static int mversion = 1;

	public AppUsageStatisticsDBOpenHelper(Context context) {
		super(context, SqLiteName, null, mversion);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		db.execSQL("create table if not exists appinfos (appname TEXT,packagename TEXT,icon BLOB,installtime LONG)");
		db.execSQL("create table if not exists netflow (appname TEXT,packagename TEXT, uid INTEGER,icon BLOB,flow LONG)");
		db.execSQL("create table if not exists startup (packagename TEXT,count INTEGER,lasttime LONG)");
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int arg1, int arg2) {
		onCreate(db);
	}

}
