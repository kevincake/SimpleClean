package cn.com.opda.android.clearmaster;

import java.io.File;
import java.io.FileFilter;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Resources;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.preference.PreferenceManager;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnChildClickListener;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import cn.com.opda.android.clearmaster.adapter.Adapter4ApkCustom;
import cn.com.opda.android.clearmaster.custom.CustomActivity;
import cn.com.opda.android.clearmaster.custom.CustomDialog3;
import cn.com.opda.android.clearmaster.custom.IOSProgressDialog;
import cn.com.opda.android.clearmaster.dao.DBApkPathUtils;
import cn.com.opda.android.clearmaster.model.AppItem;
import cn.com.opda.android.clearmaster.model.GroupItem;
import cn.com.opda.android.clearmaster.utils.AppManagerUtils;
import cn.com.opda.android.clearmaster.utils.ClearUtils;
import cn.com.opda.android.clearmaster.utils.CodeSizeComparator;
import cn.com.opda.android.clearmaster.utils.Constants;
import cn.com.opda.android.clearmaster.utils.DLog;
import cn.com.opda.android.clearmaster.utils.FileUtils;
import cn.com.opda.android.clearmaster.utils.FormatUtils;

public class SoftwareInstallActivity extends CustomActivity implements OnChildClickListener, OnClickListener {

	private final String SDCARDPATH = Environment.getExternalStorageDirectory().toString();
	private boolean stop;
	private AppItem installApp;
	private LinearLayout clear_button_layout;
	private TextView count_textview;
	private long freeMemory;
	private Button clear_button;
	private boolean apkPathcollection;
	private HashSet<String> collectionPaths;
	private boolean init;
	private Adapter4ApkCustom expandAdapter;
	private ExpandableListView apkCustomListView;
	private ArrayList<AppItem> mAppItems;
	private ArrayList<AppItem> apkInstalledArray;
	private ArrayList<AppItem> apkUnstalledArray;
	private ArrayList<GroupItem> groupList = new ArrayList<GroupItem>();
	private ArrayList<ArrayList<AppItem>> childList = new ArrayList<ArrayList<AppItem>>();// 子列表

	public SoftwareInstallActivity(Context context, int resId) {
		super(context, resId);
		initViewAndEvent();
	}

	@Override
	public void initData() {
		if (!init) {
			init = true;
			stop = false;
			if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
				new GetApkThread().start();
			} else {
				// 无sd卡
				TextView app_install_tips_textview = (TextView) findViewById(R.id.software_install_tips_textview);
				findViewById(R.id.apk_custom_listview).setVisibility(View.GONE);
				clear_button_layout.setVisibility(View.GONE);
				app_install_tips_textview.setText(R.string.memory_tips_sd_nohave);
				app_install_tips_textview.setVisibility(View.VISIBLE);
				count_textview.setText("未扫描到安装包");
			}
		}
	}

	private void updateUI() {
		if (mAppItems.size() == 0) {
			count_textview.setText("未扫描到安装包");
		} else {
			count_textview.setText("安装包数量：" + (apkUnstalledArray.size() + apkInstalledArray.size()));
		}
	}

	private void initViewAndEvent() {

		count_textview = (TextView) findViewById(R.id.count_textview);
		clear_button_layout = (LinearLayout) findViewById(R.id.clear_button_layout);
		clear_button = (Button) findViewById(R.id.clear_button);
		clear_button.setOnClickListener(this);
		apkCustomListView = (ExpandableListView) findViewById(R.id.apk_custom_listview);
		apkCustomListView.setOnChildClickListener(this);
		apkCustomListView.setGroupIndicator(null);
		
		GroupItem groupItem = new GroupItem();
		groupItem.setTitle("已安装");
		groupItem.setIcon(mContext.getResources().getDrawable(R.drawable.apk_install_icon));
		groupList.add(groupItem);

		groupItem = new GroupItem();
		groupItem.setTitle("未安装");
		groupItem.setIcon(mContext.getResources().getDrawable(R.drawable.apk_uninstall_icon));
		groupList.add(groupItem);
		
	}

	private class GetApkThread extends Thread {
		private ArrayList<String> apkPathList;
		SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(mContext);
		private IOSProgressDialog iosProgressDialog;
		private long startTime;

		public GetApkThread() {
			iosProgressDialog = new IOSProgressDialog(mContext, R.string.loading);
			iosProgressDialog.setCancelable(false);
			iosProgressDialog.setCanceledOnTouchOutside(false);
			iosProgressDialog.show();
			apkPathcollection = sp.getBoolean("apkPathcollection", false);
			if (mAppItems == null) {
				mAppItems = new ArrayList<AppItem>();
			} else {
				mAppItems.clear();
			}
			
			if (apkInstalledArray == null) {
				apkInstalledArray = new ArrayList<AppItem>();
			} else {
				apkInstalledArray.clear();
			}
			
			if (apkUnstalledArray == null) {
				apkUnstalledArray = new ArrayList<AppItem>();
			} else {
				apkUnstalledArray.clear();
			}
			
		}

		@Override
		public void run() {
			super.run();

			startTime = System.currentTimeMillis();
			apkPathList = DBApkPathUtils.getApkPathList(mContext);
			if (apkPathList != null && apkPathList.size() > 0) {
				for (int i = 0; i < apkPathList.size(); i++) {
					File file = new File(SDCARDPATH, apkPathList.get(i));
					if (stop) {
						return;
					}
					ergodicFiles(file);
				}

				File file = new File(SDCARDPATH);
				if (stop) {
					return;
				}
				ergodicFiles(file);
			}
			Collections.sort(apkInstalledArray, new CodeSizeComparator());
			Collections.sort(apkUnstalledArray, new CodeSizeComparator());
			if (!apkPathcollection && collectionPaths != null && collectionPaths.size() > 0) {
				Iterator<String> iterator = collectionPaths.iterator();
				ArrayList<String> paths = new ArrayList<String>();
				while (iterator.hasNext()) {
					paths.add(iterator.next());
				}
				try {
					DBApkPathUtils.save(mContext, paths);
					sp.edit().putBoolean("apkPathcollection", true).commit();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			handler.sendEmptyMessage(0);
		}

		Handler handler = new Handler() {

			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				if (mAppItems.size() > 0) {
					findViewById(R.id.software_install_tips_textview).setVisibility(View.GONE);
					childList.add(apkInstalledArray);
					childList.add(apkUnstalledArray);
					expandAdapter = new Adapter4ApkCustom(mContext, groupList, childList);
					apkCustomListView.setVisibility(View.VISIBLE);
					apkCustomListView.setAdapter(expandAdapter);
					apkCustomListView.expandGroup(0);
					apkCustomListView.expandGroup(1);
				} else {
					apkCustomListView.setVisibility(View.GONE);
					TextView app_install_tips_textview = (TextView) findViewById(R.id.software_install_tips_textview);
					app_install_tips_textview.setVisibility(View.VISIBLE);
					app_install_tips_textview.setText(R.string.scan_apk_null);
				}
				updateUI();
				iosProgressDialog.dismiss();

				DLog.i("debug", "apk扫描用时: " + (System.currentTimeMillis() - startTime) + "毫秒");
			}

		};

		/**
		 * 遍历file
		 */
		public void ergodicFiles(File path) {
			if (path.isDirectory()) {
				File[] files = path.listFiles(new FileFilter() {

					@Override
					public boolean accept(File pathname) {
						if (pathname.getName().endsWith(".apk")) {
							return true;
						}
						return false;
					}
				});
				if (files != null) {
					for (File file : files) {
						String fileName = file.getName();
						if (fileName != null && fileName.length() != 0) {
							AppItem appItem = new AppItem();
							appItem.setAppName(file.getName());
							appItem.setFilePath(file.getAbsolutePath());
							if (fillApkModel(appItem)) {
								
								if (appItem.isInstall()) {
									apkInstalledArray.add(appItem);
								} else {
									apkUnstalledArray.add(appItem);
								}
								mAppItems.add(appItem);
								if (!apkPathcollection) {
									addCollectionPath(appItem.getFilePath());
								}
							} else {
								appItem.setAppVersion(mContext.getString(R.string.app_version_name, "0"));
								appItem.setAppName(getString(R.string.apk_not_full));
								appItem.setCodeSize(file.length());
								appItem.setChecked(true);
								mAppItems.add(appItem);
								if (!apkPathcollection) {
									addCollectionPath(appItem.getFilePath());
								}
								if (appItem.isInstall()) {
									apkInstalledArray.add(appItem);
								} else {
									apkUnstalledArray.add(appItem);
								}
							}
						}
					}
				}
			}
		}
	}

	/**
	 * 获取未安装的apk信息
	 * 
	 * @param ctx
	 * @param apkPath
	 * @return
	 */
	public boolean fillApkModel(AppItem info) {
		String filepath = info.getFilePath();
		File file = new File(filepath);
		if (file == null || !file.exists()) {
			return false;
		}
		info.setCodePath(filepath);
		info.setCodeSize(file.length());
		String PATH_PackageParser = "android.content.pm.PackageParser";
		String PATH_AssetManager = "android.content.res.AssetManager";
		try {
			// 反射得到pkgParserCls对象并实例化,有参数
			Class<?> pkgParserCls = Class.forName(PATH_PackageParser);
			Class<?>[] typeArgs = null;
			Object[] valueArgs = null;
			Object pkgParser = null;
			try {
				typeArgs = new Class<?>[] { String.class };
				Constructor<?> pkgParserCt = pkgParserCls.getConstructor(typeArgs);
				valueArgs = new Object[] { filepath };
				pkgParser = pkgParserCt.newInstance(valueArgs);
			} catch (Exception e1) {
				Constructor<?> pkgParserCt = pkgParserCls.getConstructor();
				pkgParser = pkgParserCt.newInstance();
			}
			if (pkgParser == null) {
				return false;
			}

			// 从pkgParserCls类得到parsePackage方法
			Object pkgParserPkg = null;
			try {
				DisplayMetrics metrics = new DisplayMetrics();
				metrics.setToDefaults();// 这个是与显示有关的, 这边使用默认
				typeArgs = new Class<?>[] { File.class, String.class, DisplayMetrics.class, int.class };
				Method pkgParser_parsePackageMtd = pkgParserCls.getDeclaredMethod("parsePackage", typeArgs);
				valueArgs = new Object[] { new File(filepath), filepath, metrics, 0 };
				// 执行pkgParser_parsePackageMtd方法并返回
				pkgParserPkg = pkgParser_parsePackageMtd.invoke(pkgParser, valueArgs);
			} catch (Exception e1) {
				typeArgs = new Class<?>[] { File.class, int.class };
				Method pkgParser_parsePackageMtd = pkgParserCls.getDeclaredMethod("parsePackage", typeArgs);
				valueArgs = new Object[] { new File(filepath), 0 };
				// 执行pkgParser_parsePackageMtd方法并返回
				pkgParserPkg = pkgParser_parsePackageMtd.invoke(pkgParser, valueArgs);
			}
			if (pkgParserPkg == null) {
				return false;
			}
			// 从返回的对象得到名为"applicationInfo"的字段对象
			Field appInfoFld = pkgParserPkg.getClass().getDeclaredField("applicationInfo");

			// 从对象"pkgParserPkg"得到字段"appInfoFld"的值
			if (appInfoFld.get(pkgParserPkg) == null) {
				return false;
			}
			ApplicationInfo applicationInfo = (ApplicationInfo) appInfoFld.get(pkgParserPkg);

			// 反射得到assetMagCls对象并实例化,无参
			Class<?> assetMagCls = Class.forName(PATH_AssetManager);
			Object assetMag = assetMagCls.newInstance();

			// 从assetMagCls类得到addAssetPath方法
			typeArgs = new Class[1];
			typeArgs[0] = String.class;
			Method assetMag_addAssetPathMtd = assetMagCls.getDeclaredMethod("addAssetPath", typeArgs);
			valueArgs = new Object[1];
			valueArgs[0] = filepath;
			// 执行assetMag_addAssetPathMtd方法
			assetMag_addAssetPathMtd.invoke(assetMag, valueArgs);

			// 得到Resources对象并实例化,有参数
			Resources res = mContext.getResources();
			typeArgs = new Class[3];
			typeArgs[0] = assetMag.getClass();
			typeArgs[1] = res.getDisplayMetrics().getClass();
			typeArgs[2] = res.getConfiguration().getClass();
			Constructor<Resources> resCt = Resources.class.getConstructor(typeArgs);
			valueArgs = new Object[3];
			valueArgs[0] = assetMag;
			valueArgs[1] = res.getDisplayMetrics();
			valueArgs[2] = res.getConfiguration();
			res = (Resources) resCt.newInstance(valueArgs);

			// 读取apk文件的信息
			if (applicationInfo != null) {
				if (applicationInfo.icon != 0) {// 图片存在，则读取相关信息
					// Drawable icon = res.getDrawable(applicationInfo.icon);//
					// 图标
					// info.setAppIcon(icon);
					info.setApplicationInfo(applicationInfo);
					info.setResources(res);
				}
				if (applicationInfo.labelRes != 0) {
					String neme = (String) res.getText(applicationInfo.labelRes);// 名字
					info.setAppName(neme);
				} else {
					String apkName = file.getName();
					info.setAppName(apkName.substring(0, apkName.lastIndexOf(".")));
				}
				String pkgName = applicationInfo.packageName;// 包名
				info.setAppPackage(pkgName);
			} else {
				return false;
			}
			PackageManager pm = mContext.getPackageManager();
			PackageInfo packageInfo = pm.getPackageArchiveInfo(filepath, PackageManager.GET_ACTIVITIES);
			if (packageInfo != null) {
				info.setAppVersion(packageInfo.versionName);// 版本号
				info.setAppVersionCode(packageInfo.versionCode);// 版本码
			}
			PackageInfo mPackageInfo = null;
			try {
				mPackageInfo = pm.getPackageInfo(info.getAppPackage(), 0);
			} catch (NameNotFoundException e) {
			}
			if (mPackageInfo != null) {
				info.setInstall(true);
				info.setChecked(true);
				if (info.getAppVersionCode() > mPackageInfo.versionCode) {
					info.setAppVersion(getString(R.string.app_install_version_hight_tip));
				} else {
					info.setAppVersion(getString(R.string.app_install_version_low_tip));
					info.setChecked(true);
				}
			} else {
				info.setInstall(false);
				info.setChecked(false);
				info.setAppVersion(getString(R.string.app_not_install_tip));
			}

			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	private void clearApk() {
		ArrayList<AppItem> appItems = expandAdapter.getSelectApkList();
		freeMemory = 0;
		for (AppItem appItem : appItems) {
			FileUtils.deleteFileByPath(appItem.getFilePath());
			freeMemory += appItem.getCodeSize();
			expandAdapter.remove(appItem);
		}
		ClearUtils.setDayClearSize(mContext, freeMemory);
		ClearUtils.setHistoryClearSize(mContext, freeMemory);
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		stop = true;
	}

	/**
	 * 收集apk path
	 * 
	 * @param path
	 */
	private void addCollectionPath(String path) {
		String sdPath = Constants.SDCARD_PATH;
		File apkFile = new File(path);

		String parentPath = apkFile.getParent();
		if (sdPath.equals(parentPath)) {
			return;
		}
		parentPath = parentPath.substring(parentPath.indexOf(sdPath) + sdPath.length(), parentPath.length());
		if (collectionPaths == null) {
			collectionPaths = new HashSet<String>();
		}
		collectionPaths.add(parentPath);
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.clear_button:

			if (expandAdapter != null && expandAdapter.getSelectApkList().size() > 0) {
				clearApk();
				updateUI();
			} else {
				Toast.makeText(mContext, R.string.clear_select_null, Toast.LENGTH_SHORT).show();
			}
			break;

		default:
			break;
		}
	}

	@Override
	public void onResume() {
		if (installApp != null) {
			PackageInfo packageInfo = null;
			try {
				packageInfo = mContext.getPackageManager().getPackageInfo(installApp.getAppPackage(), 0);
			} catch (NameNotFoundException e) {
				e.printStackTrace();
			}
			if (packageInfo != null) {
				if (expandAdapter != null) {
					installApp.setAppVersion(getString(R.string.app_install_version_low_tip));
					installApp.setChecked(true);
				}
			}
			installApp = null;
		}
	}

	@Override
	public boolean onChildClick(ExpandableListView parent, View v,
			final int groupPosition, final int childPosition, long id) {
		final AppItem appItem2 = (AppItem) expandAdapter.getChild(groupPosition, childPosition);
		final CustomDialog3 customDialog3 = new CustomDialog3(mContext);
		customDialog3.setTitle(R.string.dialog_tip_detail);
		View dialog_view_process = LayoutInflater.from(mContext).inflate(R.layout.dialog_apk_item, null);
		TextView cache_memory_textview = (TextView) dialog_view_process.findViewById(R.id.apk_memory_textview);
		TextView cache_path_textview = (TextView) dialog_view_process.findViewById(R.id.apk_path_textview);
		TextView button_install = (TextView) dialog_view_process.findViewById(R.id.button_install);
		cache_memory_textview.setText(getString(R.string.dialog_tip_size) + ": " + FormatUtils.formatBytesInByte(appItem2.getCodeSize()));
		cache_path_textview.setText(getString(R.string.dialog_tip_path) + ": " + appItem2.getFilePath());

		customDialog3.setView(dialog_view_process);
		customDialog3.setButton1(getString(R.string.dialog_button_cancel), null);
		customDialog3.setButton2(getString(R.string.clear_depth_button_delete), new OnClickListener() {

			@Override
			public void onClick(View v) {
				customDialog3.dismiss();
				FileUtils.deleteFileByPath(appItem2.getFilePath());
				expandAdapter.remove(groupPosition, childPosition);
				updateUI();
			}
		});
		button_install.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				customDialog3.dismiss();
				AppManagerUtils.openInstaller(mContext, appItem2.getFilePath());
			}
		});
		customDialog3.show();
		return false;
	}

}
