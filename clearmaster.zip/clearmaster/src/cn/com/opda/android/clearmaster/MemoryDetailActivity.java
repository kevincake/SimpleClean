package cn.com.opda.android.clearmaster;

import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.CountDownLatch;

import android.content.pm.ApplicationInfo;
import android.content.pm.IPackageStatsObserver;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageStats;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.RemoteException;
import android.text.TextUtils;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import cn.com.opda.android.clearmaster.custom.CustomMemoryChart;
import cn.com.opda.android.clearmaster.custom.CustomProgressbar;
import cn.com.opda.android.clearmaster.custom.CustomRectFView;
import cn.com.opda.android.clearmaster.custom.RoundProgressView;
import cn.com.opda.android.clearmaster.model.AppItem;
import cn.com.opda.android.clearmaster.utils.BannerUtils;
import cn.com.opda.android.clearmaster.utils.DLog;
import cn.com.opda.android.clearmaster.utils.FileUtils;
import cn.com.opda.android.clearmaster.utils.FormatUtils;
import cn.com.opda.android.clearmaster.utils.MemoryUtils;

/**
 * 内存使用情况详细页面
 * @author 庄宏岩
 *
 */
public class MemoryDetailActivity extends BaseActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_memory_detail);
		BannerUtils.setMainTitle(this, R.string.external_space_title);
		BannerUtils.initBackButton(this);
		initViewAndEvent();
	}

	private void initViewAndEvent() {
		LinearLayout one_memory_layout = (LinearLayout) findViewById(R.id.one_memory_layout);
		LinearLayout more_memory_layout = (LinearLayout) findViewById(R.id.more_memory_layout);

		final TextView app_size_textview = (TextView) findViewById(R.id.app_size_textview);
		final TextView media_size_textview = (TextView) findViewById(R.id.media_size_textview);
		final TextView other_size_textview = (TextView) findViewById(R.id.other_size_textview);
		final TextView avil_size_textview = (TextView) findViewById(R.id.avil_size_textview);

		final TextView progress_title_2 = (TextView) findViewById(R.id.progress_title_2);
		final TextView progress_title_3 = (TextView) findViewById(R.id.progress_title_3);

		CustomRectFView app_rect_view = (CustomRectFView) findViewById(R.id.app_rect_view);
		CustomRectFView media_rect_view = (CustomRectFView) findViewById(R.id.media_rect_view);
		CustomRectFView other_rect_view = (CustomRectFView) findViewById(R.id.other_rect_view);
		CustomRectFView avil_rect_view = (CustomRectFView) findViewById(R.id.avil_rect_view);

		app_rect_view.init(CustomMemoryChart.appColor);
		media_rect_view.init(CustomMemoryChart.mediaColor);
		other_rect_view.init(CustomMemoryChart.otherColor);
		avil_rect_view.init(CustomMemoryChart.avilColor);

		RoundProgressView rount_progressview_1 = (RoundProgressView) findViewById(R.id.rount_progressview_1);
		TextView progress_textview_1 = (TextView) findViewById(R.id.progress_textview_1);

		final long romMax = MemoryUtils.getTotalInternalMemorySize();
		final long romAva = MemoryUtils.getAvailableInternalMemorySize();
		int romProgress = (int) ((romMax - romAva) * 100 / romMax);
		rount_progressview_1.setProgress(romProgress);
		progress_textview_1.setText(romProgress + "%");

		RoundProgressView rount_progressview_2 = (RoundProgressView) findViewById(R.id.rount_progressview_2);
		LinearLayout rount_progressview_layout2 = (LinearLayout) findViewById(R.id.rount_progressview_layout2);
		View memory_line_1 = (View) findViewById(R.id.memory_line_1);
		TextView progress_textview_2 = (TextView) findViewById(R.id.progress_textview_2);
		final long sdMax = MemoryUtils.getTotalExternalMemorySize();
		final long sdAva = MemoryUtils.getAvailableExternalMemorySize();

		long totalMemory = 0;
		long avaMemory = 0;
		if (FormatUtils.compareSize(sdMax, romMax) && FormatUtils.compareSize(sdAva, romAva)) {
			rount_progressview_layout2.setVisibility(View.GONE);
			memory_line_1.setVisibility(View.GONE);
			totalMemory = romMax;
			avaMemory = romAva;
		} else {
			rount_progressview_layout2.setVisibility(View.VISIBLE);
			memory_line_1.setVisibility(View.VISIBLE);
			int sdProgress = (int) ((sdMax - sdAva) * 100 / sdMax);
			rount_progressview_2.setProgress(sdProgress);
			progress_textview_2.setText(sdProgress + "%");
			if (Build.VERSION.SDK_INT > 10) {
				if (Environment.isExternalStorageEmulated()) {
					progress_title_2.setText(R.string.memory_space_external);
				} else {
					progress_title_2.setText(R.string.memory_space_internal);
				}
			}else{
				progress_title_2.setText(R.string.memory_space_external);
			}
			totalMemory = sdMax + romMax;
			avaMemory = sdAva + romAva;
		}

		String sdcard1 = MemoryUtils.getSdcard0();
		String sdcard2 = MemoryUtils.getSdcard1();

		if (!TextUtils.isEmpty(sdcard2) && !sdcard1.equals(sdcard2)) {
			long sd2Total = MemoryUtils.getFileTotalSize(sdcard2);
			long sd2Ava = MemoryUtils.getFileAvailableSize(sdcard2);

			if (sd2Total > 0 && sd2Total != sdMax) {
				totalMemory += sd2Total;
				avaMemory += sd2Ava;

				RoundProgressView rount_progressview_3 = (RoundProgressView) findViewById(R.id.rount_progressview_3);
				LinearLayout rount_progressview_layout3 = (LinearLayout) findViewById(R.id.rount_progressview_layout3);
				rount_progressview_layout3.setVisibility(View.VISIBLE);
				View memory_line_2 = (View) findViewById(R.id.memory_line_2);
				memory_line_2.setVisibility(View.VISIBLE);
				TextView progress_textview_3 = (TextView) findViewById(R.id.progress_textview_3);
				if (rount_progressview_layout2.getVisibility() == View.VISIBLE) {
					progress_textview_3.setCompoundDrawablesWithIntrinsicBounds(null, getResources().getDrawable(R.drawable.card2), null, null);
					progress_textview_2.setCompoundDrawablesWithIntrinsicBounds(null, getResources().getDrawable(R.drawable.card1), null, null);
					progress_title_2.setText(R.string.memory_space_internal);
					progress_title_3.setText(R.string.memory_space_external);
				} else {
					progress_textview_3.setCompoundDrawablesWithIntrinsicBounds(null, getResources().getDrawable(R.drawable.card), null, null);
					progress_title_3.setText(R.string.memory_space_external);
				}

				int sd2Progress = (int) ((sd2Total - sd2Ava) * 100 / sd2Total);
				rount_progressview_3.setProgress(sd2Progress);
				progress_textview_3.setText(sd2Progress + "%");

			}
		}
		if (findViewById(R.id.rount_progressview_layout2).getVisibility() == View.GONE
				&& findViewById(R.id.rount_progressview_layout3).getVisibility() == View.GONE) {
			one_memory_layout.setVisibility(View.VISIBLE);
			more_memory_layout.setVisibility(View.GONE);
			CustomProgressbar memory_progressbar = (CustomProgressbar) findViewById(R.id.memory_progressbar);
			memory_progressbar.setProgress(romProgress);
			TextView memory_progress_textview = (TextView) findViewById(R.id.memory_progress_textview);
			memory_progress_textview.setText(romProgress + "%");
		}

		final long finalTotalMemory = totalMemory;
		final long finalAvalMemory = avaMemory;
		final CustomMemoryChart memory_chart_view = (CustomMemoryChart) findViewById(R.id.memory_chart_view);
		new Thread(new Runnable() {

			@Override
			public void run() {
				long totalImage = FileUtils.getMediaImageTotalSize(MemoryDetailActivity.this);
				long totalVideo = FileUtils.getMediaVideoTotalSize(MemoryDetailActivity.this);
				long totalAudio = FileUtils.getMediaAudioTotalSize(MemoryDetailActivity.this);
				final long totalMediaSize = totalAudio + totalImage + totalVideo;
				final float mediaProgress = FormatUtils.formatFloatRound((float) (totalMediaSize) * 100 / (float) (finalTotalMemory));
				DLog.i("debug", "mediaProgress : " + mediaProgress);
				runOnUiThread(new Runnable() {

					@Override
					public void run() {
						memory_chart_view.setMediaProgress(mediaProgress);
						media_size_textview.setText(FormatUtils.formatBytesInByte(totalMediaSize) + " " + mediaProgress + "%");
					}
				});

				final long totalAppSize = getTotalAppSize();
				final float appProgress = FormatUtils.formatFloatRound((float) totalAppSize * 100 / (float) (finalTotalMemory));
				DLog.i("debug", "appProgress : " + appProgress);
				runOnUiThread(new Runnable() {

					@Override
					public void run() {
						memory_chart_view.setAppProgress(appProgress);
						app_size_textview.setText(FormatUtils.formatBytesInByte(totalAppSize) + " " + appProgress + "%");
					}
				});

				final float otherProgress = FormatUtils.formatFloatRound((float) (finalTotalMemory - finalAvalMemory) * 100 / (float) (finalTotalMemory)
						- mediaProgress - appProgress);
				DLog.i("debug", "otherProgress : " + otherProgress);
				runOnUiThread(new Runnable() {

					@Override
					public void run() {
						memory_chart_view.setOtherProgress(otherProgress);
						other_size_textview.setText(FormatUtils.formatBytesInByte(finalTotalMemory - finalAvalMemory - totalAppSize - totalMediaSize) + " "
								+ otherProgress + "%");

					}
				});

				final float avilProgress = FormatUtils.formatFloatRound(100.0f - otherProgress - mediaProgress - appProgress);
				runOnUiThread(new Runnable() {

					@Override
					public void run() {
						avil_size_textview.setText(FormatUtils.formatBytesInByte(finalAvalMemory) + " " + avilProgress + "%");
					}
				});

			}

		}).start();

	}

	/**
	 * 获取app占用的内存大小
	 * @return
	 */
	public long getTotalAppSize() {
		PackageManager pm = getPackageManager();
		List<PackageInfo> list = pm.getInstalledPackages((PackageManager.GET_UNINSTALLED_PACKAGES));
		long totalSize = 0;
		if (list != null) {
			for (PackageInfo packageInfo : list) {
				ApplicationInfo applicationInfo = packageInfo.applicationInfo;
				if (applicationInfo == null) {
					continue;
				}
				final String sourceDir = applicationInfo.sourceDir;
				if (sourceDir != null) {
					final AppItem appItem = new AppItem();
					appItem.setAppPackage(applicationInfo.packageName);
					final CountDownLatch countDownLatch = new CountDownLatch(1);
					try {
						Method getPackageSizeInfo = pm.getClass().getMethod("getPackageSizeInfo", String.class, IPackageStatsObserver.class);
						getPackageSizeInfo.invoke(pm, appItem.getAppPackage(), new IPackageStatsObserver.Stub() {
							public void onGetStatsCompleted(PackageStats pStats, boolean succeeded) throws RemoteException {
								if (pStats != null) {
									if(Build.VERSION.SDK_INT>=11){
										appItem.setCacheSize(pStats.cacheSize + pStats.externalCacheSize);
									}else{
										appItem.setCacheSize(pStats.cacheSize);
									}
									if(Build.VERSION.SDK_INT>=14){
										appItem.setCodeSize(pStats.codeSize + pStats.dataSize + pStats.externalDataSize + pStats.externalCodeSize + pStats.externalObbSize);
									}else if(Build.VERSION.SDK_INT>=11){
										appItem.setCodeSize(pStats.codeSize + pStats.dataSize + pStats.externalDataSize + pStats.externalObbSize);
									}else{
										appItem.setCodeSize(pStats.codeSize + pStats.dataSize);
									}
								}
								countDownLatch.countDown();
							}
						});
						countDownLatch.await();
					} catch (Exception e) {
						e.printStackTrace();
					}
					totalSize += appItem.getCacheSize();
					totalSize += appItem.getCodeSize();
				}
			}
		}
		return totalSize;
	}
}
