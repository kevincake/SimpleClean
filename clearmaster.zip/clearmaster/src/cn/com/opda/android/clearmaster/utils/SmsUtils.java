package cn.com.opda.android.clearmaster.utils;

import java.util.ArrayList;

import android.content.ContentResolver;
import android.content.Context;
import cn.com.opda.android.clearmaster.model.ConversationInfo;
import cn.com.opda.android.clearmaster.privacy.SmsBackUpInfo;

public class SmsUtils {
	/**
	 * 根据电话号码顺便判定电话号码的种类！！，
	 */
	public static ConversationInfo findRealNameInOther(Context context, ConversationInfo conversation, boolean isCN) {
		if (conversation == null)
			return null;
		String phone = conversation.getAddress();

		if (phone == null)
			return null;

		String name = null;

		name = CallUtils.findNameByPhoneNumORId(context, phone);
		if (name != null) {
			conversation.setName(name);
			conversation.setNumberType(Constants.PHONETYPE_CONTACT);
			return conversation;
		} else {
			conversation.setName(phone);
			conversation.setNumberType(Constants.PHONETYPE_UNKNOWN);
		}
		if (isCN) {
			name = CallUtils.isServerPhone(context, phone);
			if (name != null) {
				conversation.setNumberType(Constants.PHONETYPE_SERVER);
				conversation.setName(name);
			} else {
				conversation.setNumberType(Constants.PHONETYPE_UNKNOWN);
			}
		}

		return conversation;
	}

	/**
	 * 根据手机号码查找联系人姓名 修改后的方法！！2010.11.12
	 */
	public static String findRealNameInOther(Context context, String phone) {
		if (phone == null)
			return null;

		String name = null;

		name = CallUtils.findNameByPhoneNumORId(context, phone);
		if (name != null) {
			return name;
		}else{
			name = CallUtils.isServerPhone(context, phone);
			if (name != null) {
				return name;
			}
		}
		return phone;
	}

	/**
	 * 删除所有的信息
	 */
	public static final synchronized void deleteAllMessage(Context context) {
		ContentResolver contentResolver = context.getContentResolver();
		contentResolver.delete(Constants.SMSAll_URL, null, null);
	}

	/**
	 * 根据短信的id删除信息
	 */
	public static final synchronized void deleteMessageById(Context context, int id) {
		ContentResolver contentResolver = context.getContentResolver();
		contentResolver.delete(Constants.SMSAll_URL, Constants.SMS_ID + "=?", new String[] { id + "" });
	}
	/**
	 * 根据短信的id删除信息
	 */
	public static final synchronized void deleteMessageByList(Context context, ArrayList<SmsBackUpInfo> backUpInfos) {
		ContentResolver contentResolver = context.getContentResolver();
		for(SmsBackUpInfo smsBackUpInfo: backUpInfos){
			contentResolver.delete(Constants.SMSAll_URL, Constants.SMS_ID + "=?", new String[] { smsBackUpInfo.getId() + "" });
		}
	}

	/**
	 * 根据会话 的id来删除会话中的所有信息
	 */
	public static final synchronized void deleteConversationByThreadId(Context context, int id) {
		ContentResolver contentResolver = context.getContentResolver();
		contentResolver.delete(Constants.SMSAll_URL, Constants.SMS_thread_id + "=?", new String[] { id + "" });

	}

}
