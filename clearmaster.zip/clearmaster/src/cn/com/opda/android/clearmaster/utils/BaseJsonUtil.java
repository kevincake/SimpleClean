package cn.com.opda.android.clearmaster.utils;

import java.net.ConnectException;

import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.text.TextUtils;

public class BaseJsonUtil {
	protected Context context;
	private int code;

	public BaseJsonUtil(Context context) {
		this.context = context;
	}

	/**
	 * 添加请求前的公共参数
	 * 
	 * @param did
	 * @return 请求的根JSONObject
	 * @throws JSONException
	 */
	public  JSONObject commonRequest() throws Exception {
		long did = DeviceInfoUtils.getDid(context);
		long deviceid = DeviceInfoUtils.getDeviceId(context);
		JSONObject value = new JSONObject();
		value.put("configversion", 1000);
		try {
			DeviceInfoUtils.addDeviceNode(did, deviceid, value, context);
		} catch (JSONException e) {
			e.printStackTrace();
		}

		if (TextUtils.isEmpty(NetworkUtil.getNetworkIp(context))) {
			throw new ConnectException();
		}

		return value;
	}

	public void parseResponse(String response) throws Exception {
		JSONObject root = new JSONObject(response);
		code = root.optInt("code");
		int did = root.optInt("did");
		JSONObject device = root.optJSONObject("devices");
		int devices_id = device.optInt("devices_id");
		if (devices_id >= 0) {
			DeviceInfoUtils.updateDeviceId(context, devices_id);
		}
		if (did > 0) {
			DeviceInfoUtils.updateDid(context, did);
		}
	}

	public int getCode() {
		return code;
	}
}
