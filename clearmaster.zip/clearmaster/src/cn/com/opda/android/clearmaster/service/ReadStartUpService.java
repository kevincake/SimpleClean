package cn.com.opda.android.clearmaster.service;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;

import android.Manifest.permission;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.IBinder;
import cn.com.opda.android.clearmaster.dao.AppStartUpDBUtils;
import cn.com.opda.android.clearmaster.utils.DLog;
import cn.com.opda.android.clearmaster.utils.Terminal;

/**
 * 监听应用的启动
 * @author 庄宏岩
 *
 */
public class ReadStartUpService extends Service {
	public static boolean start = false;
	public boolean stop = false;
	private ReadLogcatAsyntask readLogcatAsyntask;
	private ActivityManager mActivityManager;
	private String lastPackage = "";

	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

	private BroadcastReceiver mReceiver = new BroadcastReceiver() {
		public void onReceive(Context context, Intent intent) {
			String action = intent.getAction();
			if (Intent.ACTION_SCREEN_ON.equals(action)) {
				if (!start) {
					if (!getPackageName().equals(getTopActivity())) {
						stop = false;
						start = true;
						readLogcatAsyntask = new ReadLogcatAsyntask();
						readLogcatAsyntask.execute();
					}
				}
			}
			if (Intent.ACTION_SCREEN_OFF.equals(action)) {
				stop = true;
				start = false;
				if (readLogcatAsyntask != null) {
					readLogcatAsyntask.cancel(true);
					readLogcatAsyntask = null;
				}
			}
		}
	};

	@Override
	public void onCreate() {
		super.onCreate();
		IntentFilter intentFilter = new IntentFilter();
		intentFilter.addAction(Intent.ACTION_SCREEN_ON);
		intentFilter.addAction(Intent.ACTION_SCREEN_OFF);
		registerReceiver(mReceiver, intentFilter);
		if (!start) {
			if (!getPackageName().equals(getTopActivity())) {
				stop = false;
				start = true;
				readLogcatAsyntask = new ReadLogcatAsyntask();
				readLogcatAsyntask.execute();
			}
		}
	}

	class ReadLogcatAsyntask extends AsyncTask<String, String, String> {

		@Override
		protected String doInBackground(String... params) {
			PackageManager manager = getPackageManager();
			int state = manager.checkPermission(permission.READ_LOGS, getPackageName());
			if (Build.VERSION.SDK_INT < 16 || state == PackageManager.PERMISSION_GRANTED) {
				readLog();
			} else {
				if (Terminal.isRoot(ReadStartUpService.this)) {
					Terminal.RootCommand("pm grant cn.com.opda.android.clearmaster android.permission.READ_LOGS");
					state = manager.checkPermission(permission.READ_LOGS, getPackageName());
					DLog.i("debug", "read log permission state : " + state);
					if (state == PackageManager.PERMISSION_GRANTED) {
						Terminal.RootCommand("kill " + getMyPid());
						//readLog();
					} else {
						//readTopActivity();
					}
				}
			}
			return null;
		}

		@SuppressWarnings("unused")
		private void readTopActivity() {
			while (!stop) {
				String topPackage = getTopActivity();
				DLog.d("debug", "TopPackageName : " + topPackage);
				if (!topPackage.equals(getPackageName()) && !topPackage.equals(lastPackage)) {
					lastPackage = topPackage;
					AppStartUpDBUtils.save(getApplicationContext(), lastPackage, System.currentTimeMillis());
				}
				try {
					Thread.sleep(5000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			start = false;
		}

		private void readLog() {
			boolean bool = false;
			try {
				Runtime.getRuntime().exec("logcat -c").waitFor();
				Process logprocess = Runtime.getRuntime().exec("logcat ActivityManager:I *:S");
				InputStream inputStream = logprocess.getInputStream();
				InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
				BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
				while (!stop) {
					String str = bufferedReader.readLine();
					if (str != null) {
						bool = str.contains("act=android.intent.action.MAIN cat=[android.intent.category.LAUNCHER");
						if (bool) {
							String packageName = str.substring(str.indexOf("cmp=") + 4, str.lastIndexOf("/"));
							if (!packageName.equals(getPackageName()) && !lastPackage.equals(packageName)) {
								lastPackage = packageName;
								DLog.d("debug", "log packageName :" + packageName);
								AppStartUpDBUtils.save(getApplicationContext(), lastPackage, System.currentTimeMillis());
							}
						}
					}
					Thread.sleep(100);
				}
				start = false;
			} catch (Exception e) {
				e.printStackTrace();
			} finally {

			}
		}
	}

	private String getTopActivity() {
		if (mActivityManager == null) {
			mActivityManager = ((ActivityManager) getSystemService(Context.ACTIVITY_SERVICE));
		}
		return mActivityManager.getRunningTasks(1).get(0).topActivity.getPackageName();
	}

	private int getMyPid() {
		ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
		List<RunningAppProcessInfo> lists = am.getRunningAppProcesses();
		for (RunningAppProcessInfo runapp : lists) {
			String packageName = runapp.processName;
			if (packageName.equals(getPackageName())) {
				return runapp.pid;
			}
		}
		return -1;
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		unregisterReceiver(mReceiver);
		DLog.i("debug", "service onDestroy");
		stop = true;
		start = false;
		if (readLogcatAsyntask != null) {
			readLogcatAsyntask.cancel(true);
			readLogcatAsyntask = null;
		}
		stopSelf();
	}

}
