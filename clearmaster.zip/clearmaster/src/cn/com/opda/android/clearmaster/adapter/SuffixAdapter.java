package cn.com.opda.android.clearmaster.adapter;

import java.util.ArrayList;

import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.TextView;
import cn.com.opda.android.clearmaster.R;
import cn.com.opda.android.clearmaster.model.SuffixInfo;

public class SuffixAdapter extends BaseAdapter {
	private ArrayList<SuffixInfo> suffixInfos;
	private Context mContext;
	public SuffixAdapter(Context mContext,ArrayList<SuffixInfo> suffixInfos){
		this.suffixInfos = suffixInfos;
		this.mContext = mContext;
	}

	@Override
	public int getCount() {
		return suffixInfos.size();
	}

	@Override
	public Object getItem(int position) {
		return suffixInfos.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}


	public ArrayList<SuffixInfo> getList() {
		return suffixInfos;
	}
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		final Holder mHolder;
		if (convertView == null) {
			LayoutInflater inflater = LayoutInflater.from(mContext);
			convertView = inflater.inflate(R.layout.listview_suffix_item_layout, null);
			mHolder = new Holder();
			mHolder.suffix_name_textview = (TextView) convertView.findViewById(R.id.suffix_name_textview);
			mHolder.suffix_type_textview = (TextView) convertView.findViewById(R.id.suffix_type_textview);
			mHolder.suffix_checkbox = (CheckBox) convertView.findViewById(R.id.suffix_checkbox);
			mHolder.suffix_item_line = convertView.findViewById(R.id.suffix_item_line);
			convertView.setTag(mHolder);
		} else {
			mHolder = (Holder) convertView.getTag();
		}
		final SuffixInfo suffixInfo = suffixInfos.get(position);
		mHolder.suffix_name_textview.setText(suffixInfo.getSuffixName());
		mHolder.suffix_type_textview.setText(suffixInfo.getSuffixType());
		mHolder.suffix_checkbox.setChecked(suffixInfo.isChecked());
		if(position==getCount()-1){
			mHolder.suffix_item_line.setVisibility(View.GONE);
		}else{
			mHolder.suffix_item_line.setVisibility(View.VISIBLE);
		}
		mHolder.suffix_checkbox.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				suffixInfo.setChecked(!suffixInfo.isChecked());
				setSuffixList(suffixInfos);
			}
		});
		return convertView;
	}

	private void setSuffixList(ArrayList<SuffixInfo> suffixInfos) {
		JSONObject jsonObject = new JSONObject();
		String suffix_type = "";
		for (SuffixInfo suffixInfo : suffixInfos) {
			if (suffixInfo.isChecked()) {
				suffix_type += suffixInfo.getSuffixType();

			}
		}
		try {
			jsonObject.put("suffix_type", suffix_type);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(mContext);
		sp.edit().putString("suffix_json", jsonObject.toString()).commit();
	}
	
	class Holder {
		private TextView suffix_name_textview;
		private TextView suffix_type_textview;
		private View suffix_item_line;
		private CheckBox suffix_checkbox; 

	}

}
