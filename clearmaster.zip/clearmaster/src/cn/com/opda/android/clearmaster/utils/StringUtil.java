package cn.com.opda.android.clearmaster.utils;

public class StringUtil {


	/** 字符串拼接方法
	 * StringUtil.link("tel:", "1234", "ddd", this, 1)
	 * @param objs
	 * @return
	 */
	public static final String link(Object... objs) {
		StringBuffer buffer = new StringBuffer();
		for (Object obj : objs) {
			buffer.append(obj);
		}
		return buffer.toString();
	}
}
