package cn.com.opda.android.clearmaster;

import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationSet;
import android.view.animation.OvershootInterpolator;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import cn.com.opda.android.clearmaster.custom.CommentDialog;
import cn.com.opda.android.clearmaster.custom.CustomProgressView;
import cn.com.opda.android.clearmaster.dao.CacheWhiteListUtils;
import cn.com.opda.android.clearmaster.dao.KeepListUtils;
import cn.com.opda.android.clearmaster.quickaction2.ActionItem2;
import cn.com.opda.android.clearmaster.quickaction2.QuickAction2;
import cn.com.opda.android.clearmaster.service.ReadStartUpService;
import cn.com.opda.android.clearmaster.service.SearchApkService;
import cn.com.opda.android.clearmaster.utils.BannerUtils;
import cn.com.opda.android.clearmaster.utils.ClearUtils;
import cn.com.opda.android.clearmaster.utils.Constants;
import cn.com.opda.android.clearmaster.utils.DLog;
import cn.com.opda.android.clearmaster.utils.FormatUtils;
import cn.com.opda.android.clearmaster.utils.MemoryUtils;
import cn.com.opda.android.clearmaster.utils.MenuOptionUtil;
import cn.com.opda.android.clearmaster.utils.ProcessManagerUtils;
import cn.com.opda.android.clearmaster.utils.ShortCutUtils;
import cn.com.opda.android.clearmaster.utils.Terminal;
import cn.com.opda.android.clearmaster.utils.ToolboxAdUtils;
import cn.com.opda.android.clearmaster.utils.VerboseUtils;

import com.chunjie.hongbao.DownloadService;
import com.chunjie.hongbao.FirstDialog;
import com.chunjie.hongbao.JineDialog;
import com.chunjie.hongbao.SharePreUtil;
import com.dashi.smartstore.DashiSmartStore_RootUtils;
import com.lib.statistics.StatisticsUtils;
import com.umeng.analytics.MobclickAgent;
import com.umeng.fb.FeedbackAgent;
import com.umeng.update.UmengUpdateAgent;

public class MainClearActivity extends Activity implements OnClickListener {
	private RelativeLayout tab_1_layout, tab_2_layout, tab_3_layout, tab_4_layout;
	private View vertical_line_view, horizontal_line_1, horizontal_line_2;
	private CustomProgressView big, small;
	private TextView day_clear_size, history_clear_size;
	private TextView small_percent_textview, big_percent_textview;
	private TextView big_available_memory_textview;
	private boolean first = true;
	private RelativeLayout percent_view_layout;
	private Context mContext;

	// 默认的进程白名单
	private String[] keepApps = { "com.android.launcher", "com.tencent.mm", "com.android.phone", "android", "com.google.android.gsf", "com.tencent.mobileqq",
			"com.tencent.padqq", "com.android.systemui", "com.lge.quickcover", "com.sec.android.sviewcover","com.letv.android.client"};
	private boolean mDoubleClickExit = false;
	private long firstExitTime = 0;

	private QuickAction2 qa;

	private RelativeLayout splash_layout;
	private ImageView splash_icon_imageview;
	private ImageView banner_left_imageview;
	private LinearLayout main_layout;
	private SharedPreferences sp;
	private int comment_version = 1;
	private boolean stop;
	
	private ImageView iv_touch_me;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main_clear);
		mContext = MainClearActivity.this;
		stopService(new Intent(mContext, ReadStartUpService.class));
		MobclickAgent.updateOnlineConfig(this);
		UmengUpdateAgent.setUpdateOnlyWifi(false);
		UmengUpdateAgent.update(this);
		BannerUtils.initAppButton(this);
		BannerUtils.initFuliButton(this);
		sp = PreferenceManager.getDefaultSharedPreferences(mContext);
		initSplashView();
		initViewAndEvent();
		initQuickaction();


		sp.edit().putLong("lastUseTime", System.currentTimeMillis()).commit();

		VerboseUtils.init(this, "http://static.opda.com/verbose/clearmaster/verbose_clear.json");

		if (!sp.getBoolean("initKeep", false)) {
			new Thread(new Runnable() {

				@Override
				public void run() {

					KeepListUtils.saveAll(mContext, keepApps);

					PackageManager packageManager = getPackageManager();
					Intent intent = new Intent(Intent.ACTION_MAIN);
					intent.addCategory(Intent.CATEGORY_HOME);

					// 将所有的launcher应用都放到白名单中
					List<ResolveInfo> resolveInfos = packageManager.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);

					for (ResolveInfo resolveInfo : resolveInfos) {
						ActivityInfo activityInfo = resolveInfo.activityInfo;
						if (activityInfo != null) {
							String packageName = resolveInfo.activityInfo.packageName;
							KeepListUtils.save(mContext, packageName);
						}
					}
					String mDefaultInputMethodId = Settings.Secure.getString(getContentResolver(), Settings.Secure.DEFAULT_INPUT_METHOD);
					if (!TextUtils.isEmpty(mDefaultInputMethodId) && mDefaultInputMethodId.contains("/")) {
						String packageName = mDefaultInputMethodId.substring(0, mDefaultInputMethodId.indexOf("/"));
						KeepListUtils.save(mContext, packageName);
					}
					sp.edit().putBoolean("initKeep", true).commit();
				}
			}).start();
		}

		new Thread(new Runnable() {

			@Override
			public void run() {
				CacheWhiteListUtils.initDB(mContext);
			}
		}).start();
		if (Terminal.isRoot(this)) {
			DashiSmartStore_RootUtils.isroot = true;
		}

		boolean addshortcut = sp.getBoolean("addshortcut", false);
		if (!addshortcut) {
			ShortCutUtils.createMainShortCut(this);
			sp.edit().putBoolean("addshortcut", true).commit();
			ShortCutUtils.createShortCut(getApplicationContext(), "cn.com.opda.android.clearmaster.ClearShortcutActivity", R.drawable.shortcut_icon,
					R.string.chortcut_name);
		}

		StatisticsUtils.setAppCode(this, Constants.UPDATE_APPCODE);

		// startService(new Intent(mContext, NetSpeedListenerService.class));

		ImageView shoufa_imageview = (ImageView) findViewById(R.id.shoufa_imageview);
		if (Constants.SHOUFA) {
			DashiSmartStore_RootUtils.packnamelist = new String[] { "com.qihoo.appstore", "com.zhuoyi.market", "cn.goapk.market", "com.nd.android.pandahome2",
					"com.taobao.appcenter", "com.taobao.appcenter", "com.eoemobile.netmarket", "com.baidu.appsearch", "com.sogou.appmall", "com.oppo.market",
					"com.tencent.android.qqdownloader", "cn.ninegame.gamemanager", "com.muzhiwan.market" };
			// DashiSmartStore_RootUtils.packnamelist = new String[] {
			// "com.qihoo.appstore", "com.zhuoyi.market", "cn.goapk.market",
			// "com.nd.android.pandahome2",
			// "com.taobao.appcenter", "com.taobao.appcenter",
			// "com.eoemobile.netmarket", "com.baidu.appsearch",
			// "com.sogou.appmall","com.oppo.market","com.tencent.android.qqdownloader","cn.ninegame.gamemanager","com.muzhiwan.market"
			// };
			shoufa_imageview.setVisibility(View.VISIBLE);
		} else {
			shoufa_imageview.setVisibility(View.GONE);
		}

		new Thread(new Runnable() {

			@Override
			public void run() {
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				runOnUiThread(new Runnable() {

					@Override
					public void run() {
						startAnim();
					}

				});
			}
		}).start();

		FeedbackAgent agent = new FeedbackAgent(this);
		agent.sync();

		new Thread(new Runnable() {
			@Override
			public void run() {
				ToolboxAdUtils.getResultAdInfo(mContext);
				ToolboxAdUtils.getAdInfo(mContext);
			}
		}).start();
	}

	private void initSplashView() {
		splash_layout = (RelativeLayout) findViewById(R.id.splash_layout);
		main_layout = (LinearLayout) findViewById(R.id.main_layout);
		splash_icon_imageview = (ImageView) findViewById(R.id.splash_icon_imageview);
	}

	@Override
	protected void onResume() {
		super.onResume();
		MobclickAgent.onResume(this);
		if (!first) {
			updatePercentView();
		} else {
			first = false;
		}
		int version = sp.getInt("version", -1);
		if (version < getVerCode() || version > getVerCode()) {
			iv_touch_me.setVisibility(View.VISIBLE);
			sp.edit().putBoolean("gone", false).commit();
			sp.edit().putInt("version", getVerCode()).commit();
		} else {
			if (sp.getBoolean("gone", false)) {
				iv_touch_me.setVisibility(View.GONE);
			} else {
				iv_touch_me.setVisibility(View.VISIBLE);
			}
		}

	}

	private void startAnim() {
		AnimationSet animationSet = new AnimationSet(true);
		animationSet.setDuration(1000);
		animationSet.setFillAfter(true);

		int translate_x = -splash_icon_imageview.getRight() - splash_icon_imageview.getWidth();
		int translate_y = -splash_icon_imageview.getBottom() - splash_icon_imageview.getHeight();

		TranslateAnimation translateAnimation = new TranslateAnimation(0, translate_x, 0, translate_y);
		translateAnimation.setInterpolator(new OvershootInterpolator());
		animationSet.addAnimation(translateAnimation);

		float f = banner_left_imageview.getWidth() * 1.0f / splash_icon_imageview.getWidth();

		ScaleAnimation scaleAnimation = new ScaleAnimation(1.0f, f, 1.0f, f);
		scaleAnimation.setDuration(800);
		animationSet.addAnimation(scaleAnimation);

		animationSet.setAnimationListener(new AnimationListener() {

			@Override
			public void onAnimationStart(Animation animation) {

			}

			@Override
			public void onAnimationRepeat(Animation animation) {

			}

			@Override
			public void onAnimationEnd(Animation animation) {
				splash_layout.clearAnimation();
				splash_layout.setVisibility(View.GONE);
				main_layout.setVisibility(View.VISIBLE);
				startTabAnim();
			}
		});

		AlphaAnimation alphaAnimation = new AlphaAnimation(1.0f, 0.1f);
		alphaAnimation.setDuration(1000);
		alphaAnimation.setFillAfter(true);
		splash_layout.startAnimation(alphaAnimation);

		splash_icon_imageview.startAnimation(animationSet);

	}

	private void startTabAnim() {

		AnimationSet animationSet1 = getAnim(200);
		AnimationSet animationSet2 = getAnim(400);
		AnimationSet animationSet3 = getAnim(600);
		AnimationSet animationSet4 = getAnim(800);

		tab_3_layout.startAnimation(animationSet1);
		tab_4_layout.startAnimation(animationSet2);
		tab_1_layout.startAnimation(animationSet3);
		tab_2_layout.startAnimation(animationSet4);

		animationSet2.setAnimationListener(new AnimationListener() {

			@Override
			public void onAnimationStart(Animation animation) {

			}

			@Override
			public void onAnimationRepeat(Animation animation) {

			}

			@Override
			public void onAnimationEnd(Animation animation) {
				vertical_line_view.setVisibility(View.VISIBLE);
				horizontal_line_1.setVisibility(View.VISIBLE);
			}
		});

		animationSet4.setAnimationListener(new AnimationListener() {

			@Override
			public void onAnimationStart(Animation animation) {

			}

			@Override
			public void onAnimationRepeat(Animation animation) {

			}

			@Override
			public void onAnimationEnd(Animation animation) {
				horizontal_line_2.setVisibility(View.VISIBLE);

				tab_1_layout.setClickable(true);
				tab_2_layout.setClickable(true);
				tab_3_layout.setClickable(true);
				tab_4_layout.setClickable(true);
			}
		});

		updatePercentView();

		handler.sendEmptyMessageDelayed(0, 1000);
		handler.sendEmptyMessageDelayed(1, 1500);

	}

	Handler handler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			switch (msg.what) {
			case 0:
				showTipsDialog();
				break;

			case 1:
				loadChunjieHongbao(mContext);
				break;
			default:
				break;
			}
		}

	};

	private void showTipsDialog() {
		new Thread(new Runnable() {

			@Override
			public void run() {
				Terminal.grantRoot(mContext);
			}
		}).start();
		if (sp.getInt("comment_version", 0) < comment_version) {
			if (sp.getInt("run_count", 0) >= 8) {
				if (!stop) {
					sp.edit().putInt("comment_version", comment_version).commit();
					sp.edit().putInt("run_count", 0).commit();
					new CommentDialog(this).show();
				}
			} else {
				sp.edit().putInt("run_count", sp.getInt("run_count", 0) + 1).commit();
			}
		}
	}

	@Override
	protected void onPause() {
		super.onPause();
		MobclickAgent.onPause(this);
	}

	public void updatePercentView() {

		new Thread(new Runnable() {

			@Override
			public void run() {
				long sdMax = MemoryUtils.getTotalExternalMemorySize();
				long sdAva = MemoryUtils.getAvailableExternalMemorySize();
				long romMax = MemoryUtils.getTotalInternalMemorySize();
				long romAva = MemoryUtils.getAvailableInternalMemorySize();

				DLog.i("debug", "sdMax: " + sdMax);
				DLog.i("debug", "sdAva: " + sdAva);
				DLog.i("debug", "romMax: " + romMax);
				DLog.i("debug", "romAva: " + romAva);

				long totalMemory = 0;
				long avaMemory = 0;
				if (FormatUtils.compareSize(sdMax, romMax) && FormatUtils.compareSize(sdAva, romAva)) {
					totalMemory = romMax;
					avaMemory = romAva;
				} else {
					totalMemory = sdMax + romMax;
					avaMemory = sdAva + romAva;
				}

				String sdcard1 = MemoryUtils.getSdcard0();
				String sdcard2 = MemoryUtils.getSdcard1();

				DLog.i("debug", "sdcard1: " + sdcard1);
				DLog.i("debug", "sdcard2: " + sdcard2);
				if (!TextUtils.isEmpty(sdcard2) && !sdcard1.equals(sdcard2)) {
					long sd2Total = MemoryUtils.getFileTotalSize(sdcard2);
					long sd2Ava = MemoryUtils.getFileAvailableSize(sdcard2);
					DLog.i("debug", "sd2Total: " + sd2Total);
					DLog.i("debug", "sd2Ava: " + sd2Ava);
					if (sd2Total > 0 && sd2Total != sdMax) {
						totalMemory += sd2Total;
						avaMemory += sd2Ava;
					}
				}

				final long finalAvaMemory = avaMemory;
				final int memoryProgress = (int) ((totalMemory - avaMemory) * 100 / totalMemory);

				long ramMax = ProcessManagerUtils.getRuntimeTotalMemory();
				long ramAva = ProcessManagerUtils.getRuntimeAvailableMemory(mContext);
				final int ramProgress = (int) ((ramMax - ramAva) * 100 / ramMax);
				runOnUiThread(new Runnable() {

					@Override
					public void run() {
						percent_view_layout.setVisibility(View.VISIBLE);
						big.setBig(true);
						big.setPercentView(big_percent_textview);
						big.setProgress(memoryProgress);

						big_available_memory_textview.setText(getString(R.string.available_memory_title, FormatUtils.formatBytesInByte(finalAvaMemory)));

						small.setBig(false);
						small.setPercentView(small_percent_textview);
						small.setProgress(ramProgress);

						day_clear_size.setText(getResources()
								.getString(R.string.day_clear, FormatUtils.formatBytesInByte(ClearUtils.getDayClearSize(mContext))));
						history_clear_size.setText(getResources().getString(R.string.history_clear,
								FormatUtils.formatBytesInByte(ClearUtils.getHistoryClearSize(mContext))));
					}
				});

			}
		}).start();

	}

	private void initViewAndEvent() {
		iv_touch_me = (ImageView) findViewById(R.id.iv_touch_me);
		percent_view_layout = (RelativeLayout) findViewById(R.id.percent_view_layout);

		big = (CustomProgressView) findViewById(R.id.big);
		small = (CustomProgressView) findViewById(R.id.small);

		big.setOnClickListener(this);
		small.setOnClickListener(this);

		TextView banner_title_textview = (TextView) findViewById(R.id.banner_title_textview);
		banner_title_textview.setText(R.string.app_name);

		banner_left_imageview = (ImageView) findViewById(R.id.banner_left_imageview);
		banner_left_imageview.setVisibility(View.VISIBLE);

		big_percent_textview = (TextView) findViewById(R.id.big_percent_textview);
		small_percent_textview = (TextView) findViewById(R.id.small_percent_textview);

		big_available_memory_textview = (TextView) findViewById(R.id.big_available_memory_textview);

		day_clear_size = (TextView) findViewById(R.id.day_clear_size);
		history_clear_size = (TextView) findViewById(R.id.history_clear_size);

		tab_1_layout = (RelativeLayout) findViewById(R.id.tab_1_layout);
		tab_2_layout = (RelativeLayout) findViewById(R.id.tab_2_layout);
		tab_3_layout = (RelativeLayout) findViewById(R.id.tab_3_layout);
		tab_4_layout = (RelativeLayout) findViewById(R.id.tab_4_layout);

		tab_1_layout.setOnClickListener(this);
		tab_2_layout.setOnClickListener(this);
		tab_3_layout.setOnClickListener(this);
		tab_4_layout.setOnClickListener(this);

		tab_1_layout.setClickable(false);
		tab_2_layout.setClickable(false);
		tab_3_layout.setClickable(false);
		tab_4_layout.setClickable(false);

		vertical_line_view = findViewById(R.id.vertical_line_view);
		horizontal_line_1 = findViewById(R.id.horizontal_line_1);
		horizontal_line_2 = findViewById(R.id.horizontal_line_2);
	}
	
	private int getVerCode() {
        int verCode = -1;
        try {
            verCode = getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
        } catch (NameNotFoundException e) {
            Log.e("msg", e.getMessage());
        }
        return verCode;
    }
	
	private void initQuickaction() {
		ImageView banner_about_imageview = (ImageView) findViewById(R.id.banner_about_imageview);
		banner_about_imageview.setVisibility(View.INVISIBLE);
		qa = new QuickAction2(banner_about_imageview);

		final ActionItem2 share = new ActionItem2();
		share.setTitle(getString(R.string.menu_appshare));
		share.setIcon(mContext.getResources().getDrawable(R.drawable.menu_share));
		share.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				qa.dismiss();
				MenuOptionUtil.share(mContext);
			}
		});
		qa.addActionItem(share);

		final ActionItem2 feedback = new ActionItem2();
		feedback.setTitle(getString(R.string.menu_feedback));
		feedback.setIcon(mContext.getResources().getDrawable(R.drawable.menu_feedback));
		feedback.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				qa.dismiss();
				FeedbackAgent agent = new FeedbackAgent(mContext);
				agent.startFeedbackActivity();
				overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
			}
		});
		qa.addActionItem(feedback);

		final ActionItem2 setting = new ActionItem2();
		setting.setTitle(getString(R.string.menu_setting));
		setting.setIcon(mContext.getResources().getDrawable(R.drawable.menu_setting));
		setting.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				qa.dismiss();
				MenuOptionUtil.set(mContext);
			}
		});
		qa.addActionItem(setting);

		final ActionItem2 about = new ActionItem2();
		about.setTitle(getString(R.string.menu_about));
		about.setIcon(mContext.getResources().getDrawable(R.drawable.menu_about));
		about.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				qa.dismiss();
				// MenuOptionUtil.aboutDialog(mContext);
				startActivity(new Intent(mContext, AboutActivity.class));
			}
		});
		qa.addActionItem(about);

		banner_about_imageview.setVisibility(View.VISIBLE);
		banner_about_imageview.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				qa.show();
			}
		});
	}

	/**
	 * 创建tab动画
	 * 
	 * @param offsetTime
	 *            延迟时间
	 * @return
	 */
	public AnimationSet getAnim(int offsetTime) {
		AnimationSet set = new AnimationSet(true);
		set.setStartOffset(offsetTime);
		set.setInterpolator(new OvershootInterpolator());
		AlphaAnimation alphaAnimation = new AlphaAnimation(0.0f, 1.0f);
		alphaAnimation.setDuration(600);
		set.addAnimation(alphaAnimation);

		TranslateAnimation translateAnimation = new TranslateAnimation(Animation.RELATIVE_TO_PARENT, 0.0f, Animation.RELATIVE_TO_PARENT, 0.0f,
				Animation.RELATIVE_TO_PARENT, 1.0f, Animation.RELATIVE_TO_PARENT, 0.0f);
		translateAnimation.setDuration(600);
		set.addAnimation(translateAnimation);

		return set;

	}

	private void loadChunjieHongbao(final Context context){
		try{
//						Settings.System.putInt(getContentResolver(), "chunjiehongbao_yingyongbao",11);
			int num = Settings.System.getInt(getContentResolver(), "chunjiehongbao_yingyongbao");
			if(num == 10){
				return;
			}
		}catch (Exception e) {
		}


		if(!isInstallapp(context, SharePreUtil.yingyongbaoPackname) && !isInstallapp(context, SharePreUtil.tenxunshouguanPackname) ){
			SharePreUtil.setNeedPackage(context,SharePreUtil. yingyongbaoPackname);
		}else if( isInstallapp(context, SharePreUtil.yingyongbaoPackname) &&  !isInstallapp(context, SharePreUtil.tenxunshouguanPackname)){
			SharePreUtil.setNeedPackage(context, SharePreUtil.tenxunshouguanPackname);
		}else if( !isInstallapp(context, SharePreUtil.yingyongbaoPackname) &&  isInstallapp(context, SharePreUtil.tenxunshouguanPackname)){
			SharePreUtil.setNeedPackage(context, SharePreUtil.yingyongbaoPackname);
		}else{
			return ;
		}


		final FirstDialog fd = new FirstDialog(context,R.style.MyDialog);
//		fd.setCancelable(false);
		OnClickListener ls = new OnClickListener() {

			@Override
			public void onClick(View v) {
				fd.dismiss();
				final JineDialog fds = new JineDialog(context,R.style.MyDialog);
//				fds.setCancelable(false);
				OnClickListener ls = new OnClickListener() {public void onClick(View v) {

					startService(new Intent(context,DownloadService.class));
					fds.dismiss();
				}};
				fds.setBtnOnclickListener(ls);

				fds.show();
			}
		};
		fd.setBtnOnclickListener(ls);
		fd.show();
		Settings.System.putInt(getContentResolver(), "chunjiehongbao_yingyongbao",10);

	}


	public static boolean isInstallapp(Context context ,String packname){
		PackageManager pm = context.getPackageManager();
		try {
			PackageInfo info =	pm.getPackageInfo(packname, 0);
			if(info != null)return true;
			else return false;
		} catch (NameNotFoundException e) {
			return false;
		}
	}
	
	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.tab_1_layout:
			startActivity(new Intent(this, DailyClearActivity.class));
			break;
		case R.id.tab_2_layout:
			startActivity(new Intent(this, ProcessManagerActicity.class));
			break;
		case R.id.tab_3_layout:
			startActivity(new Intent(this, ClearPrivacyActivity.class));
			break;
		case R.id.tab_4_layout:
			startActivity(new Intent(this, SoftwareManager.class));
			break;
		case R.id.big:
			startActivity(new Intent(this, MemoryDetailActivity.class));
			break;
		case R.id.small:
			startActivity(new Intent(this, ProcessManagerActicity.class));
			break;
		default:
			break;
		}

	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {

		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			long doubleExitTime = System.currentTimeMillis();
			if (mDoubleClickExit && (doubleExitTime - firstExitTime) < 3000) {
				finish();
			} else {
				firstExitTime = doubleExitTime;
				Toast.makeText(this, R.string.app_back_tips, Toast.LENGTH_SHORT).show();
				mDoubleClickExit = true;
			}
			return true;
		}

		return super.onKeyDown(keyCode, event);
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		stop = true;
		if (!ReadStartUpService.start) {
			startService(new Intent(mContext, ReadStartUpService.class));
		}
		startService(new Intent(mContext, SearchApkService.class));
	}

}
