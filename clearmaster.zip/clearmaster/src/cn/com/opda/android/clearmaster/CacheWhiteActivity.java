package cn.com.opda.android.clearmaster;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ListView;
import cn.com.opda.android.clearmaster.adapter.CacheWhiteAdapter;
import cn.com.opda.android.clearmaster.dao.CacheWhiteListUtils;
import cn.com.opda.android.clearmaster.utils.BannerUtils;

import com.umeng.analytics.MobclickAgent;

/**
 * 缓存白名单
 * @author 庄宏岩
 *
 */
public class CacheWhiteActivity extends BaseActivity  {
	private Context mContext;
	private ListView cache_whitelist_listview;
	private ArrayList<ApplicationInfo> cacheWhites;
	private CacheWhiteAdapter mCacheWhiteAdapter;
	private boolean stop;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mContext = CacheWhiteActivity.this;
		setContentView(R.layout.activity_cache_white_list);
		BannerUtils.setMainTitle(this, R.string.cache_white_list);
		BannerUtils.initBackButton(this);

		initViewAndEvent();
		new KeepListTask().execute();
	}

	private void initViewAndEvent() {
		cache_whitelist_listview = (ListView) findViewById(R.id.cache_whitelist_listview);
	}

	private class KeepListTask extends AsyncTask<Void, ApplicationInfo, Integer> {

		@Override
		protected void onPreExecute() {
			cacheWhites = new ArrayList<ApplicationInfo>();
			mCacheWhiteAdapter = new CacheWhiteAdapter(mContext, cacheWhites);
			cache_whitelist_listview.setAdapter(mCacheWhiteAdapter);
		}

		@Override
		protected Integer doInBackground(Void... params) {
			PackageManager pm = getPackageManager();
			List<PackageInfo> list = pm.getInstalledPackages(0);
			ArrayList<String> keeps = CacheWhiteListUtils.getAllList(mContext);
			if (list != null) {
				for (PackageInfo packageInfo : list) {
					if (stop) {
						break;
					}
					ApplicationInfo applicationInfo = packageInfo.applicationInfo;
					if (applicationInfo == null) {
						continue;
					}
					if (applicationInfo.packageName.equals(getPackageName())) {
						continue;
					}
					final String sourceDir = applicationInfo.sourceDir;
					if (sourceDir != null) {

						applicationInfo.name = applicationInfo.loadLabel(pm).toString();
						applicationInfo.enabled = keeps.contains(applicationInfo.packageName);
						publishProgress(applicationInfo);
					}
				}
			}

			return null;

		}

		@Override
		protected void onProgressUpdate(ApplicationInfo... values) {
			if (values.length > 0) {
				ApplicationInfo appInfo = values[0];
				if (appInfo.enabled) {
					cacheWhites.add(0, appInfo);
				} else {
					cacheWhites.add(appInfo);
				}
				mCacheWhiteAdapter.notifyDataSetChanged();
			}
			super.onProgressUpdate(values);
		}

		@Override
		protected void onPostExecute(Integer result) {
			super.onPostExecute(result);

		}

	}

	@Override
	protected void onResume() {
		MobclickAgent.onResume(this);
		super.onResume();
	}

	@Override
	protected void onPause() {
		MobclickAgent.onPause(this);
		super.onPause();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		stop = true;
	}
	
	

}
