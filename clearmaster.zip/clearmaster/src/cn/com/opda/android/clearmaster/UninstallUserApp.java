package cn.com.opda.android.clearmaster;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;
import android.preference.PreferenceManager;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import cn.com.opda.android.clearmaster.adapter.Adapter4UninstallApp;
import cn.com.opda.android.clearmaster.custom.CustomActivity;
import cn.com.opda.android.clearmaster.custom.CustomDialog2;
import cn.com.opda.android.clearmaster.custom.IOSProgressDialog;
import cn.com.opda.android.clearmaster.impl.SelectListener;
import cn.com.opda.android.clearmaster.model.AppItem;
import cn.com.opda.android.clearmaster.utils.AppManagerUtils;
import cn.com.opda.android.clearmaster.utils.ClearUtils;
import cn.com.opda.android.clearmaster.utils.CodeSizeComparator;
import cn.com.opda.android.clearmaster.utils.CustomEventCommit;
import cn.com.opda.android.clearmaster.utils.Terminal;
import cn.com.opda.android.clearmaster.utils.listsort.TimeComparator;

public class UninstallUserApp extends CustomActivity implements OnClickListener {
	private boolean init;
	private ArrayList<AppItem> uninstallApps = new ArrayList<AppItem>();
	private TimeComparator timeComparator;
	private Adapter4UninstallApp mUserAppUninstallAdapter;
	private ListView app_uninstall_listview;
	private String[] keepApps = { "com.android.launcher", "com.android.phone", "android", "com.google.android.gsf", "com.android.systemui" };
	private long freeMemory;
	private IOSProgressDialog mIosProgressDialog;
	private boolean stop;
	private Button clear_button;
	private TextView tv_search_result;
	private AppItem uninstallApp;
	private ArrayList<AppItem> systemApps = new ArrayList<AppItem>();
	private ArrayList<AppItem> userApps = new ArrayList<AppItem>();
	private SoftwareUninstallActivity softwareUninstallActivity;

	public UninstallUserApp(Context context, int resId, SoftwareUninstallActivity softwareUninstallActivity) {
		super(context, resId);
		this.softwareUninstallActivity = softwareUninstallActivity;
		initViewAndEvent();
	}

	private void initViewAndEvent() {
		app_uninstall_listview = (ListView) findViewById(R.id.app_uninstall_listview);
		tv_search_result = (TextView) findViewById(R.id.tv_search_result);
		clear_button = (Button) findViewById(R.id.clear_button);
		clear_button.setOnClickListener(this);
	}

	@Override
	public void onResume() {
		if (uninstallApps != null && uninstallApps.size() > 0 && !Terminal.isRoot(mContext)) {
			updateUnstalledHaoziyuanAdapter();
			updateUnstalledChongfuAdapter();
			updateUnstalledUserAdapter();
			uninstallApps.clear();
		}
	}

	@Override
	public void initData() {
		if (!init) {
			init = true;
			app_uninstall_listview.setVisibility(View.VISIBLE);
			timeComparator = new TimeComparator();

			new GetAppListTask().execute();
		}
	}

	private class GetAppListTask extends AsyncTask<Void, AppItem, Integer> {

		@Override
		protected void onPreExecute() {

			mIosProgressDialog = new IOSProgressDialog(mContext, R.string.loading);
			mIosProgressDialog.setCancelable(false);
			mIosProgressDialog.setCanceledOnTouchOutside(false);
			mIosProgressDialog.show();

		}

		@Override
		protected Integer doInBackground(Void... params) {
			PackageManager pm = mContext.getPackageManager();
			List<PackageInfo> installedAppList = pm.getInstalledPackages(0);
			for (int i = 0; i < installedAppList.size(); i++) {
				if (stop) {
					break;
				}
				PackageInfo packageInfo = installedAppList.get(i);
				ApplicationInfo info = packageInfo.applicationInfo;
				String sourceDir = info.sourceDir;
				if (sourceDir != null) {
					if (info.packageName.equals(mContext.getPackageName())) {
						continue;
					}
					if (isKeepApp(info.packageName)) {
						continue;
					}
					boolean flag = false;
					if ((info.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0) {
						flag = true;
					} else if ((info.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
						flag = true;
					}
					AppItem appItem = new AppItem();
					appItem.setAppPackage(info.packageName);
					appItem.setAppName(info.loadLabel(pm).toString());

					appItem.setApplicationInfo(info);
					String dir = info.publicSourceDir;
					appItem.setInstallTime(new File(dir).lastModified());

					appItem.setCodePath(sourceDir);
					appItem.setCodeSize(new File(sourceDir).length());
					if (sourceDir.contains(".apk")) {
						appItem.setOdexPath(sourceDir.replace(".apk", ".odex"));
					}
					if (flag) {
						appItem.setSystemApp(false);
						appItem.setUserApp(true);
						userApps.add(appItem);
					} else {
						appItem.setSystemApp(true);
						appItem.setUserApp(false);
						if (isInBlack(appItem.getAppPackage())) {
							appItem.setKeep(true);
						}
						systemApps.add(appItem);
					}
				}
			}
			return null;

		}

		@Override
		protected void onProgressUpdate(AppItem... values) {
			super.onProgressUpdate(values);
		}

		@Override
		protected void onPostExecute(Integer result) {
			super.onPostExecute(result);
			Collections.sort(userApps, timeComparator);
			Collections.sort(systemApps, new CodeSizeComparator());
			mIosProgressDialog.dismiss();
			mUserAppUninstallAdapter = new Adapter4UninstallApp(mContext, userApps, mHandler);
			mUserAppUninstallAdapter.setSelectListener(new SelectListener() {

				@Override
				public void selectSize(long size) {

				}
			});

			app_uninstall_listview.setAdapter(mUserAppUninstallAdapter);
		}

		public boolean isKeepApp(String packageName) {
			for (String string : keepApps) {
				if (string.equals(packageName)) {
					return true;
				}
			}
			return false;
		}
	}

	public void showTipsDialog() {
		final SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(mContext);
		if (!sp.getBoolean("uninstall_tip", false)) {
			final CustomDialog2 customDialog = new CustomDialog2(mContext);
			customDialog.setDialogIcon(R.drawable.dialog_icon_warning);
			customDialog.setMessage(R.string.uninstall_system_app_tips);
			customDialog.setButton2(R.string.dialog_button_ok, new OnClickListener() {

				@Override
				public void onClick(View v) {
					sp.edit().putBoolean("uninstall_tip", true).commit();
					customDialog.dismiss();
				}
			});
			customDialog.show();
		}

	}

	public boolean isInBlack(String packageName) {
		if (packageName.startsWith("com.android") || packageName.startsWith("com.google") || packageName.startsWith("com.htc")
				|| packageName.startsWith("android") || packageName.startsWith("com.sonyericsson") || packageName.startsWith("com.adobe")
				|| packageName.startsWith("com.huawei") || packageName.startsWith("com.cyanogenmod") || packageName.startsWith("com.miui")
				|| packageName.startsWith("com.facebook") || packageName.startsWith("com.xiaomi") || packageName.startsWith("com.qualcomm")
				|| packageName.startsWith("com.mediatek") || packageName.startsWith("com.lenovo") || packageName.startsWith("com.samsung")
				|| packageName.startsWith("com.motorola") || packageName.startsWith("com.zte") || packageName.startsWith("com.meizu")
				|| packageName.startsWith("com.twitter") || packageName.startsWith("com.lg") || packageName.startsWith("com.sony")
				|| packageName.startsWith("com.rockchip") || packageName.startsWith("com.spreadtrum") || packageName.startsWith("com.asus")
				|| packageName.startsWith("com.dell") || packageName.startsWith("com.philips") || packageName.startsWith("com.haier")
				|| packageName.startsWith("com.aigo") || packageName.startsWith("com.sharp") || packageName.startsWith("com.oppo")
				|| packageName.startsWith("com.10moons") || packageName.startsWith("com.nvidia") || packageName.startsWith("com.nook")
				|| packageName.startsWith("com.lephone") || packageName.startsWith("com.hisense") || packageName.startsWith("com.opda")
				|| packageName.startsWith("cn.opda") || packageName.startsWith("cn.com.opda") || packageName.startsWith("com.dashi")
				|| packageName.startsWith("com.sec") || packageName.contains(".launcher")) {
			return true;
		}

		return false;
	}

	@Override
	public void onClick(View v) {
		CustomEventCommit.commit(mContext, CustomEventCommit.user_app_uninstall);
		if (Terminal.isRoot(mContext)) {
			uninstallApp(mUserAppUninstallAdapter.getSelectList());
		} else {
			uninstallWithoutRoot(mUserAppUninstallAdapter.getSelectList());
		}

	}

	private void uninstallWithoutRoot(ArrayList<AppItem> apps) {
		uninstallApps.clear();
		uninstallApps = apps;
		if (uninstallApps != null && uninstallApps.size() > 0) {
			for (AppItem appItem : uninstallApps) {
				AppManagerUtils.openUninstaller(mContext, appItem.getAppPackage());
			}
		} else {
			Toast.makeText(mContext, R.string.clear_select_null, Toast.LENGTH_SHORT).show();
		}
	}

	private void uninstallApp(ArrayList<AppItem> apps) {
		freeMemory = 0;
		final ArrayList<AppItem> appItems = apps;
		if (appItems != null && appItems.size() > 0) {
			mIosProgressDialog = new IOSProgressDialog(mContext, R.string.app_uninstall_loading);
			mIosProgressDialog.setCancelable(false);
			mIosProgressDialog.setCanceledOnTouchOutside(false);
			mIosProgressDialog.show();
			new Thread(new Runnable() {

				@Override
				public void run() {
					for (int i = 0; i < appItems.size(); i++) {
						AppItem appItem = appItems.get(i);
						boolean b = false;
						if (appItem.isSystemApp()) {
							if (AppManagerUtils.backupApp(appItem)) {
								b = Terminal.uninstallSystemApp(appItem);
							}
						} else {
							b = Terminal.uninstallUserApp(appItem);
						}
						if (b) {
							freeMemory += appItem.getCodeSize();
							uninstallApp = appItem;
							Message message = new Message();
							message.what = 1;
							message.arg1 = appItems.size();
							message.arg2 = i + 1;
							mHandler.sendMessage(message);
						}
					}

					Message message = new Message();
					message.what = 0;
					message.arg1 = appItems.size();
					message.arg2 = appItems.size();
					mHandler.sendMessageDelayed(message, 200);
				}
			}).start();
		} else {
			Toast.makeText(mContext, R.string.clear_select_null, Toast.LENGTH_SHORT).show();
		}
	}

	Handler mHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			switch (msg.what) {
			case 0:
				mIosProgressDialog.dismiss();
				ClearUtils.setDayClearSize(mContext, freeMemory);
				ClearUtils.setHistoryClearSize(mContext, freeMemory);
				break;
			case 1:
				Toast.makeText(mContext, mContext.getString(R.string.app_uninstall_succeed_toast, uninstallApp.getAppName()), Toast.LENGTH_SHORT).show();
				if (mUserAppUninstallAdapter != null) {
					mUserAppUninstallAdapter.removeApp2(uninstallApp);
				}

				softwareUninstallActivity.removeChongfuAdapter(uninstallApp);
				softwareUninstallActivity.removeHaoziyuanAdapter(uninstallApp);
				clear_button.setText(getString(R.string.one_uninstall_button));
				break;
			case 110:
				if (mUserAppUninstallAdapter.getSelectList().size() == 0) {
					clear_button.setText(getString(R.string.one_uninstall_button));
				} else {
					clear_button.setText(getString(R.string.one_uninstall_button) +" ("+ mUserAppUninstallAdapter.getSelectList().size() + ")");
				}
				break;

			default:
				break;
			}
		}
	};

	private void updateUnstalledUserAdapter() {
		for (AppItem appItem : uninstallApps) {
			if (!AppManagerUtils.appIsInstall(mContext, appItem.getAppPackage())) {
				Toast.makeText(mContext, mContext.getString(R.string.app_uninstall_succeed_toast, appItem.getAppName()), Toast.LENGTH_SHORT).show();
				if (mUserAppUninstallAdapter != null) {
					mUserAppUninstallAdapter.removeApp2(appItem);
					if (mUserAppUninstallAdapter.getSelectList().size() == 0) {
						clear_button.setText(getString(R.string.one_uninstall_button));
					} else {
						clear_button.setText(getString(R.string.one_uninstall_button) +" ("+ mUserAppUninstallAdapter.getSelectList().size() + ")");
					}
					ClearUtils.setDayClearSize(mContext, appItem.getCodeSize());
					ClearUtils.setHistoryClearSize(mContext, appItem.getCodeSize());
				}
			}
		}
	}

	private void updateUnstalledChongfuAdapter() {
		for (AppItem appItem : uninstallApps) {
			if (!AppManagerUtils.appIsInstall(mContext, appItem.getAppPackage())) {
				Toast.makeText(mContext, mContext.getString(R.string.app_uninstall_succeed_toast, appItem.getAppName()), Toast.LENGTH_SHORT).show();
				softwareUninstallActivity.removeChongfuAdapter(appItem);
			}
		}
	}

	private void updateUnstalledHaoziyuanAdapter() {
		for (AppItem appItem : uninstallApps) {
			if (!AppManagerUtils.appIsInstall(mContext, appItem.getAppPackage())) {
				Toast.makeText(mContext, mContext.getString(R.string.app_uninstall_succeed_toast, appItem.getAppName()), Toast.LENGTH_SHORT).show();
				softwareUninstallActivity.removeHaoziyuanAdapter(appItem);
			}
		}
	}

	public View getNoResultView() {
		return tv_search_result;

	}

	public void updateUserAdapter() {
		if(mUserAppUninstallAdapter!=null){
			mUserAppUninstallAdapter.updateListView(userApps);
		}
	}

	public void updateUserAdapter(ArrayList<AppItem> filterDateList) {
		if(mUserAppUninstallAdapter!=null){
			mUserAppUninstallAdapter.updateListView(filterDateList);
		}
	}

	public void notifyUserAdapter() {
		if(mUserAppUninstallAdapter!=null){
			mUserAppUninstallAdapter.notifyDataSetChanged();
		}
	}

	public ArrayList<AppItem> getUserApps() {
		return userApps;
	}

	public ArrayList<AppItem> getSystemApps() {
		return systemApps;
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		stop = true;
	}

	public void removeApp(AppItem appItem) {
		if (mUserAppUninstallAdapter != null) {
			mUserAppUninstallAdapter.removeApp2(appItem);
		}
	}

}
