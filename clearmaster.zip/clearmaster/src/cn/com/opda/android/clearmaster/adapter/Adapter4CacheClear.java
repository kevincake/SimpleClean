package cn.com.opda.android.clearmaster.adapter;

import java.util.ArrayList;

import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import cn.com.opda.android.clearmaster.R;
import cn.com.opda.android.clearmaster.impl.CheckedListener;
import cn.com.opda.android.clearmaster.impl.SelectListener;
import cn.com.opda.android.clearmaster.model.AppItem;
import cn.com.opda.android.clearmaster.model.GroupItem;
import cn.com.opda.android.clearmaster.utils.FormatUtils;
import cn.com.opda.android.clearmaster.utils.Terminal;

public class Adapter4CacheClear extends BaseExpandableListAdapter {
	private ArrayList<GroupItem> groupArray;// 组列表
	private ArrayList<ArrayList<AppItem>> childArray;// 子列表
	private Context mContext;
	private LayoutInflater mLayoutInflater;
	private SelectListener selectListener;
	private Drawable defaultIcon;
	private PackageManager pm;
	private CheckedListener checkedListener;

	public Adapter4CacheClear(Context mContext, ArrayList<GroupItem> groupArray, ArrayList<ArrayList<AppItem>> childArray) {
		this.groupArray = groupArray;
		this.childArray = childArray;
		this.mContext = mContext;
		this.mLayoutInflater = LayoutInflater.from(mContext);
		defaultIcon = mContext.getResources().getDrawable(android.R.drawable.sym_def_app_icon);
		pm = mContext.getPackageManager();
	}

	public void setSelectListener(SelectListener selectListener) {
		this.selectListener = selectListener;
	}

	@Override
	public int getGroupCount() {
		return groupArray.size();
	}

	@Override
	public int getChildrenCount(int groupPosition) {
		return childArray.get(groupPosition).size();
	}

	@Override
	public Object getGroup(int groupPosition) {
		return groupArray.get(groupPosition);
	}

	@Override
	public Object getChild(int groupPosition, int childPosition) {
		return childArray.get(groupPosition).get(childPosition);
	}

	@Override
	public long getGroupId(int groupPosition) {
		return groupPosition;
	}

	@Override
	public long getChildId(int groupPosition, int childPosition) {
		return childPosition;
	}

	@Override
	public boolean hasStableIds() {
		return false;
	}

	public void updateSelectCacheSize() {
		long totalSize = 0;
		boolean allCheck = true;
		for (ArrayList<AppItem> appItems : childArray) {
			if (appItems != null && appItems.size() > 0) {
				for (AppItem appItem : appItems) {
					if (appItem != null && appItem.isChecked()) {
						totalSize += appItem.getCacheSize();
					} else {
						allCheck = false;
					}
				}
			}
		}
		selectListener.selectSize(totalSize);
		if (allCheck) {
			checkedListener.allChecked(0);
		} else {
			checkedListener.someChecked(0);
		}
	}

	public ArrayList<AppItem> getSelectClearList() {
		ArrayList<AppItem> appItems = new ArrayList<AppItem>();
		if (Terminal.isRoot(mContext)) {
			for (int i = 0; i < groupArray.size(); i++) {
				GroupItem groupItem = groupArray.get(i);
				if (groupItem.isChecked()) {
					appItems.addAll(childArray.get(i));
				} else {
					for (AppItem appItem : childArray.get(i)) {
						if (appItem.isChecked()) {
							appItems.add(appItem);
						}
					}
				}
			}
		} else {
			if (groupArray != null && groupArray.size() > 0) {
				if (groupArray.get(0).getTitle().equals(mContext.getString(R.string.system_cache_title))) {
					for (int i = 1; i < groupArray.size(); i++) {
						GroupItem groupItem = groupArray.get(i);
						if (groupItem.isChecked()) {
							appItems.addAll(childArray.get(i));
						} else {
							for (AppItem appItem : childArray.get(i)) {
								if (appItem.isChecked()) {
									appItems.add(appItem);
								}
							}
						}
					}
				} else {
					for (int i = 0; i < groupArray.size(); i++) {
						GroupItem groupItem = groupArray.get(i);
						if (groupItem.isChecked()) {
							appItems.addAll(childArray.get(i));
						} else {
							for (AppItem appItem : childArray.get(i)) {
								if (appItem.isChecked()) {
									appItems.add(appItem);
								}
							}
						}
					}
				}
			}
		}
		return appItems;
	}

	@Override
	public View getGroupView(final int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {

		final GroupHolder mHolder;
		if (convertView == null) {
			convertView = mLayoutInflater.inflate(R.layout.expandlistview_group_item_layout, null);
			mHolder = new GroupHolder();
			mHolder.clear_trash_group_title_textview = (TextView) convertView.findViewById(R.id.clear_trash_group_title_textview);
			mHolder.clear_trash_group_count_textview = (TextView) convertView.findViewById(R.id.clear_trash_group_count_textview);
			mHolder.clear_trash_group_icon_imageview = (ImageView) convertView.findViewById(R.id.clear_trash_group_icon_imageview);
			mHolder.clear_trash_group_checked_imageview = (CheckBox) convertView.findViewById(R.id.clear_trash_group_checked_imageview);
			convertView.setTag(mHolder);
		} else {
			mHolder = (GroupHolder) convertView.getTag();
			if (mHolder.imageLoader != null) {
				mHolder.imageLoader.cancel(true);
			}
		}
		final GroupItem groupItem = groupArray.get(groupPosition);
		mHolder.clear_trash_group_title_textview.setText(groupItem.getTitle());

		mHolder.clear_trash_group_count_textview.setVisibility(View.VISIBLE);
		long totalSize = 0;
		for (AppItem appItem : childArray.get(groupPosition)) {
			totalSize += appItem.getCacheSize();
		}
		mHolder.clear_trash_group_count_textview.setText(FormatUtils.formatBytesInByte(totalSize));

		mHolder.clear_trash_group_checked_imageview.setVisibility(View.VISIBLE);

		mHolder.clear_trash_group_checked_imageview.setChecked(groupItem.isChecked());
		if (groupItem.getIcon() == null) {
			mHolder.clear_trash_group_icon_imageview.setImageDrawable(defaultIcon);
			mHolder.imageLoader = new AsyncTask<GroupHolder, Void, Drawable>() {
				private GroupHolder holder;

				@Override
				protected Drawable doInBackground(GroupHolder... params) {
					holder = params[0];
					if (groupItem.getApplicationInfo() != null) {
						return groupItem.getApplicationInfo().loadIcon(pm);
					} else {
						return null;
					}

				}

				@Override
				protected void onPostExecute(Drawable result) {
					if (result != null) {
						groupItem.setIcon(result);
						holder.clear_trash_group_icon_imageview.setImageDrawable(result);
					}
				}
			}.execute(mHolder);
		} else {
			mHolder.clear_trash_group_icon_imageview.setImageDrawable(groupItem.getIcon());
		}
		mHolder.clear_trash_group_checked_imageview.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				groupItem.setChecked(!groupItem.isChecked());
				ArrayList<AppItem> appItems = childArray.get(groupPosition);
				for (AppItem appItem : appItems) {
					appItem.setChecked(groupItem.isChecked());
				}
				updateSelectCacheSize();
				notifyDataSetChanged();
			}
		});
		return convertView;

	}

	@Override
	public View getChildView(final int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
		final Holder mHolder;
		if (convertView == null) {
			convertView = mLayoutInflater.inflate(R.layout.expandlistview_child_item_layout, null);
			mHolder = new Holder();
			mHolder.clear_trash_child_version_textview = (TextView) convertView.findViewById(R.id.clear_trash_child_version_textview);
			mHolder.clear_trash_child_name_textview = (TextView) convertView.findViewById(R.id.clear_trash_child_name_textview);
			mHolder.clear_trash_child_cachesize_textview = (TextView) convertView.findViewById(R.id.clear_trash_child_cachesize_textview);
			mHolder.clear_trash_child_icon_imageview = (ImageView) convertView.findViewById(R.id.clear_trash_child_icon_imageview);
			mHolder.clear_trash_child_checked_imageview = (CheckBox) convertView.findViewById(R.id.clear_trash_child_checked_imageview);
			convertView.setTag(mHolder);
		} else {
			mHolder = (Holder) convertView.getTag();
			if (mHolder.imageLoader != null) {
				mHolder.imageLoader.cancel(true);
			}
		}

		final AppItem mAppItem = childArray.get(groupPosition).get(childPosition);
		mHolder.clear_trash_child_name_textview.setText(mAppItem.getAppName());
		mHolder.clear_trash_child_version_textview.setVisibility(View.GONE);
		if (groupPosition == 0) {
			mHolder.clear_trash_child_cachesize_textview.setText(FormatUtils.formatBytesInByte(mAppItem.getCacheSize()));
			if (Terminal.isRoot(mContext)) {
				mHolder.clear_trash_child_checked_imageview.setVisibility(View.VISIBLE);
				mHolder.clear_trash_child_checked_imageview.setChecked(mAppItem.isChecked());
			} else {
				mHolder.clear_trash_child_checked_imageview.setVisibility(View.GONE);
			}
		} else {
			mHolder.clear_trash_child_cachesize_textview.setText(FormatUtils.formatBytesInByte(mAppItem.getCacheSize()));
			mHolder.clear_trash_child_checked_imageview.setVisibility(View.VISIBLE);
			mHolder.clear_trash_child_checked_imageview.setChecked(mAppItem.isChecked());
		}

		mHolder.clear_trash_child_icon_imageview.setVisibility(View.VISIBLE);
		if (mAppItem.getAppIcon() == null) {
			mHolder.clear_trash_child_icon_imageview.setImageDrawable(defaultIcon);
			mHolder.imageLoader = new AsyncTask<Holder, Void, Drawable>() {
				private Holder holder;

				@Override
				protected Drawable doInBackground(Holder... params) {
					holder = params[0];
					if (mAppItem.getApplicationInfo() != null) {
						return mAppItem.getApplicationInfo().loadIcon(pm);
					} else {
						return null;
					}

				}

				@Override
				protected void onPostExecute(Drawable result) {
					if (result != null) {
						mAppItem.setAppIcon(result);
						holder.clear_trash_child_icon_imageview.setImageDrawable(mAppItem.getAppIcon());
					}
				}
			}.execute(mHolder);
		} else {
			mHolder.clear_trash_child_icon_imageview.setImageDrawable(mAppItem.getAppIcon());
		}
		mHolder.clear_trash_child_checked_imageview.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				mAppItem.setChecked(!mAppItem.isChecked());

				ArrayList<AppItem> appItems = childArray.get(groupPosition);
				GroupItem groupItem = groupArray.get(groupPosition);
				boolean b = true;
				for (AppItem appItem : appItems) {
					if (!appItem.isChecked()) {
						b = false;
						break;
					}
				}
				groupItem.setChecked(b);
				updateSelectCacheSize();
				notifyDataSetChanged();
			}
		});
		return convertView;

	}

	@Override
	public boolean isChildSelectable(int groupPosition, int childPosition) {
		return true;
	}

	private class Holder {
		private TextView clear_trash_child_version_textview;
		private TextView clear_trash_child_name_textview;
		private TextView clear_trash_child_cachesize_textview;
		private ImageView clear_trash_child_icon_imageview;
		private CheckBox clear_trash_child_checked_imageview;
		AsyncTask<Holder, Void, Drawable> imageLoader;
	}

	private class GroupHolder {
		private TextView clear_trash_group_title_textview;
		private TextView clear_trash_group_count_textview;
		private ImageView clear_trash_group_icon_imageview;
		private CheckBox clear_trash_group_checked_imageview;
		AsyncTask<GroupHolder, Void, Drawable> imageLoader;
	}

	public void remove(AppItem appItem, int groupPosition, int childPosition) {
		childArray.get(groupPosition).remove(childPosition);
		groupArray.get(groupPosition).setCount(childArray.get(groupPosition).size());
		if (groupArray.get(groupPosition).getCount() == 0) {
			groupArray.remove(groupPosition);
			childArray.remove(groupPosition);
		}
		notifyDataSetChanged();
	}

	public void setAllChecked(boolean checked) {
		long total = 0;
		for (int i = 0; i < groupArray.size(); i++) {
			GroupItem groupItem = groupArray.get(i);
			groupItem.setChecked(checked);
			ArrayList<AppItem> appItems = childArray.get(i);
			for (AppItem appItem : appItems) {
				appItem.setChecked(checked);
				total += appItem.getCacheSize();
			}
		}
		notifyDataSetChanged();
		if (checked) {
			selectListener.selectSize(total);
		} else {
			selectListener.selectSize(0);
		}
	}

	public void setCheckListener(CheckedListener checkedListener) {
		this.checkedListener = checkedListener;
	}

}
