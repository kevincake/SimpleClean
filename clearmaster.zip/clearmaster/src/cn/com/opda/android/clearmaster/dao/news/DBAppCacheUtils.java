package cn.com.opda.android.clearmaster.dao.news;

import java.util.ArrayList;

import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import cn.com.opda.android.clearmaster.model.ClearItem;
import cn.com.opda.android.clearmaster.utils.DesUtils;
import cn.com.opda.android.clearmaster.utils.HASH;

/**
 * 缓存目录数据库操作类
 * 
 * @author 庄宏岩
 * 
 */
public class DBAppCacheUtils {
	private static DBAppCacheUtils dbUtils = null;
	private static DBAppCacheOpenHelper tdbOpenHelper = null;
	private static SQLiteDatabase db = null;

	public static DBAppCacheUtils getInstance(Context context) {
		if (dbUtils == null) {
			dbUtils = new DBAppCacheUtils();
		}
		if (tdbOpenHelper == null) {
			tdbOpenHelper = new DBAppCacheOpenHelper(context);
		}
		if (db == null) {
			db = tdbOpenHelper.getWritableDatabase();
		}
		return dbUtils;
	}

	/**
	 * @param info
	 * @param context
	 *            把信息保存到数据库
	 */
	public static void save(Context context, ArrayList<ClearItem> infos) {
		// DBAppCacheOpenHelper tdbOpenHelper = new
		// DBAppCacheOpenHelper(context);
		// SQLiteDatabase db = tdbOpenHelper.getWritableDatabase();
		// try {
		// for (ClearItem info : infos) {
		// Cursor cursor = db.rawQuery("select * from pname where pname = ?",
		// new String[] { info.getPackageName() });
		// if (cursor == null || cursor.getCount() == 0) {
		// if (cursor != null) {
		// cursor.close();
		// }
		// db.execSQL("insert into pname (pname) values(?)", new Object[] {
		// info.getPackageName() });
		// Log.i(TAG, "save()");
		// }
		// cursor = db.rawQuery("select _id from pname where pname = ?", new
		// String[] { info.getPackageName() });
		// cursor.moveToFirst();
		// int id = cursor.getInt(0);
		// if (cursor != null) {
		// cursor.close();
		// }
		// cursor = db.rawQuery("select * from type_zh where t_name = ?", new
		// String[] { info.getCname() });
		// if (cursor == null || cursor.getCount() == 0) {
		// if (cursor != null) {
		// cursor.close();
		// }
		// db.execSQL("insert into type_en (t_name) values(?)", new Object[] {
		// info.getEname() });
		// db.execSQL("insert into type_zh (t_name) values(?)", new Object[] {
		// info.getCname() });
		// }
		// cursor = db.rawQuery("select t_id from type_zh where t_name = ?", new
		// String[] { info.getCname() });
		// cursor.moveToFirst();
		// int t_id = cursor.getInt(0);
		// if (cursor != null) {
		// cursor.close();
		// }
		// db.execSQL("insert into path (_id,path,t_id,checked) values(?,?,?,?)",
		// new Object[] { id,info.getFilePath(),t_id,0 });
		// }
		// } catch (SQLException e) {
		// e.printStackTrace();
		// } finally {
		// db.close();
		// tdbOpenHelper.close();
		// }
	}

	/**
	 * @param context
	 * @return 从数据库中获取所有数据并返回一个集合
	 */
	public ArrayList<ClearItem> get(Context context, String packageName, String language) {
		String key = DesUtils.getKey1();
		key = DesUtils.getKey2();
		key = DesUtils.getKey3();
		ArrayList<ClearItem> list = new ArrayList<ClearItem>();
		Cursor cursor = null;
		try {
			String type_table = "type_" + language;
			String sql = "SELECT " + type_table + ".*,path.*,pname.* from " + type_table + ",path,pname WHERE pname.pname=? AND " + type_table
					+ ".t_id=path.t_id AND path._id=pname._id";
			cursor = db.rawQuery(sql, new String[] { HASH.md5sum(packageName+"_zz")});
			if (cursor != null) {
				while (cursor.moveToNext()) {
					ClearItem info = new ClearItem();
					info.setName(cursor.getString(cursor.getColumnIndex("t_name")));
					info.setPackageName(packageName);
					String filePath = cursor.getString(cursor.getColumnIndex("path"));
					info.setFilePath(DesUtils.decryptDES(filePath, key));
					info.setChecked(cursor.getInt(cursor.getColumnIndex("checked")) == 1);
					list.add(info);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (cursor != null) {
				cursor.close();
			}
		}
		return list;
	}

	/**
	 * @param context
	 * @return 从数据库中获取所有数据并返回一个集合
	 */
	public ArrayList<ClearItem> getAll(Context context, String language) {
		String key = DesUtils.getKey1();
		key = DesUtils.getKey2();
		key = DesUtils.getKey3();
		ArrayList<ClearItem> list = new ArrayList<ClearItem>();
		Cursor cursor = null;
		try {
			String type_table = "type_" + language;
			String sql = "SELECT " + type_table + ".*,path.*,pname.* from " + type_table + ",path,pname WHERE " + type_table
					+ ".t_id=path.t_id AND path._id=pname._id";
			cursor = db.rawQuery(sql, null);
			if (cursor != null) {
				while (cursor.moveToNext()) {
					ClearItem info = new ClearItem();
					info.setName(cursor.getString(cursor.getColumnIndex("t_name")));
					String packageName = cursor.getString(cursor.getColumnIndex("pname"));
					info.setPackageName(DesUtils.decryptDES(packageName, key));
					String filePath = cursor.getString(cursor.getColumnIndex("path"));
					info.setFilePath(DesUtils.decryptDES(filePath, key));
					info.setChecked(cursor.getInt(cursor.getColumnIndex("checked")) == 1);
					list.add(info);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (cursor != null) {
				cursor.close();
			}
		}
		return list;
	}

	/**
	 * @param context
	 * @return 从数据库中获取所有数据并返回一个集合
	 */
	public ArrayList<ClearItem> old_get(Context context, String language) {
		ArrayList<ClearItem> list = new ArrayList<ClearItem>();
		Cursor cursor = null;
		try {
			String type_table = "type_" + language;
			String sql = "SELECT " + type_table + ".*,path.*,pname.* from " + type_table + ",path,pname where " + type_table
					+ ".t_id=path.t_id AND path._id=pname._id";
			cursor = db.rawQuery(sql, null);
			if (cursor != null) {
				while (cursor.moveToNext()) {
					ClearItem info = new ClearItem();
					info.setName(cursor.getString(cursor.getColumnIndex("t_name")));
					info.setPackageName(cursor.getString(cursor.getColumnIndex("pname")));
					info.setFilePath(cursor.getString(cursor.getColumnIndex("path")));
					info.setChecked(cursor.getInt(cursor.getColumnIndex("checked")) == 1);
					list.add(info);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (cursor != null) {
				cursor.close();
			}
		}
		return list;
	}

	/**
	 * @param info
	 * @param context
	 *            把信息保存到数据库
	 */
	public void update(Context context, ArrayList<ClearItem> infos) {
		try {
			for (ClearItem info : infos) {
				db.execSQL("update path set path=? where path=?", new Object[] { info.getMd5Path(), info.getFilePath() });
				db.execSQL("update pname set pname=? where pname=?", new Object[] { info.getMd5PackageName(), info.getPackageName() });
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void close() {
		try {
			if (db != null) {
				db.close();
				db = null;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (tdbOpenHelper != null) {
				tdbOpenHelper.close();
				tdbOpenHelper = null;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
