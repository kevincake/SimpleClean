package cn.com.opda.android.clearmaster.model;

import android.graphics.drawable.Drawable;

public class SquanderApp {
	private Drawable icon;
	private String name;
	private String type;
	private AppItem topSquander;
	public Drawable getIcon() {
		return icon;
	}
	public void setIcon(Drawable icon) {
		this.icon = icon;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public AppItem getTopSquander() {
		return topSquander;
	}
	public void setTopSquander(AppItem topSquander) {
		this.topSquander = topSquander;
	}
	
}
