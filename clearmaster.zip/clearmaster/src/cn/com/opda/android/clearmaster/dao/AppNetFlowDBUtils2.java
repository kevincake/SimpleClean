package cn.com.opda.android.clearmaster.dao;

import java.util.ArrayList;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.net.TrafficStats;
import android.preference.PreferenceManager;
import cn.com.opda.android.clearmaster.model.AppItem;
import cn.com.opda.android.clearmaster.utils.AppManagerUtils;
import cn.com.opda.android.clearmaster.utils.BaseJsonUtil;
import cn.com.opda.android.clearmaster.utils.DLog;
import cn.com.opda.android.clearmaster.utils.DrawableUtils;

/**
 * 流量统计数据库
 * @author 庄宏岩
 * 
 */
public class AppNetFlowDBUtils2 extends BaseJsonUtil {
	private static final String TAG = "debug";

	public AppNetFlowDBUtils2(Context context) {
		super(context);
	}

	/**
	 * @param info
	 * @param context
	 *            把信息保存到数据库
	 */
	public static void save(Context context, AppItem info) {
		AppUsageStatisticsDBOpenHelper tdbOpenHelper = new AppUsageStatisticsDBOpenHelper(context);
		SQLiteDatabase db = tdbOpenHelper.getWritableDatabase();
		Cursor cursor = db.rawQuery("select * from netflow where packagename = ?", new String[] { info.getAppPackage() });
		try {
			if (cursor == null || cursor.getCount() == 0) {
				db.execSQL("insert into netflow (appname,packagename,uid,icon,flow) values(?,?,?,?,?)", new Object[] { info.getAppName(),
						info.getAppPackage(), info.getUid(), info.getIcon(), info.getFlow() });
				DLog.i(TAG, "save()");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (cursor != null) {
				cursor.close();
			}
			db.close();
			tdbOpenHelper.close();
		}
	}

	/**
	 * @param info
	 * @param context
	 *            把信息保存到数据库
	 */
	public static void save(Context context, String packageName) {
		AppUsageStatisticsDBOpenHelper tdbOpenHelper = new AppUsageStatisticsDBOpenHelper(context);
		SQLiteDatabase db = tdbOpenHelper.getWritableDatabase();
		Cursor cursor = db.rawQuery("select * from netflow where packagename = ?", new String[] { packageName });
		try {
			if (cursor == null || cursor.getCount() == 0) {
				PackageInfo packageInfo = null;
				try {
					packageInfo = context.getPackageManager().getPackageInfo(packageName, 0);
				} catch (NameNotFoundException e) {
					e.printStackTrace();
				}
				if (packageInfo != null) {
					ApplicationInfo appInfo = packageInfo.applicationInfo;
					AppItem info = new AppItem();
					info.setIcon(DrawableUtils.drawable2Byte(appInfo.loadIcon(context.getPackageManager())));
					info.setAppName(appInfo.loadLabel(context.getPackageManager()).toString());
					info.setAppPackage(appInfo.packageName);
					info.setUid(appInfo.uid);
					db.execSQL("insert into netflow (appname,packagename,uid,icon,flow) values(?,?,?,?,?)",
							new Object[] { info.getAppName(), info.getAppPackage(), info.getUid(), info.getIcon(), info.getFlow() });
					DLog.i(TAG, "save()");
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (cursor != null) {
				cursor.close();
			}
			db.close();
			tdbOpenHelper.close();
		}
	}

	public static void save(Context mContext, ArrayList<AppItem> mNetFlowInfos) {
		if (mNetFlowInfos != null && mNetFlowInfos.size() > 0) {
			AppUsageStatisticsDBOpenHelper tdbOpenHelper = new AppUsageStatisticsDBOpenHelper(mContext);
			SQLiteDatabase db = tdbOpenHelper.getWritableDatabase();
			for (AppItem info : mNetFlowInfos) {
				Cursor cursor = db.rawQuery("select * from netflow where packagename = ?", new String[] { info.getAppPackage() });
				try {
					if (cursor == null || cursor.getCount() == 0) {
						db.execSQL("insert into netflow (appname,packagename,uid,icon,flow) values(?,?,?,?,?)",
								new Object[] { info.getAppName(), info.getAppPackage(), info.getUid(), info.getIcon(), info.getFlow() });
						DLog.i(TAG, "save()");
					}
				} catch (SQLException e) {
					e.printStackTrace();
				} finally {
					if (cursor != null) {
						cursor.close();
					}
				}
			}
			db.close();
			tdbOpenHelper.close();
			inited(mContext);
		}
	}

	/**
	 * @param info
	 * @param context
	 *            从数据库中删除某条数据
	 */
	public static void delete(Context context, String packageName) {
		AppUsageStatisticsDBOpenHelper tdbOpenHelper = new AppUsageStatisticsDBOpenHelper(context);
		SQLiteDatabase db = tdbOpenHelper.getWritableDatabase();
		db.execSQL("delete from netflow where packagename=?", new Object[] { packageName });

		DLog.i(TAG, "delete()");

		db.close();
		tdbOpenHelper.close();
	}

	public static void update(Context mContext, AppItem info) {
		AppUsageStatisticsDBOpenHelper tdbOpenHelper = new AppUsageStatisticsDBOpenHelper(mContext);
		SQLiteDatabase db = tdbOpenHelper.getWritableDatabase();

		Cursor cursor = db.rawQuery("select * from netflow where packagename = ?", new String[] { info.getAppPackage() });
		try {
			if (cursor == null || cursor.getCount() == 0) {
				db.execSQL("insert into netflow (appname,packagename,uid,icon,flow) values(?,?,?,?,?)", new Object[] { info.getAppName(),
						info.getAppPackage(), info.getUid(), info.getIcon(), info.getFlow() });
				DLog.i(TAG, "save()");
			} else {
				db.execSQL("update netflow set flow=? where packagename=?", new Object[] { info.getFlow(), info.getAppPackage() });
				DLog.i(TAG, "update()");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (cursor != null) {
				cursor.close();
			}
			db.close();
			tdbOpenHelper.close();
		}
	}

	/**
	 * @param context
	 * @return 从数据库中获取所有数据并返回一个集合
	 */
	public static ArrayList<AppItem> getList(Context context) {
		ArrayList<AppItem> list = new ArrayList<AppItem>();
		AppUsageStatisticsDBOpenHelper tdbOpenHelper = new AppUsageStatisticsDBOpenHelper(context);
		SQLiteDatabase db = tdbOpenHelper.getWritableDatabase();
		Cursor cursor = db.rawQuery("select * from netflow ", null);
		try {
			if (cursor != null) {
				while (cursor.moveToNext()) {
					AppItem info = new AppItem();
					info.setAppName(cursor.getString(0));
					info.setAppPackage(cursor.getString(1));
					info.setUid(cursor.getInt(2));
					info.setIcon(cursor.getBlob(3));
					info.setFlow(cursor.getLong(4));
					info.setTypeFlag("netflow");
					if (AppManagerUtils.appIsInstall(context, info.getAppPackage())) {
						info.setTempFlow(TrafficStats.getUidRxBytes(info.getUid()) + TrafficStats.getUidTxBytes(info.getUid()));
						list.add(info);
					} else {
						db.execSQL("delete from netflow where packagename=?", new Object[] { info.getAppPackage() });
					}
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			if (cursor != null) {
				cursor.close();
			}
			db.close();
			tdbOpenHelper.close();
		}
		return list;
	}

	/**
	 * @param context
	 * @return 从数据库中获取所有数据并返回一个集合
	 */
	public static void updateList(Context context) {
		AppUsageStatisticsDBOpenHelper tdbOpenHelper = new AppUsageStatisticsDBOpenHelper(context);
		SQLiteDatabase db = tdbOpenHelper.getWritableDatabase();
		Cursor cursor = db.rawQuery("select * from netflow", null);
		try {
			if (cursor != null) {
				while (cursor.moveToNext()) {
					AppItem info = new AppItem();
					info.setAppPackage(cursor.getString(1));
					info.setUid(cursor.getInt(2));
					info.setTempFlow(TrafficStats.getUidRxBytes(info.getUid()) + TrafficStats.getUidTxBytes(info.getUid()));
					if (info.getTempFlow() > 0) {
						info.setFlow(cursor.getLong(4) + info.getTempFlow());
						db.execSQL("update netflow set flow=? where packagename=?", new Object[] { info.getFlow(), info.getAppPackage() });
						DLog.i(TAG, "update()");
					}
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			if (cursor != null) {
				cursor.close();
			}
			db.close();
			tdbOpenHelper.close();
		}
	}

	public static boolean isInit(Context mContext) {
		SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(mContext);
		return sp.getBoolean("AppNetFlowDBInit", false);
	}

	public static void inited(Context mContext) {
		SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(mContext);
		sp.edit().putBoolean("AppNetFlowDBInit", true).commit();
	}

}
