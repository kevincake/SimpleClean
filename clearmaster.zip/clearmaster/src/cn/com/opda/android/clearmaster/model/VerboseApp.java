package cn.com.opda.android.clearmaster.model;

import java.util.ArrayList;

import android.graphics.Bitmap;

public class VerboseApp {
	private ArrayList<String> packages;
	private String type;
	private String name;
	private boolean finish;
	private ArrayList<AppItem> appItems = new ArrayList<AppItem>();
	private ArrayList<VerboseAdInfo> adInfos = new ArrayList<VerboseAdInfo>();
	private Bitmap icon;

	public Bitmap getIcon() {
		return icon;
	}

	public void setIcon(Bitmap icon) {
		this.icon = icon;
	}

	public ArrayList<VerboseAdInfo> getAdInfos() {
		return adInfos;
	}

	public void setAdInfos(ArrayList<VerboseAdInfo> adInfos) {
		this.adInfos = adInfos;
	}

	public boolean isFinish() {
		return finish;
	}

	public void setFinish(boolean finish) {
		this.finish = finish;
	}

	public ArrayList<AppItem> getAppItems() {
		return appItems;
	}

	public void setAppItems(ArrayList<AppItem> appItems) {
		this.appItems = appItems;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ArrayList<String> getPackages() {
		return packages;
	}

	public void setPackages(ArrayList<String> packages) {
		this.packages = packages;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}
