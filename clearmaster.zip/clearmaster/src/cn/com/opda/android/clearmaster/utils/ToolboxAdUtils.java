package cn.com.opda.android.clearmaster.utils;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import cn.com.opda.android.clearmaster.model.AdInfo;
import cn.com.opda.android.clearmaster.model.ToolboxAd;

public class ToolboxAdUtils {

	public static ArrayList<ToolboxAd> getAdInfo(Context context) {
		SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
		ArrayList<ToolboxAd> toolboxAds = null;
		ArrayList<AdInfo> adInfos = null;
		try {
			String adJson = "";
			if(Constants.SHOUFA){
				adJson = "http://static.kfkx.net/app/clearmaster/clearmaster_ad_new_yingyongbao.json";
//				adJson = "http://static.kfkx.net/app/clearmaster/clearmaster_ad_new_baidu.json";
			}else{
				adJson = "http://static.kfkx.net/app/clearmaster/clearmaster_ad_new.json";
			}
			URL url = new URL(adJson);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setConnectTimeout(5 * 1000);
			conn.setRequestMethod("GET");
			conn.setReadTimeout(30 * 1000);
			if (conn.getResponseCode() == 200) {
				InputStream inStream = conn.getInputStream();
				StringBuffer sb = new StringBuffer();
				byte[] buffer = new byte[1024];
				int len;
				while ((len = inStream.read(buffer)) != -1) {
					String string = new String(buffer, 0, len);
					sb.append(string);

				}
				inStream.close();
				String response = sb.toString();
				DLog.i("debug", "response : " + response);
				JSONObject jsonObject = new JSONObject(response);
				if (jsonObject != null) {
					boolean show = jsonObject.optBoolean("show");
					sp.edit().putString("toolbox_ad_json", jsonObject.toString()).commit();
					if (show) {
						JSONArray jsonArray = jsonObject.optJSONArray("items");
						if (jsonArray != null && jsonArray.length() > 0) {
							toolboxAds = new ArrayList<ToolboxAd>();
							for (int i = 0; i < jsonArray.length(); i++) {
								JSONArray itemJsonArray = jsonArray.optJSONArray(i);
								ToolboxAd toolboxAd = new ToolboxAd();
								if (itemJsonArray != null && itemJsonArray.length() > 0) {
									adInfos = new ArrayList<AdInfo>();
									for (int t = 0; t < itemJsonArray.length(); t++) {
										JSONObject itemJsonObject = itemJsonArray.optJSONObject(t);
										if (itemJsonObject != null) {
											AdInfo adInfo = new AdInfo();
											adInfo.setApkUrl(itemJsonObject.optString("url"));
											adInfo.setAppName(itemJsonObject.optString("appname"));
											adInfo.setImageUrl(itemJsonObject.optString("iconurl"));
											adInfo.setPackageName(itemJsonObject.optString("packagename"));
											adInfo.setContent(itemJsonObject.optString("content"));
											adInfo.setTitle(itemJsonObject.optString("title"));
											adInfo.setDetailUrl(itemJsonObject.optString("detail_url"));
											adInfo.setWeight_l(itemJsonObject.optInt("weight_l"));
											adInfo.setWeight_r(itemJsonObject.optInt("weight_r"));
											adInfo.setSize(itemJsonObject.optString("size"));
											String game_url = itemJsonObject.optString("game_url");
											if(!TextUtils.isEmpty(game_url)){
												adInfo.setGameUrl(game_url);
												adInfo.setHtml5(true);
											}
											adInfos.add(adInfo);
										}
									}
								}
								toolboxAd.setAdInfos(adInfos);
								toolboxAds.add(toolboxAd);
							}
						}
					} else {
						return null;
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return toolboxAds;
	}
	
	
	public static ArrayList<ToolboxAd> getResultAdInfo(Context context) {
		SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
		ArrayList<ToolboxAd> toolboxAds = null;
		ArrayList<AdInfo> adInfos = null;
		try {
			String adJson = "";
			if(Constants.SHOUFA){
				adJson = "http://static.kfkx.net/app/clearmaster/clearmaster_result_ad.json";
			}else{
				adJson = "http://static.kfkx.net/app/clearmaster/clearmaster_result_ad.json";
			}
			URL url = new URL(adJson);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setConnectTimeout(5 * 1000);
			conn.setRequestMethod("GET");
			conn.setReadTimeout(30 * 1000);
			if (conn.getResponseCode() == 200) {
				InputStream inStream = conn.getInputStream();
				StringBuffer sb = new StringBuffer();
				byte[] buffer = new byte[1024];
				int len;
				while ((len = inStream.read(buffer)) != -1) {
					String string = new String(buffer, 0, len);
					sb.append(string);

				}
				inStream.close();
				String response = sb.toString();
				DLog.i("debug", "response : " + response);
				JSONObject jsonObject = new JSONObject(response);
				if (jsonObject != null) {
					boolean show = jsonObject.optBoolean("show");
					sp.edit().putString("result_ad_json", jsonObject.toString()).commit();
					if (show) {
						JSONArray jsonArray = jsonObject.optJSONArray("items");
						if (jsonArray != null && jsonArray.length() > 0) {
							toolboxAds = new ArrayList<ToolboxAd>();
							for (int i = 0; i < jsonArray.length(); i++) {
								JSONArray itemJsonArray = jsonArray.optJSONArray(i);
								ToolboxAd toolboxAd = new ToolboxAd();
								if (itemJsonArray != null && itemJsonArray.length() > 0) {
									adInfos = new ArrayList<AdInfo>();
									for (int t = 0; t < itemJsonArray.length(); t++) {
										JSONObject itemJsonObject = itemJsonArray.optJSONObject(t);
										if (itemJsonObject != null) {
											AdInfo adInfo = new AdInfo();
											adInfo.setApkUrl(itemJsonObject.optString("url"));
											adInfo.setAppName(itemJsonObject.optString("appname"));
											adInfo.setImageUrl(itemJsonObject.optString("iconurl"));
											adInfo.setPackageName(itemJsonObject.optString("packagename"));
											adInfo.setContent(itemJsonObject.optString("content"));
											adInfo.setTitle(itemJsonObject.optString("title"));
											adInfo.setDetailUrl(itemJsonObject.optString("detail_url"));
											adInfo.setWeight_l(itemJsonObject.optInt("weight_l"));
											adInfo.setWeight_r(itemJsonObject.optInt("weight_r"));
											adInfo.setSize(itemJsonObject.optString("size"));
											String game_url = itemJsonObject.optString("game_url");
											if(!TextUtils.isEmpty(game_url)){
												adInfo.setGameUrl(game_url);
												adInfo.setHtml5(true);
											}
											adInfos.add(adInfo);
										}
									}
								}
								toolboxAd.setAdInfos(adInfos);
								toolboxAds.add(toolboxAd);
							}
						}
					} else {
						return null;
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return toolboxAds;
	}

	public static ArrayList<ToolboxAd> getAdInfo(String json) {
		ArrayList<ToolboxAd> toolboxAds = null;
		ArrayList<AdInfo> adInfos = null;
		try {
			JSONObject jsonObject = new JSONObject(json);
			if (jsonObject != null) {
				boolean show = jsonObject.optBoolean("show");
				if (show) {
					JSONArray jsonArray = jsonObject.optJSONArray("items");
					if (jsonArray != null && jsonArray.length() > 0) {
						toolboxAds = new ArrayList<ToolboxAd>();
						for (int i = 0; i < jsonArray.length(); i++) {
							JSONArray itemJsonArray = jsonArray.optJSONArray(i);
							ToolboxAd toolboxAd = new ToolboxAd();
							if (itemJsonArray != null && itemJsonArray.length() > 0) {
								adInfos = new ArrayList<AdInfo>();
								for (int t = 0; t < itemJsonArray.length(); t++) {
									JSONObject itemJsonObject = itemJsonArray.optJSONObject(t);
									if (itemJsonObject != null) {
										AdInfo adInfo = new AdInfo();
										adInfo.setApkUrl(itemJsonObject.optString("url"));
										adInfo.setAppName(itemJsonObject.optString("appname"));
										adInfo.setImageUrl(itemJsonObject.optString("iconurl"));
										adInfo.setPackageName(itemJsonObject.optString("packagename"));
										adInfo.setContent(itemJsonObject.optString("content"));
										adInfo.setDetailUrl(itemJsonObject.optString("detail_url"));
										adInfo.setTitle(itemJsonObject.optString("title"));
										adInfo.setWeight_l(itemJsonObject.optInt("weight_l"));
										adInfo.setWeight_r(itemJsonObject.optInt("weight_r"));
										adInfo.setSize(itemJsonObject.optString("size"));
										String game_url = itemJsonObject.optString("game_url");
										if(!TextUtils.isEmpty(game_url)){
											adInfo.setGameUrl(game_url);
											adInfo.setHtml5(true);
										}
										adInfos.add(adInfo);
									}
								}
							}
							toolboxAd.setAdInfos(adInfos);
							toolboxAds.add(toolboxAd);
						}
					}
				} else {
					return null;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return toolboxAds;
	}

}
