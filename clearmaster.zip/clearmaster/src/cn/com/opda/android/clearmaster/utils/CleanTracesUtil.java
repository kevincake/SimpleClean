package cn.com.opda.android.clearmaster.utils;

import android.content.Context;
import android.net.Uri;
import android.provider.Browser;
import android.provider.SearchRecentSuggestions;
import android.text.ClipboardManager;

public class CleanTracesUtil {
	private Context mContext;

	public CleanTracesUtil(Context context) {
		this.mContext = context;
	}

	/**
	 * 清理系统浏览器历史记录和搜索记录
	 */
	public void cleanCookies() {
		try {
			Browser.clearHistory(mContext.getContentResolver());
			Browser.clearSearches(mContext.getContentResolver());

		} catch (Exception e) {
		}
	}

	/**
	 * 清理地图搜索记录
	 */
	public void cleanMapsSearchRecorder() {
		try {
			new SearchRecentSuggestions(mContext, "com.google.android.maps.SearchHistoryProvider", 1).clearHistory();
			Uri localUri = Uri.parse("content://com.google.android.maps.SearchHistoryProvider/history");
			mContext.getContentResolver().delete(localUri, null, null);

		} catch (Exception e) {
		}
	}

	/**
	 * 清理Gmail搜索记录
	 */
	public void cleanGmailSearchRecorder() {
		try {
			new SearchRecentSuggestions(mContext, "com.google.android.gmail.SuggestionProvider", 1).clearHistory();

		} catch (Exception e) {
		}

	}

	/**
	 * 清理电子市场搜索记录
	 */
	public void cleanMarketSearchRecorder() {

		try {
			new SearchRecentSuggestions(mContext, "com.android.vending.SuggestionsProvider", 1).clearHistory();

		} catch (Exception localException) {

		}

	}

	/**
	 * 清理剪贴板记录
	 */
	public void cleanClipboard() {
		((ClipboardManager) mContext.getSystemService("clipboard")).setText("");
	}

}
