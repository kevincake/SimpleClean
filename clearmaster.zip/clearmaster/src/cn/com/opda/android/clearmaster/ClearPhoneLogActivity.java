package cn.com.opda.android.clearmaster;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Parcelable;
import android.provider.CallLog;
import android.provider.CallLog.Calls;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import cn.com.opda.android.clearmaster.adapter.ClearPhoneLogAdapter;
import cn.com.opda.android.clearmaster.impl.CheckedListener;
import cn.com.opda.android.clearmaster.model.PhoneLog;
import cn.com.opda.android.clearmaster.utils.BannerUtils;
import cn.com.opda.android.clearmaster.utils.CallUtils;
import cn.com.opda.android.clearmaster.utils.CustomEventCommit;
import cn.com.opda.android.clearmaster.utils.DateUtils;

import com.umeng.analytics.MobclickAgent;

/**
 * 通话记录清理页面
 * 
 * @author 庄宏岩
 * 
 */
public class ClearPhoneLogActivity extends BaseActivity implements OnClickListener, OnItemClickListener,CheckedListener {
	private Context mContext;

	private ClearPhoneLogAdapter allCallLogAdapter;
	private ClearPhoneLogAdapter inCallLogAdapter;
	private ClearPhoneLogAdapter outCallLogAdapter;
	private ClearPhoneLogAdapter missCallLogAdapter;
	private ArrayList<PhoneLog> allCallLogs;
	private ArrayList<PhoneLog> inCallLogs;
	private ArrayList<PhoneLog> outCallLogs;
	private ArrayList<PhoneLog> missCallLogs;
	private LinearLayout all_calllog_tips_layout;
	private LinearLayout in_calllog_tips_layout;
	private LinearLayout out_calllog_tips_layout;
	private LinearLayout miss_calllog_tips_layout;
	private ListView all_call_listview;
	private ListView in_call_listview;
	private ListView out_call_listview;
	private ListView miss_call_listview;

	private TextView call_count;
	private long callCount;
	private boolean stop;
	private String[] calllogFilter;
	private Button clear_button;
	private RelativeLayout clear_button_layout;

	private ViewPager mPager;// 页卡内容
	private List<View> listViews; // Tab页面列表
	private ImageView cursor;// 动画图片
	private int offset = 0;// 动画图片偏移量
	private int currIndex = 0;// 当前页卡编号
	private int bmpW;// 动画图片宽度
	private int screenW;
	private TextView viewpager_tab1, viewpager_tab2, viewpager_tab3, viewpager_tab4;
	private CheckBox allCheckbox;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mContext = ClearPhoneLogActivity.this;
		setContentView(R.layout.activity_clear_call);
		BannerUtils.setTitle(this, R.string.clean_phonelog_title);
		BannerUtils.initBackButton(this);
		calllogFilter = getResources().getStringArray(R.array.calllog_filter);
		initViewAndEvent();
		initTextView();
		initImageView();
		initViewPager();
		new GetCallLogTask().execute();
	}

	/**
	 * 初始化头标
	 */
	private void initTextView() {
		viewpager_tab1 = (TextView) findViewById(R.id.viewpager_tab1);
		viewpager_tab2 = (TextView) findViewById(R.id.viewpager_tab2);
		viewpager_tab3 = (TextView) findViewById(R.id.viewpager_tab3);
		viewpager_tab4 = (TextView) findViewById(R.id.viewpager_tab4);

		viewpager_tab1.setText(calllogFilter[0]);
		viewpager_tab2.setText(calllogFilter[1]);
		viewpager_tab3.setText(calllogFilter[2]);
		viewpager_tab4.setText(calllogFilter[3]);

		viewpager_tab1.setOnClickListener(this);
		viewpager_tab2.setOnClickListener(this);
		viewpager_tab3.setOnClickListener(this);
		viewpager_tab4.setOnClickListener(this);
	}

	/**
	 * 初始化ViewPager
	 */
	private void initViewPager() {
		mPager = (ViewPager) findViewById(R.id.vPager);

		listViews = new ArrayList<View>();

		View view1 = LayoutInflater.from(mContext).inflate(R.layout.calllog_listview_layout, null);
		all_call_listview = (ListView) view1.findViewById(R.id.clear_calllog_listview);
		all_call_listview.setOnItemClickListener(this);
		all_calllog_tips_layout = (LinearLayout) view1.findViewById(R.id.clear_calllog_tips_layout);
		allCallLogs = new ArrayList<PhoneLog>();
		allCallLogAdapter = new ClearPhoneLogAdapter(mContext, allCallLogs);
		allCallLogAdapter.setCheckedListener(this);
		all_call_listview.setAdapter(allCallLogAdapter);

		View view2 = LayoutInflater.from(mContext).inflate(R.layout.calllog_listview_layout, null);
		in_call_listview = (ListView) view2.findViewById(R.id.clear_calllog_listview);
		in_call_listview.setOnItemClickListener(this);
		in_calllog_tips_layout = (LinearLayout) view2.findViewById(R.id.clear_calllog_tips_layout);
		inCallLogs = new ArrayList<PhoneLog>();
		inCallLogAdapter = new ClearPhoneLogAdapter(mContext, inCallLogs);
		inCallLogAdapter.setCheckedListener(this);
		in_call_listview.setAdapter(inCallLogAdapter);

		View view3 = LayoutInflater.from(mContext).inflate(R.layout.calllog_listview_layout, null);
		out_call_listview = (ListView) view3.findViewById(R.id.clear_calllog_listview);
		out_call_listview.setOnItemClickListener(this);
		out_calllog_tips_layout = (LinearLayout) view3.findViewById(R.id.clear_calllog_tips_layout);
		outCallLogs = new ArrayList<PhoneLog>();
		outCallLogAdapter = new ClearPhoneLogAdapter(mContext, outCallLogs);
		outCallLogAdapter.setCheckedListener(this);
		out_call_listview.setAdapter(outCallLogAdapter);

		View view4 = LayoutInflater.from(mContext).inflate(R.layout.calllog_listview_layout, null);
		miss_call_listview = (ListView) view4.findViewById(R.id.clear_calllog_listview);
		miss_call_listview.setOnItemClickListener(this);
		miss_calllog_tips_layout = (LinearLayout) view4.findViewById(R.id.clear_calllog_tips_layout);
		missCallLogs = new ArrayList<PhoneLog>();
		missCallLogAdapter = new ClearPhoneLogAdapter(mContext, missCallLogs);
		missCallLogAdapter.setCheckedListener(this);
		miss_call_listview.setAdapter(missCallLogAdapter);

		listViews.add(view1);
		listViews.add(view2);
		listViews.add(view3);
		listViews.add(view4);
		mPager.setAdapter(new MyPagerAdapter(listViews));
		mPager.setCurrentItem(0);
		mPager.setOnPageChangeListener(new MyOnPageChangeListener());

	}

	/**
	 * 初始化动画
	 */
	private void initImageView() {
		cursor = (ImageView) findViewById(R.id.cursor);
		bmpW = BitmapFactory.decodeResource(getResources(), R.drawable.indicator).getWidth();// 获取图片宽度
		DisplayMetrics dm = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(dm);
		screenW = dm.widthPixels;// 获取分辨率宽度
		offset = (screenW / 4 - bmpW) / 2;// 计算偏移量
		Matrix matrix = new Matrix();
		matrix.postTranslate(offset, 0);

		cursor.setImageMatrix(matrix);// 设置动画初始位置
	}

	/**
	 * ViewPager适配器
	 */
	public class MyPagerAdapter extends PagerAdapter {
		public List<View> mListViews;

		public MyPagerAdapter(List<View> mListViews) {
			this.mListViews = mListViews;
		}

		@Override
		public void destroyItem(View view, int position, Object object) {
			((ViewPager) view).removeView(mListViews.get(position));
		}

		@Override
		public void finishUpdate(View view) {

		}

		@Override
		public int getCount() {
			return mListViews.size();
		}

		@Override
		public Object instantiateItem(View view, int position) {
			((ViewPager) view).addView(mListViews.get(position), 0);
			return mListViews.get(position);
		}

		@Override
		public boolean isViewFromObject(View view, Object obj) {
			return view == (obj);
		}

		@Override
		public void restoreState(Parcelable view, ClassLoader classLoader) {
		}

		@Override
		public Parcelable saveState() {
			return null;
		}

		@Override
		public void startUpdate(View view) {
		}
	}

	public class MyOnPageChangeListener implements OnPageChangeListener {
		int one = offset + screenW / 4;
		int two = offset + (screenW / 4) * 2;
		int three = offset + (screenW / 4) * 3;

		@Override
		public void onPageSelected(int position) {

			currIndex = position;
			updatePage();
		}

		@Override
		public void onPageScrolled(int arg0, float arg1, int arg2) {
			Matrix matrix = new Matrix();
			switch (arg0) {
			case 0:
				matrix.postTranslate(offset + (one - offset) * arg1, 0);
				break;
			case 1:
				matrix.postTranslate(one + (two - one) * arg1, 0);
				break;
			case 2:
				matrix.postTranslate(two + (two - one) * arg1, 0);
				break;
			case 3:
				matrix.postTranslate(three + (two - one) * arg1, 0);
				break;

			default:
				break;
			}
			cursor.setImageMatrix(matrix);
		}

		@Override
		public void onPageScrollStateChanged(int position) {

		}
	}

	private void initViewAndEvent() {
		call_count = (TextView) findViewById(R.id.header_memory_textview);

		clear_button = (Button) findViewById(R.id.clear_button);
		clear_button.setOnClickListener(this);
		
		allCheckbox = (CheckBox) findViewById(R.id.all_checked_checkbox);
		allCheckbox.setChecked(false);
		allCheckbox.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				allCheckbox.setChecked(allCheckbox.isChecked());
				updateChecked(allCheckbox.isChecked());
				
			}
		});
		clear_button_layout = (RelativeLayout) findViewById(R.id.clear_button_layout);
	}

	private class GetCallLogTask extends AsyncTask<Void, PhoneLog, Integer> {

		@Override
		protected void onPreExecute() {
			clear_button.setText(R.string.stop_scan_button);
		}

		@Override
		protected Integer doInBackground(Void... params) {
			String[] projection = new String[] { CallLog.Calls._ID, CallLog.Calls.NUMBER, CallLog.Calls.DATE, CallLog.Calls.TYPE };
			Cursor cursor = mContext.getContentResolver().query(CallLog.Calls.CONTENT_URI, projection, null, null, Calls.DEFAULT_SORT_ORDER);

			String name = null;
			String tNum = null;
			if (cursor != null) {
				cursor.moveToFirst();
				int count = cursor.getCount();
				for (int i = 0; i < count; i++) {
					if (stop) {
						break;
					}

					cursor.moveToPosition(i);
					PhoneLog phoneLog = new PhoneLog();
					phoneLog.setId(cursor.getString(0));
					tNum = cursor.getString(1);
					phoneLog.setTime(DateUtils.parseLongtoTime(cursor.getLong(2)));
					phoneLog.setType(cursor.getInt(3));
					phoneLog.setChecked(false);

					name = CallUtils.getNamebyPhoneNum(mContext, tNum);
					phoneLog.setName(name == null ? tNum : name);
					callCount++;
					publishProgress(phoneLog);
				}

				cursor.close();
			}
			return null;
		}

		@Override
		protected void onProgressUpdate(PhoneLog... values) {
			if (values.length > 0) {
				PhoneLog phoneLog = values[0];
				allCallLogs.add(phoneLog);
				allCallLogAdapter.notifyDataSetChanged();

				if (phoneLog.getType() == Calls.INCOMING_TYPE) {
					inCallLogs.add(phoneLog);
					inCallLogAdapter.notifyDataSetChanged();
				}

				if (phoneLog.getType() == Calls.OUTGOING_TYPE) {
					outCallLogs.add(phoneLog);
					outCallLogAdapter.notifyDataSetChanged();
				}

				if (phoneLog.getType() == Calls.MISSED_TYPE) {
					missCallLogs.add(phoneLog);
					missCallLogAdapter.notifyDataSetChanged();
				}

			}
			super.onProgressUpdate(values);
			updateCount();
		}

		@Override
		protected void onPostExecute(Integer result) {
			super.onPostExecute(result);

			if (allCallLogs.size() == 0) {
				all_calllog_tips_layout.setVisibility(View.VISIBLE);
				all_call_listview.setVisibility(View.GONE);
			} else {
				all_calllog_tips_layout.setVisibility(View.GONE);
				all_call_listview.setVisibility(View.VISIBLE);
			}

			if (inCallLogs.size() == 0) {
				in_calllog_tips_layout.setVisibility(View.VISIBLE);
				in_call_listview.setVisibility(View.GONE);
			} else {
				in_calllog_tips_layout.setVisibility(View.GONE);
				in_call_listview.setVisibility(View.VISIBLE);
			}

			if (outCallLogs.size() == 0) {
				out_calllog_tips_layout.setVisibility(View.VISIBLE);
				out_call_listview.setVisibility(View.GONE);
			} else {
				out_calllog_tips_layout.setVisibility(View.GONE);
				out_call_listview.setVisibility(View.VISIBLE);
			}

			if (missCallLogs.size() == 0) {
				miss_calllog_tips_layout.setVisibility(View.VISIBLE);
				miss_call_listview.setVisibility(View.GONE);
			} else {
				miss_calllog_tips_layout.setVisibility(View.GONE);
				miss_call_listview.setVisibility(View.VISIBLE);
			}

			handler.sendEmptyMessage(2);
		}

		Handler handler = new Handler() {

			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				switch (msg.what) {
				case 2:
					clear_button.setText(R.string.one_clear_button);
					updatePage();
					break;

				default:
					break;
				}
			}

		};

	}

	private class DeleteCallLogTask extends AsyncTask<Void, PhoneLog, Integer> {
		private ArrayList<PhoneLog> mDeleteCallLogs;

		public DeleteCallLogTask(ArrayList<PhoneLog> mDeleteCallLogs) {
			this.mDeleteCallLogs = mDeleteCallLogs;
		}

		@Override
		protected Integer doInBackground(Void... params) {
			if (mDeleteCallLogs.size() > 0) {
				for (int i = 0; i < mDeleteCallLogs.size(); i++) {
					if (stop) {
						return null;
					}

					PhoneLog phoneLog = mDeleteCallLogs.get(i);
					CallUtils.deleteCallLog(mContext, phoneLog);
					try {
						Thread.sleep(30);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					publishProgress(phoneLog);
				}
			}
			return null;
		}

		@Override
		protected void onProgressUpdate(PhoneLog... values) {
			if (values.length > 0) {
				PhoneLog phoneLog = values[0];
				allCallLogs.remove(phoneLog);
				allCallLogAdapter.notifyDataSetChanged();

				if (phoneLog.getType() == Calls.INCOMING_TYPE) {
					inCallLogs.remove(phoneLog);
					inCallLogAdapter.notifyDataSetChanged();
				}

				if (phoneLog.getType() == Calls.OUTGOING_TYPE) {
					outCallLogs.remove(phoneLog);
					outCallLogAdapter.notifyDataSetChanged();
				}

				if (phoneLog.getType() == Calls.MISSED_TYPE) {
					missCallLogs.remove(phoneLog);
					missCallLogAdapter.notifyDataSetChanged();
				}
				handler.sendEmptyMessage(1);

			}
			super.onProgressUpdate(values);
		}

		@Override
		protected void onPostExecute(Integer result) {
			super.onPostExecute(result);
			if (allCallLogs.size() == 0) {
				all_calllog_tips_layout.setVisibility(View.VISIBLE);
				all_call_listview.setVisibility(View.GONE);
			} else {
				all_calllog_tips_layout.setVisibility(View.GONE);
				all_call_listview.setVisibility(View.VISIBLE);
			}

			if (inCallLogs.size() == 0) {
				in_calllog_tips_layout.setVisibility(View.VISIBLE);
				in_call_listview.setVisibility(View.GONE);
			} else {
				in_calllog_tips_layout.setVisibility(View.GONE);
				in_call_listview.setVisibility(View.VISIBLE);
			}

			if (outCallLogs.size() == 0) {
				out_calllog_tips_layout.setVisibility(View.VISIBLE);
				out_call_listview.setVisibility(View.GONE);
			} else {
				out_calllog_tips_layout.setVisibility(View.GONE);
				out_call_listview.setVisibility(View.VISIBLE);
			}

			if (missCallLogs.size() == 0) {
				miss_calllog_tips_layout.setVisibility(View.VISIBLE);
				miss_call_listview.setVisibility(View.GONE);
			} else {
				miss_calllog_tips_layout.setVisibility(View.GONE);
				miss_call_listview.setVisibility(View.VISIBLE);
			}
			handler.sendEmptyMessage(2);
			Toast.makeText(mContext, getString(R.string.clean_end_calllog_count_toast, mDeleteCallLogs.size()), Toast.LENGTH_SHORT).show();
		}

		Handler handler = new Handler() {

			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				switch (msg.what) {
				case 1:
					updateCount();
					break;
				case 2:
					updatePage();
					break;

				default:
					break;
				}
			}

		};

	}

	public void updateCount() {
		switch (currIndex) {
		case 0:
			callCount = allCallLogAdapter.getList().size();
			call_count.setText(callCount + "");
			break;
		case 1:
			callCount = inCallLogAdapter.getList().size();
			call_count.setText(callCount + "");
			break;
		case 2:
			callCount = outCallLogAdapter.getList().size();
			call_count.setText(callCount + "");
			break;
		case 3:
			callCount = missCallLogAdapter.getList().size();
			call_count.setText(callCount + "");
			break;

		default:
			break;
		}
	}

	protected void updatePage() {
		switch (currIndex) {
		case 0:
			if (allCallLogs.size() > 0) {
				clear_button_layout.setVisibility(View.VISIBLE);
			} else {
				clear_button_layout.setVisibility(View.GONE);
			}
			callCount = allCallLogAdapter.getList().size();
			call_count.setText(callCount + "");
			allCallLogAdapter.updateChecked();
			break;
		case 1:
			if (inCallLogs.size() > 0) {
				clear_button_layout.setVisibility(View.VISIBLE);
			} else {
				clear_button_layout.setVisibility(View.GONE);
			}
			callCount = inCallLogAdapter.getList().size();
			call_count.setText(callCount + "");
			inCallLogAdapter.updateChecked();
			break;
		case 2:
			if (outCallLogs.size() > 0) {
				clear_button_layout.setVisibility(View.VISIBLE);
			} else {
				clear_button_layout.setVisibility(View.GONE);
			}
			callCount = outCallLogAdapter.getList().size();
			call_count.setText(callCount + "");
			outCallLogAdapter.updateChecked();
			break;
		case 3:
			if (missCallLogs.size() > 0) {
				clear_button_layout.setVisibility(View.VISIBLE);
			} else {
				clear_button_layout.setVisibility(View.GONE);
			}
			callCount = missCallLogAdapter.getList().size();
			call_count.setText(callCount + "");
			missCallLogAdapter.updateChecked();
			break;

		default:
			break;
		}
	}

	private void updateChecked(boolean checked) {
		switch (currIndex) {
		case 0:
			allCallLogAdapter.setAllChecked(checked);
			break;
		case 1:
			inCallLogAdapter.setAllChecked(checked);
			break;
		case 2:
			outCallLogAdapter.setAllChecked(checked);
			break;
		case 3:
			missCallLogAdapter.setAllChecked(checked);
			break;

		default:
			break;
		}
	}

	@Override
	protected void onResume() {
		MobclickAgent.onResume(this);
		super.onResume();
	}

	@Override
	protected void onPause() {
		MobclickAgent.onPause(this);
		super.onPause();
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
		PhoneLog callLog = (PhoneLog) parent.getItemAtPosition(position);
		callLog.setChecked(!callLog.isChecked());
		switch (currIndex) {
		case 0:
			allCallLogAdapter.updateChecked();
			allCallLogAdapter.notifyDataSetChanged();
			break;
		case 1:
			inCallLogAdapter.updateChecked();
			inCallLogAdapter.notifyDataSetChanged();
			break;
		case 2:
			outCallLogAdapter.updateChecked();
			outCallLogAdapter.notifyDataSetChanged();
			break;
		case 3:
			missCallLogAdapter.updateChecked();
			missCallLogAdapter.notifyDataSetChanged();
			break;

		default:
			break;
		}
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.clear_button:
			if (clear_button.getText().equals(getString(R.string.stop_scan_button))) {
				stop = true;
				clear_button.setText(R.string.one_clear_button);
			} else {
				CustomEventCommit.commit(mContext, CustomEventCommit.button_calllog_click);
				deleteCallLog();
			}
			break;
		case R.id.viewpager_tab1:
			mPager.setCurrentItem(0);
			break;
		case R.id.viewpager_tab2:
			mPager.setCurrentItem(1);
			break;
		case R.id.viewpager_tab3:
			mPager.setCurrentItem(2);
			break;
		case R.id.viewpager_tab4:
			mPager.setCurrentItem(3);
			break;
		default:
			break;
		}
	}

	private void deleteCallLog() {
		ArrayList<PhoneLog> deleteList = null;
		switch (currIndex) {
		case 0:
			deleteList = allCallLogAdapter.getSelecteList();
			break;
		case 1:
			deleteList = inCallLogAdapter.getSelecteList();
			break;
		case 2:
			deleteList = outCallLogAdapter.getSelecteList();
			break;
		case 3:
			deleteList = missCallLogAdapter.getSelecteList();
			break;

		default:
			break;
		}

		if (deleteList == null || deleteList.size() == 0) {
			Toast.makeText(mContext, R.string.clear_select_null, Toast.LENGTH_SHORT).show();
		} else {
			new DeleteCallLogTask(deleteList).execute();
		}
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		stop = true;
	}
	@Override
	public void nothingChecked() {
		allCheckbox.setChecked(false);
	}

	@Override
	public void someChecked(int count) {
		allCheckbox.setChecked(false);
	}

	@Override
	public void allChecked(int count) {
		allCheckbox.setChecked(true);
	}
}
