package cn.com.opda.android.clearmaster.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import cn.com.opda.android.clearmaster.dao.AppNetFlowDBUtils;
import cn.com.opda.android.clearmaster.utils.ClearUtils;

public class ShutdownReceiver extends BroadcastReceiver {

	@Override
	public void onReceive(final Context context, Intent intent) {
		if (intent != null) {
			String action = intent.getAction();
			if (("android.intent.action.ACTION_SHUTDOWN").equals(action)) {
				if (Build.VERSION.SDK_INT > 7) {
					new Thread(new Runnable() {

						@Override
						public void run() {
							AppNetFlowDBUtils.updateList(context);
						}
					}).start();
				}
			}
			if ("android.intent.action.DATE_CHANGED".equals(action)) {
				ClearUtils.clearDayClearSize(context,System.currentTimeMillis());
			}
		}
	}

}
