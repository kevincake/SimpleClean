package cn.com.opda.android.clearmaster;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationSet;
import android.view.animation.OvershootInterpolator;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import cn.com.opda.android.clearmaster.service.ReadStartUpService;
import cn.com.opda.android.clearmaster.utils.BannerUtils;
import cn.com.opda.android.clearmaster.utils.Constants;

import com.umeng.analytics.MobclickAgent;

public class SplashActivity extends Activity {
	private RelativeLayout splash_layout;
	private ImageView splash_icon_imageview;
	private ImageView banner_left_imageview;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_splash_layout);

		TextView banner_title_textview = (TextView) findViewById(R.id.banner_title_textview);
		banner_title_textview.setText(R.string.app_name);

		banner_left_imageview = (ImageView) findViewById(R.id.banner_left_imageview);
		banner_left_imageview.setVisibility(View.VISIBLE);

		BannerUtils.initAppButton(this);

		ImageView banner_about_imageview = (ImageView) findViewById(R.id.banner_about_imageview);
		banner_about_imageview.setVisibility(View.VISIBLE);

		splash_layout = (RelativeLayout) findViewById(R.id.splash_layout);
		splash_icon_imageview = (ImageView) findViewById(R.id.splash_icon_imageview);

		ImageView shoufa_imageview = (ImageView) findViewById(R.id.shoufa_imageview);
		if (Constants.SHOUFA) {
			shoufa_imageview.setVisibility(View.VISIBLE);
		} else {
			shoufa_imageview.setVisibility(View.GONE);
		}

		new Thread(new Runnable() {

			@Override
			public void run() {
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				runOnUiThread(new Runnable() {

					@Override
					public void run() {
						// startActivity(new Intent(SplashActivity.this,
						// MainClearActivity.class));
						// finish();
						startAnim();

					}

				});
			}
		}).start();
	}

	private void startAnim() {
		AnimationSet animationSet = new AnimationSet(true);
		animationSet.setDuration(1000);
		animationSet.setFillAfter(true);

		int translate_x = -splash_icon_imageview.getRight() - splash_icon_imageview.getWidth();
		int translate_y = -splash_icon_imageview.getBottom() - splash_icon_imageview.getHeight();

		TranslateAnimation translateAnimation = new TranslateAnimation(0, translate_x, 0, translate_y);
		translateAnimation.setInterpolator(new OvershootInterpolator());
		animationSet.addAnimation(translateAnimation);

		float f = banner_left_imageview.getWidth() * 1.0f / splash_icon_imageview.getWidth();

		ScaleAnimation scaleAnimation = new ScaleAnimation(1.0f, f, 1.0f, f);
		scaleAnimation.setDuration(800);
		animationSet.addAnimation(scaleAnimation);

		animationSet.setAnimationListener(new AnimationListener() {

			@Override
			public void onAnimationStart(Animation animation) {

			}

			@Override
			public void onAnimationRepeat(Animation animation) {

			}

			@Override
			public void onAnimationEnd(Animation animation) {
				splash_layout.clearAnimation();
				splash_layout.setVisibility(View.GONE);
			}
		});

		AlphaAnimation alphaAnimation = new AlphaAnimation(1.0f, 0.1f);
		alphaAnimation.setDuration(1000);
		alphaAnimation.setFillAfter(true);
		splash_layout.startAnimation(alphaAnimation);

		splash_icon_imageview.startAnimation(animationSet);

	}

	@Override
	protected void onResume() {
		super.onResume();
		MobclickAgent.onResume(this);
		stopService(new Intent(this, ReadStartUpService.class));
	}

	@Override
	protected void onPause() {
		super.onPause();
		MobclickAgent.onPause(this);
	}

}
