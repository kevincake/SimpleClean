package cn.com.opda.android.clearmaster.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.hardware.Camera;
import android.hardware.Camera.CameraInfo;
import android.hardware.Camera.Parameters;
import android.hardware.Camera.Size;
import android.media.ThumbnailUtils;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import cn.com.opda.android.clearmaster.http.CustomHttpClient;
import cn.com.opda.android.clearmaster.http.CustomHttpUtil;

public class DeviceInfoUtils extends BaseJsonUtil {
	public static final int CAMERA_FACING_BACK = 0;
	public static final int CAMERA_FACING_FRONT = 1;

	public DeviceInfoUtils(Context context) {
		super(context);
	}

	/**
	 * @return 设备型号
	 */
	public static String getDeviceModel() {
		return Build.MODEL;
	}

	/**
	 * @return 系统版本
	 */
	public static String getSystemVerson() {
		return Build.VERSION.RELEASE;
	}

	/**
	 * 判断sd卡是否被挂载
	 * 
	 * @return true:挂载 false：未挂载
	 */
	public static boolean externalMemoryAvailable() {
		return Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState());
	}

	public static int getDeviceWidth(Context context) {
		WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
		DisplayMetrics dm = new DisplayMetrics();
		wm.getDefaultDisplay().getMetrics(dm);
		return dm.widthPixels;
	}

	public static int getDeviceHeight(Context context) {
		WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
		DisplayMetrics dm = new DisplayMetrics();
		wm.getDefaultDisplay().getMetrics(dm);
		return dm.heightPixels;
	}

	public static String getIMEI(Context context) {
		TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
		return tm.getDeviceId();
	}

	public static String getMacAddress(Context context) {
		WifiManager wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
		WifiInfo wifiInfo = wifiManager.getConnectionInfo();
		return wifiInfo.getMacAddress();
	}

	public static String getTelNumber(Context cxt) {
		try {
			TelephonyManager tm = (TelephonyManager) cxt.getSystemService("phone");
			return tm.getLine1Number();
		} catch (Exception e) {
		}
		return null;
	}

	/**
	 * 添加请求的公共参数
	 * 
	 * @param did
	 * @param deviceid
	 * @param value
	 * @param context
	 * @throws JSONException
	 */
	public static void addDeviceNode(long did, long deviceid, JSONObject value, Context context) throws JSONException {
		if (deviceid > 0) {
			value.put("devices_id", deviceid);
		}
		if (did > 0) {
			value.put("did", did);
		} else {
			value.put("imei", DeviceInfoUtils.getIMEI(context));
			value.put("wifimac", DeviceInfoUtils.getMacAddress(context));
			if (value.isNull("imei")) {
				value.put("imei", "");
			}
			if (value.isNull("wifimac")) {
				value.put("wifimac", "");
			}
		}
		value.put("device", new JSONObject().put("info", getInfoNode(context)));
	}

	public static void addDeviceNode(long deviceid, JSONObject value) throws JSONException {
		value.put("hid", "-1000");
		if (deviceid > 0) {
			value.put("did", deviceid);
		} else {
			value.put("did", 0);

		}
	}

	/**
	 * 添加公共参数
	 * 
	 * @param context
	 * @return
	 * @throws JSONException
	 */
	public static JSONObject getInfoNode(Context context) throws JSONException {
		List<String> list = DeviceInfoUtils.runComm("getprop");
		if (list == null || list.size() == 0) {
			list = DeviceInfoUtils.runComm("cat /system/build.prop");
		}
		Map<String, String> m = new HashMap<String, String>();
		for (String item : list) {
			if (item.startsWith("[")) {
				String[] strings = item.split("\\]: \\[");
				if (strings != null && strings.length == 2)
					m.put(strings[0].substring(1), strings[1].substring(0, strings[1].length() - 1));
			} else {
				String[] strings = item.split("=");
				if (strings != null && strings.length == 2)
					m.put(strings[0], strings[1]);
			}
		}
		JSONObject root = new JSONObject();
		root.put("identifier", getV(m, "ro.serialno"));
		root.put("secure", 1);
		root.put("model_internal", getV(m, "ro.model.internal"));
		root.put("baseband", getV(m, "ro.baseband"));
		root.put("bootloader", getV(m, "ro.bootloader"));
		root.put("cid", getV(m, "ro.cid"));
		root.put("build_id", getV(m, "ro.build.id"));
		root.put("sdk", getV(m, "ro.build.version.sdk"));
		root.put("release", getV(m, "ro.build.version.release"));
		root.put("model", getV(m, "ro.product.model"));
		root.put("board", getV(m, "ro.board.platform"));
		root.put("description", getV(m, "ro.build.description"));

		String version = getV(m, "ro.product.version");
		if ("".equals(version))
			version = getV(m, "ro.modversion");
		else if ("".equals(version))
			version = getV(m, "ro.htc.common.version");
		root.put("version", version);

		root.put("vendor", getV(m, "ro.product.manufacturer"));
		root.put("product_brand", getV(m, "ro.product.brand"));
		root.put("product_board", getV(m, "ro.product.board"));
		root.put("build_product", getV(m, "ro.build.product"));
		root.put("product_device", getV(m, "ro.product.device"));
		root.put("product_name", getV(m, "ro.semc.product.name"));// 索爱特有
		root.put("keyboards_devname", getV(m, "hw.keyboards.0.devname"));

		root.put("kernel", ZDeviceInfo.newZDeviceInfo(context).getFormattedKernelVersion().trim());

		root.put("tel_number", DeviceInfoUtils.getTelNumber(context));
		if (DeviceInfoUtils.getTelNumber(context) == null) {
			root.put("tel_number", "");
		}
		root.put("device_width", DeviceInfoUtils.getDeviceWidth(context));
		root.put("device_height", DeviceInfoUtils.getDeviceHeight(context));
		// TelephonyManager tm = (TelephonyManager) context
		// .getSystemService(Context.TELEPHONY_SERVICE);

		root.put("sim_operator", getV(m, "gsm.sim.operator.numeric") + "," + getV(m, "gsm.sim.operator.numeric.2") + ","
				+ getV(m, "gsm.sim.operator.numeric_2"));

		return root;
	}

	private static String getV(Map<String, String> mapSource, String key) {
		String value = mapSource.get(key);
		if (TextUtils.isEmpty(value))
			value = "";
		return value;
	}

	public static ArrayList<String> runComm(String comm) {
		Process process = null;
		ArrayList<String> resultStr = new ArrayList<String>();
		String line = null;
		BufferedReader brout = null;
		try {
			process = Runtime.getRuntime().exec(comm);
			InputStream outs = process.getInputStream();
			InputStreamReader isrout = new InputStreamReader(outs);
			brout = new BufferedReader(isrout, 8 * 1024);
			while ((line = brout.readLine()) != null) {
				resultStr.add(line);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (brout != null) {
					brout.close();
				}
			} catch (IOException e) {
			}
		}
		return resultStr;
	}

	/**
	 * 校验机型 获取设备的id和recovery信息
	 * 
	 * @return
	 */
	public int getDeviceInfo() {
		try {
			JSONObject value = commonRequest();
			Map<String, String> params = new HashMap<String, String>();
			String response = null;
			params.put("json", value.toString());
			response = CustomHttpUtil.sendPostRequest(Constants.DEVICEINFO_URL, params, CustomHttpClient.UTF8, context);
			parseResponse(response);
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}
		return getCode();
	}


	/**
	 * 更新设备id
	 * 
	 * @param context
	 * @param deviceid
	 */
	public static void updateDeviceId(Context context, long deviceid) {
		SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
		sp.edit().putLong(Constants.GLOBAL_DEVICEID_KEY, deviceid).commit();
	}

	/**
	 * 获取设备id
	 * 
	 * @param context
	 * @return
	 */
	public static long getDeviceId(Context context) {
		SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
		return sp.getLong(Constants.GLOBAL_DEVICEID_KEY, -1);
	}

	/**
	 * 更新did
	 * 
	 * @param context
	 * @param did
	 */
	public static void updateDid(Context context, long did) {
		SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
		sp.edit().putLong(Constants.GLOBAL_DID_KEY, did).commit();
	}

	/**
	 * 获取did
	 * 
	 * @param context
	 * @param deviceid
	 */
	public static long getDid(Context context) {
		SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
		return sp.getLong(Constants.GLOBAL_DID_KEY, -1);
	}

	/**
	 * 更新设备的数据名称
	 * 
	 * @param dataName
	 */
	public static void updateDataName(Context context, String dataName) {
		SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
		sp.edit().putString(Constants.GLOBAL_DEVICE_DADANAME_KEY, dataName).commit();
	}

	/**
	 * 获取设备的数据名称
	 * 
	 * @param context
	 * @return
	 */
	public static String getDataName(Context context) {
		SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
		return sp.getString(Constants.GLOBAL_DEVICE_DADANAME_KEY, "");
	}

	/**
	 * 更新检查更新的时间
	 * 
	 * @param dataName
	 */
	public static void updateCheckDate(Context context, long date) {
		SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
		sp.edit().putLong("check_update_data", date).commit();
	}

	/**
	 * 获取检查更新的时间
	 * 
	 * @param context
	 * @return
	 */
	public static long getCheckDate(Context context) {
		SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
		return sp.getLong("check_update_data", 0);
	}

	/**
	 * 获取屏幕密度
	 * 
	 * @param context
	 */
	public static int getScreenDpi(Context context) {
		WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
		DisplayMetrics dm = new DisplayMetrics();
		wm.getDefaultDisplay().getMetrics(dm);
		return dm.densityDpi;
	}

	/**
	 * 获取摄像头的像素
	 * 
	 * @param type
	 *            前置还是后置
	 * @return
	 */
	public static int getCameraPix(int type) {
		Parameters parameters = null;
		if (Build.VERSION.SDK_INT > 8) {
			int cameraId = getCameraId(type);
			if (cameraId == -1) {
				return 0;
			}
			try {
				Camera camera = Camera.open(cameraId);
				parameters = camera.getParameters();
				camera.release();
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			try {
				Camera camera = Camera.open();
				parameters = camera.getParameters();
				camera.release();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if (parameters != null) {
			int height = 0;
			int width = 0;
			List<Size> sizes = parameters.getSupportedPictureSizes();
			for (Size size : sizes) {
				int h = size.height;
				int w = size.width;
				if (h > height) {
					height = h;
				}
				if (w > width) {
					width = w;
				}
			}
			return Math.round(height * width / 10000f);
		}
		return 0;
	}

	/**
	 * 获取摄像头的id
	 * 
	 * @param type
	 * @return
	 */
	public static int getCameraId(int type) {
		int numberOfCameras = getCameraNum();
		CameraInfo cameraInfo = new CameraInfo();
		for (int i = 0; i < numberOfCameras; i++) {
			Camera.getCameraInfo(i, cameraInfo);
			if (cameraInfo.facing == type) {
				return i;
			}
		}
		return -1;
	}

	/**
	 * 获取摄像头的数量
	 * 
	 * @return
	 */
	public static int getCameraNum() {
		if (Build.VERSION.SDK_INT > 8) {
			return Camera.getNumberOfCameras();
		} else {
			return 1;
		}
	}

	/**
	 * 获取第一个sdcard的路径
	 * @return
	 */
	public static String getSdcard0() {
		return Environment.getExternalStorageDirectory().getAbsolutePath();
	}

	/**
	 * 获取外置sd卡的路径
	 * @return
	 */
	public static String getSdcard1() {
		Map<String, String> map = System.getenv();
		if (map != null) {
			Set<Map.Entry<String, String>> set = map.entrySet();
			for (Iterator<Map.Entry<String, String>> it = set.iterator(); it.hasNext();) {
				Map.Entry<String, String> entry = (Map.Entry<String, String>) it.next();
				Log.i("debug", entry.getKey() + "--->" + entry.getValue());
			}
			String SECONDARY_STORAGE = map.get("SECONDARY_STORAGE");
			if (SECONDARY_STORAGE == null) {
				return null;
			}
			if (SECONDARY_STORAGE.contains(":")) {
				String[] sdcards = SECONDARY_STORAGE.split(":");
				if (sdcards != null && sdcards.length > 0) {
					return sdcards[0];
				}
			} else {
				return SECONDARY_STORAGE;
			}
		}
		return null;
	}

	/**
	 * 获取屏幕截图的方法
	 * 
	 * @param activity
	 * @return
	 */
	@SuppressWarnings("deprecation")
	public static File getScreenPic(Activity mContext) {
		WindowManager windowManager = mContext.getWindowManager();
		Display display = windowManager.getDefaultDisplay();
		int w = display.getWidth();
		int h = display.getHeight();
		Bitmap bmp = Bitmap.createBitmap(w, h, Config.ARGB_8888);
		View decorview = mContext.getWindow().getDecorView();
		decorview.setDrawingCacheEnabled(true);
		bmp = decorview.getDrawingCache();
		Bitmap newBmp = ThumbnailUtils.extractThumbnail(bmp, bmp.getWidth(), bmp.getHeight(), ThumbnailUtils.OPTIONS_RECYCLE_INPUT);
		if (bmp != null && !bmp.isRecycled()) {
			bmp.recycle();
		}
		decorview.destroyDrawingCache();
		FileOutputStream outputStream;
		File file = new File(Environment.getExternalStorageDirectory(), "screen.jpg");
		try {
			outputStream = new FileOutputStream(file);
			newBmp.compress(CompressFormat.JPEG, 70, outputStream);
			outputStream.flush();
			outputStream.close();
			if (newBmp != null && !newBmp.isRecycled()) {
				newBmp.recycle();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return file;
	}

}
