package cn.com.opda.android.clearmaster.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.text.TextUtils;
import cn.com.opda.android.clearmaster.impl.ImageDownloadListener;
import cn.com.opda.android.clearmaster.model.BaseItem;
import cn.com.opda.android.clearmaster.model.VerboseAdInfo;

/**
 * 图片下载工具类
 * @author 庄宏岩
 *
 */
public class ImageDownload {
	private ImageDownloadListener downloadListener;
	private String imageName;

	public ImageDownload(ImageDownloadListener downloadListener) {
		this.downloadListener = downloadListener;
	}

	public void download(final String imageurl) {
		DLog.i("debug", "download image url : " + imageurl);
		new Thread(new Runnable() {
			@Override
			public void run() {
				long totalSize = 0;
				long downloadSize = 0;
				File folder = new File(Constants.IMAGECACHE_PATH);
				File nomedia_file = new File(Constants.IMAGECACHE_NOMEDIA);
				if (!folder.exists()) {
					folder.mkdirs();
				}
				if (!nomedia_file.exists()) {
					try {
						nomedia_file.createNewFile();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				String imagePath = null;
				if (TextUtils.isEmpty(imageName)) {
					String picName  = imageurl.substring(imageurl.lastIndexOf("/") + 1);
					picName = picName.substring(0, imageurl.lastIndexOf("."));
					imagePath = Constants.IMAGECACHE_PATH + "/" + picName;
				} else {
					imagePath = Constants.IMAGECACHE_PATH + "/" + imageName;
				}
				File imageFile = new File(imagePath);
				File imageFileTemp = new File(imagePath + ".temp");
				if (imageFile.exists()) {
					downloadListener.finish(imagePath);
					return;
				} else {
					try {
						imageFileTemp.createNewFile();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				try {
					URL url = new URL(imageurl);
					HttpURLConnection conn = (HttpURLConnection) url.openConnection();
					conn.setConnectTimeout(5 * 1000);
					conn.setRequestMethod("GET");
					conn.setReadTimeout(30 * 1000);
					if (conn.getResponseCode() == 200) {
						InputStream inStream = conn.getInputStream();
						FileOutputStream outputStream = new FileOutputStream(imageFileTemp);
						byte[] buffer = new byte[1024];
						totalSize = conn.getContentLength();
						int len;
						while ((len = inStream.read(buffer)) != -1) {
							outputStream.write(buffer, 0, len);
							downloadSize += len;
						}
						inStream.close();
						outputStream.close();
						if (totalSize == downloadSize) {
							imageFileTemp.renameTo(imageFile);
							downloadListener.finish(imagePath);
						}
					} else {
						downloadListener.error();
					}
				} catch (Exception e) {
					e.printStackTrace();
					downloadListener.error();
				}

			}
		}).start();
	}

	public void setImageName(String imageName) {
		this.imageName = imageName;
	}

	public static Bitmap downloadImage(Context mContext,VerboseAdInfo verboseAdInfo) {
		long totalSize = 0;
		long downloadSize = 0;
		
		File folder = new File(Constants.IMAGECACHE_PATH);
		File nomedia_file = new File(Constants.IMAGECACHE_NOMEDIA);
		if (!folder.exists()) {
			folder.mkdirs();
		}
		if (!nomedia_file.exists()) {
			try {
				nomedia_file.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		String imagePath = Constants.IMAGECACHE_PATH + "/" + verboseAdInfo.getPackageName() + "_icon";
		File imageFile = new File(imagePath);
		File imageFileTemp = new File(imagePath + ".temp");
		if (imageFile.exists()) {
			return BitmapFactory.decodeFile(imagePath);
		} else {
			try {
				imageFileTemp.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		try {
			URL url = new URL(verboseAdInfo.getIconUrl());
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setConnectTimeout(5 * 1000);
			conn.setRequestMethod("GET");
			conn.setReadTimeout(30 * 1000);
			if (conn.getResponseCode() == 200) {
				InputStream inStream = conn.getInputStream();
				FileOutputStream outputStream = new FileOutputStream(imageFileTemp);
				byte[] buffer = new byte[1024];
				totalSize = conn.getContentLength();
				int len;
				while ((len = inStream.read(buffer)) != -1) {
					outputStream.write(buffer, 0, len);
					downloadSize += len;
				}
				inStream.close();
				outputStream.close();
				if (totalSize == downloadSize) {
					imageFileTemp.renameTo(imageFile);
					return BitmapFactory.decodeFile(imagePath);
				}
			} 
		} catch (Exception e) {
			e.printStackTrace();
		}
		return BitmapFactory.decodeResource(mContext.getResources(), android.R.drawable.sym_def_app_icon);
	}
	
	
	public static Bitmap downloadImage(Context mContext,BaseItem baseItem) {
		long totalSize = 0;
		long downloadSize = 0;
		
		File folder = new File(Constants.IMAGECACHE_PATH);
		File nomedia_file = new File(Constants.IMAGECACHE_NOMEDIA);
		if (!folder.exists()) {
			folder.mkdirs();
		}
		if (!nomedia_file.exists()) {
			try {
				nomedia_file.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		String imagePath = Constants.IMAGECACHE_PATH + "/" + baseItem.getPackageName() + "_icon";
		File imageFile = new File(imagePath);
		File imageFileTemp = new File(imagePath + ".temp");
		if (imageFile.exists()) {
			return BitmapFactory.decodeFile(imagePath);
		} else {
			try {
				imageFileTemp.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		try {
			URL url = new URL(baseItem.getImageUrl());
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setConnectTimeout(5 * 1000);
			conn.setRequestMethod("GET");
			conn.setReadTimeout(30 * 1000);
			if (conn.getResponseCode() == 200) {
				InputStream inStream = conn.getInputStream();
				FileOutputStream outputStream = new FileOutputStream(imageFileTemp);
				byte[] buffer = new byte[1024];
				totalSize = conn.getContentLength();
				int len;
				while ((len = inStream.read(buffer)) != -1) {
					outputStream.write(buffer, 0, len);
					downloadSize += len;
				}
				inStream.close();
				outputStream.close();
				if (totalSize == downloadSize) {
					imageFileTemp.renameTo(imageFile);
					return BitmapFactory.decodeFile(imagePath);
				}
			} 
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
