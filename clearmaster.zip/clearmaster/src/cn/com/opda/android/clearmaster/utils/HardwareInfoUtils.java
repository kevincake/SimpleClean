package cn.com.opda.android.clearmaster.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.json.JSONException;
import org.json.JSONObject;

import android.text.TextUtils;

public class HardwareInfoUtils {

	/**
	 * 获取某个目录个某个文件的内容
	 * 
	 * @param fileName
	 * @param searchDir
	 * @return
	 */
	public static HashSet<String> findFile(String fileName, String searchDir) {
		Process process = null;
		HashSet<String> resultSet = new HashSet<String>();
		ArrayList<String> strings = new ArrayList<String>();
		String line = null;
		BufferedReader brout = null;
		try {
			process = Runtime.getRuntime().exec("find " + searchDir + " -name " + fileName);
			InputStream outs = process.getInputStream();
			InputStreamReader isrout = new InputStreamReader(outs);
			brout = new BufferedReader(isrout, 8 * 1024);
			while ((line = brout.readLine()) != null) {
				strings.add(line);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (brout != null) {
					brout.close();
				}
			} catch (IOException e) {
			}
		}
		if (strings.size() == 0) {
			listFile(strings, fileName, searchDir);
		}

		for (String string : strings) {
			String fileContent = readFile(string);
			if (!TextUtils.isEmpty(fileContent)) {
				resultSet.add(fileContent);
			}
		}
		return resultSet;
	}

	public static ArrayList<String> listFile(ArrayList<String> strings, String fileName, String searchDir) {
		File[] files = new File(searchDir).listFiles();
		for (File file : files) {
			if (file.isDirectory()) {
				String canonicalPath = null;
				try {
					canonicalPath = file.getCanonicalPath();
				} catch (IOException e) {
					e.printStackTrace();
				}
				if (canonicalPath != null) {
					if (file.getAbsolutePath().equals(canonicalPath)) {
						listFile(strings, fileName, file.getAbsolutePath());
					}
				}
			} else {
				if (fileName.equals(file.getName())) {
					strings.add(file.getAbsolutePath());
				}
			}
		}
		return strings;
	}

	public static String readFile(String filePath) {
		BufferedReader reader = null;
		StringBuffer buffer = new StringBuffer();
		String line;
		try {
			reader = new BufferedReader(new FileReader(filePath), 256);
			while ((line = reader.readLine()) != null) {
				buffer.append(line);
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (reader != null) {
					reader.close();
				}
			} catch (IOException e) {
			}
		}
		return buffer.toString();
	}

	public static String getProcessor() {
		try {
			FileInputStream fileInputStream = new FileInputStream("/proc/cpuinfo");
			InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
			BufferedReader bufferedReader = new BufferedReader(inputStreamReader, 1 * 1024);
			String line;
			String[] list;
			while ((line = bufferedReader.readLine()) != null) {
				list = line.split(":");
				if (list.length == 2) {
					if (list[0].contains("Processor")) {
						return list[1].trim();
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public static String getHardware() {
		try {
			FileInputStream fileInputStream = new FileInputStream("/proc/cpuinfo");
			InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
			BufferedReader bufferedReader = new BufferedReader(inputStreamReader, 1 * 1024);
			String line;
			String[] list;
			while ((line = bufferedReader.readLine()) != null) {
				list = line.split(":");
				if (list.length == 2) {
					if (list[0].contains("Hardware")) {
						return list[1].trim();
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public static ArrayList<String> getModules() {
		ArrayList<String> arrayList = new ArrayList<String>();
		try {
			FileInputStream fileInputStream = new FileInputStream("/proc/modules");
			InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
			BufferedReader bufferedReader = new BufferedReader(inputStreamReader, 1 * 1024);
			String line;
			String[] list;
			while ((line = bufferedReader.readLine()) != null) {
				list = line.split(" ");
				if (list.length > 0) {
					arrayList.add(list[0]);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return arrayList;
	}

	/**
	 * 获取CPU核心数
	 * 
	 * @return
	 */
	public static int getCpuCores() {
		class CpuFilter implements FileFilter {
			@Override
			public boolean accept(File pathname) {
				if (Pattern.matches("cpu[0-9]", pathname.getName())) {
					return true;
				}
				return false;
			}
		}
		try {
			File dir = new File("/sys/devices/system/cpu/");
			File[] files = dir.listFiles(new CpuFilter());
			return files.length;
		} catch (Exception e) {
			e.printStackTrace();
			return 1;
		}
	}

	/**
	 * 获取cpu频率的最大值
	 * 
	 * @return
	 */
	public static String getMaxCPU() {
		String str = "/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq";
		File file = new File(str);
		FileInputStream in = null;
		try {
			in = new FileInputStream(file);

		} catch (FileNotFoundException e) {

			e.printStackTrace();
			return "0";
		}
		InputStreamReader isrout = new InputStreamReader(in);
		BufferedReader brout = new BufferedReader(isrout, 8 * 1024);

		String result = "";

		String line;
		try {
			while ((line = brout.readLine()) != null) {
				result += line;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		int cpu = Integer.parseInt(result) / 1000;
		return cpu + "";
	}

	/**
	 * 获取cpu频率的最小值
	 * 
	 * @return
	 */
	public static String getMinCPU() {
		String str = "/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_min_freq";
		File file = new File(str);
		FileInputStream in = null;
		try {
			in = new FileInputStream(file);

		} catch (FileNotFoundException e) {

			e.printStackTrace();
			return "0";
		}
		InputStreamReader isrout = new InputStreamReader(in);
		BufferedReader brout = new BufferedReader(isrout, 8 * 1024);

		String result = "";

		String line;
		try {
			while ((line = brout.readLine()) != null) {
				result += line;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		int cpu = Integer.parseInt(result) / 1000;
		return cpu + "";
	}

	/**
	 * 添加公共参数
	 * 
	 * @param context
	 * @return
	 * @throws JSONException
	 */
	public static JSONObject getInfoNode() throws JSONException {
		List<String> list = DeviceInfoUtils.runComm("getprop");
		if (list == null || list.size() == 0) {
			list = DeviceInfoUtils.runComm("cat /system/build.prop");
		}
		Map<String, String> m = new HashMap<String, String>();
		for (String item : list) {
			if (item.startsWith("[")) {
				String[] strings = item.split("\\]: \\[");
				if (strings != null && strings.length == 2)
					m.put(strings[0].substring(1), strings[1].substring(0, strings[1].length() - 1));
			} else {
				String[] strings = item.split("=");
				if (strings != null && strings.length == 2)
					m.put(strings[0], strings[1]);
			}
		}
		JSONObject root = new JSONObject();
		root.put("ro.product.model", getV(m, "ro.product.model"));
		root.put("ro.product.brand", getV(m, "ro.product.brand"));
		root.put("ro.product.name", getV(m, "ro.product.name"));
		root.put("ro.product.device", getV(m, "ro.product.device"));
		root.put("ro.product.manufacturer", getV(m, "ro.product.manufacturer"));
		root.put("ro.board.platform", getV(m, "ro.board.platform"));
		root.put("ro.serialno", getV(m, "ro.serialno"));
		root.put("ro.carrier", getV(m, "ro.carrier"));
		root.put("ro.bootloader", getV(m, "ro.bootloader"));
		root.put("ro.hardware", getV(m, "ro.hardware"));
		root.put("ro.chipname", getV(m, "ro.chipname"));

		return root;
	}

	private static String getV(Map<String, String> mapSource, String key) {
		String value = mapSource.get(key);
		if (TextUtils.isEmpty(value))
			value = "";
		return value;
	}

	public static ArrayList<String> runComm(String comm) {
		Process process = null;
		ArrayList<String> resultStr = new ArrayList<String>();
		String line = null;
		BufferedReader brout = null;
		try {
			process = Runtime.getRuntime().exec(comm);
			InputStream outs = process.getInputStream();
			InputStreamReader isrout = new InputStreamReader(outs);
			brout = new BufferedReader(isrout, 8 * 1024);
			while ((line = brout.readLine()) != null) {
				resultStr.add(line);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (brout != null) {
					brout.close();
				}
			} catch (IOException e) {
			}
		}
		return resultStr;
	}

}
