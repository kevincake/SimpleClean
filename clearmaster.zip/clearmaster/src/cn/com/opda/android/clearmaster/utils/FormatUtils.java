package cn.com.opda.android.clearmaster.utils;

import java.text.DecimalFormat;

import android.content.Context;
import cn.com.opda.android.clearmaster.R;

/**
 * 垃圾大小格式化工具类
 * @author 庄宏岩
 *
 */
public class FormatUtils {
	public static String formatBytesInByte2(long size) {
		if (size > 1024 * 1024 * 1024) {
			DecimalFormat formatter = new DecimalFormat("#0.0");
			return formatter.format(size / (float) (1024 * 1024 * 1024)) + "GB";
		} else if (size > 1024 * 1024) {
			DecimalFormat formatter = new DecimalFormat("#0");
			return formatter.format(size / (float) (1024 * 1024)) + "MB";
		} else if (size > 1024) {
			DecimalFormat formatter = new DecimalFormat("#0");
			return formatter.format(size / 1024) + "KB";
		} else {
			DecimalFormat formatter = new DecimalFormat("#0");
			return formatter.format(size) + " B";
		}
	}

	public static String formatBytesInByte(long size) {
		DecimalFormat formatter = new DecimalFormat("#0.0");
		if (size > 1024 * 1024 * 1024) {
			return formatter.format(size / (float) (1024 * 1024 * 1024)) + "GB";
		} else if (size > 1024 * 1024) {
			return formatter.format(size / (float) (1024 * 1024)) + "MB";
		} else if (size > 1024) {
			return formatter.format(size / 1024) + "KB";
		} else {
			return formatter.format(size) + "B";
		}
	}

	public static boolean compareSize(long size1, long size2) {
		String s1 = "";
		String s2 = "";
		DecimalFormat formatter = new DecimalFormat("#0.0");
		if (size1 > 1024 * 1024 * 1024) {
			s1 = formatter.format(size1 / (float) (1024 * 1024 * 1024));
		} else if (size1 > 1024 * 1024) {
			s1 = formatter.format(size1 / (float) (1024 * 1024));
		} else if (size1 > 1024) {
			s1 = formatter.format(size1 / 1024);
		} else {
			s1 = formatter.format(size1);
		}

		if (size2 > 1024 * 1024 * 1024) {
			s2 = formatter.format(size2 / (float) (1024 * 1024 * 1024));
		} else if (size2 > 1024 * 1024) {
			s2 = formatter.format(size2 / (float) (1024 * 1024));
		} else if (size2 > 1024) {
			s2 = formatter.format(size2 / 1024);
		} else {
			s2 = formatter.format(size2);
		}

		int i1,i2;
		i1 = Integer.parseInt(s1.substring(0, s1.length()-2));
		i2 =  Integer.parseInt(s2.substring(0, s2.length()-2));
		
		DLog.i("debug", s1 + "--" + s2);
		DLog.i("debug", i1 + "--" + i2);
		if (i1 == i2) {
			return true;
		}
		return false;
	}

	public static String formatGBBytesInByte(long size) {
		DecimalFormat formatter = new DecimalFormat("#0.00");
		return formatter.format(size / (float) (1024)) + "GB";
	}

	public static float formatFloatRound(float a) {
		return (float) (Math.round(a * 10)) / 10;
	}

	public static String formatDateByLong(Context mContext, long time) {
		int i = (int) (time / (24 * 60 * 60 * 1000));
		return mContext.getString(R.string.startup_format_day, i);
	}
}
