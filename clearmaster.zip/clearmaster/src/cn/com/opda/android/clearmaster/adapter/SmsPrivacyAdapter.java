package cn.com.opda.android.clearmaster.adapter;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.CheckBox;
import android.widget.TextView;
import cn.com.opda.android.clearmaster.R;
import cn.com.opda.android.clearmaster.privacy.SmsBackUpInfo;
import cn.com.opda.android.clearmaster.utils.DateUtils;

public class SmsPrivacyAdapter extends BaseExpandableListAdapter {
	private ArrayList<SmsBackUpInfo> groupArray;// 组列表
	private ArrayList<ArrayList<SmsBackUpInfo>> childArray;// 子列表
	private LayoutInflater mLayoutInflater;
	private Context mContext;
	public SmsPrivacyAdapter(Context mContext, ArrayList<SmsBackUpInfo> groupArray, ArrayList<ArrayList<SmsBackUpInfo>> childArray) {
		this.groupArray = groupArray;
		this.childArray = childArray;
		this.mLayoutInflater = LayoutInflater.from(mContext);
		this.mContext = mContext;
	}

	@Override
	public int getGroupCount() {
		return groupArray.size();
	}

	@Override
	public int getChildrenCount(int groupPosition) {
		return childArray.get(groupPosition).size();
	}

	@Override
	public Object getGroup(int groupPosition) {
		return groupArray.get(groupPosition);
	}

	@Override
	public Object getChild(int groupPosition, int childPosition) {
		return childArray.get(groupPosition).get(childPosition);
	}

	@Override
	public long getGroupId(int groupPosition) {
		return groupPosition;
	}

	@Override
	public long getChildId(int groupPosition, int childPosition) {
		return childPosition;
	}

	@Override
	public boolean hasStableIds() {
		return false;
	}

	public ArrayList<SmsBackUpInfo> getSelectList() {
		ArrayList<SmsBackUpInfo> smsBackUpInfos = new ArrayList<SmsBackUpInfo>();
		for (int i = 0; i < groupArray.size(); i++) {
			for (SmsBackUpInfo child : childArray.get(i)) {
				if (child.isCheck()) {
					smsBackUpInfos.add(child);
				}
			}
		}
		return smsBackUpInfos;
	}

	@Override
	public View getGroupView(final int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {

		final GroupHolder mHolder;
		if (convertView == null) {
			convertView = mLayoutInflater.inflate(R.layout.expandlistview_sms_group_layout, parent, false);
			mHolder = new GroupHolder();
			mHolder.sms_group_name_textview = (TextView) convertView.findViewById(R.id.sms_group_name_textview);
			mHolder.sms_group_count_textview = (TextView) convertView.findViewById(R.id.sms_group_count_textview);
			mHolder.sms_group_checkbox = (CheckBox) convertView.findViewById(R.id.sms_group_checkbox);
			convertView.setTag(mHolder);
		} else {
			mHolder = (GroupHolder) convertView.getTag();
		}
		final SmsBackUpInfo group = groupArray.get(groupPosition);
		mHolder.sms_group_name_textview.setText(group.getName());
		mHolder.sms_group_count_textview.setText(childArray.get(groupPosition).size() + "");
		mHolder.sms_group_checkbox.setChecked(group.isCheck());
		mHolder.sms_group_checkbox.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				group.setCheck(!group.isCheck());
				// TODO 全选反选child
				ArrayList<SmsBackUpInfo> backUpInfos = childArray.get(groupPosition);
				if (group.isCheck()) {
					for (SmsBackUpInfo smsBackUpInfo : backUpInfos) {
						smsBackUpInfo.setCheck(true);
					}
				} else {
					for (SmsBackUpInfo smsBackUpInfo : backUpInfos) {
						smsBackUpInfo.setCheck(false);
					}
				}
				notifyDataSetChanged();
			}
		});
		return convertView;

	}

	@Override
	public View getChildView(final int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
		final Holder mHolder;
		if (convertView == null) {
			convertView = mLayoutInflater.inflate(R.layout.expandlistview_sms_child_layout, parent, false);
			mHolder = new Holder();
			mHolder.sms_child_body_textview = (TextView) convertView.findViewById(R.id.sms_child_body_textview);
			mHolder.sms_child_date_textview = (TextView) convertView.findViewById(R.id.sms_child_date_textview);
			mHolder.sms_child_checkbox = (CheckBox) convertView.findViewById(R.id.sms_child_checkbox);
			convertView.setTag(mHolder);
		} else {
			mHolder = (Holder) convertView.getTag();
		}

		final SmsBackUpInfo child = childArray.get(groupPosition).get(childPosition);
		
		// 判断类型若为自己发送出去的
				if (child.getType() == 2) {
					mHolder.sms_child_body_textview.setText(mContext.getString(R.string.sms_send_me, child.getBody()));
				} else if (child.getType() == 1) {
					mHolder.sms_child_body_textview.setText(child.getName() + "：" + child.getBody());
				} else {
					mHolder.sms_child_body_textview.setText(mContext.getString(R.string.sms_send_me, child.getBody()));
				}
		mHolder.sms_child_date_textview.setText(DateUtils.parseLongtoTime(Long.parseLong(child.getDate())));
		mHolder.sms_child_checkbox.setChecked(child.isCheck());
		mHolder.sms_child_checkbox.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				child.setCheck(!child.isCheck());
			}
		});
		return convertView;

	}

	@Override
	public boolean isChildSelectable(int groupPosition, int childPosition) {
		return true;
	}

	private class Holder {
		private TextView sms_child_body_textview;
		private TextView sms_child_date_textview;
		private CheckBox sms_child_checkbox;
	}

	private class GroupHolder {
		private TextView sms_group_name_textview;
		private TextView sms_group_count_textview;
		private CheckBox sms_group_checkbox;
	}

	public void remove(int groupPosition, int childPosition) {
		childArray.get(groupPosition).remove(childPosition);
		if (childArray.get(groupPosition).size() == 0) {
			groupArray.remove(groupPosition);
			childArray.remove(groupPosition);
		}
		notifyDataSetChanged();
	}

	public void removeSelect() {
		for (int i = 0; i < groupArray.size(); i++) {
			ArrayList<SmsBackUpInfo> childList = childArray.get(i);
			for (int j = 0; j < childList.size(); j++) {
				SmsBackUpInfo smsBackUpInfo = childList.get(j);
				if(smsBackUpInfo.isCheck()){
					childList.remove(j);
					j--;
				}
			}
			if(childList.size()==0){
				groupArray.remove(i);
				childArray.remove(i);
				i--;
			}
		}
		notifyDataSetChanged();
	}

	public int getSmsCount() {
		int count = 0;
		for(ArrayList<SmsBackUpInfo> backUpInfos : childArray){
			count += backUpInfos.size();
		}
		return count;
	}

	public void checkAll(boolean isChecked) {
		for(int i = 0;i<getGroupCount();i++){
			groupArray.get(i).setCheck(isChecked);
			ArrayList<SmsBackUpInfo> backUpInfos = childArray.get(i);
			for(SmsBackUpInfo backUpInfo :backUpInfos){
				backUpInfo.setCheck(isChecked);
			}
		}
		notifyDataSetChanged();
	}
}
