package cn.com.opda.android.clearmaster;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import cn.com.opda.android.clearmaster.adapter.Adapter4BigFileItem;
import cn.com.opda.android.clearmaster.model.BigFileItem;
import cn.com.opda.android.clearmaster.utils.BannerUtils;
import cn.com.opda.android.clearmaster.utils.FileUtils;

import com.umeng.analytics.MobclickAgent;

public class BigFileDetailActivity extends BaseActivity {
	private Context mContext;
	private ListView bigfile_listview;
	private int position;
	private Adapter4BigFileItem adapter4BigFileItem;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mContext = BigFileDetailActivity.this;
		setContentView(R.layout.activity_bigfile_detail);
		BannerUtils.setMainTitle(this, getIntent().getStringExtra("title"));
		BannerUtils.initBackButton(this);
		position = getIntent().getIntExtra("position", 0);
		initViewAndEvent();
		ArrayList<BigFileItem> bigFileItems = (ArrayList<BigFileItem>) getIntent().getSerializableExtra("list");
		Collections.sort(bigFileItems, new SizeComparator());
		adapter4BigFileItem = new Adapter4BigFileItem(mContext, bigFileItems);
		bigfile_listview.setAdapter(adapter4BigFileItem);
		bigfile_listview.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				BigFileItem bigFileItem = (BigFileItem) parent.getItemAtPosition(position);
				bigFileItem.setChecked(!bigFileItem.isChecked());
				adapter4BigFileItem.notifyDataSetChanged();
			}
		});

		Button clear_button = (Button) findViewById(R.id.clear_button);
		clear_button.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				ArrayList<BigFileItem> bigFileItems = adapter4BigFileItem.getSelectList();

				if (bigFileItems.size() > 0) {
					for (BigFileItem bigFileItem : bigFileItems) {
						FileUtils.deleteFileByPath(bigFileItem.getPath());
						adapter4BigFileItem.remove(bigFileItem);
					}
					Toast.makeText(mContext, "大文件清理完成", Toast.LENGTH_SHORT).show();
					finish();
					overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
				} else {
					Toast.makeText(mContext, "请至少勾选一项进行清理", Toast.LENGTH_SHORT).show();
				}

			}
		});

		Intent intent = new Intent(mContext, DepthClearActivity.class);
		Bundle bundle = new Bundle();
		bundle.putSerializable("list", adapter4BigFileItem.getList());
		bundle.putInt("position", position);
		intent.putExtras(bundle);
		setResult(101, intent);
	}

	class SizeComparator implements Comparator<BigFileItem> {

		@Override
		public int compare(BigFileItem o1, BigFileItem o2) {
			long num1 = o1.getSize();
			long num2 = o2.getSize();
			if (num1 < num2) {
				return 1;
			} else if (num1 == num2) {
				return 0;
			} else if (num1 > num2) {
				return -1;
			}
			return 0;
		}
	}
	private void initViewAndEvent() {
		bigfile_listview = (ListView) findViewById(R.id.bigfile_listview);
	}

	@Override
	protected void onResume() {
		MobclickAgent.onResume(this);
		super.onResume();
	}

	@Override
	protected void onPause() {
		MobclickAgent.onPause(this);
		super.onPause();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
	}

}
