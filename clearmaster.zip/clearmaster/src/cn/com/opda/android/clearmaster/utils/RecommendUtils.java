package cn.com.opda.android.clearmaster.utils;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import cn.com.opda.android.clearmaster.R;
import cn.com.opda.android.clearmaster.custom.CustomDialog2;

import com.dashi.smartstore.DashiSmartStore_ViewPagerMainActivity;

public class RecommendUtils {
	public static void recommentRootMaster(final Context mContext) {
		final CustomDialog2 mCustomDialog = new CustomDialog2(mContext);
		mCustomDialog.setDialogIcon(R.drawable.dialog_icon_tips);
		mCustomDialog.setMessage(R.string.recommend_message);
		mCustomDialog.setButton1(R.string.dialog_button_cancel, null);
		mCustomDialog.setButton2(R.string.recommend_download, new OnClickListener() {

			@Override
			public void onClick(View v) {
				mCustomDialog.dismiss();
				if(AppManagerUtils.appIsInstall(mContext, "com.zhiqupk.root")){
					mContext.startActivity(mContext.getPackageManager().getLaunchIntentForPackage("com.zhiqupk.root"));
				}else{
					AppDownload appDownload = new AppDownload(mContext);
					appDownload.setAppName("一键Root大师");
					appDownload.setPackageName("com.zhiqupk.root");
					appDownload.createNotify();
					appDownload.startDownloadApp();
				}
			}
		});
		mCustomDialog.show();
	}

	public static void recommentRootMaster(final Context mContext, String message) {
		final CustomDialog2 mCustomDialog = new CustomDialog2(mContext);
		mCustomDialog.setDialogIcon(R.drawable.dialog_icon_tips);
		mCustomDialog.setMessage(message);
		mCustomDialog.setButton1(R.string.dialog_button_cancel, null);
		mCustomDialog.setButton2(R.string.recommend_download, new OnClickListener() {

			@Override
			public void onClick(View v) {
				mCustomDialog.dismiss();
				if(AppManagerUtils.appIsInstall(mContext, "com.zhiqupk.root")){
					mContext.startActivity(mContext.getPackageManager().getLaunchIntentForPackage("com.zhiqupk.root"));
				}else{
					AppDownload appDownload = new AppDownload(mContext);
					appDownload.setAppName("一键Root大师");
					appDownload.setPackageName("com.zhiqupk.root");
					appDownload.createNotify();
					appDownload.startDownloadApp();
				}
			}
		});
		mCustomDialog.show();
	}

	public static void showTuijianDialog(final Context mContext, String message) {
		final SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(mContext);
		boolean checked = sp.getBoolean("tuijian_checked", false);
		if (!checked) {
			final CustomDialog2 customDialog = new CustomDialog2(mContext);
			customDialog.setDialogIcon(R.drawable.dialog_icon_tips);
			customDialog.setMessage(message);
			CheckBox checkBox = new CheckBox(mContext);
			checkBox.setText(R.string.next_not_tips);
			checkBox.setTextColor(mContext.getResources().getColor(R.color.secondary_textcolor));
			checkBox.setButtonDrawable(R.drawable.checkbox_circle_background);
			checkBox.setOnCheckedChangeListener(new OnCheckedChangeListener() {

				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					sp.edit().putBoolean("tuijian_checked", isChecked).commit();
				}
			});
			customDialog.setView(checkBox);
			customDialog.setButton2("去看看", new OnClickListener() {

				@Override
				public void onClick(View v) {
					customDialog.dismiss();
					mContext.startActivity(new Intent(mContext, DashiSmartStore_ViewPagerMainActivity.class));
				}
			});
			customDialog.setButton1("下次吧", null);
			customDialog.show();
		}
	}

}
