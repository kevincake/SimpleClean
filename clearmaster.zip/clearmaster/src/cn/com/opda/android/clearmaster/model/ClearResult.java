package cn.com.opda.android.clearmaster.model;

public class ClearResult {
	private int count;
	private long memory;
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public long getMemory() {
		return memory;
	}
	public void setMemory(long memory) {
		this.memory = memory;
	}
}
