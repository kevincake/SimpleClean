package cn.com.opda.android.clearmaster.model;

public class ReceiverInfo {
	private String className = "";
	private boolean enable = true;
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public boolean isEnable() {
		return enable;
	}
	public void setEnable(boolean enable) {
		this.enable = enable;
	}
	
}
