package com.chunjie.hongbao;


import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.widget.Button;
import cn.com.opda.android.clearmaster.R;

public class FirstDialog extends Dialog {

	protected FirstDialog(Context context, boolean cancelable,
			OnCancelListener cancelListener) {
		super(context, cancelable, cancelListener);
		// TODO Auto-generated constructor stub
	}
	public FirstDialog(Context context, int theme){
		super(context, theme);
	}



	public  FirstDialog(Context context) {
		super(context);
	}
	android.view.View.OnClickListener mls;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		setContentView(R.layout.dialog_firsterhongbao);
		Button	chaihongbao_btn = (Button)findViewById(R.id.chaihongbao_btn);
		chaihongbao_btn.setOnClickListener(mls);
		super.onCreate(savedInstanceState);
	}
	public void setBtnOnclickListener(android.view.View.OnClickListener ls) {
		mls = ls;
	}

}
