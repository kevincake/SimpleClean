package cn.com.opda.android.clearmaster.utils.listsort;

import java.util.Comparator;

import cn.com.opda.android.clearmaster.privacy.VideoInfo;

public class TimeComparatorForPrivacyVideo implements Comparator<VideoInfo>{

	@Override
	public int compare(VideoInfo o1, VideoInfo o2) {
		long num1 = o1.getDateAdded();
		long num2 = o2.getDateAdded();
		if (num1 < num2) {
			return 1;
		} else if (num1 == num2) {
			return 0;
		} else if (num1 > num2) {
			return -1;
		}
		return 0;
	
	}

}
