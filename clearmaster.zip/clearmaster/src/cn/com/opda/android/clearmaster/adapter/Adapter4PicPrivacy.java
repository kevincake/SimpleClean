package cn.com.opda.android.clearmaster.adapter;

import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.ThumbnailUtils;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import cn.com.opda.android.clearmaster.PhotoPagerActivity;
import cn.com.opda.android.clearmaster.R;
import cn.com.opda.android.clearmaster.privacy.PicInfo;

public class Adapter4PicPrivacy extends BaseAdapter {

	private ArrayList<PicInfo> mPicInfoList = new ArrayList<PicInfo>();
	private LayoutInflater mInflater;
	private Context mContext;
	private Drawable defaultIcon;
	private boolean checkFlag = false;
	
	
	public Adapter4PicPrivacy(Context mContext, ArrayList<PicInfo> mPicInfoList) {
		super();
		this.mPicInfoList = mPicInfoList;
		this.mContext = mContext;
		defaultIcon = mContext.getResources().getDrawable(R.drawable.privacy_wait_pic);
		mInflater = LayoutInflater.from(mContext);
	}

	@Override
	public int getCount() {
		return mPicInfoList.size();
	}

	@Override
	public Object getItem(int position) {
		return mPicInfoList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@SuppressLint("NewApi")
	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		final ViewHolder mHolder;
		if (convertView == null) {
			mHolder = new ViewHolder();
			convertView = mInflater.inflate(R.layout.listview_privacy_pic_item, null);
			mHolder.privacy_pic_icon = (ImageView) convertView.findViewById(R.id.privacy_pic_icon);
			mHolder.privacy_pic_checked = (CheckBox) convertView.findViewById(R.id.privacy_pic_checked);
			convertView.setTag(mHolder);
		} else {
			mHolder = (ViewHolder) convertView.getTag();
			if (mHolder.imageLoader != null) {
				mHolder.imageLoader.cancel(true);
			}
		}
		final PicInfo mPicInfo = mPicInfoList.get(position);
		
		mHolder.privacy_pic_checked.setChecked(mPicInfo.isChecked());
		
		if (checkFlag) {
			mHolder.privacy_pic_checked.setVisibility(View.VISIBLE);
			mHolder.privacy_pic_checked.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					mPicInfo.setChecked(mHolder.privacy_pic_checked.isChecked());
					notifyDataSetChanged();
				}
			});
			
			convertView.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					if (mHolder.privacy_pic_checked.isChecked()) {
						mHolder.privacy_pic_checked.setChecked(false);
					} else {
						mHolder.privacy_pic_checked.setChecked(true);
					}
					mPicInfo.setChecked(mHolder.privacy_pic_checked.isChecked());
					notifyDataSetChanged();
				}
			});
		} else {
			mHolder.privacy_pic_checked.setVisibility(View.GONE);
			convertView.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					Intent intent = new Intent(mContext, PhotoPagerActivity.class);
					Bundle bundle = new Bundle();
					bundle.putParcelableArrayList("privacy_pic", mPicInfoList);
					bundle.putInt("current", position);
					intent.putExtras(bundle);
					mContext.startActivity(intent);
				}
			});
			for (int i = 0; i < mPicInfoList.size(); i++) {
				PicInfo picinfo = mPicInfoList.get(i);
				picinfo.setChecked(false);
			}
		}
		
		
		if (mPicInfo.getBitmap() == null) {
			mHolder.privacy_pic_icon.setBackgroundDrawable(defaultIcon);
			mHolder.imageLoader = new AsyncTask<ViewHolder, Void, Bitmap>() {
				
				private ViewHolder hoder;
				@Override
				protected Bitmap doInBackground(ViewHolder... params) {
					hoder = params[0];
					Bitmap bitmap = null;  
			        BitmapFactory.Options options = new BitmapFactory.Options();  
			        options.inJustDecodeBounds = true;  
			        // 获取这个图片的宽和高，注意此处的bitmap为null  
			        bitmap = BitmapFactory.decodeFile(mPicInfo.getNewPath(), options);  
			        options.inJustDecodeBounds = false; // 设为 false  
			        // 计算缩放比  
			        int h = options.outHeight;  
			        int w = options.outWidth;  
			        int beWidth = w / 200;  
			        int beHeight = h / 200;  
			        int be = 1;  
			        if (beWidth < beHeight) {  
			            be = beWidth;  
			        } else {  
			            be = beHeight;  
			        }  
			        if (be <= 0) {  
			            be = 1;  
			        }  
			        options.inSampleSize = be;  
			        // 重新读入图片，读取缩放后的bitmap，注意这次要把options.inJustDecodeBounds 设为 false  
			        bitmap = BitmapFactory.decodeFile(mPicInfo.getNewPath(), options);  
			        // 利用ThumbnailUtils来创建缩略图，这里要指定要缩放哪个Bitmap对象  
			        bitmap = ThumbnailUtils.extractThumbnail(bitmap, 150, 150,  
			                ThumbnailUtils.OPTIONS_RECYCLE_INPUT);  
					return bitmap;
				}

				@Override
				protected void onPostExecute(Bitmap result) {
					mPicInfo.setBitmap(result);
					hoder.privacy_pic_icon.setBackgroundDrawable(new BitmapDrawable(result));
				}
			}.execute(mHolder);
		} else {
			mHolder.privacy_pic_icon.setBackgroundDrawable(new BitmapDrawable(mPicInfo.getBitmap()));
		}
		
		if (mPicInfo.isChecked()) {
			mHolder.privacy_pic_checked.setChecked(true);
		} else {
			mHolder.privacy_pic_checked.setChecked(false);
		}
		
		return convertView;
	}
	
	public ArrayList<PicInfo> getSelectList() {
		ArrayList<PicInfo> selectPicInfos = new ArrayList<PicInfo>();
		for (int i = 0; i < mPicInfoList.size(); i++) {
			PicInfo picinfo = mPicInfoList.get(i);
			if (picinfo.isChecked()) {
				selectPicInfos.add(picinfo);
			}
		}
		return selectPicInfos;
	}
	
	public void selectAll(){
		for (int i = 0; i < mPicInfoList.size(); i++) {
			PicInfo picinfo = mPicInfoList.get(i);
			picinfo.setChecked(true);
		}
		notifyDataSetChanged();
	}
	
	public void selectNull(){
		for (int i = 0; i < mPicInfoList.size(); i++) {
			PicInfo picinfo = mPicInfoList.get(i);
			picinfo.setChecked(false);
		}
		notifyDataSetChanged();
	}
	
	public void removePic(PicInfo info){
		mPicInfoList.remove(info);
		notifyDataSetChanged();
	}
	public void removePics(ArrayList<PicInfo> picInfos){
		for (int i = 0; i < picInfos.size(); i++) {
			mPicInfoList.remove(picInfos.get(i));
		}
		notifyDataSetChanged();
	}
	
	public void changeFlag(){
		checkFlag = !checkFlag;
		notifyDataSetChanged();
	}
	
	class ViewHolder {
		ImageView privacy_pic_icon;
		CheckBox privacy_pic_checked;
		
		AsyncTask<ViewHolder, Void, Bitmap> imageLoader;
	}
	
}
