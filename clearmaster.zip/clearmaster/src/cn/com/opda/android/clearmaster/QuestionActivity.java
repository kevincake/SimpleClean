package cn.com.opda.android.clearmaster;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import cn.com.opda.android.clearmaster.utils.BannerUtils;

import com.umeng.analytics.MobclickAgent;

/**
 * 
 * 问题列表
 * @author 庄宏岩
 *
 */
public class QuestionActivity extends BaseActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_question_layout);
		BannerUtils.initBackButton(this);
		BannerUtils.setMainTitle(this, R.string.menu_question);
		
		initViewAndEvent();
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		MobclickAgent.onResume(this);
	}



	@Override
	protected void onPause() {
		super.onPause();
		MobclickAgent.onPause(this);
	}



	private void initViewAndEvent() {
		WebView ad_detail_webview = (WebView) findViewById(R.id.question_webview);
		WebSettings webSettings = ad_detail_webview.getSettings();
		webSettings.setJavaScriptEnabled(true);
		ad_detail_webview.loadUrl("file:///android_asset/question.html");

	}
	
}
