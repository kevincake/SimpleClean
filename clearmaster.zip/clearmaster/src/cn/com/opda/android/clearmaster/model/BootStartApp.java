package cn.com.opda.android.clearmaster.model;

import java.util.ArrayList;

import android.graphics.drawable.Drawable;

public class BootStartApp {
	private String lableName = "";
	private String packageName;
	private Drawable icon;
	private boolean buttonstate;
	public static final int CONTENT = 0;
	public static final int ENABLETITLE = 1;
	public static final int DISABLETITLE = 2;
	private ArrayList<ReceiverInfo> receivers;
	private boolean isBootStart;
	private boolean isBackgroundStart;
	private int type = 0;
	
	
	public ArrayList<ReceiverInfo> getReceivers() {
		return receivers;
	}
	public void setReceivers(ArrayList<ReceiverInfo> receivers) {
		this.receivers = receivers;
	}
	public boolean isBootStart() {
		return isBootStart;
	}
	public void setBootStart(boolean isBootStart) {
		this.isBootStart = isBootStart;
	}
	public boolean isBackgroundStart() {
		return isBackgroundStart;
	}
	public void setBackgroundStart(boolean isBackgroundStart) {
		this.isBackgroundStart = isBackgroundStart;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public boolean isButtonstate() {
		return buttonstate;
	}
	public void setButtonstate(boolean buttonstate) {
		this.buttonstate = buttonstate;
	}
	
	public String getPackageName() {
		return packageName;
	}
	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}
	public Drawable getIcon() {
		return icon;
	}
	public void setIcon(Drawable icon) {
		this.icon = icon;
	}
	public String getLableName() {
		return lableName;
	}
	public void setLableName(String lableName) {
		this.lableName = lableName;
	}
}
