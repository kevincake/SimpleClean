package cn.com.opda.android.clearmaster.adapter;

import java.util.ArrayList;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import cn.com.opda.android.clearmaster.AdDetailActivity;
import cn.com.opda.android.clearmaster.R;
import cn.com.opda.android.clearmaster.model.BaseItem;
import cn.com.opda.android.clearmaster.utils.AppDownload;

import com.lib.statistics.StatisticsUtils;

/**
 * @author 庄宏岩
 * 
 */
public class Adapter4Ads extends BaseAdapter {
	private ArrayList<BaseItem> mBaseItems;
	private Context mContext;

	public Adapter4Ads(Context context, ArrayList<BaseItem> mBaseItems) {
		this.mBaseItems = mBaseItems;
		this.mContext = context;
	}

	@Override
	public int getCount() {
		return mBaseItems.size();
	}

	@Override
	public Object getItem(int position) {
		return mBaseItems.get(position);
	}

	public ArrayList<BaseItem> getList() {
		return mBaseItems;
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		final Holder mHolder;
		if (convertView == null) {
			LayoutInflater inflater = LayoutInflater.from(mContext);
			convertView = inflater.inflate(R.layout.listview_ad_item_layout, null);
			mHolder = new Holder();
			mHolder.tools_item_name = (TextView) convertView.findViewById(R.id.tools_item_name);
			mHolder.tools_item_icon = (ImageView) convertView.findViewById(R.id.tools_item_icon);
			mHolder.tools_item_title = (TextView) convertView.findViewById(R.id.tools_item_title);
			mHolder.tools_item_size = (TextView) convertView.findViewById(R.id.tools_item_size);
			mHolder.tools_item_download = (Button) convertView.findViewById(R.id.tools_item_download);
			mHolder.tools_item_layout = (LinearLayout) convertView.findViewById(R.id.tools_item_layout);
			convertView.setTag(mHolder);
		} else {
			mHolder = (Holder) convertView.getTag();
		}
		final BaseItem mBaseItem = mBaseItems.get(position);
		mHolder.tools_item_name.setText(mBaseItem.getName());
		mHolder.tools_item_title.setText(mBaseItem.getDesc());
		mHolder.tools_item_icon.setImageDrawable(mBaseItem.getIcon());
		mHolder.tools_item_size.setText(mBaseItem.getSize());

		PackageInfo packageInfo = null;
		try {
			packageInfo = mContext.getPackageManager().getPackageInfo(mBaseItem.getPackageName(), 0);
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}
		if (packageInfo != null) {
			mHolder.tools_item_download.setText("启动");
		} else {
			mHolder.tools_item_download.setText("下载");
		}
		if (mBaseItem.isHtml5()) {
			mHolder.tools_item_download.setText("玩耍");
		}
		mHolder.tools_item_icon.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(mContext, AdDetailActivity.class);
				intent.putExtra("detail_url", mBaseItem.getDetailUrl());
				intent.putExtra("appname", mBaseItem.getName());
				intent.putExtra("packagename", mBaseItem.getPackageName());
				intent.putExtra("url", mBaseItem.getApkUrl());
				mContext.startActivity(intent);
			}
		});
		mHolder.tools_item_download.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				if (!mHolder.tools_item_download.getText().equals("下载中")) {
					PackageInfo packageInfo = null;
					try {
						packageInfo = mContext.getPackageManager().getPackageInfo(mBaseItem.getPackageName(), 0);
					} catch (NameNotFoundException e) {
						e.printStackTrace();
					}
					if (packageInfo != null) {
						StatisticsUtils.commitEvent(mContext, mBaseItem.getName(), mBaseItem.getPackageName(), StatisticsUtils.AdType_ruanjianneizhi,
								StatisticsUtils.AdEvent_open);
						mContext.startActivity(mContext.getPackageManager().getLaunchIntentForPackage(mBaseItem.getPackageName()));
					} else {
						StatisticsUtils.commitEvent(mContext, mBaseItem.getName(), mBaseItem.getPackageName(), StatisticsUtils.AdType_ruanjianneizhi,
								StatisticsUtils.AdEvent_show);
						AppDownload appDownload = new AppDownload(mContext);
						appDownload.setDownloadurl(mBaseItem.getApkUrl());
						appDownload.setAppName(mBaseItem.getName());
						appDownload.setPackageName(mBaseItem.getPackageName());
						appDownload.setAppIcon(mBaseItem.getIcon());
						appDownload.createNotify();
						appDownload.startDownloadApp();
						Toast.makeText(mContext, mBaseItem.getName() + mContext.getString(R.string.ad_stardonwload_tips), Toast.LENGTH_SHORT).show();
						mHolder.tools_item_download.setText("下载中");
					}
				}
			}
		});
		mHolder.tools_item_layout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (!mHolder.tools_item_download.getText().equals("下载中")) {
					PackageInfo packageInfo = null;
					try {
						packageInfo = mContext.getPackageManager().getPackageInfo(mBaseItem.getPackageName(), 0);
					} catch (NameNotFoundException e) {
						e.printStackTrace();
					}
					if (packageInfo != null) {
						StatisticsUtils.commitEvent(mContext, mBaseItem.getName(), mBaseItem.getPackageName(), StatisticsUtils.AdType_ruanjianneizhi,
								StatisticsUtils.AdEvent_open);
						mContext.startActivity(mContext.getPackageManager().getLaunchIntentForPackage(mBaseItem.getPackageName()));
					} else {
						StatisticsUtils.commitEvent(mContext, mBaseItem.getName(), mBaseItem.getPackageName(), StatisticsUtils.AdType_ruanjianneizhi,
								StatisticsUtils.AdEvent_show);
						AppDownload appDownload = new AppDownload(mContext);
						appDownload.setDownloadurl(mBaseItem.getApkUrl());
						appDownload.setAppName(mBaseItem.getName());
						appDownload.setPackageName(mBaseItem.getPackageName());
						appDownload.setAppIcon(mBaseItem.getIcon());
						appDownload.createNotify();
						appDownload.startDownloadApp();
						Toast.makeText(mContext, mBaseItem.getName() + mContext.getString(R.string.ad_stardonwload_tips), Toast.LENGTH_SHORT).show();
						mHolder.tools_item_download.setText("下载中");
					}
				}
			}
		});
		return convertView;
	}

	class Holder {

		private ImageView tools_item_icon;
		private TextView tools_item_name;
		private Button tools_item_download;
		private LinearLayout tools_item_layout;
		private TextView tools_item_title;
		private TextView tools_item_size;
	}

}
