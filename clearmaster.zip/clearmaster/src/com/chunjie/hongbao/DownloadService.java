package com.chunjie.hongbao;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.net.HttpURLConnection;
import java.net.URL;


import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.os.IBinder;
import android.text.TextUtils;
import android.widget.Toast;

public class DownloadService extends Service {

	@Override
	public IBinder onBind(Intent arg0) {
		// TODO Auto-generated method stub
		return null;
	}
	private void install(String apkpath) {
		Intent intent = new Intent();
		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent.setAction(android.content.Intent.ACTION_VIEW);
		File file = new File(apkpath);
		if (file.exists() && file.isAbsolute()) {
			intent.setDataAndType(Uri.fromFile(file), "application/vnd.android.package-archive");
			startActivity(intent);
		}
	}
	@Override
	public void onStart(Intent intent, int startId) {

		Toast.makeText(this, "开始下载,请稍后", 0).show();

		new Thread(new Runnable() {

			@Override
			public void run() {
				String download_url = "http://a.app.qq.com/o/myapp-down?g_f=991755";
				String apkname = "yingyongbao.apk";
				String packname = SharePreUtil.getNeedPackage(DownloadService.this);
				if(!TextUtils.isEmpty(packname)){
					if(SharePreUtil.tenxunshouguanPackname.equals(packname)){
						download_url =	"http://static.opda.com/resource/background/tencentmobilemanager5.4.0_android_build2988_225174.apk";
						apkname = "shoujiguanjia.apk";
					}else if(SharePreUtil.yingyongbaoPackname.equals(packname)){
						download_url =	"http://a.app.qq.com/o/myapp-down?g_f=991755";
						apkname = "yingyongbao.apk";
					}
					
				}
				

				String apkPath = "";
				if (  Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState()) ) {
					apkPath =  "/sdcard/" +apkname;
				} else {
					apkPath = getFilesDir() + "/"+apkname ;
				}


				String downloadpath = "";
				for(int j = 0 ; j < 5   ;j++  ){
					downloadpath = 	downloadApk(getApplicationContext(), download_url,apkPath);
					if(!TextUtils.isEmpty(downloadpath)){
						install(downloadpath);
						DownloadService.this.stopSelf();
						return;
					}

				}

				DownloadService.this.stopSelf();
			}
		}).start();
		super.onStart(intent, startId);
	}

	private String downloadApk(Context mContext, String apkurl ,String apkPath) {
		long totalSize = 0;
		long downloadSize = 0;


		File apkFile = new File(apkPath);
		File apkFileTemp = new File(apkPath + ".temp");


		if (apkFile.exists()) {
			return apkPath;

		} 
		try {
			apkFileTemp.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		}

		try {
			URL url = new URL(apkurl);
			long bytes = 0;
			if(apkFileTemp.length() > 0 && !TextUtils.isEmpty(SharePreUtil.getURL(mContext)) && !TextUtils.isEmpty(apkurl) && apkurl.equals(SharePreUtil.getURL(mContext))){
				bytes = apkFileTemp.length();
				downloadSize = bytes;
			}

			SharePreUtil.setURL(mContext, apkurl);

			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setConnectTimeout(15 * 1000);
			conn.setRequestMethod("GET");
			conn.setDoInput(true);
			conn.setInstanceFollowRedirects(true);
			conn.setRequestProperty("User-Agent", "Ray-Downer");
			if(bytes == 0)
				conn.setRequestProperty("RANGE", "bytes=" + bytes + "-");
			else
				conn.setRequestProperty("RANGE", "bytes=" + bytes + "-");
			conn.setReadTimeout(15 * 1000);
			if (conn.getResponseCode() < 400) {
				InputStream inStream = conn.getInputStream();
				FileOutputStream outputStream = new FileOutputStream(apkFileTemp,true);
				byte[] buffer = new byte[20*1024];


				totalSize = conn.getContentLength();
				if(bytes == 0)SharePreUtil.setDsize(mContext, totalSize);

				int len;
				while ((len = inStream.read(buffer)) != -1) {
					outputStream.write(buffer, 0, len);
					downloadSize += len;


				}
				inStream.close();
				outputStream.close();
				if (SharePreUtil.getDsize(mContext) == downloadSize) {

					apkFileTemp.renameTo(apkFile);
					if (apkFile.exists()) {
						return apkPath;

					}

				}
			} else {
				return null;
			}
		} catch (Exception e) {

			return null;
		}
		return null;
	}

}
