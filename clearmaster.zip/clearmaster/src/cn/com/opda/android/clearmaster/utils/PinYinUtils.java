package cn.com.opda.android.clearmaster.utils;

import net.sourceforge.pinyin4j.PinyinHelper;
import net.sourceforge.pinyin4j.format.HanyuPinyinCaseType;
import net.sourceforge.pinyin4j.format.HanyuPinyinOutputFormat;
import net.sourceforge.pinyin4j.format.HanyuPinyinToneType;
import net.sourceforge.pinyin4j.format.exception.BadHanyuPinyinOutputFormatCombination;
import android.text.TextUtils;

public class PinYinUtils {
	public static String CnToSpell(String str) {
		String result = "";
		try {
			if(TextUtils.isEmpty(str))
				return result;
			char[] srcChar = str.toCharArray();
			HanyuPinyinOutputFormat defaultFormat = new HanyuPinyinOutputFormat();
			// 输出设置，大小写，音标方式等
			defaultFormat.setCaseType(HanyuPinyinCaseType.UPPERCASE);
			defaultFormat.setToneType(HanyuPinyinToneType.WITHOUT_TONE);
			for (int i = 0; i < srcChar.length; i++) {
				// 判断是否为汉字字符
				if (Character.toString(srcChar[i]).matches("[\\u4E00-\\u9FA5]+")) {
					String[] srcArry = PinyinHelper.toHanyuPinyinStringArray(srcChar[i], defaultFormat);
					result += srcArry[0];
				} else
					result += Character.toString(srcChar[i]);
			}

			return result;
		} catch (BadHanyuPinyinOutputFormatCombination e) {
			e.printStackTrace();
		}
		return result;
	}
}
