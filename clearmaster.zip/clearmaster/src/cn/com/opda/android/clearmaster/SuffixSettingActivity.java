package cn.com.opda.android.clearmaster;

import java.util.ArrayList;

import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import cn.com.opda.android.clearmaster.adapter.SuffixAdapter;
import cn.com.opda.android.clearmaster.model.SuffixInfo;
import cn.com.opda.android.clearmaster.utils.BannerUtils;

import com.umeng.analytics.MobclickAgent;

public class SuffixSettingActivity extends BaseActivity {
	private Context mContext;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mContext = SuffixSettingActivity.this;
		setContentView(R.layout.activity_suffix_settings);
		BannerUtils.initBackButton(this);
		BannerUtils.setTitle(this, "大文件类型过滤");
		ArrayList<SuffixInfo> suffixInfos = getSuffixList();
		final SuffixAdapter suffixAdapter = new SuffixAdapter(mContext, suffixInfos);
		ListView suffix_listview = (ListView) findViewById(R.id.suffix_listview);
		suffix_listview.setAdapter(suffixAdapter);
		suffix_listview.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				SuffixInfo suffixInfo = (SuffixInfo) parent.getItemAtPosition(position);
				suffixInfo.setChecked(!suffixInfo.isChecked());
				suffixAdapter.notifyDataSetChanged();
				setSuffixList(suffixAdapter.getList());
			}

		});

	}

	private void setSuffixList(ArrayList<SuffixInfo> suffixInfos) {
		JSONObject jsonObject = new JSONObject();
		String suffix_type = "";
		for (SuffixInfo suffixInfo : suffixInfos) {
			if (suffixInfo.isChecked()) {
				suffix_type += suffixInfo.getSuffixType();

			}
		}
		try {
			jsonObject.put("suffix_type", suffix_type);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(mContext);
		sp.edit().putString("suffix_json", jsonObject.toString()).commit();
	}

	private ArrayList<SuffixInfo> getSuffixList() {
		SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(mContext);
		String suffix_json = sp.getString("suffix_json", null);
		JSONObject jsonObject = null;
		if (TextUtils.isEmpty(suffix_json)) {
			jsonObject = new JSONObject();
		} else {
			try {
				jsonObject = new JSONObject(suffix_json);
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}

		ArrayList<SuffixInfo> suffixInfos = new ArrayList<SuffixInfo>();

		SuffixInfo suffixInfo = new SuffixInfo();
		suffixInfo.setSuffixName("音频");
		suffixInfo.setSuffixType(".mp3.wma.ogg.aac.wav.flac.ape");
		suffixInfo.setChecked(jsonObject.optString("suffix_type").contains(suffixInfo.getSuffixType()));
		suffixInfos.add(suffixInfo);

		suffixInfo = new SuffixInfo();
		suffixInfo.setSuffixName("视频");
		suffixInfo.setSuffixType(".flv.avi.wmv.vob.mp4.mkv.mov");
		suffixInfo.setChecked(jsonObject.optString("suffix_type").contains(suffixInfo.getSuffixType()));
		suffixInfos.add(suffixInfo);

		suffixInfo = new SuffixInfo();
		suffixInfo.setSuffixName("压缩包");
		suffixInfo.setSuffixType(".rar.zip.7z.ios.cbr.tar.ace");
		suffixInfo.setChecked(jsonObject.optString("suffix_type").contains(suffixInfo.getSuffixType()));
		suffixInfos.add(suffixInfo);

		suffixInfo = new SuffixInfo();
		suffixInfo.setSuffixName("文档");
		suffixInfo.setSuffixType(".doc.xls.ppt.docx.xlsx.pptx.pdf");
		suffixInfo.setChecked(jsonObject.optString("suffix_type").contains(suffixInfo.getSuffixType()));
		suffixInfos.add(suffixInfo);
		
		suffixInfo = new SuffixInfo();
		suffixInfo.setSuffixName("字体");
		suffixInfo.setSuffixType(".ttf.otf");
		suffixInfo.setChecked(jsonObject.optString("suffix_type").contains(suffixInfo.getSuffixType()));
		suffixInfos.add(suffixInfo);

		suffixInfo = new SuffixInfo();
		suffixInfo.setSuffixName("安装包");
		suffixInfo.setSuffixType(".apk");
		suffixInfo.setChecked(jsonObject.optString("suffix_type").contains(suffixInfo.getSuffixType()));
		suffixInfos.add(suffixInfo);

		suffixInfo = new SuffixInfo();
		suffixInfo.setSuffixName("游戏数据");
		suffixInfo.setSuffixType(".obb");
		suffixInfo.setChecked(jsonObject.optString("suffix_type").contains(suffixInfo.getSuffixType()));
		suffixInfos.add(suffixInfo);

		return suffixInfos;
	}

	@Override
	protected void onResume() {
		MobclickAgent.onResume(this);
		super.onResume();
	}

	@Override
	protected void onPause() {
		MobclickAgent.onPause(this);
		super.onPause();
	}

}
