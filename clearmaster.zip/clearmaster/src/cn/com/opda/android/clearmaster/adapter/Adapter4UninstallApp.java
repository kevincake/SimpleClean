package cn.com.opda.android.clearmaster.adapter;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import cn.com.opda.android.clearmaster.R;
import cn.com.opda.android.clearmaster.custom.CustomDialog2;
import cn.com.opda.android.clearmaster.impl.SelectListener;
import cn.com.opda.android.clearmaster.model.AppItem;
import cn.com.opda.android.clearmaster.utils.AppDownload;
import cn.com.opda.android.clearmaster.utils.AppManagerUtils;
import cn.com.opda.android.clearmaster.utils.FormatUtils;
import cn.com.opda.android.clearmaster.utils.Terminal;

public class Adapter4UninstallApp extends BaseAdapter {
	private Context mContext;
	private SelectListener mSelectListener;
	private ArrayList<AppItem> mAppItems;// 子列表
	private LayoutInflater mLayoutInflater;
	private Drawable defaultIcon;
	private PackageManager pm;
	private Handler mHandler;

	public Adapter4UninstallApp(Context context, ArrayList<AppItem> mAppItems, Handler mHandler) {
		this.mAppItems = mAppItems;
		this.mContext = context;
		defaultIcon = mContext.getResources().getDrawable(android.R.drawable.sym_def_app_icon);
		mLayoutInflater = LayoutInflater.from(mContext);
		pm = mContext.getPackageManager();
		this.mHandler = mHandler;
	}

	public void setSelectListener(SelectListener mSelectListener) {
		this.mSelectListener = mSelectListener;
	}

	public ArrayList<AppItem> getList() {
		return mAppItems;
	}

	public void removeApp(int i) {
		mAppItems.remove(i);
		notifyDataSetChanged();
	}

	public void removeApp(AppItem appItem) {
		mAppItems.remove(appItem);
		notifyDataSetChanged();
	}

	public void removeApp2(AppItem appItem) {
		for (int i = 0; i < mAppItems.size(); i++) {
			if (mAppItems.get(i).getAppPackage().equals(appItem.getAppPackage())) {
				mAppItems.remove(i);
				break;
			}
		}
		notifyDataSetChanged();
	}

	public void updateListView(ArrayList<AppItem> filterDateList) {
		if (filterDateList == null) {
			filterDateList = new ArrayList<AppItem>();
		}
		this.mAppItems = filterDateList;
		notifyDataSetChanged();
	}

	public ArrayList<AppItem> getSelectList() {
		ArrayList<AppItem> selectAppItems = new ArrayList<AppItem>();
		for (int i = 0; i < mAppItems.size(); i++) {
			AppItem appItem = mAppItems.get(i);
			if (appItem.isChecked()) {
				selectAppItems.add(appItem);
			}
		}
		return selectAppItems;
	}

	public void checkup() {
		int checkedSize = 0;
		for (int i = 0; i < mAppItems.size(); i++) {
			AppItem appItem = mAppItems.get(i);
			if (appItem.isChecked()) {
				checkedSize++;
			}
		}
		mSelectListener.selectSize(checkedSize);
	}

	@Override
	public int getCount() {
		return mAppItems.size();
	}

	@Override
	public Object getItem(int position) {
		return mAppItems.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		final Holder mHolder;
		if (convertView == null) {
			convertView = mLayoutInflater.inflate(R.layout.listview_app_uninstall_item_for_manager, null);
			mHolder = new Holder();
			mHolder.appuninstall_item_appname_textview = (TextView) convertView.findViewById(R.id.appuninstall_item_name_textview);
			mHolder.appuninstall_item_size_textview = (TextView) convertView.findViewById(R.id.appuninstall_item_size_textview);
			mHolder.appuninstall_item_secondline_textview = (TextView) convertView.findViewById(R.id.appuninstall_item_secondline_textview);
			mHolder.appuninstall_item_tip_textview = (TextView) convertView.findViewById(R.id.appuninstall_item_tip_textview);
			mHolder.appuninstall_item_icon_imageview = (ImageView) convertView.findViewById(R.id.appuninstall_item_icon_imageview);
			mHolder.appuninstall_item_checked_checkbox = (CheckBox) convertView.findViewById(R.id.appuninstall_item_checked_checkbox);
			convertView.setTag(mHolder);
		} else {
			mHolder = (Holder) convertView.getTag();
			if (mHolder.imageLoader != null) {
				mHolder.imageLoader.cancel(true);
			}
		}
		final AppItem appItem = (AppItem) getItem(position);

		mHolder.appuninstall_item_appname_textview.setText(appItem.getAppName());
		mHolder.appuninstall_item_size_textview.setText(FormatUtils.formatBytesInByte(appItem.getCodeSize()));
		mHolder.appuninstall_item_secondline_textview.setText(FormatUtils.formatBytesInByte(appItem.getCodeSize()));
		mHolder.appuninstall_item_icon_imageview.setImageDrawable(appItem.getAppIcon());
		if (appItem.isChecked()) {
			mHolder.appuninstall_item_checked_checkbox.setChecked(true);
		} else {
			mHolder.appuninstall_item_checked_checkbox.setChecked(false);
		}

		if (appItem.isSystemApp()) {
			mHolder.appuninstall_item_size_textview.setVisibility(View.GONE);
			mHolder.appuninstall_item_secondline_textview.setText(FormatUtils.formatBytesInByte(appItem.getCodeSize()));
		} else {
			mHolder.appuninstall_item_size_textview.setVisibility(View.VISIBLE);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			mHolder.appuninstall_item_secondline_textview.setText(sdf.format(appItem.getInstallTime()));
		}

		if (appItem.isKeep()) {
			mHolder.appuninstall_item_tip_textview.setVisibility(View.VISIBLE);
		} else {
			mHolder.appuninstall_item_tip_textview.setVisibility(View.GONE);
		}

		if (appItem.getAppIcon() == null) {
			mHolder.appuninstall_item_icon_imageview.setImageDrawable(defaultIcon);
			mHolder.imageLoader = new AsyncTask<Holder, Void, Drawable>() {
				private Holder holder;

				@Override
				protected Drawable doInBackground(Holder... params) {
					holder = params[0];
					return appItem.getApplicationInfo().loadIcon(pm);
				}

				@Override
				protected void onPostExecute(Drawable result) {
					appItem.setAppIcon(result);
					holder.appuninstall_item_icon_imageview.setImageDrawable(result);
				}
			}.execute(mHolder);
		} else {
			mHolder.appuninstall_item_icon_imageview.setImageDrawable(appItem.getAppIcon());
		}

		convertView.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (Terminal.isRoot(mContext)) {
					appItem.setChecked(!appItem.isChecked());
					if (appItem.isChecked()) {
						mHolder.appuninstall_item_checked_checkbox.setChecked(true);
					} else {
						mHolder.appuninstall_item_checked_checkbox.setChecked(false);
					}
					checkup();
					mHandler.sendEmptyMessage(110);
				} else {
					if (!appItem.isSystemApp()) {
						appItem.setChecked(!appItem.isChecked());
						if (appItem.isChecked()) {
							mHolder.appuninstall_item_checked_checkbox.setChecked(true);
						} else {
							mHolder.appuninstall_item_checked_checkbox.setChecked(false);
						}
						checkup();
						mHandler.sendEmptyMessage(110);
					} else {
						final CustomDialog2 mCustomDialog = new CustomDialog2(mContext);
						mCustomDialog.setDialogIcon(R.drawable.dialog_icon_tips);
						if (Build.VERSION.SDK_INT >= 14) {
							mCustomDialog.setMessage("由于您的设备尚未获取ROOT权限,暂时无法删除系统应用.推荐使用ROOT成功率极高的一键ROOT大师快速获取权限.您还可以点击停用冻结系统应用.");
							mCustomDialog.setButton1(R.string.dialog_disable, new OnClickListener() {

								@Override
								public void onClick(View v) {
									AppManagerUtils.openInstalledDetail(mContext, appItem.getAppPackage());
									mCustomDialog.dismiss();
								}
							});
						} else {
							mCustomDialog.setMessage("由于您的设备尚未获取ROOT权限,暂时无法删除系统应用.推荐使用ROOT成功率极高的一键ROOT大师快速获取权限.");
							mCustomDialog.setButton1(R.string.dialog_button_cancel, null);
						}
						mCustomDialog.setButton2(R.string.recommend_download, new OnClickListener() {

							@Override
							public void onClick(View v) {
								mCustomDialog.dismiss();
								if(AppManagerUtils.appIsInstall(mContext, "com.zhiqupk.root")){
									mContext.startActivity(mContext.getPackageManager().getLaunchIntentForPackage("com.zhiqupk.root"));
								}else{
									AppDownload appDownload = new AppDownload(mContext);
									appDownload.setAppName("一键Root大师");
									appDownload.setPackageName("com.zhiqupk.root");
									appDownload.createNotify();
									appDownload.startDownloadApp();
								}
							}
						});
						mCustomDialog.show();
					}
				}
			}
		});
		return convertView;
	}

	class Holder {
		private TextView appuninstall_item_appname_textview;
		private TextView appuninstall_item_secondline_textview;
		private TextView appuninstall_item_size_textview;
		private TextView appuninstall_item_tip_textview;
		private ImageView appuninstall_item_icon_imageview;
		private CheckBox appuninstall_item_checked_checkbox;

		AsyncTask<Holder, Void, Drawable> imageLoader;
	}

}
