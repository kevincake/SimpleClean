package cn.com.opda.android.clearmaster.model;

import java.util.ArrayList;

public class ThumbnailInfo {
	private ArrayList<String> pathList;
	private long totalSize;
	private String path;
	private long count;
	
	
	public long getCount() {
		return count;
	}
	public void setCount(long count) {
		this.count = count;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public ArrayList<String> getPathList() {
		return pathList;
	}
	public void setPathList(ArrayList<String> pathList) {
		this.pathList = pathList;
	}
	public long getTotalSize() {
		return totalSize;
	}
	public void setTotalSize(long totalSize) {
		this.totalSize = totalSize;
	}
	
}
