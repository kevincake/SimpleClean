package cn.com.opda.android.clearmaster.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.preference.PreferenceManager;
import android.support.v4.app.NotificationCompat.Builder;
import android.text.TextUtils;
import android.widget.RemoteViews;
import android.widget.Toast;
import cn.com.opda.android.clearmaster.R;

import com.lib.statistics.StatisticsUtils;

/**
 * 广告下载类
 * 
 * @author 庄宏岩
 * 
 */
public class AppDownload {
	public Context mContext;
	private int NF_ID = 1003;
	private Notification nf;
	private NotificationManager nm;
	private String downloadurl;
	private String appName;
	private String packageName;
	private Bitmap appIcon;
	private Builder builder;

	public AppDownload(Context context) {
		this.mContext = context;
	}

	public void createNotify() {
		String time = System.currentTimeMillis() + "";
		NF_ID = Integer.parseInt(time.substring(time.length() / 2, time.length()));
		nm = (NotificationManager) mContext.getSystemService(Context.NOTIFICATION_SERVICE);
		if (Build.VERSION.SDK_INT >= 11) {
			builder = new Builder(mContext);
			builder.setSmallIcon(R.drawable.notify_download);
			if (appIcon == null) {
				appIcon = ((BitmapDrawable) mContext.getResources().getDrawable(R.drawable.notify_download)).getBitmap();
			}
			builder.setLargeIcon(appIcon);
			builder.setContentTitle(appName);
			builder.setContentText(mContext.getString(R.string.app_download_progress) + "0%");
			builder.setProgress(100, 0, false);

			nf = builder.build();
			nf.flags = Notification.FLAG_AUTO_CANCEL;
			nf.icon = android.R.drawable.stat_sys_download;
			nf.contentIntent = PendingIntent.getActivity(mContext, 0, new Intent(), 0);
			nf = builder.build();
		} else {
			nf = new Notification(R.drawable.notify_download, "", System.currentTimeMillis());
			nf.icon = android.R.drawable.stat_sys_download;
			nf.flags = Notification.FLAG_NO_CLEAR;
			nf.contentView = new RemoteViews(mContext.getPackageName(), R.layout.notification_layout);
			nf.contentView.setProgressBar(R.id.progressbar_notification, 100, 0, false);
			nf.contentView.setTextViewText(R.id.textivew_notification, mContext.getString(R.string.app_download_progress) + "0%");
			nf.contentIntent = PendingIntent.getActivity(mContext, 0, new Intent(), 0);
		}
	}

	public void setDownloadurl(String downloadurl) {
		this.downloadurl = downloadurl;
	}

	public void setAppIcon(Drawable appIcon) {
		if (appIcon != null) {
			this.appIcon = ((BitmapDrawable) appIcon).getBitmap();
		}
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}

	private Handler mHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			switch (msg.what) {
			case 3: {
				nm.cancel(NF_ID);
				Toast.makeText(mContext, R.string.appupdate_result_download_error, Toast.LENGTH_SHORT).show();
				break;
			}
			case 4: {
				if (Build.VERSION.SDK_INT >= 11) {
					builder.setContentText(mContext.getString(R.string.app_download_progress) + msg.obj + "%");
					builder.setProgress(100, (Integer) msg.obj, false);
					nf = builder.build();
				} else {
					nf.contentView.setProgressBar(R.id.progressbar_notification, 100, (Integer) msg.obj, false);
					nf.contentView.setTextViewText(R.id.textivew_notification, appName + mContext.getString(R.string.app_download_progress) + msg.obj + "%");
				}
				nm.notify(NF_ID, nf);
				break;
			}
			case 5: {
				StatisticsUtils.commitEvent(mContext, appName, packageName, StatisticsUtils.AdType_ruanjianneizhi, StatisticsUtils.AdEvent_download_done);
				Intent intent = new Intent();
				intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				intent.setAction(android.content.Intent.ACTION_VIEW);
				File file = new File((String) msg.obj);
				if (file.exists() && file.isAbsolute()) {
					intent.setDataAndType(Uri.fromFile(file), "application/vnd.android.package-archive");
					mContext.startActivity(intent);
					if (!TextUtils.isEmpty(appName)) {
						StatisticsUtils.commitEvent(mContext, appName, packageName, StatisticsUtils.AdType_ruanjianneizhi, StatisticsUtils.AdEvent_installed);
					}
				}
				Toast.makeText(mContext, R.string.appupdate_result_download_succeed, Toast.LENGTH_SHORT).show();
				nm.cancel(NF_ID);

				SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(mContext);
				sp.edit().putString("lastInstall", packageName).commit();
				sp.edit().putLong("lastInstallTime", System.currentTimeMillis()).commit();
				break;
			}
			case 6: {
				StatisticsUtils.commitEvent(mContext, appName, packageName, StatisticsUtils.AdType_ruanjianneizhi, StatisticsUtils.AdEvent_download_done);
				if (!TextUtils.isEmpty(appName)) {
					StatisticsUtils.commitEvent(mContext, appName, packageName, StatisticsUtils.AdType_ruanjianneizhi, StatisticsUtils.AdEvent_installed);
				}
				Toast.makeText(mContext, R.string.appupdate_result_download_succeed, Toast.LENGTH_SHORT).show();
				nm.cancel(NF_ID);

				if (packageName != null) {
					mContext.startActivity(mContext.getPackageManager().getLaunchIntentForPackage(packageName));
					if (!TextUtils.isEmpty(appName)) {
						StatisticsUtils.commitEvent(mContext, appName, packageName, StatisticsUtils.AdType_ruanjianneizhi, StatisticsUtils.AdEvent_open);
					}
				}
				break;
			}
			default:
				break;
			}
		}
	};

	/**
	 * 开始下载app
	 */
	public void startDownloadApp() {
		StatisticsUtils.commitEvent(mContext, appName, packageName, StatisticsUtils.AdType_ruanjianneizhi, StatisticsUtils.AdEvent_download);
		final String root_action_point_url = "http://static.kfkx.net/rootdashi/rootdashi_clearmaster.apk";
		Message msg2 = new Message();
		msg2.obj = 0;
		msg2.what = 4;
		mHandler.sendMessage(msg2);
		new Thread(new Runnable() {
			@Override
			public void run() {
				String path = TextUtils.isEmpty(downloadurl) ? root_action_point_url : downloadurl;
				String apkName = path.substring(path.lastIndexOf("/") + 1, path.length());
				if (!apkName.endsWith(".apk")) {
					apkName += ".apk";
				}
				String downloadPath = Constants.DOWNLOAD_PATH;
				if (!new File(downloadPath).exists()) {
					new File(downloadPath).mkdirs();
				}
				String apkPath = downloadPath + "/" + apkName;
				String apkPathTemp = downloadPath + "/" + apkName + ".temp";
				if (new File(apkPath).exists()) {
					if (Terminal.isRoot(mContext)) {
						boolean b = Terminal.installApp(apkPath);
						if (b) {
							Message msg = new Message();
							msg.what = 6;
							mHandler.sendMessage(msg);
						} else {
							Message msg = new Message();
							msg.what = 5;
							msg.obj = apkPath;
							mHandler.sendMessage(msg);
						}
					} else {
						Message msg = new Message();
						msg.what = 5;
						msg.obj = apkPath;
						mHandler.sendMessage(msg);
					}
					return;
				}
				long totalSize = 0;
				long downloadSize = 0;
				long progress = 0;
				try {
					URL url = new URL(path);
					HttpURLConnection conn = (HttpURLConnection) url.openConnection();
					conn.setConnectTimeout(5 * 1000);
					conn.setRequestMethod("GET");
					conn.setReadTimeout(30 * 1000);
					if (conn.getResponseCode() == 200) {
						InputStream inStream = conn.getInputStream();
						FileOutputStream outputStream = new FileOutputStream(apkPathTemp);
						byte[] buffer = new byte[1024];
						totalSize = conn.getContentLength();
						int len;
						while ((len = inStream.read(buffer)) != -1) {
							outputStream.write(buffer, 0, len);
							downloadSize += len;
							int newProgress = (int) ((100 * downloadSize) / totalSize);
							if (newProgress - 1 > progress) {
								progress = newProgress;
								Message msg = new Message();
								msg.obj = newProgress;
								msg.what = 4;
								mHandler.sendMessage(msg);
							}
						}
						inStream.close();
						outputStream.close();
						if (totalSize == downloadSize) {
							new File(apkPathTemp).renameTo(new File(apkPath));
							if (Terminal.isRoot(mContext)) {
								boolean b = Terminal.installApp(apkPath);
								if (b) {
									Message msg = new Message();
									msg.what = 6;
									mHandler.sendMessage(msg);
								} else {
									Message msg = new Message();
									msg.what = 5;
									msg.obj = apkPath;
									mHandler.sendMessage(msg);
								}
							} else {
								Message msg = new Message();
								msg.what = 5;
								msg.obj = apkPath;
								mHandler.sendMessage(msg);
							}
						}
					} else {
						mHandler.sendEmptyMessage(3);
					}
				} catch (Exception e) {
					mHandler.sendEmptyMessage(3);
					e.printStackTrace();
				}
			}
		}).start();

	}

}
