package cn.com.opda.android.clearmaster.receiver;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import cn.com.opda.android.clearmaster.dao.AppListDBUtils;
import cn.com.opda.android.clearmaster.dao.AppNetFlowDBUtils;
import cn.com.opda.android.clearmaster.model.AppItem;
import cn.com.opda.android.clearmaster.service.ClearApkService;
import cn.com.opda.android.clearmaster.service.ClearRemainFileService;
import cn.com.opda.android.clearmaster.service.ReadStartUpService;
import cn.com.opda.android.clearmaster.utils.ClearUtils;
import cn.com.opda.android.clearmaster.utils.Constants;
import cn.com.opda.android.clearmaster.utils.DLog;
import cn.com.opda.android.clearmaster.utils.DrawableUtils;

public class AppListenerReceiver extends BroadcastReceiver {
	@Override
	public void onReceive(final Context context, Intent intent) {
		if (intent != null) {
			String action = intent.getAction();
			if(action!=null){
				DLog.i("debug", "clearmaster action: " + action);
			}
			if (Intent.ACTION_PACKAGE_REMOVED.equals(action)) {
				SharedPreferences sharedPreferences = context.getSharedPreferences(Constants.SHARED_PREFERENCES_NAME, Context.MODE_PRIVATE);
				if(sharedPreferences.getBoolean(Constants.DEPTH_TIPS_CHECKED, true)){
					String packageName = URI.create(intent.getDataString()).getSchemeSpecificPart();
					if (!TextUtils.isEmpty(packageName)) {
						Intent intent2 = new Intent(context, ClearRemainFileService.class);
						intent2.putExtra("packageName", packageName);
						context.startService(intent2);
					}
				}
			}
			if (Intent.ACTION_PACKAGE_ADDED.equals(action)) {
				final String packageName = URI.create(intent.getDataString()).getSchemeSpecificPart();
				if (!TextUtils.isEmpty(packageName)||!packageName.equals(context.getPackageName())) {
					SharedPreferences sharedPreferences = context.getSharedPreferences(Constants.SHARED_PREFERENCES_NAME, Context.MODE_PRIVATE);
					if(sharedPreferences.getBoolean(Constants.APK_CLEAR_TIPS_CHECKED, true)){
						Intent intent2 = new Intent(context, ClearApkService.class);
						intent2.putExtra("packageName", packageName);
						context.startService(intent2);
					}
					
					SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
					String lastInstallPackage = sp.getString("lastInstall", "");
					long lastInstallTime = sp.getLong("lastInstallTime", 0);

					if (packageName.equals(lastInstallPackage) && System.currentTimeMillis() - lastInstallTime <= 10 * 60 * 1000) {
						sp.edit().putString("lastInstall", "").commit();
						sp.edit().putLong("lastInstallTime", 0).commit();
						context.startActivity(context.getPackageManager().getLaunchIntentForPackage(lastInstallPackage));
					}
					if(AppNetFlowDBUtils.isInit(context)){
						AppNetFlowDBUtils.save(context, packageName);
					}
					if(AppListDBUtils.isInit(context)){
						AppListDBUtils.save(context, packageName);
					}else{
						new Thread(new Runnable() {
							
							@Override
							public void run() {
								initAppinfosDB(context);
							}
						}).start();
					}
				}

			}

			if ("android.intent.action.USER_PRESENT".equals(action)) {
//				SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
//				long lastUseTime = sp.getLong("lastUseTime", System.currentTimeMillis());
//
//				if (System.currentTimeMillis() - lastUseTime > 60*60*1000*24*3) {
//					sp.edit().putLong("lastUseTime", System.currentTimeMillis()).commit();
//					ClearUtils.showClearNotify(context);
//				}
				
				ClearUtils.showClearNotify2(context);
				ClearUtils.showProcessNotify(context);
				
				if(!ReadStartUpService.start){
					context.startService(new Intent(context, ReadStartUpService.class));
				}
				
				ClearUtils.clearDayClearSize(context,System.currentTimeMillis());

			}
		}
	}
	
	
	private void initAppinfosDB(Context mContext){
		ArrayList<AppItem> tempList = new ArrayList<AppItem>();
		PackageManager pm = mContext.getPackageManager();
		List<PackageInfo> list = pm.getInstalledPackages((PackageManager.GET_UNINSTALLED_PACKAGES));
		for (PackageInfo packageInfo : list) {
			if (packageInfo.packageName.equals(mContext.getPackageName())) {
				continue;
			}
			ApplicationInfo appInfo = packageInfo.applicationInfo;
			boolean flag = false;
			if ((appInfo.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0) {
				flag = true;
			} else if ((appInfo.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
				flag = true;
			}
			final String sourceDir = appInfo.sourceDir;
			if (flag && sourceDir != null) {
				final AppItem info = new AppItem();
				info.setIcon(DrawableUtils.drawable2Byte(appInfo.loadIcon(pm)));
				info.setAppName(appInfo.loadLabel(pm).toString());
				info.setAppPackage(appInfo.packageName);
				info.setInstallTime(System.currentTimeMillis());
				tempList.add(info);
			}
		}
		if (!AppListDBUtils.isInit(mContext)) {
			AppListDBUtils.save(mContext, tempList);
		}
	}

}
