package cn.com.opda.android.clearmaster;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.Toast;
import cn.com.opda.android.clearmaster.utils.AppDownload;
import cn.com.opda.android.clearmaster.utils.BannerUtils;

import com.lib.statistics.StatisticsUtils;
import com.umeng.analytics.MobclickAgent;

/**
 * 广告详细页面
 * @author 庄宏岩
 *
 */
public class AdDetailActivity extends BaseActivity implements OnClickListener {
	private String appName;
	private String packageName;
	private String detailUrl;
	private String apkUrl;
	private Button detail_download;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_ad_webview);
		BannerUtils.initBackButton(this);
		BannerUtils.setMainTitle(this, "应用详情");
		appName = getIntent().getStringExtra("appname");
		packageName = getIntent().getStringExtra("packagename");
		detailUrl = getIntent().getStringExtra("detail_url");
		apkUrl = getIntent().getStringExtra("url");

		initViewAndEvent();
	}
	
	

	@Override
	protected void onResume() {
		super.onResume();
		MobclickAgent.onResume(this);
		PackageInfo packageInfo = null;
		try {
			packageInfo = getPackageManager().getPackageInfo(packageName, 0);
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}
		if (packageInfo != null) {
			detail_download.setText("启动");
		} else{
			detail_download.setText("下载");
		}
	}



	@Override
	protected void onPause() {
		super.onPause();
		MobclickAgent.onPause(this);
	}



	private void initViewAndEvent() {
		WebView ad_detail_webview = (WebView) findViewById(R.id.ad_detail_webview);
		
		WebSettings webSettings = ad_detail_webview.getSettings();
		webSettings.setJavaScriptEnabled(true);
		ad_detail_webview.loadUrl(detailUrl);
		
		
		detail_download = (Button) findViewById(R.id.detail_download);
		detail_download.setOnClickListener(this);

	}

	@Override
	public void onClick(View v) {
		if (detail_download.getText().equals("下载")) {

			StatisticsUtils.commitEvent(this, appName, packageName, StatisticsUtils.AdType_ruanjianneizhi, StatisticsUtils.AdEvent_show);
			AppDownload appDownload = new AppDownload(this);
			appDownload.setDownloadurl(apkUrl);
			appDownload.setAppName(appName);
			appDownload.setPackageName(packageName);
			appDownload.createNotify();
			appDownload.startDownloadApp();
			Toast.makeText(this, appName + getString(R.string.ad_stardonwload_tips), Toast.LENGTH_SHORT).show();
			detail_download.setText("下载中");
		} else if (detail_download.getText().equals("启动")) {
			StatisticsUtils.commitEvent(this, appName, packageName, StatisticsUtils.AdType_ruanjianneizhi, StatisticsUtils.AdEvent_open);
			startActivity(getPackageManager().getLaunchIntentForPackage(packageName));
		}
	}

}
