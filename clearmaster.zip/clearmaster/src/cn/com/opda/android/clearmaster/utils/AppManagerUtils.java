package cn.com.opda.android.clearmaster.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.ActivityManager.RunningServiceInfo;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.Uri;
import android.os.Build;
import cn.com.opda.android.clearmaster.model.AppItem;

public class AppManagerUtils {
	/**
	 * 清除全部用户数据 包括数据和缓存
	 * 
	 * @param mContext
	 * @param packageName
	 */
	public static void clearAppAllData(Context mContext, String packageName) {
		if (!new File(mContext.getFilesDir(), "RemoteTools.jar").exists()) {
			String fileName = "RemoteTools_low.jar";
			if (Build.VERSION.SDK_INT >= 17) {
				fileName = "RemoteTools.jar";
			} else {
				fileName = "RemoteTools_low.jar";
			}
			FileUtils.copyAssetFile(mContext, fileName);
		}
		Terminal2 terminal2 = null;
		try {
			terminal2 = new Terminal2(mContext);
		} catch (IOException e) {
			e.printStackTrace();
		}
		terminal2.RootCommand("pm clear " + packageName + "\n");
	}

	/**
	 * 清除应用的数据
	 * 
	 * @param mContext
	 * @param packageName
	 */
	public static void clearAppData(Context mContext, String packageName) {
		if (!new File(mContext.getFilesDir(), "RemoteTools.jar").exists()) {
			String fileName = "RemoteTools_low.jar";
			if (Build.VERSION.SDK_INT >= 17) {
				fileName = "RemoteTools.jar";
			} else {
				fileName = "RemoteTools_low.jar";
			}
			FileUtils.copyAssetFile(mContext, fileName);
		}
		try {
			Terminal2 terminal2 = new Terminal2(mContext);
			terminal2.runCommand("cleanAppData", packageName);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 清除应用的缓存
	 * 
	 * @param mContext
	 * @param packageName
	 */
	public static void clearAppCache(Context mContext, String packageName) {

		if (!new File(mContext.getFilesDir(), "RemoteTools.jar").exists()) {
			String fileName = "RemoteTools_low.jar";
			if (Build.VERSION.SDK_INT >= 17) {
				fileName = "RemoteTools.jar";
			} else {
				fileName = "RemoteTools_low.jar";
			}
			FileUtils.copyAssetFile(mContext, fileName);
		}
		try {
			Terminal2 terminal2 = new Terminal2(mContext);
			terminal2.runCommand("cleanAppCache", packageName);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 强行停止应用
	 * 
	 * @param mContext
	 * @param packageName
	 */
	public static void forceStopPackage(Context mContext, String packageName) {
		if (!new File(mContext.getFilesDir(), "RemoteTools.jar").exists()) {
			String fileName = "RemoteTools_low.jar";
			if (Build.VERSION.SDK_INT >= 17) {
				fileName = "RemoteTools.jar";
			} else {
				fileName = "RemoteTools_low.jar";
			}
			FileUtils.copyAssetFile(mContext, fileName);
		}
		try {
			Terminal2 terminal2 = new Terminal2(mContext);
			terminal2.runCommand("forceStopPackage", packageName);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 软件搬家
	 * 
	 * @param mContext
	 * @param packageName
	 */
	public static void movePackage(Context mContext, AppItem appItem) {
		if (!new File(mContext.getFilesDir(), "RemoteTools.jar").exists()) {
			String fileName = "RemoteTools_low.jar";
			if (Build.VERSION.SDK_INT >= 17) {
				fileName = "RemoteTools.jar";
			} else {
				fileName = "RemoteTools_low.jar";
			}
			FileUtils.copyAssetFile(mContext, fileName);
		}
		try {
			Terminal2 terminal2 = new Terminal2(mContext);
			if (appItem.getLocation() == AppItem.INSTALL_INTERNAL) {
				terminal2.runCommand("moveApp", appItem.getAppPackage(), 2 + "");
			} else {
				terminal2.runCommand("moveApp", appItem.getAppPackage(), 1 + "");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 运行app
	 * 
	 * @param packageName
	 */
	public static void runApp(Context context, String packageName) {
		PackageManager pManager = context.getPackageManager();
		Intent intent = pManager.getLaunchIntentForPackage(packageName);
		if (intent != null) {
			context.startActivity(intent);
		}
	}

	/**
	 * 获取某个应用的LaunchIntent
	 * 
	 * @param context
	 * @param packageName
	 * @return
	 */
	public static Intent getLaunchIntent(Context context, String packageName) {
		PackageManager pManager = context.getPackageManager();
		return pManager.getLaunchIntentForPackage(packageName);
	}

	/**
	 * 打开某个app的详细设置页面
	 * 
	 * @param cxt
	 * @param packageName
	 */
	public static void openInstalledDetail(Context cxt, String packageName) {
		try {
			Intent intent = new Intent("android.intent.action.VIEW");
			intent.setClassName("com.android.settings", "com.android.settings.InstalledAppDetails");
			intent.putExtra("com.android.settings.ApplicationPkgName", packageName);
			intent.putExtra("pkg", packageName);
			cxt.startActivity(intent);
		} catch (Exception e) {
			try {
				Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS", Uri.fromParts("package", packageName, null));
				cxt.startActivity(intent);
			} catch (Exception e1) {
				openUninstaller(cxt, packageName);
			}
		}
	}

	/**
	 * 调用系统卸载某个应用
	 * 
	 * @param cxt
	 * @param packageName
	 */
	public static void openUninstaller(Context cxt, String packageName) {
		Uri packageURI = Uri.parse("package:" + packageName);
		Intent uninstallIntent = new Intent("android.intent.action.DELETE", packageURI);
		cxt.startActivity(uninstallIntent);
	}

	/**
	 * 调用系统安装某个应用
	 * 
	 * @param cxt
	 * @param filePath
	 */
	public static void openInstaller(Context cxt, String filePath) {
		Intent intent = new Intent();
		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent.setAction(android.content.Intent.ACTION_VIEW);
		File file = new File(filePath);
		if (file.exists() && file.isAbsolute()) {
			intent.setDataAndType(Uri.fromFile(file), "application/vnd.android.package-archive");
			cxt.startActivity(intent);
		}
	}

	/**
	 * 备份系统应用
	 * 
	 * @param appinfoModel
	 * @return true:备份成功
	 */
	public static boolean backupApp(AppItem appinfoModel) {
		File fileDir = new File(Constants.SYSTEM_BACKUP_PATH);
		if (!fileDir.exists()) {
			fileDir.mkdirs();
		}
		String apkName = appinfoModel.getCodePath().substring(appinfoModel.getCodePath().lastIndexOf("/") + 1, appinfoModel.getCodePath().length());
		String outFileName = Constants.SYSTEM_BACKUP_PATH + apkName;
		if (!outFileName.endsWith(".apk")) {
			outFileName += ".apk";
		}
		File outFile = new File(outFileName);
		if (outFile.exists()) {
			outFile.delete();
		}

		String odexName = apkName.replace(".apk", ".odex");
		String odexOutFileName = Constants.SYSTEM_BACKUP_PATH + odexName;
		File odexOutFile = new File(odexOutFileName);
		if (odexOutFile.exists()) {
			odexOutFile.delete();
		}
		try {
			outFile.createNewFile();
			InputStream myInput = new FileInputStream(new File(appinfoModel.getCodePath()));
			OutputStream myOutput = new FileOutputStream(outFileName);
			byte[] buffer = new byte[1024];
			int len;
			int totalLen = 0;
			while ((len = myInput.read(buffer)) > 0) {
				totalLen += len;
				myOutput.write(buffer, 0, len);
			}
			if (totalLen != new File(appinfoModel.getCodePath()).length()) {
				outFile.delete();
				return false;
			}
			myOutput.flush();
			myOutput.close();
			myInput.close();
			if (new File(appinfoModel.getOdexPath()).exists()) {
				odexOutFile.createNewFile();
				myInput = new FileInputStream(new File(appinfoModel.getOdexPath()));
				myOutput = new FileOutputStream(odexOutFile);
				len = 0;
				totalLen = 0;
				while ((len = myInput.read(buffer)) > 0) {
					totalLen += len;
					myOutput.write(buffer, 0, len);
				}
				if (totalLen != new File(appinfoModel.getOdexPath()).length()) {
					odexOutFile.delete();
					return false;
				}
				myOutput.flush();
				myOutput.close();
				myInput.close();
			}
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * 卸载系统应用
	 * 
	 * @param appItem
	 * @return ture:卸载成功
	 */
	public static boolean uninstallSystemApp(AppItem appItem) {
		Terminal.RootCommand("mount -o remount rw /system");
		Terminal.RootCommand("PATH='/system/bin';'mount' '-o' 'remount,rw' '' '/system'");
		String command = "rm " + appItem.getCodePath() + "\n";
		command += "pm uninstall " + appItem.getAppPackage() + "\n";
		int code = Terminal.RootCommand(command);
		return code == 0 ? true : false;
	}

	/**
	 * 还原系统应用
	 * 
	 * @param appItem
	 * @return true:备份成功
	 */
	public static boolean restoreApp(AppItem appItem) {
		String apkName = appItem.getFilePath().substring(appItem.getFilePath().lastIndexOf("/") + 1, appItem.getFilePath().length());
		Terminal.RootCommand("mount -o remount rw /system");
		Terminal.RootCommand("PATH='/system/bin';'mount' '-o' 'remount,rw' '' '/system'");
		int result = 0;
		String odexName = apkName.replace(".apk", ".odex");
		if (new File(appItem.getOdexPath()).exists()) {
			String cmd = "touch /system/app/" + odexName + "\n";
			cmd += "chmod 0644 /system/app/" + odexName + "\n";
			cmd += "cat " + appItem.getOdexPath() + " > " + "/system/app/" + odexName;
			result = Terminal.RootCommand(cmd);
		}
		String cmd = "touch /system/app/" + apkName + "\n";
		cmd += "chmod 0644 /system/app/" + apkName + "\n";
		cmd += "cat " + appItem.getFilePath() + " > " + "/system/app/" + apkName;
		result = Terminal.RootCommand(cmd);
		return result == 0 ? true : false;
	}

	/**
	 * 判断应用的安装状态
	 * 
	 * @param mContext
	 * @param packageName
	 * @return true: 已安装
	 */
	public static boolean appIsInstall(Context mContext, String packageName) {
		PackageInfo packageInfo = null;
		try {
			packageInfo = mContext.getPackageManager().getPackageInfo(packageName, 0);
		} catch (NameNotFoundException e) {
		}
		return packageInfo != null ? true : false;
	}

	public static ArrayList<String> getApkPathList(Context mContext) {
		ArrayList<String> arrayList = new ArrayList<String>();
		try {
			InputStream inputStream = mContext.getAssets().open("apkpath");
			int len = 0;
			byte[] buff = new byte[1024];
			StringBuffer sb = new StringBuffer();
			while ((len = inputStream.read(buff)) != -1) {
				sb.append(new String(buff, 0, len));
			}
			inputStream.close();
			String[] strings = sb.toString().split("\n");
			for (String string : strings) {
				arrayList.add(string.trim());
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return arrayList;
	}

	public static boolean appIsRunning(Context mContext, String appPackage) {
		ActivityManager am = (ActivityManager) mContext.getSystemService(Context.ACTIVITY_SERVICE);
		List<RunningAppProcessInfo> lists = am.getRunningAppProcesses();
		List<RunningServiceInfo> serviceList = am.getRunningServices(100);
		if (lists != null) {
			for (RunningAppProcessInfo runapp : lists) {
				String packageName = runapp.pkgList[0];
				if (packageName.equals(appPackage)) {
					return true;
				}
			}
		}

		if (serviceList != null) {
			for (RunningServiceInfo runService : serviceList) {
				String packageName = runService.service.getPackageName();
				if (packageName.equals(appPackage)) {
					return true;
				}
			}
		}

		return false;
	}
}
