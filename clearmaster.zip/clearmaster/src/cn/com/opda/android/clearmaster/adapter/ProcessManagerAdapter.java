package cn.com.opda.android.clearmaster.adapter;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import cn.com.opda.android.clearmaster.R;
import cn.com.opda.android.clearmaster.impl.CheckedListener;
import cn.com.opda.android.clearmaster.impl.SelectListener;
import cn.com.opda.android.clearmaster.model.AppItem;
import cn.com.opda.android.clearmaster.utils.FormatUtils;

/**
 * 
 * @author 庄宏岩
 * 
 */
public class ProcessManagerAdapter extends BaseAdapter {
	private ArrayList<AppItem> appItems;// 子列表
	private LayoutInflater mLayoutInflater;
	private SelectListener selectListener;
	private CheckedListener checkedListener;

	public ProcessManagerAdapter(Context mContext, ArrayList<AppItem> appItems) {
		this.appItems = appItems;
		this.mLayoutInflater = LayoutInflater.from(mContext);
	}

	public void setSelectListener(SelectListener selectListener) {
		this.selectListener = selectListener;
	}

	public void setCheckedListener(CheckedListener checkedListener) {
		this.checkedListener = checkedListener;
	}

	public void setAllChecked(boolean isChecked) {
		for (AppItem appItem : appItems) {
			appItem.setChecked(isChecked);
		}
		notifyDataSetChanged();
	}

	public ArrayList<AppItem> getSelectList() {
		ArrayList<AppItem> selects = new ArrayList<AppItem>();
		for (AppItem appItem : appItems) {
			if (appItem.isChecked()) {
				selects.add(appItem);
			}
		}
		return selects;
	}

	public void updateSelectMemorySize() {
		long totalSize = 0;
		int checkedSize = 0;
		for (AppItem appItem : appItems) {
			if (appItem != null && appItem.isChecked()) {
				totalSize += appItem.getMemorySize();
				checkedSize++;
			}
		}
		if (selectListener != null) {
			selectListener.selectSize(totalSize);
		}

		if (checkedListener != null) {
			if (checkedSize == 0) {
				checkedListener.nothingChecked();
			} else if (checkedSize == getCount()) {
				checkedListener.allChecked(checkedSize);
			} else {
				checkedListener.someChecked(checkedSize);
			}
		}
	}

	public ArrayList<AppItem> getList() {
		return appItems;
	}

	public void remove(AppItem appItem) {
		appItems.remove(appItem);
		updateSelectMemorySize();
	}

	@Override
	public int getCount() {
		return appItems.size();
	}

	@Override
	public Object getItem(int position) {
		return appItems.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		final Holder mHolder;
		if (convertView == null) {
			convertView = mLayoutInflater.inflate(R.layout.listview_process_manager_item, null);
			mHolder = new Holder();
			mHolder.process_item_name_textview = (TextView) convertView.findViewById(R.id.process_item_name_textview);
			mHolder.process_item_checked_imageview = (CheckBox) convertView.findViewById(R.id.process_item_checked_imageview);
			mHolder.process_item_memory_textview = (TextView) convertView.findViewById(R.id.process_item_memory_textview);
			mHolder.process_item_icon_imageview = (ImageView) convertView.findViewById(R.id.process_item_icon_imageview);
			convertView.setTag(mHolder);
		} else {
			mHolder = (Holder) convertView.getTag();
		}

		final AppItem appItem = appItems.get(position);
		mHolder.process_item_name_textview.setText(appItem.getAppName());
		mHolder.process_item_memory_textview.setText(FormatUtils.formatBytesInByte(appItem.getMemorySize()));
		mHolder.process_item_icon_imageview.setImageDrawable(appItem.getAppIcon());
		mHolder.process_item_checked_imageview.setChecked(appItem.isChecked());
		mHolder.process_item_checked_imageview.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				appItem.setChecked(!appItem.isChecked());
				updateSelectMemorySize();
			}
		});
		return convertView;
	}

	private class Holder {
		private TextView process_item_name_textview;
		private TextView process_item_memory_textview;
		private ImageView process_item_icon_imageview;
		private CheckBox process_item_checked_imageview;
	}

}
