package cn.com.opda.android.clearmaster.privacy;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import cn.com.opda.android.clearmaster.utils.Constants;

public class VideoDBHelper {

	private static final String VideoSqLiteName = Constants.FILE_VIDEO;
	private static SQLiteDatabase db;

	/**
	 * 创建并打开数据库
	 * 
	 * @param newversion
	 */
	public static void openOrCreateDb(int newversion) {
		db = SQLiteDatabase.openOrCreateDatabase(getDatabasePath(VideoSqLiteName), null);
		int version = db.getVersion();
		if (version != newversion) {
			db.execSQL("drop table if exists video_path");
			db.execSQL("create table if not exists video_path (_id INTEGER  primary key autoincrement,video_id,old_path TEXT,new_path TEXT)");
			db.setVersion(newversion);
		}
	}

	/**
	 * 加入备份数据库
	 * 
	 * @param infolist
	 */
	public static void addVideo(List<VideoInfo> infolist) {
		openOrCreateDb(1);
		for (int i = 0; i < infolist.size(); i++) {
			VideoInfo info = infolist.get(i);
			db.execSQL("insert into video_path (video_id,old_path,new_path) values(?,?,?)",
					new Object[] { info.getVideoId(), info.getOldPath(), info.getNewPath() });
		}
		closeDb();

	}

	public static void addVideo(VideoInfo info) {
		openOrCreateDb(1);
		db.execSQL("insert into video_path (video_id,old_path,new_path) values(?,?,?)",
				new Object[] { info.getVideoId(), info.getOldPath(), info.getNewPath() });
		closeDb();
	}

	/**
	 * 根据id删除信息
	 */
	public static void deleteVideo(Context context, String videoId) {
		openOrCreateDb(1);
		db.execSQL("delete from video_path where video_id=?", new Object[] { videoId + "" });
		closeDb();
	}

	/**
	 * 根据id删除信息
	 */
	public static void deleteVideo(Context context, ArrayList<VideoInfo> VideoInfos) {
		openOrCreateDb(1);
		for (VideoInfo videoInfo : VideoInfos) {
			db.execSQL("delete from video_path where video_id=?", new Object[] { videoInfo.getVideoId() });
		}
		closeDb();
	}

	/**
	 * 阅读备份数据库
	 * 
	 * @return
	 */
	public static ArrayList<VideoInfo> readVideoList() {
		openOrCreateDb(1);
		ArrayList<VideoInfo> list = new ArrayList<VideoInfo>();
		Cursor cursor = db.rawQuery("select * from video_path", null);
		if (cursor != null) {
			while (cursor.moveToNext()) {
				VideoInfo info = new VideoInfo();
				info.setId(cursor.getInt(0));
				info.setVideoId(cursor.getString(1));
				info.setOldPath(cursor.getString(2));
				info.setNewPath(cursor.getString(3));
				list.add(info);
			}
			cursor.close();
		}
		closeDb();
		return list;
	}

	/**
	 * 关闭数据库
	 */
	public static void closeDb() {
		if (db != null) {
			db.close();
		}
	}

	/**
	 * 创建数据库路径
	 * 
	 * @param name
	 * @return
	 */
	public static File getDatabasePath(String name) {
		File f = new File(Constants.BACKUP_DIR_PATH);
		if (!f.exists()) {
			f.mkdirs();
		}
		return new File(f, name);
	}

}
