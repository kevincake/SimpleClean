package cn.com.opda.android.clearmaster.model;

import java.util.ArrayList;
import java.util.List;

public class ConversationInfo {
	private int id; // 会话的id号
	private List<SmsInfo> junSMSs = new ArrayList<SmsInfo>(); // 会话所包含的信息
	private boolean isChecked = false; // 是否被选中
	private String person; // 联系人id
	private String address; // 会话的电话号码地址
	private int count; // 会话包含的信息总数
	private String name; // 会话人对方的名字

	private int numberType; // 手机号码的种类
	private String numberInfo; // 手机号码信息，归属地，或者服务号码名称
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public List<SmsInfo> getJunSMSs() {
		return junSMSs;
	}
	public void setJunSMSs(List<SmsInfo> junSMSs) {
		this.junSMSs = junSMSs;
	}
	public boolean isChecked() {
		return isChecked;
	}
	public void setChecked(boolean isChecked) {
		this.isChecked = isChecked;
	}
	public String getPerson() {
		return person;
	}
	public void setPerson(String person) {
		this.person = person;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getNumberType() {
		return numberType;
	}
	public void setNumberType(int numberType) {
		this.numberType = numberType;
	}
	public String getNumberInfo() {
		return numberInfo;
	}
	public void setNumberInfo(String numberInfo) {
		this.numberInfo = numberInfo;
	}
	
	
	
}
