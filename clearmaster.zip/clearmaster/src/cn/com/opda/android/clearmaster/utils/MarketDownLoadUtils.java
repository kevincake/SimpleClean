package cn.com.opda.android.clearmaster.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.json.JSONObject;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;

public class MarketDownLoadUtils {
	public static String downloadUrl = "http://static.opda.com/verbose/yingyongbao_verbose.apk";
	public static String marketPackage = "com.tencent.android.qqdownloader";
	public static boolean finish;
	public static boolean donwloading;
	public static String filePath = Constants.DOWNLOAD_PATH + "/yingyongbao_verbose_1234";
	public static boolean error;
	public static boolean alert;
	public static Context mContext;
	public static boolean show;

	public static void init(Context context) {
		try {
			URL url = new URL("http://static.opda.com/verbose/clearmaster/market.json");
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setConnectTimeout(5 * 1000);
			conn.setRequestMethod("GET");
			conn.setReadTimeout(30 * 1000);
			if (conn.getResponseCode() == 200) {
				InputStream inStream = conn.getInputStream();
				StringBuffer sb = new StringBuffer();
				byte[] buffer = new byte[1024];
				int len;
				while ((len = inStream.read(buffer)) != -1) {
					String string = new String(buffer, 0, len);
					sb.append(string);

				}
				inStream.close();
				String response = sb.toString();
				DLog.i("debug", "response : " + response);
				JSONObject rootJsonObject = new JSONObject(response);
				if (rootJsonObject != null) {
					int code = rootJsonObject.optInt("code");
					if (code == 200) {
						show = true;
						downloadUrl = rootJsonObject.optString("url");
						marketPackage = rootJsonObject.optString("package");
						String downloadPath = Constants.DOWNLOAD_PATH;
						if (!new File(downloadPath).exists()) {
							new File(downloadPath).mkdirs();
						}
						filePath = downloadPath + "/yingyongbao_verbose_1234";
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void download(Context context) {
		mContext = context;
		donwloading = true;
		error = false;
		finish = false;
		init(context);

		String apkTempPath = filePath + ".temp";
		long totalSize = 0;
		long downloadSize = 0;
		if (new File(filePath).exists()) {
			donwloading = false;
			finish = true;
			return;
		}
		try {
			URL url = new URL(downloadUrl);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setConnectTimeout(5 * 1000);
			conn.setRequestMethod("GET");
			conn.setReadTimeout(30 * 1000);
			if (conn.getResponseCode() == 200) {
				InputStream inStream = conn.getInputStream();
				FileOutputStream outputStream = new FileOutputStream(apkTempPath);
				byte[] buffer = new byte[1024];
				totalSize = conn.getContentLength();
				int len;
				while ((len = inStream.read(buffer)) != -1) {
					outputStream.write(buffer, 0, len);
					downloadSize += len;

				}
				inStream.close();
				outputStream.close();
				if (totalSize == downloadSize) {
					new File(apkTempPath).renameTo(new File(filePath));
					donwloading = false;
					finish = true;
					return;
				}
			} else {
				donwloading = false;
				finish = true;
				error = true;
			}
		} catch (Exception e) {
			donwloading = false;
			finish = true;
			error = true;
		}
	}

	public static boolean marketInstall(Context mContext) {
		PackageInfo info = null;
		try {
			info = mContext.getPackageManager().getPackageInfo(marketPackage, 0);
		} catch (NameNotFoundException e) {
		}
		return info != null ? true : false;
	}

	public static boolean isShow(Context mContext2) {
		return show;
	}
}
