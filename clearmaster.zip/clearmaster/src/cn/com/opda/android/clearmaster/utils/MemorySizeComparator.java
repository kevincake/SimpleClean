package cn.com.opda.android.clearmaster.utils;

import java.util.Comparator;

import cn.com.opda.android.clearmaster.model.AppItem;

public class MemorySizeComparator implements Comparator<AppItem> {

	@Override
	public int compare(AppItem o1, AppItem o2) {
		long num1 = o1.getMemorySize();
		long num2 = o2.getMemorySize();
		if (num1 < num2) {
			return 1;
		} else if (num1 == num2) {
			return 0;
		} else if (num1 > num2) {
			return -1;
		}
		return 0;
	}
}