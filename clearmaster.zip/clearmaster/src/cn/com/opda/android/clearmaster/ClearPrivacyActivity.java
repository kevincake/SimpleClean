package cn.com.opda.android.clearmaster;

import java.lang.reflect.Field;
import java.util.ArrayList;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.preference.PreferenceManager;
import android.provider.CallLog;
import android.provider.CallLog.Calls;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.TranslateAnimation;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import cn.com.opda.android.clearmaster.adapter.Adapter4ResultAd;
import cn.com.opda.android.clearmaster.adapter.ClearTracesAdapter;
import cn.com.opda.android.clearmaster.custom.CustomListView;
import cn.com.opda.android.clearmaster.custom.WaterWaveCustomView;
import cn.com.opda.android.clearmaster.model.AdInfo;
import cn.com.opda.android.clearmaster.model.BaseItem;
import cn.com.opda.android.clearmaster.model.ToolboxAd;
import cn.com.opda.android.clearmaster.model.TraceItem;
import cn.com.opda.android.clearmaster.utils.AppDownload;
import cn.com.opda.android.clearmaster.utils.BannerUtils;
import cn.com.opda.android.clearmaster.utils.CleanTracesUtil;
import cn.com.opda.android.clearmaster.utils.Constants;
import cn.com.opda.android.clearmaster.utils.CustomEventCommit;
import cn.com.opda.android.clearmaster.utils.DensityUtil;
import cn.com.opda.android.clearmaster.utils.ToolboxAdUtils;

import com.lib.statistics.StatisticsUtils;
import com.umeng.analytics.MobclickAgent;

/**
 * 隐私清理页面
 * 
 * @author 庄宏岩
 * 
 */
public class ClearPrivacyActivity extends BaseActivity implements OnItemClickListener, OnClickListener {
	private Context mContext;
	private ClearTracesAdapter mTracesAdapter;
	private CustomListView clear_traces_listview;
	private TextView call_count, huihua_count;
	private RelativeLayout progress_layout;
	private ProgressBar clear_line_progressbar;
	private TextView clear_textview;
	private LinearLayout result_page;
	private LinearLayout list_page;
	private WaterWaveCustomView header_waterwave_view;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_clear_privacy);
		mContext = ClearPrivacyActivity.this;
		BannerUtils.setTitle(this, R.string.title_clear_privacy);
		BannerUtils.initBackButton(this);
		initViewAndEvent();
		initAdView();
		initADListView();
		initResultImageView();
	}

	private void initViewAndEvent() {
		progress_layout = (RelativeLayout) findViewById(R.id.progress_layout);
		clear_line_progressbar = (ProgressBar) findViewById(R.id.clear_line_progressbar);
		clear_textview = (TextView) findViewById(R.id.clear_textview);

		clear_traces_listview = (CustomListView) findViewById(R.id.clear_traces_listview);
		clear_traces_listview.setOnItemClickListener(this);

		call_count = (TextView) findViewById(R.id.call_count);
		huihua_count = (TextView) findViewById(R.id.huihua_count);

		new Thread(new Runnable() {

			@Override
			public void run() {
				String where = "0==0) group by (" + Constants.SMS_thread_id;
				String[] projection = new String[] { Constants.SMS_thread_id, Constants.SMS_address, Constants.SMS_person, "COUNT(*) AS " + "COUNT" };
				Cursor cursor = getContentResolver().query(Constants.SMSAll_URL, projection, where, null, Constants.SMS_thread_id + " ASC");
				if (cursor != null) {
					final int count = cursor.getCount();
					runOnUiThread(new Runnable() {

						@Override
						public void run() {
							huihua_count.setText("" + count);
						}
					});
				}
			}
		}).start();

		new Thread(new Runnable() {

			@Override
			public void run() {
				String[] projection = new String[] { CallLog.Calls._ID, CallLog.Calls.NUMBER, CallLog.Calls.DATE, CallLog.Calls.TYPE };
				Cursor cursor = mContext.getContentResolver().query(CallLog.Calls.CONTENT_URI, projection, null, null, Calls.DEFAULT_SORT_ORDER);
				if (cursor != null) {
					final int count = cursor.getCount();
					runOnUiThread(new Runnable() {

						@Override
						public void run() {
							call_count.setText("" + count);
						}
					});
				}
			}
		}).start();

		Button clear_button = (Button) findViewById(R.id.clear_button);
		clear_button.setOnClickListener(this);

		LinearLayout sms_title_layout = (LinearLayout) findViewById(R.id.sms_title_layout);
		LinearLayout calllog_title_layout = (LinearLayout) findViewById(R.id.calllog_title_layout);
		LinearLayout picture_title_layout = (LinearLayout) findViewById(R.id.picture_title_layout);
		LinearLayout video_title_layout = (LinearLayout) findViewById(R.id.video_title_layout);
		sms_title_layout.setOnClickListener(this);
		calllog_title_layout.setOnClickListener(this);
		picture_title_layout.setOnClickListener(this);
		video_title_layout.setOnClickListener(this);

		ArrayList<TraceItem> mTraceItems = new ArrayList<TraceItem>();
		TraceItem traceItem = new TraceItem();
		traceItem.setTraceName(getString(R.string.clean_trace_browser));
		traceItem.setIcon(getResources().getDrawable(R.drawable.trace_browser));
		traceItem.setChecked(true);
		traceItem.setShowValue(false);
		mTraceItems.add(traceItem);

		traceItem = new TraceItem();
		traceItem.setTraceName(getString(R.string.clean_trace_gmailsearch));
		traceItem.setIcon(getResources().getDrawable(R.drawable.trace_gmail));
		traceItem.setChecked(true);
		traceItem.setShowValue(false);
		mTraceItems.add(traceItem);

		traceItem = new TraceItem();
		traceItem.setTraceName(getString(R.string.clean_trace_mapsearch));
		traceItem.setIcon(getResources().getDrawable(R.drawable.trace_googlemap));
		traceItem.setChecked(true);
		traceItem.setShowValue(false);
		mTraceItems.add(traceItem);

		traceItem = new TraceItem();
		traceItem.setTraceName(getString(R.string.clean_trace_marketsearch));
		traceItem.setIcon(getResources().getDrawable(R.drawable.trace_market));
		traceItem.setChecked(true);
		traceItem.setShowValue(false);
		mTraceItems.add(traceItem);

		traceItem = new TraceItem();
		traceItem.setTraceName(getString(R.string.clean_trace_clipboard));
		traceItem.setIcon(getResources().getDrawable(R.drawable.trace_clipboard));
		traceItem.setChecked(true);
		traceItem.setShowValue(false);
		mTraceItems.add(traceItem);

		mTracesAdapter = new ClearTracesAdapter(mContext, mTraceItems);
		clear_traces_listview.setAdapter(mTracesAdapter);
		clear_traces_listview.setFocusable(false);

		findViewById(R.id.back_imageview).setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				finish();
				overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
			}
		});
		findViewById(R.id.back_title).setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				finish();
				overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
			}
		});

		result_page = (LinearLayout) findViewById(R.id.result_page);
		list_page = (LinearLayout) findViewById(R.id.list_page);
		
		header_waterwave_view = (WaterWaveCustomView) findViewById(R.id.header_waterwave_view);
		header_waterwave_view.setWaterLevel(50);
		header_waterwave_view.startWave();
	}
	
	private void initResultImageView() {
		ImageView result_icon_imageview = (ImageView) findViewById(R.id.result_icon_imageview);
		int r = (int) (Math.random() * 5);
		int resId = R.drawable.result_page_icon_1;
		switch (r) {
		case 0:
			resId = R.drawable.result_page_icon_2;
			break;
		case 1:
			resId = R.drawable.result_page_icon_3;
			break;
		case 2:
			resId = R.drawable.result_page_icon_4;
			break;
		case 3:
			resId = R.drawable.result_page_icon_5;
			break;

		default:
			break;
		}
		result_icon_imageview.setImageResource(resId);
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
		TraceItem traceItem = (TraceItem) parent.getAdapter().getItem(position);
		if (!traceItem.isAcvitiy()) {
			traceItem.setChecked(!traceItem.isChecked());
			((ClearTracesAdapter) parent.getAdapter()).notifyDataSetChanged();
		}
	}

	private void clear() {
		
		new Thread(new Runnable() {
			@Override
			public void run() {
				final CleanTracesUtil cleanTracesUtil = new CleanTracesUtil(mContext);
				ArrayList<TraceItem> mTraceItems = mTracesAdapter.getSelecteList();
				for (int i = 0; i < mTraceItems.size(); i++) {
					TraceItem traceItem = mTraceItems.get(i);
					if (getString(R.string.clean_trace_browser).equals(traceItem.getTraceName())) {
						Message message = new Message();
						message.obj = traceItem.getTraceName();
						message.arg1 = i;
						message.arg2 = mTraceItems.size();
						message.what = 0;
						mHandler.sendMessage(message);
						try {
							Thread.sleep(150);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
						cleanTracesUtil.cleanCookies();
						message = new Message();
						message.obj = traceItem.getTraceName();
						message.arg1 = i;
						message.arg2 = mTraceItems.size();
						message.what = 1;
						mHandler.sendMessage(message);
					}
					if (getString(R.string.clean_trace_gmailsearch).equals(traceItem.getTraceName())) {
						Message message = new Message();
						message.obj = traceItem.getTraceName();
						message.arg1 = i;
						message.arg2 = mTraceItems.size();
						message.what = 0;
						mHandler.sendMessage(message);
						try {
							Thread.sleep(150);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
						cleanTracesUtil.cleanGmailSearchRecorder();
						message = new Message();
						message.obj = traceItem.getTraceName();
						message.arg1 = i;
						message.arg2 = mTraceItems.size();
						message.what = 1;
						mHandler.sendMessage(message);
					}
					if (getString(R.string.clean_trace_mapsearch).equals(traceItem.getTraceName())) {
						Message message = new Message();
						message.obj = traceItem.getTraceName();
						message.arg1 = i;
						message.arg2 = mTraceItems.size();
						message.what = 0;
						mHandler.sendMessage(message);
						try {
							Thread.sleep(150);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
						cleanTracesUtil.cleanMapsSearchRecorder();
						message = new Message();
						message.obj = traceItem.getTraceName();
						message.arg1 = i;
						message.arg2 = mTraceItems.size();
						message.what = 1;
						mHandler.sendMessage(message);
					}
					if (getString(R.string.clean_trace_marketsearch).equals(traceItem.getTraceName())) {
						Message message = new Message();
						message.obj = traceItem.getTraceName();
						message.arg1 = i;
						message.arg2 = mTraceItems.size();
						message.what = 0;
						mHandler.sendMessage(message);
						try {
							Thread.sleep(150);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
						cleanTracesUtil.cleanMarketSearchRecorder();
						message = new Message();
						message.obj = traceItem.getTraceName();
						message.arg1 = i;
						message.arg2 = mTraceItems.size();
						message.what = 1;
						mHandler.sendMessage(message);
					}
					if (getString(R.string.clean_trace_clipboard).equals(traceItem.getTraceName())) {
						Message message = new Message();
						message.obj = traceItem.getTraceName();
						message.arg1 = i;
						message.arg2 = mTraceItems.size();
						message.what = 0;
						mHandler.sendMessage(message);
						try {
							Thread.sleep(150);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
						runOnUiThread(new Runnable() {

							@Override
							public void run() {
								cleanTracesUtil.cleanClipboard();
							}
						});
						message = new Message();
						message.obj = traceItem.getTraceName();
						message.arg1 = i;
						message.arg2 = mTraceItems.size();
						message.what = 1;
						mHandler.sendMessage(message);
					}
				}
				mHandler.sendEmptyMessageDelayed(2, 200);
			}
		}).start();

	}

	Handler mHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			switch (msg.what) {
			case 0:
				progress_layout.setVisibility(View.VISIBLE);
				clear_line_progressbar.setMax(msg.arg2);
				clear_line_progressbar.setProgress(msg.arg1);
				clear_textview.setText(getString(R.string.clear_loading, (String) msg.obj));
				break;
			case 1:
				clear_line_progressbar.setMax(msg.arg2);
				clear_line_progressbar.setProgress(msg.arg1 + 1);
				View view = clear_traces_listview.getChildAt(msg.arg1);
				view.startAnimation(getDeleteAnim());
				break;
			case 2:
				progress_layout.setVisibility(View.INVISIBLE);
				clear_traces_listview.setVisibility(View.GONE);
				
				if(mTracesAdapter.getCount()==0){
					findViewById(R.id.clear_button).setClickable(false);
				}
				Animation animation = AnimationUtils.loadAnimation(mContext, R.anim.slide_out_left);
				Animation animation2 = AnimationUtils.loadAnimation(mContext, R.anim.slide_in_right);
				list_page.startAnimation(animation);
				result_page.startAnimation(animation2);
				list_page.setVisibility(View.GONE);
				result_page.setVisibility(View.VISIBLE);
				break;
			default:
				break;
			}
		}

	};
	
	
	private AnimationSet getDeleteAnim() {
		AnimationSet set = new AnimationSet(true);
		Animation animation = new AlphaAnimation(1.0f, 0.5f);
		animation.setDuration(300);
		set.addAnimation(animation);

		animation = new TranslateAnimation(Animation.RELATIVE_TO_SELF, 0.0f, Animation.RELATIVE_TO_SELF, -1.0f, Animation.RELATIVE_TO_SELF, 0.0f,
				Animation.RELATIVE_TO_SELF, -1.0f);
		animation.setDuration(300);
		set.addAnimation(animation);
		set.setFillAfter(true);
		return set;
	}
	
	private float lastY;
	private boolean lock = false;
	private boolean isOpen = true;
	private int result_layout_height_px;
	private ListView more_tools_listview;
	private int mFirstItemPosY;
	private LinearLayout result_layout;
	private ImageView ad_cursor_imageview;

	private void initAdView() {
		LinearLayout ad_cursor_layout = (LinearLayout) findViewById(R.id.ad_cursor_layout);
		ad_cursor_imageview = (ImageView) findViewById(R.id.ad_cursor_imageview);

		result_layout = (LinearLayout) findViewById(R.id.result_layout);
		more_tools_listview = (ListView) findViewById(R.id.more_tools_listview);

		LayoutParams resultLayoutParams = (LayoutParams) result_layout.getLayoutParams();
		DisplayMetrics dm = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(dm);
		int screenHeight = dm.heightPixels;

		/**** 获取状态栏高度 ****/
		int statusBarHeight = 0;
		Class<?> c = null;
		Object obj = null;
		Field field = null;
		try {
			c = Class.forName("com.android.internal.R$dimen");
			obj = c.newInstance();
			field = c.getField("status_bar_height");
			int x = Integer.parseInt(field.get(obj).toString());
			statusBarHeight = getResources().getDimensionPixelSize(x);
		} catch (Exception e1) {
			e1.printStackTrace();
			statusBarHeight = 0;
		}

		int ad_layout_height_px = DensityUtil.dip2px(mContext, 80 + 48 + 48) + statusBarHeight;
		result_layout_height_px = screenHeight - ad_layout_height_px;

		resultLayoutParams.height = result_layout_height_px;
		result_layout.setLayoutParams(resultLayoutParams);

		more_tools_listview.setOnTouchListener(new OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()) {
				case MotionEvent.ACTION_DOWN:
					lastY = event.getRawY();
					break;
				case MotionEvent.ACTION_UP:
					lastY = 0;
					break;
				case MotionEvent.ACTION_MOVE:
					if (!lock) {
						if (isOpen) {
							if (event.getRawY() - lastY <= -5) {
								lock = true;
								close();
							}
						} else {
							if (mFirstItemPosY == 0) {
								if (event.getRawY() - lastY >= 10) {
									lock = true;
									open();
								}
							}
						}
					}
					break;

				default:
					break;
				}
				return false;
			}
		});

		ad_cursor_layout.setOnTouchListener(new OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()) {
				case MotionEvent.ACTION_DOWN:
					lastY = event.getRawY();
					break;
				case MotionEvent.ACTION_UP:
					lastY = 0;
					break;
				case MotionEvent.ACTION_MOVE:
					if (!lock) {
						if (isOpen) {
							if (event.getRawY() - lastY <= -5) {
								lock = true;
								close();
							}
						} else {
							if (mFirstItemPosY == 0) {
								if (event.getRawY() - lastY >= 5) {
									lock = true;
									open();
								}
							}
						}
					}
					break;

				default:
					break;
				}
				return true;
			}
		});

		more_tools_listview.setOnScrollListener(new OnScrollListener() {

			@Override
			public void onScrollStateChanged(AbsListView view, int scrollState) {
				switch (scrollState) {
				case OnScrollListener.SCROLL_STATE_TOUCH_SCROLL:
					break;
				case OnScrollListener.SCROLL_STATE_IDLE: //
					View v = view.getChildAt(0);
					mFirstItemPosY = (v == null) ? 0 : v.getTop();
					break;
				}

			}

			@Override
			public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

			}
		});

		more_tools_listview.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

				BaseItem mBaseItem = (BaseItem) parent.getItemAtPosition(position);

				PackageInfo packageInfo = null;
				try {
					packageInfo = mContext.getPackageManager().getPackageInfo(mBaseItem.getPackageName(), 0);
				} catch (NameNotFoundException e) {
					e.printStackTrace();
				}
				if (packageInfo != null) {
					StatisticsUtils.commitEvent(mContext, mBaseItem.getName(), mBaseItem.getPackageName(), StatisticsUtils.AdType_ruanjianneizhi,
							StatisticsUtils.AdEvent_open);
					mContext.startActivity(mContext.getPackageManager().getLaunchIntentForPackage(mBaseItem.getPackageName()));
				} else {
					if (!mBaseItem.isDownload()) {
						StatisticsUtils.commitEvent(mContext, mBaseItem.getName(), mBaseItem.getPackageName(), StatisticsUtils.AdType_ruanjianneizhi,
								StatisticsUtils.AdEvent_show);
						AppDownload appDownload = new AppDownload(mContext);
						appDownload.setDownloadurl(mBaseItem.getApkUrl());
						appDownload.setAppName(mBaseItem.getName());
						appDownload.setPackageName(mBaseItem.getPackageName());
						appDownload.setAppIcon(mBaseItem.getIcon());
						appDownload.createNotify();
						appDownload.startDownloadApp();
						Toast.makeText(mContext, mBaseItem.getName() + mContext.getString(R.string.ad_stardonwload_tips), Toast.LENGTH_SHORT).show();
						mBaseItem.setDownload(true);
					}
				}

			}

		});
		startCursorUpAnim();

	}

	public void open() {
		final LayoutParams layoutParams = (LayoutParams) result_layout.getLayoutParams();
		new Thread(new Runnable() {

			@Override
			public void run() {
				for (int i = 1; i < 26; i++) {
					final int f = i;
					runOnUiThread(new Runnable() {

						@Override
						public void run() {
							layoutParams.height = (int) (result_layout_height_px * (1.0f * (f / 25f)));
							result_layout.setLayoutParams(layoutParams);
							result_layout.invalidate();
							if (f == 25) {
								more_tools_listview.setAdapter(adsAdapter);
								more_tools_listview.setSelection(0);
								TextView back_title = (TextView) findViewById(R.id.back_title);
								back_title.setText(R.string.clear_end_title);
								startCursorUpAnim();
							}
						}
					});
					try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				lock = false;
				isOpen = true;

			}
		}).start();
	}

	public void close() {
		final LayoutParams layoutParams = (LayoutParams) result_layout.getLayoutParams();
		new Thread(new Runnable() {

			@Override
			public void run() {
				for (int i = 1; i < 26; i++) {
					final int f = i;
					runOnUiThread(new Runnable() {

						@Override
						public void run() {
							layoutParams.height = (int) (result_layout_height_px * (1 - 1.0f * (f / 25f)));
							result_layout.setLayoutParams(layoutParams);
							result_layout.invalidate();
							if (f == 25) {
								TextView back_title = (TextView) findViewById(R.id.back_title);
								back_title.setText("更多功能");
								startCursorDownAnim();
								CustomEventCommit.commit(mContext, CustomEventCommit.result_ad_show);
							}
						}
					});
					try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				lock = false;
				isOpen = false;
			}
		}).start();
	}

	private void startCursorUpAnim() {
		ad_cursor_imageview.clearAnimation();
		ad_cursor_imageview.setImageResource(R.drawable.ad_cursor_up);
		Animation animation = AnimationUtils.loadAnimation(mContext, R.anim.cursor_up);
		animation.setStartOffset(100);
		ad_cursor_imageview.startAnimation(animation);
	}

	private void startCursorDownAnim() {
		ad_cursor_imageview.clearAnimation();
		ad_cursor_imageview.setImageResource(R.drawable.ad_cursor_down);
		Animation animation = AnimationUtils.loadAnimation(mContext, R.anim.cursor_down);
		animation.setStartOffset(100);
		ad_cursor_imageview.startAnimation(animation);
	}

	private void clearCursorAnim() {
		ad_cursor_imageview.clearAnimation();
	}

	private Adapter4ResultAd adsAdapter;

	private void initADListView() {
		ArrayList<BaseItem> mBaseItems = new ArrayList<BaseItem>();

		adsAdapter = new Adapter4ResultAd(mContext, mBaseItems);
		more_tools_listview.setAdapter(adsAdapter);

		SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(mContext);
		String toolbox_ad_json = sp.getString("result_ad_json", null);
		if (toolbox_ad_json != null) {
			ArrayList<ToolboxAd> toolboxAds = ToolboxAdUtils.getAdInfo(toolbox_ad_json);
			new GetAdsThread(toolboxAds).start();
		} else {
			new GetAdsThread(null).start();
		}
	}

	/**
	 * 获取广告列表
	 * 
	 * @author 庄宏岩
	 * 
	 */
	private class GetAdsThread extends Thread {
		private ArrayList<ToolboxAd> toolboxAds;
		private ArrayList<BaseItem> mBaseItems;

		public GetAdsThread(ArrayList<ToolboxAd> toolboxAds) {
			this.toolboxAds = toolboxAds;
			mBaseItems = new ArrayList<BaseItem>();
		}

		@Override
		public void run() {
			super.run();

			if (toolboxAds == null) {
				toolboxAds = ToolboxAdUtils.getResultAdInfo(mContext);
			}
			if (toolboxAds != null) {
				for (int i = 0; i < toolboxAds.size(); i++) {
					final BaseItem baseItem = new BaseItem();
					ToolboxAd toolboxAd = toolboxAds.get(i);
					AdInfo adInfo = getRandomAd(toolboxAd);
					PackageManager pm = mContext.getPackageManager();
					PackageInfo packageInfo = null;
					try {
						packageInfo = pm.getPackageInfo(adInfo.getPackageName(), 0);
					} catch (NameNotFoundException e) {
					}
					if (packageInfo != null) {
						adInfo = getNotInstallAd(toolboxAd);
					}
					baseItem.setName(adInfo.getAppName());
					baseItem.setPackageName(adInfo.getPackageName());
					baseItem.setDesc(adInfo.getContent());
					baseItem.setApkUrl(adInfo.getApkUrl());
					baseItem.setTitle(adInfo.getTitle());
					baseItem.setDetailUrl(adInfo.getDetailUrl());
					baseItem.setType(3);
					baseItem.setSize(adInfo.getSize());
					baseItem.setImageUrl(adInfo.getImageUrl());
					baseItem.setHtml5(adInfo.isHtml5());
					baseItem.setGameUrl(adInfo.getGameUrl());
					mBaseItems.add(baseItem);
				}
			}
			mHandler.sendEmptyMessage(1);
		}

		Handler mHandler = new Handler() {

			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				switch (msg.what) {
				case 1:
					if (mBaseItems != null && mBaseItems.size() > 0) {
						adsAdapter.getList().addAll(mBaseItems);
						adsAdapter.notifyDataSetChanged();
					} else {
						LayoutParams resultLayoutParams = (LayoutParams) result_layout.getLayoutParams();
						resultLayoutParams.height = LayoutParams.FILL_PARENT;
						result_layout.setLayoutParams(resultLayoutParams);
					}
					break;
				default:
					break;
				}

			}

		};
	}

	public AdInfo getRandomAd(ToolboxAd toolboxAd) {
		int r = (int) (Math.random() * 10 + 1);
		ArrayList<AdInfo> adInfos = toolboxAd.getAdInfos();
		if (adInfos != null && adInfos.size() > 0) {
			for (AdInfo adInfo : adInfos) {
				if (r >= adInfo.getWeight_l() && r <= adInfo.getWeight_r()) {
					return adInfo;
				}
			}
		}
		return null;
	}

	public AdInfo getNotInstallAd(ToolboxAd toolboxAd) {
		ArrayList<AdInfo> adInfos = toolboxAd.getAdInfos();
		PackageManager pm = mContext.getPackageManager();
		if (adInfos != null && adInfos.size() > 0) {
			for (AdInfo adInfo : adInfos) {
				PackageInfo packageInfo = null;
				try {
					packageInfo = pm.getPackageInfo(adInfo.getPackageName(), 0);
				} catch (NameNotFoundException e) {
				}
				if (packageInfo == null) {
					return adInfo;
				}

			}
			return adInfos.get(0);
		}
		return null;
	}

	@Override
	protected void onResume() {
		MobclickAgent.onResume(this);
		super.onResume();
	}

	@Override
	protected void onPause() {
		MobclickAgent.onPause(this);
		super.onPause();
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.clear_button:
			findViewById(R.id.clear_button).setClickable(false);
			clear();
			break;
		case R.id.sms_title_layout:
			startActivity(new Intent(mContext, ClearConversationActivity.class));
			break;
		case R.id.video_title_layout:
			startActivity(new Intent(mContext, VideoPrivacyManager.class));
			break;
		case R.id.picture_title_layout:
			startActivity(new Intent(mContext, PicPrivacyManager.class));
			break;
		case R.id.calllog_title_layout:
			startActivity(new Intent(mContext, ClearPhoneLogActivity.class));
			break;

		default:
			break;
		}
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		clearCursorAnim();
		header_waterwave_view.stoptWave();
	}
	
	

}
