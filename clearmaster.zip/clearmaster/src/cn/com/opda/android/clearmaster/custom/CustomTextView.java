package cn.com.opda.android.clearmaster.custom;

import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.TextView;

/**
 * 自定义textview
 * @author 庄宏岩
 *
 */
public class CustomTextView extends TextView {

	public CustomTextView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		setTypeFace(context);
		setShadowLayer();
	}

	public CustomTextView(Context context, AttributeSet attrs) {
		super(context, attrs);
		setTypeFace(context);
		setShadowLayer();
	}

	public CustomTextView(Context context) {
		super(context);
		setTypeFace(context);
		setShadowLayer();
	}
	
	public void setTypeFace(Context context){
		setTypeface(Typeface.createFromAsset(context.getAssets(), "font/ITCBook.ttf"));
	}
	
	public void setShadowLayer(){
		setShadowLayer(2, 2, 4, 0x50000000);
	}

}
