package cn.com.opda.android.clearmaster.utils;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import cn.com.opda.android.clearmaster.R;
import cn.com.opda.android.clearmaster.model.AppItem;
import cn.com.opda.android.clearmaster.model.VerboseApp;

/**
 * 图片缩放工具类
 * @author 庄宏岩
 *
 */
public class DrawableUtils {

	// 放大缩小图片
	public static Bitmap scaleTo(final Bitmap bitmapOrg, final int newWidth, final int newHeight) {
		int width = bitmapOrg.getWidth();
		int height = bitmapOrg.getHeight();
		float scaleWidth = ((float) newWidth) / width;
		float scaleHeight = ((float) newHeight) / height;
		Matrix matrix = new Matrix();
		matrix.postScale(scaleWidth, scaleHeight);

		Bitmap b = Bitmap.createBitmap(bitmapOrg, 0, 0, width, height, matrix, true);

		return b;
	}

	public static Bitmap byte2Bitmap(Context mContext, byte[] b) {
		if (b != null) {
			if (b.length != 0) {
				return BitmapFactory.decodeByteArray(b, 0, b.length);
			} else {
				return BitmapFactory.decodeResource(mContext.getResources(), android.R.drawable.sym_def_app_icon);
			}
		}
		return BitmapFactory.decodeResource(mContext.getResources(), android.R.drawable.sym_def_app_icon);
	}

	public static Bitmap drawable2Bitmap(Context mContext, Drawable drawable) {
		return ((BitmapDrawable) drawable).getBitmap();
	}

	public static byte[] drawable2Byte(Drawable icon) {
		Bitmap bitmap = ((BitmapDrawable) icon).getBitmap();
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
		return baos.toByteArray();
	}

	public static byte[] bitmap2Byte(Bitmap bitmap) {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
		return baos.toByteArray();
	}

	public static Drawable byte2Drawable(Context mContext, byte[] b) {
		if (b != null) {
			if (b.length != 0) {
				Bitmap bitmap = BitmapFactory.decodeByteArray(b, 0, b.length);
				return new BitmapDrawable(mContext.getResources(), bitmap);
			} else {
				return null;
			}
		}
		return null;
	}

	public static Bitmap drawFolderBitmap(Context mContext, VerboseApp verboseApp) {

		List<AppItem> list = verboseApp.getAppItems();
		if (list == null || list.size() == 0) {
			return BitmapFactory.decodeResource(mContext.getResources(), R.drawable.folder_add);
		}
		if(list!=null&&list.size()==1){
			return drawable2Bitmap(mContext, verboseApp.getAppItems().get(0).getAppIcon());
		}
		Bitmap bitmap = BitmapFactory.decodeResource(mContext.getResources(), R.drawable.folder_bg);
		final int width = bitmap.getWidth();
		Bitmap copyBitmap = bitmap.copy(Config.ARGB_8888, true);
		Canvas canvas = new Canvas(copyBitmap);
		bitmap.recycle();

		int x = width / 8;
		int w = width / 2 - x;
		int[] posX = { x, x + w, x, x + w };
		int[] posY = { x, x, x + w, x + w };

		for (int i = 0; i < list.size(); i++) {
			if (i > 3) {
				break;
			}
			final AppItem info = list.get(i);
			if (info != null) {
				Bitmap bmp = scaleTo(drawable2Bitmap(mContext, info.getAppIcon()), w, w);
				canvas.drawBitmap(bmp, posX[i], posY[i], null);

			}
		}
		canvas.save(Canvas.ALL_SAVE_FLAG);// 保存
		canvas.restore();// 存储

		int px_X = (int) mContext.getResources().getDimension(android.R.dimen.app_icon_size);
		int px_Y = px_X;
		if (copyBitmap.getWidth() > px_X) {
			if (copyBitmap.getWidth() > copyBitmap.getHeight()) {
				px_Y = px_X * copyBitmap.getHeight() / copyBitmap.getWidth();
			} else {
				px_Y = px_X * copyBitmap.getWidth() / copyBitmap.getHeight();
			}
		}
		Bitmap newbmp = scaleTo(copyBitmap, px_X, px_Y);
		copyBitmap.recycle();
		return newbmp;
	}
	
	
	
	public static Bitmap drawFolderBitmap(Context mContext,ArrayList<AppItem> list) {
		if (list == null || list.size() == 0) {
			return BitmapFactory.decodeResource(mContext.getResources(), R.drawable.folder_bg);
		}
		Bitmap bitmap = BitmapFactory.decodeResource(mContext.getResources(), R.drawable.folder_bg);
		final int width = bitmap.getWidth();
		Bitmap copyBitmap = bitmap.copy(Config.ARGB_8888, true);
		Canvas canvas = new Canvas(copyBitmap);
		bitmap.recycle();

		int x = width / 8;
		int w = width / 2 - x;
		int[] posX = { x, x + w, x, x + w };
		int[] posY = { x, x, x + w, x + w };

		for (int i = 0; i < list.size(); i++) {
			if (i > 3) {
				break;
			}
			final AppItem info = list.get(i);
			if (info != null) {
				Bitmap bmp = scaleTo(drawable2Bitmap(mContext, info.getAppIcon()), w, w);
				canvas.drawBitmap(bmp, posX[i], posY[i], null);

			}
		}
		canvas.save(Canvas.ALL_SAVE_FLAG);// 保存
		canvas.restore();// 存储

		int px_X = (int) mContext.getResources().getDimension(android.R.dimen.app_icon_size);
		int px_Y = px_X;
		if (copyBitmap.getWidth() > px_X) {
			if (copyBitmap.getWidth() > copyBitmap.getHeight()) {
				px_Y = px_X * copyBitmap.getHeight() / copyBitmap.getWidth();
			} else {
				px_Y = px_X * copyBitmap.getWidth() / copyBitmap.getHeight();
			}
		}
		Bitmap newbmp = scaleTo(copyBitmap, px_X, px_Y);
		copyBitmap.recycle();
		return newbmp;
	}

}
