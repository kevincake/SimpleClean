package cn.com.opda.android.clearmaster.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 日期格式化工具类
 * @author 庄宏岩
 *
 */
public class DateUtils {

	public static SimpleDateFormat getDefaultDateFormatInstance() {
		return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	}

	/**
	 * 将毫秒转成yyyy-MM-dd HH:mm:ss的时间格式
	 * 
	 * @param date
	 *            毫秒
	 * @return
	 */
	public static String parseLongtoTime(long date) {
		return getDefaultDateFormatInstance().format(new Date(date));
	}
	public static SimpleDateFormat getDefaultDateFormatInstance_ForMonth() {
		return new SimpleDateFormat("MM-dd HH:mm:ss");
	}
	public static String parseLongtoTime_ForMonth(long date) {
		return getDefaultDateFormatInstance_ForMonth().format(new Date(date));
	}
	/**
	 * 将毫秒转成制定的时间格式
	 * 
	 * @param format
	 *            时间格式
	 * @param date
	 *            毫秒
	 * @return
	 */
	public static String parseLongByFormat(String format, long date) {
		SimpleDateFormat dateFormat = new SimpleDateFormat(format);
		return dateFormat.format(new Date(date));
	}

}
