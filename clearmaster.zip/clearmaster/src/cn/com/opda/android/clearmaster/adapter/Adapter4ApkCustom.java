package cn.com.opda.android.clearmaster.adapter;

import java.util.ArrayList;

import android.content.Context;
import android.content.res.Resources.NotFoundException;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import cn.com.opda.android.clearmaster.R;
import cn.com.opda.android.clearmaster.impl.SelectListener;
import cn.com.opda.android.clearmaster.model.AppItem;
import cn.com.opda.android.clearmaster.model.GroupItem;
import cn.com.opda.android.clearmaster.utils.FormatUtils;

public class Adapter4ApkCustom extends BaseExpandableListAdapter {
	private ArrayList<GroupItem> groupArray;// 组列表
	private ArrayList<ArrayList<AppItem>> childArray;// 子列表
	private Context mContext;
	private LayoutInflater mLayoutInflater;
	private SelectListener selectListener;
	private boolean check = false;
	private Drawable defaultIcon;

	public Adapter4ApkCustom(Context mContext,
			ArrayList<GroupItem> groupArray,
			ArrayList<ArrayList<AppItem>> childArray) {
		this.groupArray = groupArray;
		this.childArray = childArray;
		this.mContext = mContext;
		this.mLayoutInflater = LayoutInflater.from(mContext);
		defaultIcon = mContext.getResources().getDrawable(android.R.drawable.sym_def_app_icon);
	}

	public void setSelectListener(SelectListener selectListener) {
		this.selectListener = selectListener;
	}

	public void updateListView(ArrayList<ArrayList<AppItem>> childArray) {
		this.childArray = childArray;
		notifyDataSetChanged();
	}

	@Override
	public int getGroupCount() {
		return groupArray.size();
	}

	@Override
	public int getChildrenCount(int groupPosition) {
		return childArray.get(groupPosition).size();
	}

	@Override
	public Object getGroup(int groupPosition) {
		return groupArray.get(groupPosition);
	}

	@Override
	public Object getChild(int groupPosition, int childPosition) {
		return childArray.get(groupPosition).get(childPosition);
	}

	@Override
	public long getGroupId(int groupPosition) {
		return groupPosition;
	}

	@Override
	public long getChildId(int groupPosition, int childPosition) {
		return childPosition;
	}

	@Override
	public boolean hasStableIds() {
		return false;
	}

	public void updateSelectApkSize() {
		long totalSize = 0;
		for (ArrayList<AppItem> appItems : childArray) {
			if (appItems != null && appItems.size() > 0) {
				for (AppItem appItem : appItems) {
					if (appItem != null && appItem.isChecked()) {
						totalSize += appItem.getCodeSize();
					}
				}
			}
		}
		selectListener.selectSize(totalSize);
	}
	
	public ArrayList<AppItem> getSelectApkList() {
		ArrayList<AppItem> appItems = new ArrayList<AppItem>();
		for (int i = 0; i < groupArray.size(); i++) {
			for (AppItem appItem : childArray.get(i)) {
				if (appItem.isChecked()) {
					appItems.add(appItem);
				}
			}
		}
		return appItems;
	}

	public void remove(int groupPosition, int childPosition) {
		childArray.get(groupPosition).remove(childPosition);
		groupArray.get(groupPosition).setCount(
				childArray.get(groupPosition).size());
		notifyDataSetChanged();

	}

	public void remove(AppItem appItem) {
		for (int i = 0; i < groupArray.size(); i++) {
			for (int j = 0; j < childArray.get(i).size(); j++) {
				if (childArray.get(i).get(j).getFilePath()
						.equals(appItem.getFilePath())) {
					childArray.get(i).remove(j);
					notifyDataSetChanged();
				}
			}
		}
	}

	@Override
	public View getGroupView(final int groupPosition, boolean isExpanded,
			View convertView, ViewGroup parent) {

		final GroupHolder mHolder;
		if (convertView == null) {
			convertView = mLayoutInflater.inflate(R.layout.expandlistview_apk_layout, null);
			mHolder = new GroupHolder();
			mHolder.clear_trash_group_title_textview = (TextView) convertView.findViewById(R.id.apk_Title_White);
			mHolder.clear_trash_group_icon_imageview = (ImageView) convertView
					.findViewById(R.id.clear_trash_group_icon_imageview);
			mHolder.uninstall_all_item_checkbox = (CheckBox) convertView.findViewById(R.id.app_install_item_checked_imageview);
			convertView.setTag(mHolder);
		} else {
			mHolder = (GroupHolder) convertView.getTag();
		}
		final GroupItem groupItem = groupArray.get(groupPosition);
		final ArrayList<AppItem> allChild = childArray.get(groupPosition);
		mHolder.clear_trash_group_title_textview.setText(groupItem.getTitle());
		mHolder.clear_trash_group_icon_imageview.setImageDrawable(groupItem.getIcon());
		
		for (int i = 0; i < allChild.size(); i++) {
			if (allChild.get(i).isChecked()) {
				groupItem.setChecked(true);
				mHolder.uninstall_all_item_checkbox.setChecked(true);
			} else {
				groupItem.setChecked(false);
				mHolder.uninstall_all_item_checkbox.setChecked(false);
				break;
			}
		}
		
		mHolder.uninstall_all_item_checkbox.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				mHolder.uninstall_all_item_checkbox.setChecked(!check);
				for (int i = 0; i < allChild.size(); i++) {
					allChild.get(i).setChecked(!check);
					groupItem.setChecked(!check);
				}
				check = !check;
				notifyDataSetChanged();
			}
		});

		return convertView;

	}

	@Override
	public View getChildView(final int groupPosition, int childPosition,
			boolean isLastChild, View convertView, ViewGroup parent) {
		final Holder mHolder;
		if (convertView == null) {
			convertView = mLayoutInflater.inflate(R.layout.listview_app_install_item_layout, null);
			mHolder = new Holder();
			mHolder.app_install_item_appname_textview = (TextView) convertView.findViewById(R.id.app_install_item_appname_textview);
			mHolder.app_install_item_size_textview = (TextView) convertView.findViewById(R.id.app_install_item_size_textview);
			mHolder.app_install_item_appversion_textview = (TextView) convertView.findViewById(R.id.app_install_item_appversion_textview);
			mHolder.app_install_item_icon_imageview = (ImageView) convertView.findViewById(R.id.app_install_item_icon_imageview);
			mHolder.app_install_item_checked_imageview = (CheckBox) convertView.findViewById(R.id.app_install_item_checked_imageview);
			convertView.setTag(mHolder);
		} else {
			mHolder = (Holder) convertView.getTag();
		}

		final AppItem appItem = childArray.get(groupPosition).get(childPosition);

		mHolder.app_install_item_appname_textview.setText(appItem.getAppName());
		mHolder.app_install_item_size_textview.setText(FormatUtils.formatBytesInByte(appItem.getCodeSize()));
		mHolder.app_install_item_icon_imageview.setImageDrawable(appItem.getAppIcon());
		mHolder.app_install_item_appversion_textview.setText(appItem.getAppVersion());
		mHolder.app_install_item_checked_imageview.setChecked(appItem.isChecked());
		mHolder.app_install_item_checked_imageview
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						appItem.setChecked(mHolder.app_install_item_checked_imageview.isChecked());
						notifyDataSetChanged();

					}
				});
		
		if (appItem.getAppIcon() == null) {
			mHolder.app_install_item_icon_imageview.setImageDrawable(defaultIcon);
			mHolder.imageLoader = new AsyncTask<Holder, Void, Drawable>() {
				private Holder holder;

				@Override
				protected Drawable doInBackground(Holder... params) {
					holder = params[0];
					if (appItem.getApplicationInfo() != null) {
						Drawable drawable = null;
						try {
							drawable = appItem.getResources().getDrawable(appItem.getApplicationInfo().icon);
						} catch (NotFoundException e) {
							e.printStackTrace();
						}
						return drawable;
					} else {
						return null;
					}

				}

				@Override
				protected void onPostExecute(Drawable result) {
					if (result != null) {
						appItem.setAppIcon(result);
						holder.app_install_item_icon_imageview.setImageDrawable(result);
					}
				}
			}.execute(mHolder);
		} else {
			mHolder.app_install_item_icon_imageview.setImageDrawable(appItem.getAppIcon());
		}

		return convertView;

	}

	@Override
	public boolean isChildSelectable(int groupPosition, int childPosition) {
		return true;
	}

	class Holder {
		private TextView app_install_item_appname_textview;
		private TextView app_install_item_size_textview;
		private TextView app_install_item_appversion_textview;
		private ImageView app_install_item_icon_imageview;
		private CheckBox app_install_item_checked_imageview;
		AsyncTask<Holder, Void, Drawable> imageLoader;
	}

	private class GroupHolder {
		private TextView clear_trash_group_title_textview;
		private ImageView clear_trash_group_icon_imageview;
		private CheckBox uninstall_all_item_checkbox;
	}

}
