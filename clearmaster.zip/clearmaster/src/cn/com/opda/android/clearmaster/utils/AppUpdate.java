//package cn.com.opda.android.clearmaster.utils;
//
//import java.io.File;
//import java.io.FileOutputStream;
//import java.io.InputStream;
//import java.net.HttpURLConnection;
//import java.net.URL;
//import java.util.HashMap;
//import java.util.Map;
//
//import org.json.JSONObject;
//
//import android.app.Notification;
//import android.app.NotificationManager;
//import android.app.PendingIntent;
//import android.content.Context;
//import android.content.Intent;
//import android.content.pm.PackageInfo;
//import android.content.pm.PackageManager;
//import android.net.Uri;
//import android.os.Environment;
//import android.os.Handler;
//import android.os.Message;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.View.OnClickListener;
//import android.widget.RemoteViews;
//import android.widget.TextView;
//import android.widget.Toast;
//import cn.com.opda.android.clearmaster.R;
//import cn.com.opda.android.clearmaster.custom.CustomDialog;
//import cn.com.opda.android.clearmaster.custom.IOSProgressDialog;
//import cn.com.opda.android.clearmaster.http.CustomHttpClient;
//import cn.com.opda.android.clearmaster.http.CustomHttpUtil;
//
///**
// * 软件自身的自动更新类
// * 
// * @author 庄宏岩
// */
//public class AppUpdate {
//	public Context mContext;
//	private boolean autoCheck; // 是否是后台检查 true：后台检查，不显示等待框，false：手动检查更新，显示等待框。
//	private IOSProgressDialog dialog;
//	private String appUrl; // 更新包的下载url
//	private String appversion; // 更新包的版本
//	private String updateNote; // 更新包的更新日志
//	private String updateDate;// 更新时间
//	private final int NF_ID = 1003;
//	private Notification nf;
//	private NotificationManager nm;
//
//	public AppUpdate(Context context) {
//		this.mContext = context;
//
//		nf = new Notification(R.drawable.notify_download, "", System.currentTimeMillis());
//		nf.icon = android.R.drawable.stat_sys_download;
//		nf.flags = Notification.FLAG_NO_CLEAR;
//		nf.contentView = new RemoteViews(mContext.getPackageName(), R.layout.notification_layout);
//		nf.contentView.setProgressBar(R.id.progressbar_notification, 100, 0, false);
//		nf.contentView.setTextViewText(R.id.textivew_notification, mContext.getString(R.string.appupdate_download_progress, "0"));
//		nf.contentIntent = PendingIntent.getActivity(mContext, 0, new Intent(), 0);
//		nm = (NotificationManager) mContext.getSystemService(Context.NOTIFICATION_SERVICE);
//	}
//
//	/**
//	 * 检查更新
//	 * 
//	 * @param context
//	 */
//	public void checkUpdate(boolean autoCheck) {
//		this.autoCheck = autoCheck;
//		if (!autoCheck) {
//			dialog = new IOSProgressDialog(mContext, R.string.appupdate_checking);
//			dialog.setCancelable(false);
//			dialog.show();
//		}
//		new Thread(new Runnable() {
//			@Override
//			public void run() {
//				try {
//					PackageManager packageManager = mContext.getPackageManager();
//					PackageInfo packageInfo = packageManager.getPackageInfo(mContext.getPackageName(), 0);
//					JSONObject value = new BaseJsonUtil(mContext).commonRequest();
//					if ("CN".equals(mContext.getResources().getConfiguration().locale.getCountry())) {
//						value.put("locale", "zh");
//					} else {
//						value.put("locale", "en");
//					}
//					Map<String, String> params = new HashMap<String, String>();
//					String response = null;
//					params.put("json", value.toString());
//					params.put("appversion", packageInfo != null ? packageInfo.versionCode + "" : 0 + "");
//					params.put("appcode", Constants.UPDATE_APPCODE);
//
//					response = CustomHttpUtil.sendPostRequest("http://api.kfkx.net/app/update", params, CustomHttpClient.UTF8, mContext);
//
//					new BaseJsonUtil(mContext).parseResponse(response);
//					JSONObject jsonObject = new JSONObject(response).optJSONObject("update");
//					if (jsonObject == null) {
//						mHandler.sendEmptyMessage(2);
//					} else {
//						appUrl = jsonObject.getString("url");
//						appversion = jsonObject.getString("version_name");
//						updateNote = jsonObject.getString("releasenote");
//						updateDate = jsonObject.getString("releasedate");
//						mHandler.sendEmptyMessage(1);
//					}
//				} catch (Exception e) {
//					mHandler.sendEmptyMessage(0);
//					e.printStackTrace();
//				}
//			}
//		}).start();
//	}
//
//	private Handler mHandler = new Handler() {
//
//		@Override
//		public void handleMessage(Message msg) {
//			super.handleMessage(msg);
//			switch (msg.what) {
//			case 0: {
//				if (!autoCheck && dialog != null) {
//					dialog.dismiss();
//				}
//				if (!autoCheck) {
//					Toast.makeText(mContext, R.string.appupdate_checked_error, Toast.LENGTH_SHORT).show();
//				}
//				break;
//			}
//			case 1: {
//				if (!autoCheck && dialog != null) {
//					dialog.dismiss();
//				}
//				LayoutInflater inflater = LayoutInflater.from(mContext);
//				View view = inflater.inflate(R.layout.app_update_dialog, null);
//				TextView app_version_name = (TextView) view.findViewById(R.id.app_version_name);
//				TextView app_update_date = (TextView) view.findViewById(R.id.app_update_date);
//				TextView app_update_note = (TextView) view.findViewById(R.id.app_update_note);
//				app_version_name.setText(mContext.getString(R.string.appupdate_version, appversion));
//				updateDate = updateDate.substring(0, updateDate.lastIndexOf(" "));
//				app_update_date.setText(mContext.getString(R.string.appupdate_date, updateDate));
//				app_update_note.setText(mContext.getString(R.string.appupdate_content, updateNote));
//				final CustomDialog bd = new CustomDialog(mContext);
//				bd.setTitle(R.string.appupdate_title);
//				bd.setCancelable(true);
//				bd.setView(view);
//				bd.setButton1(R.string.appupdate_button_next, null);
//				bd.setButton2(R.string.appupdate_button_update, new OnClickListener() {
//					@Override
//					public void onClick(View v) {
//						bd.dismiss();
//						updateApp();
//					}
//				});
//				bd.show();
//				break;
//			}
//			case 2: {
//				if (!autoCheck && dialog != null) {
//					dialog.dismiss();
//				}
//				if (!autoCheck) {
//					Toast.makeText(mContext, R.string.appupdate_result_new, Toast.LENGTH_SHORT).show();
//				}
//				break;
//			}
//			case 3: {
//				nm.cancel(NF_ID);
//				Toast.makeText(mContext, R.string.appupdate_result_download_error, Toast.LENGTH_SHORT).show();
//				break;
//			}
//			case 4: {
//				nf.contentView.setProgressBar(R.id.progressbar_notification, 100, (Integer) msg.obj, false);
//				nf.contentView.setTextViewText(R.id.textivew_notification, mContext.getString(R.string.appupdate_download_progress, msg.obj));
//				nm.notify(NF_ID, nf);
//				break;
//			}
//			case 5: {
//				Intent intent = new Intent();
//				intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//				intent.setAction(android.content.Intent.ACTION_VIEW);
//				File file = new File((String) msg.obj);
//				if (file.exists() && file.isAbsolute()) {
//					intent.setDataAndType(Uri.fromFile(file), "application/vnd.android.package-archive");
//					mContext.startActivity(intent);
//				}
//				Toast.makeText(mContext, R.string.appupdate_result_download_succeed, Toast.LENGTH_SHORT).show();
//				nm.cancel(NF_ID);
//				break;
//			}
//			default:
//				break;
//			}
//		}
//	};
//
//	private void updateApp() {
//
//		Message msg2 = new Message();
//		msg2.obj = 0;
//		msg2.what = 4;
//		mHandler.sendMessage(msg2);
//		new Thread(new Runnable() {
//			@Override
//			public void run() {
//				String path = appUrl;
//				String apkName = path.substring(path.lastIndexOf("/"), path.length());
//				String apkPath = Environment.getExternalStorageDirectory() + "/" + apkName;
//				long totalSize = 0;
//				long downloadSize = 0;
//				long progress = 0;
//				try {
//					URL url = new URL(appUrl);
//					HttpURLConnection conn = (HttpURLConnection) url.openConnection();
//					conn.setConnectTimeout(5 * 1000);
//					conn.setRequestMethod("GET");
//					conn.setReadTimeout(30 * 1000);
//					if (conn.getResponseCode() == 200) {
//						InputStream inStream = conn.getInputStream();
//						FileOutputStream outputStream = new FileOutputStream(apkPath);
//						byte[] buffer = new byte[1024];
//						totalSize = conn.getContentLength();
//						int len;
//						while ((len = inStream.read(buffer)) != -1) {
//							outputStream.write(buffer, 0, len);
//							downloadSize += len;
//							int newProgress = (int) ((100 * downloadSize) / totalSize);
//							if (newProgress - 1 > progress) {
//								progress = newProgress;
//								Message msg = new Message();
//								msg.obj = newProgress;
//								msg.what = 4;
//								mHandler.sendMessage(msg);
//							}
//						}
//						inStream.close();
//						outputStream.close();
//						if (totalSize == downloadSize) {
//							Message msg = new Message();
//							msg.what = 5;
//							msg.obj = apkPath;
//							mHandler.sendMessage(msg);
//						}
//					} else {
//						mHandler.sendEmptyMessage(3);
//					}
//				} catch (Exception e) {
//					mHandler.sendEmptyMessage(3);
//					e.printStackTrace();
//				}
//			}
//		}).start();
//
//	}
//}
