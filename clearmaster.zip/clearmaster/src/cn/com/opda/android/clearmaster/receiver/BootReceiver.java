package cn.com.opda.android.clearmaster.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.preference.PreferenceManager;
import cn.com.opda.android.clearmaster.dao.AppNetFlowDBUtils;
import cn.com.opda.android.clearmaster.service.ReadStartUpService;
import cn.com.opda.android.clearmaster.service.ShakeClearService;
import cn.com.opda.android.clearmaster.utils.ClearUtils;
import cn.com.opda.android.clearmaster.utils.CommitMissModelUtils;
import cn.com.opda.android.clearmaster.utils.Constants;
import cn.com.opda.android.clearmaster.utils.DLog;

public class BootReceiver extends BroadcastReceiver {

	@Override
	public void onReceive(final Context context, Intent intent) {
		if (intent != null) {
			String action = intent.getAction();
			DLog.i("debug", "action: " + action);
			if (("android.net.conn.CONNECTIVITY_CHANGE").equals(action)) {
				ClearUtils.showClearNotify2(context);
				ClearUtils.showProcessNotify(context);
				
				SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);

				if (!sp.getBoolean("miss_model_commit", false)) {
					new Thread(new Runnable() {
						@Override
						public void run() {
							try {
								new CommitMissModelUtils(context).commit();
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					}).start();
				}
			}

			if (("android.intent.action.BOOT_COMPLETED").equals(action)) {
				if (context.getSharedPreferences(Constants.SHARED_PREFERENCES_NAME, Context.MODE_PRIVATE).getBoolean(Constants.SHAKE_STATE_CACHE, false)) {
					context.startService(new Intent(context, ShakeClearService.class));
				}

				if (!ReadStartUpService.start) {
					context.startService(new Intent(context, ReadStartUpService.class));
				}
			}
		}
	}

}
