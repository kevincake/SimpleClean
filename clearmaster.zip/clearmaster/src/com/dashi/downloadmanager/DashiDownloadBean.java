package com.dashi.downloadmanager;

public class DashiDownloadBean {

	public String filename = "";
	public boolean isdownlaoding = false;
	public String filepath = "";
	public int download_progress = 0;
	public long file_size = 0;
	public String download_url = "";
	public String packname = "";
	public int position = -1;
	public int id = 0;
}
