package cn.com.opda.android.clearmaster;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.preference.PreferenceManager;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import cn.com.opda.android.clearmaster.custom.ClearResultDialog;
import cn.com.opda.android.clearmaster.model.ClearResult;
import cn.com.opda.android.clearmaster.utils.ClearUtils;
import cn.com.opda.android.clearmaster.utils.FormatUtils;
import cn.com.opda.android.clearmaster.utils.MemoryUtils;
import cn.com.opda.android.clearmaster.utils.ProcessManagerUtils;

import com.umeng.analytics.MobclickAgent;

/**
 * 快捷方式清理类(小火箭)
 * 
 * @author 庄宏岩
 * 
 */
public class ClearShortcutActivity extends Activity {
	private ImageView smoke_imageview, fire_imageview;
	private LinearLayout rocket_layout;
	private Context mContext;
	private String freeMemorySize;
	private static final int END = 0;
	private boolean animEnd = false;
	private ClearResult clearResult;
	private SharedPreferences sp;
	private ClearResultDialog clearResultDialog;
	private View view;
	private String percent;

	Handler mHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			switch (msg.what) {
			case 0:
				if (clearResultDialog != null) {
					AlphaAnimation alphaAnimation = new AlphaAnimation(1.0f, 0.0f);
					alphaAnimation.setDuration(500);
					alphaAnimation.setFillAfter(true);
					alphaAnimation.setAnimationListener(new AnimationListener() {

						@Override
						public void onAnimationStart(Animation animation) {

						}

						@Override
						public void onAnimationRepeat(Animation animation) {

						}

						@Override
						public void onAnimationEnd(Animation animation) {
							if (view != null) {
								// view.clearAnimation();
								clearResultDialog.dismiss();
								finish();
								overridePendingTransition(Animation.INFINITE, Animation.INFINITE);
							}
						}
					});
					if (view != null) {
						view.startAnimation(alphaAnimation);
					}
				}
				break;

			default:
				break;
			}
		}

	};

	Handler handler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			switch (msg.what) {
			case END:
				findViewById(R.id.root_layout).setVisibility(View.GONE);
				sp.edit().putLong("shortcut_last_clear_time", System.currentTimeMillis()).commit();

				clearResultDialog = new ClearResultDialog(ClearShortcutActivity.this);
				clearResultDialog.setOnCancelListener(new OnCancelListener() {

					@Override
					public void onCancel(DialogInterface dialog) {
						mHandler.removeMessages(0);
						finish();
						overridePendingTransition(Animation.INFINITE, Animation.INFINITE);
					}
				});
				if (clearResult != null) {
					clearResultDialog.setResult(clearResult.getCount(), freeMemorySize, percent);
				} else {
					clearResultDialog.setResult(0, freeMemorySize, "");
				}
				clearResultDialog.show();
				view = clearResultDialog.getView();
				mHandler.sendEmptyMessageDelayed(0, 2000);
				break;

			default:
				break;
			}
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		overridePendingTransition(Animation.INFINITE, Animation.INFINITE);
		setContentView(R.layout.clear_activity);
		mContext = ClearShortcutActivity.this;
		sp = PreferenceManager.getDefaultSharedPreferences(this);
		sp.edit().putLong("lastProcessTipTime", System.currentTimeMillis()).commit();
		initViewAndEvent();
	}

	private void initViewAndEvent() {
		smoke_imageview = (ImageView) findViewById(R.id.smoke_imageview);
		smoke_imageview.setVisibility(View.GONE);
		fire_imageview = (ImageView) findViewById(R.id.fire_imageview);

		rocket_layout = (LinearLayout) findViewById(R.id.rocket_layout);

		rocket_layout.getViewTreeObserver().addOnGlobalLayoutListener(new OnGlobalLayoutListener() {
			@SuppressWarnings("deprecation")
			@Override
			public void onGlobalLayout() {
				quickClean();

				rocket_layout.getViewTreeObserver().removeGlobalOnLayoutListener(this);

				TranslateAnimation animation = new TranslateAnimation(0, 0, 0, -rocket_layout.getTop() - rocket_layout.getHeight() - 200);
				animation.setDuration(1600);
				animation.setFillAfter(true);
				animation.setInterpolator(new AccelerateInterpolator());

				animation.setAnimationListener(new AnimationListener() {

					@Override
					public void onAnimationStart(Animation animation) {

					}

					@Override
					public void onAnimationRepeat(Animation animation) {

					}

					@Override
					public void onAnimationEnd(Animation animation) {
						animEnd = true;

					}
				});
				rocket_layout.startAnimation(animation);

				AlphaAnimation alphaAnimation = new AlphaAnimation(0.0f, 1.0f);
				alphaAnimation.setDuration(100);
				alphaAnimation.setStartOffset(400);
				alphaAnimation.setInterpolator(new AccelerateInterpolator());
				alphaAnimation.setFillAfter(true);

				final AlphaAnimation alphaAnimation2 = new AlphaAnimation(1.0f, 0.0f);
				alphaAnimation2.setDuration(800);
				alphaAnimation2.setInterpolator(new AccelerateInterpolator());
				alphaAnimation2.setFillAfter(true);

				smoke_imageview.setVisibility(View.VISIBLE);
				smoke_imageview.startAnimation(alphaAnimation);
				alphaAnimation.setAnimationListener(new AnimationListener() {

					@Override
					public void onAnimationStart(Animation animation) {

					}

					@Override
					public void onAnimationRepeat(Animation animation) {

					}

					@Override
					public void onAnimationEnd(Animation animation) {
						smoke_imageview.startAnimation(alphaAnimation2);
					}
				});

				new Thread(new Runnable() {

					@Override
					public void run() {
						try {
							Thread.sleep(300);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
						runOnUiThread(new Runnable() {

							@Override
							public void run() {
								fire_imageview.setImageResource(R.drawable.fire_big);
							}
						});
					}
				}).start();

			}
		});
	}

	private void quickClean() {
		new Thread() {

			public void run() {

				if (System.currentTimeMillis() - sp.getLong("shortcut_last_clear_time", 0) > 60 * 1000) {

					try {
						clearResult = ProcessManagerUtils.killProcessList(mContext);
						long memory = clearResult.getMemory();
						int p = (int) (memory * 100 / MemoryUtils.getRuntimeTotalMemory());
						if (p > 30) {
							p = (int) (p / 1.3);
						} else if (p > 20) {
							p = (int) (p / 1.2);
						} else if (p > 10) {
							p = (int) (p / 1.1);
						} else if (p > 3 && p < 5) {
							p = (int) (p * 1.5);
						} else if (p <= 3) {
							p = (int) (p * 1.3) + 2;
						}
						percent = p + "%";
						freeMemorySize = FormatUtils.formatBytesInByte(memory);
						ClearUtils.setDayClearSize(mContext, memory);
						ClearUtils.setHistoryClearSize(mContext, memory);
					} catch (Exception e) {

					}

					for (int i = 0; i < 50; i++) {
						if (animEnd) {
							break;
						}
						try {
							Thread.sleep(60);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
					handler.sendEmptyMessage(END);
				} else {
					for (int i = 0; i < 50; i++) {
						if (animEnd) {
							break;
						}
						try {
							Thread.sleep(60);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
					handler.sendEmptyMessage(END);
				}
			}

		}.start();

	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		switch (keyCode) {
		case KeyEvent.KEYCODE_BACK:
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	protected void onResume() {
		MobclickAgent.onResume(this);
		super.onResume();
	}

	@Override
	protected void onPause() {
		MobclickAgent.onPause(this);
		super.onPause();
	}

}
