package cn.com.opda.android.clearmaster.utils;

import android.text.Html;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;

public class StringFormat {
	public final static String BR = "<br/>";
	public final static String NEWLINE = "(\\r\\n)|\\n";

	public static Spanned fromHtml(String string) {

		Spanned spanned = Html.fromHtml(string.replaceAll(NEWLINE, BR));
		return spanned;

	}
	/**
	 * 高亮一个字符串
	 * @param text
	 * @param color
	 * @return
	 */
	public static SpannableStringBuilder highlight(String text,int color) {
		return highlight(text, 0, text.length(), color);
	}
	/**
	 * 高亮一个字符串中的字串
	 * @param text 字符串整体(包含需高亮的字符串)
	 * @param start 需高亮的字符串起始下标
	 * @param end 需高亮的字符串结束下标
	 * @param color 高亮颜色
	 * @return
	 */
	public static SpannableStringBuilder highlight(String text,int start ,int end,int color) {
		SpannableStringBuilder spannable = new SpannableStringBuilder(text);// 用于可变字符串
		ForegroundColorSpan span = new ForegroundColorSpan(color);
		spannable.setSpan(span, start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
		return spannable;
	}
}
