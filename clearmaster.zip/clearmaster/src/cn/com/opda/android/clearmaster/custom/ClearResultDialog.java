package cn.com.opda.android.clearmaster.custom;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.TextView;
import cn.com.opda.android.clearmaster.MainClearActivity;
import cn.com.opda.android.clearmaster.R;

/**
 * 自定义清理完成dialog
 * @author 庄宏岩
 *
 */
public class ClearResultDialog implements OnClickListener {

	private Dialog dialog;
	private View view;
	private Activity mContext;
	
	

	public ClearResultDialog(Activity context) {
		dialog = new Dialog(context, R.style.custom_dialog);
		view = View.inflate(context, R.layout.clear_result_dialog, null);
		mContext = context;
	}

	public void setCancelable(boolean flag) {
		dialog.setCancelable(flag);
	}

	public void setOnCancelListener(OnCancelListener listener) {
		dialog.setOnCancelListener(listener);
	}
	
	

	public View getView() {
		return view;
	}

	public void setResult(int count, String memory,String percent) {
		TextView clear_result_tip_1 = (TextView) view.findViewById(R.id.clear_result_tip_1);
		TextView clear_result_tip_2 = (TextView) view.findViewById(R.id.clear_result_tip_2);
		TextView clear_result_tip_3 = (TextView) view.findViewById(R.id.clear_result_tip_3);
		TextView clear_result_tip_4 = (TextView) view.findViewById(R.id.clear_result_tip_4);
		if(count==0){
			clear_result_tip_1.setText(R.string.clear_result_tip_5);
			clear_result_tip_2.setText(R.string.clear_result_tip_6);
			clear_result_tip_3.setVisibility(View.GONE);
			clear_result_tip_4.setVisibility(View.GONE);
		}else{
			clear_result_tip_1.setText(mContext.getString(R.string.clear_result_tip_1, count));
			clear_result_tip_2.setText(mContext.getString(R.string.clear_result_tip_2, memory));
			clear_result_tip_3.setText(mContext.getString(R.string.clear_result_tip_3, percent));
		}
	}

	public void show() {
		view.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(mContext, MainClearActivity.class); 
				intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				mContext.startActivity(intent);
				mContext.finish();
				dismiss();
			}
		});
		dialog.setContentView(view);
		dialog.show();
	}

	public void dismiss() {
		dialog.dismiss();
	}

	@Override
	public void onClick(View v) {
		dismiss();
	}

	public Window getWindow() {
		return dialog.getWindow();
	}

}
