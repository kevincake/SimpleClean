package cn.com.opda.android.clearmaster.utils;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONObject;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.preference.PreferenceManager;
import android.telephony.TelephonyManager;
import cn.com.opda.android.clearmaster.http.CustomHttpClient;
import cn.com.opda.android.clearmaster.http.CustomHttpUtil;

public class IMEIUtils extends BaseJsonUtil {
	private String imei = "";
	public static final String URL_ANALYSE_INFO = "http://api.kfkx.net/device/analyse_info";

	public IMEIUtils(Context context) {
		super(context);
	}

	public void pushIMEIData() {
		SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
		boolean isRecord = sp.getBoolean("isRecord", false);
		if(!isRecord){
			imei = getImei(context);
			final String url = getCheckoutUrl(imei);
			if (url != null) {
				new Thread(new Runnable() {
					@Override
					public void run() {
						try {
							JSONObject value = commonRequest();
							Map<String, String> params = new HashMap<String, String>();
							String response = null;
							params.put("json", value.toString());
							response = CustomHttpUtil.sendPostRequest(url, params, CustomHttpClient.UTF8, context);
							getAnalyseInfo(imei, response);
						} catch (Exception e) {
							
						}
					}

				}).start();
			}
		}
	}

	public void getAnalyseInfo(String imei, String html) throws Exception {
		JSONObject mJsonObject = commonRequest();
		JSONObject device = new JSONObject();
		device.put("imei", imei);
		device.put("manufacturer", Build.MANUFACTURER);
		device.put("model", Build.MODEL);
		mJsonObject.put("device", device);
		mJsonObject.put("html", html);
		Map<String, String> params = new HashMap<String, String>();
		params.put("json", mJsonObject.toString());
		String response = null;
		response = CustomHttpUtil.sendPostRequest(URL_ANALYSE_INFO, params, CustomHttpClient.UTF8, context);
		parseResponse(response);
		if (getCode() == 200) {
			SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
			sp.edit().putBoolean("isRecord", true).commit();
		}
	}

	private String getCheckoutUrl(String imei) {
		String menufacturer = Build.MANUFACTURER;
		if (menufacturer != null) {
			menufacturer = menufacturer.toLowerCase();
			if (menufacturer.equals("samsung")) {
				return "http://www.numberingplans.com/?page=analysis&sub=imeinr&i=" + imei;
			} else if (menufacturer.equals("motorola")) {
				return "http://imei.ihei5.com/?s=" + imei;
			} else if (menufacturer.equals("sony")) {
				return "http://www.numberingplans.com/?page=analysis&sub=imeinr&i=" + imei;
			} else if (menufacturer.equals("sony ericsson")) {
				return "http://www.numberingplans.com/?page=analysis&sub=imeinr&i=" + imei;
			} else if (menufacturer.equals("lg")) {
				return "http://www.chalg.com/api.php?m=AJAX&imei=" + imei;
			}
		}
		return null;
	}

	/**
	 * 获取IMEI
	 * 
	 * @param mContext
	 * @return
	 */
	public String getImei(Context mContext) {
		TelephonyManager telephonyManager = (TelephonyManager) mContext.getSystemService(Context.TELEPHONY_SERVICE);
		return telephonyManager.getDeviceId();
	}
}
