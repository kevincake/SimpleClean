package cn.com.opda.android.clearmaster.model;

import android.graphics.drawable.Drawable;

public class BaseItem {
	private String name;
	private Drawable icon;
	private boolean select;
	private int id;
	private int iconResouce;
	private int type;
	private String packageName;
	private boolean dragSelect;
	private String desc;
	private String apkUrl;
	private String imageUrl;
	private boolean isNew;
	private String title;
	private String detailUrl;
	private String size;
	private boolean html5;
	private String gameUrl;
	private boolean isDownload;
	
	public boolean isDownload() {
		return isDownload;
	}
	public void setDownload(boolean isDownload) {
		this.isDownload = isDownload;
	}
	public String getGameUrl() {
		return gameUrl;
	}
	public void setGameUrl(String gameUrl) {
		this.gameUrl = gameUrl;
	}
	public boolean isHtml5() {
		return html5;
	}
	public void setHtml5(boolean html5) {
		this.html5 = html5;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getDetailUrl() {
		return detailUrl;
	}

	public void setDetailUrl(String detailUrl) {
		this.detailUrl = detailUrl;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public boolean isNew() {
		return isNew;
	}

	public void setNew(boolean isNew) {
		this.isNew = isNew;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public String getApkUrl() {
		return apkUrl;
	}

	public void setApkUrl(String apkUrl) {
		this.apkUrl = apkUrl;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Drawable getIcon() {
		return icon;
	}

	public void setIcon(Drawable icon) {
		this.icon = icon;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public boolean isSelect() {
		return select;
	}

	public void setSelect(boolean select) {
		this.select = select;
	}

	public int getIconResouce() {
		return iconResouce;
	}

	public void setIconResouce(int iconResouce) {
		this.iconResouce = iconResouce;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public String getPackageName() {
		return packageName;
	}

	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}

	public boolean isDragSelect() {
		return dragSelect;
	}

	public void setDragSelect(boolean dragSelect) {
		this.dragSelect = dragSelect;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

}
