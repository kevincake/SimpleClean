package cn.com.opda.android.clearmaster.impl;

public interface CheckedListener {
	public abstract void nothingChecked();

	public abstract void someChecked(int count);

	public abstract void allChecked(int count);
}
