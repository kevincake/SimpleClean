package cn.com.opda.android.clearmaster.custom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

/**
 * 圆形进度自定义view
 * @author 庄宏岩
 *
 */
public class RoundProgressView extends View {
	private int progress;
	private int drawProgress = 1;
	private Paint paint_gray;
	private Paint paint_white;
	private Paint paint_blue;
	private Paint paint_red;
	private Paint paint_yellow;
	private int stroke_width = 12;

	public RoundProgressView(Context context) {
		super(context);
	}

	public RoundProgressView(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public RoundProgressView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
	}

	public void setProgress(int progress) {
		this.progress = progress;
		drawProgress = 1;
		paint_gray = new Paint();
		paint_gray.setAntiAlias(true);
		paint_gray.setColor(0xffdadada);

		paint_white = new Paint();
		paint_white.setAntiAlias(true);
		paint_white.setColor(Color.WHITE);

		paint_blue = new Paint();
		paint_blue.setAntiAlias(true);
		paint_blue.setColor(0xff81cdef);
		
		paint_yellow = new Paint();
		paint_yellow.setAntiAlias(true);
		paint_yellow.setColor(0xfffdcd03);
		
		paint_red = new Paint();
		paint_red.setAntiAlias(true);
		paint_red.setColor(0xffe86d4c);
		
		invalidate();
	}

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		// 定义一个矩形
		RectF oval = new RectF(0, 0, getWidth(), getHeight());
		if(paint_gray!=null){
			// 画圆
			canvas.drawArc(oval, 0, 360, true, paint_gray);
			if (drawProgress < progress) {
				float rate = (float) drawProgress / 100;
				canvas.drawArc(oval, -90, 360 * rate, true, paint_blue);
				canvas.drawArc(new RectF(stroke_width, stroke_width, getWidth() - stroke_width, getHeight() - stroke_width), 0, 360, true, paint_white);
				drawProgress += 2;
				invalidate();
			} else {
				float rate = (float) progress / 100;
				canvas.drawArc(oval, -90, 360 * rate, true, paint_blue);
				canvas.drawArc(new RectF(stroke_width, stroke_width, getWidth() - stroke_width, getHeight() - stroke_width), 0, 360, true, paint_white);
			}
		}

	}

}
