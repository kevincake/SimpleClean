package cn.com.opda.android.clearmaster.utils;

import java.util.Date;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import cn.com.opda.android.clearmaster.DepthClearActivity;
import cn.com.opda.android.clearmaster.MainClearActivity;
import cn.com.opda.android.clearmaster.ProcessManagerActicity;
import cn.com.opda.android.clearmaster.R;

public class ClearUtils {

	public static void showClearNotify(Context mContext) {

		int NF_ID = 3333;
		Notification nf = new Notification(R.drawable.icon, mContext.getString(R.string.depth_file_more_tips), System.currentTimeMillis());
		nf.icon = R.drawable.icon;
		nf.flags = Notification.FLAG_AUTO_CANCEL;
		Intent intent = new Intent(mContext, MainClearActivity.class);
		PendingIntent pendingIntent = PendingIntent.getActivity(mContext, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
		nf.setLatestEventInfo(mContext, mContext.getString(R.string.depth_file_more_tips_title), mContext.getString(R.string.depth_file_more_tips_content),
				pendingIntent);
		NotificationManager nm = (NotificationManager) mContext.getSystemService(Context.NOTIFICATION_SERVICE);
		nm.notify(NF_ID, nf);
	}

	public static void showClearNotify2(final Context mContext) {
		SharedPreferences sharedPreferences = mContext.getSharedPreferences(Constants.SHARED_PREFERENCES_NAME, Context.MODE_PRIVATE);
		if(sharedPreferences.getBoolean(Constants.SHAKE_STATE_CLEAN_REMINDER, true)){
			final SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(mContext);
			long lastClearTipTime = sp.getLong("lastClearTipTime", sp.getLong("lastUseTime", 0));
			if (System.currentTimeMillis() - lastClearTipTime >= 3 * 24 * 60 * 60 * 1000) {
				new Thread(new Runnable() {

					@Override
					public void run() {
						long cacheSize = MemoryUtils.getCacheTotalSize(mContext);
						long processSize = ProcessManagerUtils.getUsedMemory(mContext);
						long depthSize = MemoryUtils.getTotalDepthSize(mContext);
						long total = cacheSize + processSize + depthSize;
						if (total >= 50 * 1000 * 1000) {
							int NF_ID = 2222;
							Notification nf = new Notification(R.drawable.icon, mContext.getString(R.string.depth_file_more_tips), System.currentTimeMillis());
							nf.icon = R.drawable.icon;
							nf.flags = Notification.FLAG_AUTO_CANCEL;
							Intent intent = new Intent(mContext, DepthClearActivity.class);
							intent.putExtra("from_notify", true);
							PendingIntent pendingIntent = PendingIntent.getActivity(mContext, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
							nf.setLatestEventInfo(mContext, mContext.getString(R.string.clear_notify_title, FormatUtils.formatBytesInByte(total)),
									mContext.getString(R.string.clear_notify_content), pendingIntent);
							NotificationManager nm = (NotificationManager) mContext.getSystemService(Context.NOTIFICATION_SERVICE);
							nm.notify(NF_ID, nf);
							sp.edit().putLong("lastClearTipTime", System.currentTimeMillis()).commit();
						}
					}
				}).start();
			}
		}
	}

	/**
	 * 获取当日清理的垃圾大小
	 * @param mContext
	 * @return
	 */
	public static long getDayClearSize(Context mContext) {
		SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(mContext);
		long size = sp.getLong("day_clear_size", 0);
		if (size < 0) {
			size = 0;
		}
		return size;
	}

	/**
	 * 获取累计清理的垃圾大小
	 * @param mContext
	 * @return
	 */
	public static long getHistoryClearSize(Context mContext) {
		SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(mContext);
		long size = sp.getLong("history_clear_size", 0);
		if (size < 0) {
			size = 0;
		}
		return size;
	}

	/**
	 * 保存清理的数据到本日清理中
	 * @param mContext
	 * @param size
	 */
	public static void setDayClearSize(Context mContext, long size) {
		SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(mContext);
		DLog.i("debug", "add day size : " + size);
		sp.edit().putLong("day_clear_size", sp.getLong("day_clear_size", 0) + size).commit();
	}

	/**
	 * 清除当日清理的数据
	 * @param mContext
	 * @param l
	 */
	public static void clearDayClearSize(Context mContext, long l) {
		SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(mContext);
		int day_clear_time = sp.getInt("day_clear_time", -1);
		Date date = new Date(l);
		int day = date.getDay();
		if (day_clear_time == -1) {
			sp.edit().putInt("day_clear_time", day).commit();
			day_clear_time = day;
		}
		if (day != day_clear_time) {
			sp.edit().putInt("day_clear_time", day).commit();
			sp.edit().putLong("day_clear_size", 0).commit();
		}
	}

	/**
	 * 保存清理的数据到历史清理中
	 * @param mContext
	 * @param size
	 */
	public static void setHistoryClearSize(Context mContext, long size) {
		SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(mContext);
		sp.edit().putLong("history_clear_size", sp.getLong("history_clear_size", 0) + size).commit();
		DLog.i("debug", "add history size : " + size);
	}

	public static void showProcessNotify(final Context mContext) {
		SharedPreferences sharedPreferences = mContext.getSharedPreferences(Constants.SHARED_PREFERENCES_NAME, Context.MODE_PRIVATE);
		if(sharedPreferences.getBoolean(Constants.PROCESS_TIPS_CHECKED, true)){
			final SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(mContext);
			long lastClearTipTime = sp.getLong("lastProcessTipTime", sp.getLong("lastUseTime", 0));
			if (System.currentTimeMillis() - lastClearTipTime >= 1 * 24 * 60 * 60 * 1000) {
				new Thread(new Runnable() {

					@Override
					public void run() {
						long avail = ProcessManagerUtils.getRuntimeAvailableMemory(mContext);
						long total = ProcessManagerUtils.getRuntimeTotalMemory();
						int percent= 100-((int) (avail*100/total));
						if (percent >= 80) {
							int NF_ID = 2555;
							Notification nf = new Notification(R.drawable.icon, mContext.getString(R.string.process_clear_tips), System.currentTimeMillis());
							nf.icon = R.drawable.icon;
							nf.flags = Notification.FLAG_AUTO_CANCEL;
							Intent intent = new Intent(mContext, ProcessManagerActicity.class);
							intent.putExtra("from_notify", true);
							PendingIntent pendingIntent = PendingIntent.getActivity(mContext, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
							nf.setLatestEventInfo(mContext, mContext.getString(R.string.process_clear_notify_title),
									mContext.getString(R.string.process_clear_notify_content), pendingIntent);
							NotificationManager nm = (NotificationManager) mContext.getSystemService(Context.NOTIFICATION_SERVICE);
							nm.notify(NF_ID, nf);
							sp.edit().putLong("lastProcessTipTime", System.currentTimeMillis()).commit();
						}
					}
				}).start();
			}
		}
	}
}
