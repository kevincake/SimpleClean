package cn.com.opda.android.clearmaster;

import java.util.ArrayList;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import cn.com.opda.android.clearmaster.adapter.SmsDetailAdapter;
import cn.com.opda.android.clearmaster.custom.CustomListView;
import cn.com.opda.android.clearmaster.impl.CheckedListener;
import cn.com.opda.android.clearmaster.model.SmsInfo;
import cn.com.opda.android.clearmaster.utils.BannerUtils;
import cn.com.opda.android.clearmaster.utils.Constants;
import cn.com.opda.android.clearmaster.utils.SmsUtils;

import com.umeng.analytics.MobclickAgent;

/**
 * 短信清理短信详细页面
 * 
 * @author 庄宏岩
 * 
 */
public class SMSDetailListActivity extends BaseActivity implements OnClickListener, OnItemClickListener,CheckedListener {
	private Context mContext;
	private ListView sms_detail_listview;
	private int threadId;
	private String name;
	private int position;
	private SmsDetailAdapter mSmsDetailAdapter;
	private Intent resultIntent;
	private TextView sms_count;
	private int smsCount = 0;
	private boolean stop;
	private Button clear_button;
	private CheckBox allCheckbox;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_sms_detail);
		mContext = SMSDetailListActivity.this;
		BannerUtils.setMainTitle(this, R.string.clean_sms_title);
		BannerUtils.initBackButton(this);
		initViewAndEvent();
		Intent intent = getIntent();
		threadId = intent.getIntExtra("threadId", -1);
		name = intent.getStringExtra("name");
		position = intent.getIntExtra("position", -1);
		new GetSmsTask().execute();

		resultIntent = new Intent(mContext, ClearConversationActivity.class);
		resultIntent.putExtra("position", position);
	}


	private void initViewAndEvent() {
		sms_detail_listview = (ListView) findViewById(R.id.sms_detail_listview);
		sms_detail_listview.setOnItemClickListener(this);
		sms_count = (TextView) findViewById(R.id.header_memory_textview);
		clear_button  = (Button) findViewById(R.id.clear_button);
		clear_button.setOnClickListener(this);
		
		allCheckbox = (CheckBox) findViewById(R.id.all_checked_checkbox);
		allCheckbox.setChecked(false);
		allCheckbox.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				allCheckbox.setChecked(allCheckbox.isChecked());
				mSmsDetailAdapter.setAllChecked(allCheckbox.isChecked());
				
			}
		});
	}

	private class GetSmsTask extends AsyncTask<Void, SmsInfo, Integer> {
		private ArrayList<SmsInfo> mSmsInfos;

		@Override
		protected void onPreExecute() {
			mSmsInfos = new ArrayList<SmsInfo>();
			mSmsDetailAdapter = new SmsDetailAdapter(mContext, mSmsInfos);
			mSmsDetailAdapter.setCheckedListener(SMSDetailListActivity.this);
			sms_detail_listview.setAdapter(mSmsDetailAdapter);
			clear_button.setText(R.string.stop_scan_button);
		}

		@Override
		protected Integer doInBackground(Void... params) {

			String where = Constants.SMS_thread_id + "=?";
			String[] projection = new String[] { Constants.SMS_ID, Constants.SMS_thread_id, Constants.SMS_address, Constants.SMS_person, Constants.SMS_date,
					Constants.SMS_read, Constants.SMS_status, Constants.SMS_type, Constants.SMS_body };
			String[] selectArgs = new String[] { threadId + "" };
			Cursor cursor = getContentResolver().query(Constants.SMSAll_URL, projection, where, selectArgs, Constants.SMS_date + " ASC");
			if (cursor.moveToNext()) {
				int count = cursor.getCount();
				for (int i = 0; i < count; ++i) {
					if(stop){
						break;
					}
					Message message = new Message();
					message.what = 1;
					Bundle bundle = new Bundle();
					bundle.putInt("max", count);
					bundle.putInt("progress", i + 1);
					message.setData(bundle);
					handler.sendMessage(message);

					cursor.moveToPosition(i);
					String idtemp = cursor.getString(0);
					String thread_idtemp = cursor.getString(1);
					String adresstemp = cursor.getString(2);
					String persontemp = cursor.getString(3);
					String datetemp = cursor.getString(4);
					String readtemp = cursor.getString(5);
					String statustemp = cursor.getString(6);
					String typetemp = cursor.getString(7);
					String bodytemp = cursor.getString(8);
					SmsInfo smsInfo = new SmsInfo();

					if (idtemp != null) {
						smsInfo.set_id(Integer.parseInt(idtemp));
					} else {
						continue;
					}
					if (thread_idtemp != null) {
						smsInfo.setThread_id(Integer.parseInt(thread_idtemp));
					} else {
						continue;
					}
					if (adresstemp != null) {
						smsInfo.setAddress(adresstemp);
					} else {
						continue;
					}

					if (persontemp != null)
						smsInfo.setPerson(persontemp);
					smsInfo.setDate(datetemp);

					if (readtemp != null)
						smsInfo.setRead(Integer.parseInt(readtemp));
					if (statustemp != null)
						smsInfo.setStatus(Integer.parseInt(statustemp));
					if (typetemp != null)
						smsInfo.setType(Integer.parseInt(typetemp));
					smsInfo.setBody(bodytemp);

					smsInfo.setName(name);
					smsCount++;
					publishProgress(smsInfo);
				}
			}
			cursor.close();
			return null;

		}

		@Override
		protected void onProgressUpdate(SmsInfo... values) {
			if (values.length > 0) {
				mSmsInfos.add(values[0]);
			}
			mSmsDetailAdapter.notifyDataSetChanged();
			updateCount();
			super.onProgressUpdate(values);
		}

		@Override
		protected void onPostExecute(Integer result) {
			super.onPostExecute(result);
			handler.sendEmptyMessage(2);
		}

		Handler handler = new Handler() {

			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				switch (msg.what) {
				case 2:
					clear_button.setText(R.string.one_clear_button);
					break;

				default:
					break;
				}
			}

		};

	}

	private class DeleteSmsTask extends AsyncTask<Void, SmsInfo, Integer> {
		private ArrayList<SmsInfo> mSmsInfos;

		@Override
		protected void onPreExecute() {
			mSmsInfos = mSmsDetailAdapter.getSelecteList();
			if (mSmsInfos.size() == 0) {
				Toast.makeText(mContext, R.string.clear_select_null, Toast.LENGTH_SHORT).show();
			}
		}

		@Override
		protected Integer doInBackground(Void... params) {
			if (mSmsInfos.size() > 0) {
				for (int i = 0; i < mSmsInfos.size(); i++) {
					if(stop){
						return null;
					}
					Message message = new Message();
					message.what = 1;
					Bundle bundle = new Bundle();
					bundle.putInt("max", mSmsInfos.size());
					bundle.putInt("progress", i + 1);
					message.setData(bundle);
					handler.sendMessage(message);

					SmsInfo smsInfo = mSmsInfos.get(i);
					SmsUtils.deleteMessageById(mContext, smsInfo.get_id());
					try {
						Thread.sleep(30);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					publishProgress(smsInfo);
				}
			}
			return null;
		}

		@Override
		protected void onProgressUpdate(SmsInfo... values) {
			if (values.length > 0) {
				mSmsDetailAdapter.remove(values[0]);
			}
			mSmsDetailAdapter.notifyDataSetChanged();
			super.onProgressUpdate(values);
		}

		@Override
		protected void onPostExecute(Integer result) {
			super.onPostExecute(result);
			if (mSmsInfos.size() > 0) {
				handler.sendEmptyMessage(2);
				Toast.makeText(mContext, getString(R.string.clean_end_sms_count_toast, mSmsInfos.size()), Toast.LENGTH_SHORT).show();
			}
			int count = mSmsDetailAdapter.getCount();
			resultIntent.putExtra("count", count);
			setResult(100, resultIntent);
			if (count == 0) {
				finish();
				overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);  
			}
		}

		Handler handler = new Handler() {

			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				switch (msg.what) {
				case 1:
					ArrayList<SmsInfo> smsInfos = mSmsDetailAdapter.getList();
					smsCount = smsInfos.size();
					updateCount();
					break;
				case 2:
					ArrayList<SmsInfo> smsInfos2 = mSmsDetailAdapter.getList();
					smsCount = smsInfos2.size();
					updateCount();
					break;

				default:
					break;
				}
			}

		};
	}

	public void updateCount() {
		sms_count.setText(smsCount + "");
	}

	@Override
	protected void onResume() {
		MobclickAgent.onResume(this);
		super.onResume();
	}

	@Override
	protected void onPause() {
		MobclickAgent.onPause(this);
		super.onPause();
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.clear_button:
			if (clear_button.getText().equals(getString(R.string.stop_scan_button))) {
				stop = true;
				clear_button.setText(R.string.one_clear_button);
			} else {
				if (mSmsDetailAdapter.getList().size() == 0) {
					Toast.makeText(mContext, R.string.no_have_clear, Toast.LENGTH_SHORT).show();
				} else {
					new DeleteSmsTask().execute();
				}
			}
			
			break;
		default:
			break;
		}
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
		SmsInfo smsInfo = (SmsInfo) parent.getItemAtPosition(position);
		smsInfo.setChecked(!smsInfo.isChecked());
		mSmsDetailAdapter.updateChecked();
		mSmsDetailAdapter.notifyDataSetChanged();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		stop = true;
	}
	@Override
	public void nothingChecked() {
		allCheckbox.setChecked(false);
	}

	@Override
	public void someChecked(int count) {
		allCheckbox.setChecked(false);
	}

	@Override
	public void allChecked(int count) {
		allCheckbox.setChecked(true);
	}

}
