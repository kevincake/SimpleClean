package cn.com.opda.android.clearmaster.custom;

import java.lang.reflect.Method;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.view.View;

public class WaterWaveCustomView extends View {
	private Handler mHandler;
	private boolean mStarted = false;
	private int mAlpha = (int) (255*0.2);
	private float mAmplitude = 40.0F; // 振幅
	private final Paint mPaint = new Paint();
	private float progress = 0;
	private int count = 0;
	private int count2 = 30;
	private boolean ask = true;
	private boolean ask2 = false;

	public WaterWaveCustomView(Context paramContext) {
		super(paramContext);
		init(paramContext);
	}

	public WaterWaveCustomView(Context paramContext, AttributeSet paramAttributeSet) {
		super(paramContext, paramAttributeSet);
		init(paramContext);
	}

	public WaterWaveCustomView(Context paramContext, AttributeSet attrs, int defStyleAttr) {
		super(paramContext, attrs, defStyleAttr);
		init(paramContext);
	}

	public void startWave() {
		mStarted = true;
		this.mHandler.removeMessages(0);
		this.mHandler.sendEmptyMessage(0);
	}

	public void stoptWave() {
		mStarted = false;
		this.mHandler.removeMessages(0);
	}

	private void init(Context context) {
		mPaint.setStrokeWidth(1.0F);
		mPaint.setColor(Color.WHITE);
		mPaint.setAlpha(mAlpha);
		mPaint.setAntiAlias(true);
		mHandler = new Handler() {
			@Override
			public void handleMessage(Message msg) {
				if (msg.what == 0) {
					invalidate();
					if (mStarted) {
						if (ask) {
							count++;
							if (count == 30) {
								ask = false;
							}
						} else {
							count--;
							if (count == 0) {
								ask = true;
							}
						}

						if (ask2) {
							count2++;
							if (count2 == 30) {
								ask2 = false;
							}
						} else {
							count2--;
							if (count2 == 0) {
								ask2 = true;
							}
						}
						mHandler.sendEmptyMessageDelayed(0, 50);
					}
				}
			}
		};
	}

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		int width = getWidth();
		int height = getHeight();
		if ((!mStarted) || progress == 0) {
			return;
		}
		canvas.save();
		float h = height * (1 - (progress * 1.0f) / 100) - mAmplitude / 2;
		
		float topX1 = width / 5;
		float topX2 = width - width / 5;

		float topY1 = h + count;
		float topY2 = h - count;

		Path path = new Path();
		path.moveTo(0, height);
		path.lineTo(0, h);
		path.quadTo(topX1, topY1, width / 2, h);
		path.quadTo(topX2, topY2, width, h);
		path.lineTo(width, height);
		canvas.drawPath(path, mPaint);

		float topX3 = width / 3;
		float topX4 = width - width / 3;

		float topY3 = h + count2;
		float topY4 = h - count2;

		Path path2 = new Path();
		path2.moveTo(0, height);
		path2.lineTo(0, h);
		path2.quadTo(topX3, topY3, width / 2, h);
		path2.quadTo(topX4, topY4, width, h);
		path2.lineTo(width, height);

		canvas.drawPath(path2, mPaint);

		canvas.restore();
	}

	@SuppressWarnings("rawtypes")
	@Override
	protected void onAttachedToWindow() {
		super.onAttachedToWindow();
		if (Build.VERSION.SDK_INT >= 11) {
			try {
				boolean bool = ((Boolean) View.class.getMethod("isHardwareAccelerated", new Class[0]).invoke(this, new Object[0])).booleanValue();
				if (bool) {
					Class[] arrayOfClass = new Class[2];
					arrayOfClass[0] = Integer.TYPE;
					arrayOfClass[1] = Paint.class;
					Method localMethod = View.class.getMethod("setLayerType", arrayOfClass);
					Object[] arrayOfObject = new Object[2];
					arrayOfObject[0] = Integer.valueOf(1);
					arrayOfObject[1] = null;
					localMethod.invoke(this, arrayOfObject);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public void setAmplitude(float amplitued) {
		mAmplitude = amplitued;
	}

	public void setWaterAlpha(float alpha) {
		this.mAlpha = ((int) (255.0F * alpha));
		mPaint.setAlpha(this.mAlpha);
	}

	public void setWaterLevel(float paramFloat) {
		progress = paramFloat;
		if(progress<5){
			progress = 5;
		}
		
		if(progress>90){
			progress = 90;
		}
	}
}
