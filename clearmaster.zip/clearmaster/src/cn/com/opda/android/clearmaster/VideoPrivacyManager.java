package cn.com.opda.android.clearmaster;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import cn.com.opda.android.clearmaster.adapter.Adapter4VideoPrivacy;
import cn.com.opda.android.clearmaster.custom.IOSProgressDialog;
import cn.com.opda.android.clearmaster.privacy.VideoDBHelper;
import cn.com.opda.android.clearmaster.privacy.VideoInfo;
import cn.com.opda.android.clearmaster.utils.BannerUtils;
import cn.com.opda.android.clearmaster.utils.FileUtils;
import cn.com.opda.android.clearmaster.utils.listsort.TimeComparatorForMyPrivacyVideo;

import com.umeng.analytics.MobclickAgent;

public class VideoPrivacyManager extends BaseActivity implements OnClickListener{
	
	private RelativeLayout rl_no_pic;
	private GridView gv_for_pic;
	private Button bt_add_button;
	private LinearLayout ll_edit_button_layout;
	private ImageView iv_edit;
	private Button bt_huanyuan, bt_delete;
	private RelativeLayout rl_check_all;
	private CheckBox cb_edit_all;
	private TextView banner_title_textview, tv_main_word;
	private ImageView banner_back_imageview;
	
	private Adapter4VideoPrivacy mPrivacyVideoAdapter;
	private boolean editFlag, sdFlag;
	private IOSProgressDialog pd;
	
	private ArrayList<VideoInfo> mVideoInfoList = new ArrayList<VideoInfo>();
	
	private Handler mHandler = new Handler(){

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			switch (msg.what) {
			case 1:
				pd.dismiss();
				if (mVideoInfoList.size() == 0) {
					editFlag = true;
					showPrivacyPic();
					showLayout();
				}
				break;

			default:
				break;
			}
		}
		
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_video_privacy);
		BannerUtils.initBackButton(this);
		BannerUtils.setMainTitle(this, R.string.privacy_video);
		initViewAndEvent();
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		MobclickAgent.onResume(this);
		showLayout();
		TimeComparatorForMyPrivacyVideo timeComparator = new TimeComparatorForMyPrivacyVideo();
		Collections.sort(mVideoInfoList, timeComparator);
		mPrivacyVideoAdapter = new Adapter4VideoPrivacy(this, mVideoInfoList);
		gv_for_pic.setAdapter(mPrivacyVideoAdapter);
		
	}

	private void showLayout() {
		if (!FileUtils.hasSDCard()) {
			rl_no_pic.setVisibility(View.VISIBLE);
			gv_for_pic.setVisibility(View.GONE);
			iv_edit.setVisibility(View.GONE);
			tv_main_word.setText(getString(R.string.privacy_no_sdcard));
			sdFlag = false;
		} else {
			sdFlag = true;
			mVideoInfoList = VideoDBHelper.readVideoList();
			if (mVideoInfoList != null && mVideoInfoList.size() == 0) {
				rl_no_pic.setVisibility(View.VISIBLE);
				gv_for_pic.setVisibility(View.GONE);
				iv_edit.setVisibility(View.GONE);
				tv_main_word.setText(getString(R.string.privacy_no_video));
			} else {
				rl_no_pic.setVisibility(View.GONE);
				gv_for_pic.setVisibility(View.VISIBLE);
				iv_edit.setVisibility(View.VISIBLE);
			}
		}
	}

	private void initViewAndEvent() {
		tv_main_word = (TextView) findViewById(R.id.tv_main_word);
		rl_no_pic = (RelativeLayout) findViewById(R.id.rl_no_pic);
		gv_for_pic = (GridView) findViewById(R.id.gv_for_pic);
		gv_for_pic.setSelector(new ColorDrawable(Color.TRANSPARENT));
		bt_add_button = (Button) findViewById(R.id.bt_add_button);
		bt_add_button.setOnClickListener(this);
		
		iv_edit = (ImageView) findViewById(R.id.banner_about_imageview);
		iv_edit.setVisibility(View.VISIBLE);
		iv_edit.setImageResource(R.drawable.privacy_edit_pic);
		editFlag = true;
		iv_edit.setOnClickListener(this);
		
		ll_edit_button_layout = (LinearLayout) findViewById(R.id.ll_edit_button_layout);
		bt_delete = (Button) findViewById(R.id.bt_delete);
		bt_delete.setOnClickListener(this);
		bt_huanyuan = (Button) findViewById(R.id.bt_huanyuan);
		bt_huanyuan.setOnClickListener(this);
		
		rl_check_all = (RelativeLayout) findViewById(R.id.rl_check_all);
		rl_check_all.setOnClickListener(this);
		cb_edit_all = (CheckBox) findViewById(R.id.cb_edit_all);
		cb_edit_all.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if (isChecked) {
					mPrivacyVideoAdapter.selectAll();
				} else {
					mPrivacyVideoAdapter.selectNull();
				}
			}
		});
		
		banner_title_textview = (TextView)findViewById(R.id.banner_title_textview);
		banner_title_textview.setOnClickListener(this);
		banner_back_imageview = (ImageView)findViewById(R.id.banner_back_imageview);
		banner_back_imageview.setOnClickListener(this);
	}
	

	private void showPrivacyPic() {
		iv_edit.setImageResource(R.drawable.privacy_edit_pic);
		bt_add_button.setVisibility(View.VISIBLE);
		ll_edit_button_layout.setVisibility(View.GONE);
		mPrivacyVideoAdapter.changeFlag();
		cb_edit_all.setChecked(false);
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.bt_add_button:
			if (sdFlag) {
				startActivity(new Intent(this, 	ShowAllVideoActivity.class));
			} else {
				Toast.makeText(this, R.string.privacy_no_sdcard, Toast.LENGTH_SHORT).show();
			}
			break;
			
		case R.id.banner_about_imageview:
			if (editFlag) {
				editFlag = false;
				iv_edit.setImageResource(R.drawable.privacy_edit_pic_exit);
				bt_add_button.setVisibility(View.GONE);
				ll_edit_button_layout.setVisibility(View.VISIBLE);
				mPrivacyVideoAdapter.changeFlag();
			} else {
				editFlag = true;
				showPrivacyPic();
				showLayout();
			}
			break;
			
		case R.id.rl_check_all:
			cb_edit_all.setChecked(!cb_edit_all.isChecked());
			break;
			
		case R.id.bt_huanyuan:
			final ArrayList<VideoInfo> xVideoInfo = mPrivacyVideoAdapter.getSelectList();
			if (xVideoInfo.size() == 0) {
				Toast.makeText(VideoPrivacyManager.this, R.string.clear_select_null, Toast.LENGTH_SHORT).show();
				return;
			}
			pd = new IOSProgressDialog(this, R.string.privacy_video_unlock);
			pd.setCancelable(false);
			pd.setCanceledOnTouchOutside(false);
			pd.show();
			
			new Thread(new Runnable() {
				
				@Override
				public void run() {
					
					for (int i = 0; i < xVideoInfo.size(); i++) {
						VideoInfo info = xVideoInfo.get(i);
						String newPath = info.getNewPath();
						String oldPath = info.getOldPath();
						
						System.out.println("oldPath== "+oldPath +"   newPath=== "+newPath);
						
						try {
							FileUtils.copyFile(new File(newPath), new File(oldPath));
						} catch (IOException e) {
							e.printStackTrace();
						}
						//通知系统图库更新
						VideoPrivacyManager.this.sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.parse("file://" + oldPath)));
						FileUtils.deleteFileByPath(newPath);
					}
					//删除当前隐私界面的图片
					VideoDBHelper.deleteVideo(VideoPrivacyManager.this, xVideoInfo);
					runOnUiThread(new Runnable() {
						
						@Override
						public void run() {
							mPrivacyVideoAdapter.removeVideos(xVideoInfo);
						}
					});
					mHandler.sendEmptyMessage(1);
				}
			}).start();
			
			
			break;
			
		case R.id.bt_delete:
			final ArrayList<VideoInfo> xxVideoInfos = mPrivacyVideoAdapter.getSelectList();
			if (xxVideoInfos.size() == 0) {
				Toast.makeText(this, R.string.clear_select_null, Toast.LENGTH_SHORT).show();
				return;
			}
			
			pd = new IOSProgressDialog(this, R.string.privacy_video_unlock);
			pd.setCancelable(false);
			pd.show();
			
			new Thread(new Runnable() {
				
				@Override
				public void run() {
					
					//删除当前隐私界面的图片
					VideoDBHelper.deleteVideo(VideoPrivacyManager.this, xxVideoInfos);
					for (int i = 0; i < xxVideoInfos.size(); i++) {
						FileUtils.deleteFileByPath(xxVideoInfos.get(i).getNewPath());
					}
					runOnUiThread(new Runnable() {
						
						@Override
						public void run() {
							mPrivacyVideoAdapter.removeVideos(xxVideoInfos);
						}
					});
					mHandler.sendEmptyMessage(1);
				}
			}).start();
					
			break;
			
		case R.id.banner_back_imageview:
			if (editFlag) {
				finish();
				overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
			} else {
				editFlag = true;
				showPrivacyPic();
				showLayout();
			}
			break;
			
		case R.id.banner_title_textview:
			if (editFlag) {
				finish();
				overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
			} else {
				editFlag = true;
				showPrivacyPic();
				showLayout();
			}
			break;
		default:
			break;
		}
		
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			if (editFlag == true) {
				finish();
				overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
				return true;
			}else {
				editFlag = true;
				showPrivacyPic();
				showLayout();
				return true;
			}
		} 
		return super.onKeyDown(keyCode, event);
	}
	

	@Override
	protected void onPause() {
		super.onPause();
		MobclickAgent.onPause(this);
	}
}
