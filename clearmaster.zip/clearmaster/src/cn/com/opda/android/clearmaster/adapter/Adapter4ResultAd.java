package cn.com.opda.android.clearmaster.adapter;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import cn.com.opda.android.clearmaster.R;
import cn.com.opda.android.clearmaster.model.BaseItem;
import cn.com.opda.android.clearmaster.utils.ImageDownload;

/**
 * @author 庄宏岩
 * 
 */
public class Adapter4ResultAd extends BaseAdapter {
	private ArrayList<BaseItem> mBaseItems;
	private Context mContext;
	private Drawable defaultIcon;

	public Adapter4ResultAd(Context context, ArrayList<BaseItem> mBaseItems) {
		this.mBaseItems = mBaseItems;
		this.mContext = context;
		defaultIcon = mContext.getResources().getDrawable(android.R.drawable.sym_def_app_icon);
	}

	@Override
	public int getCount() {
		return mBaseItems.size();
	}

	@Override
	public Object getItem(int position) {
		return mBaseItems.get(position);
	}

	public ArrayList<BaseItem> getList() {
		return mBaseItems;
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	float lastX, lastY;

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		final Holder mHolder;
		if (convertView == null) {
			LayoutInflater inflater = LayoutInflater.from(mContext);
			convertView = inflater.inflate(R.layout.listview_result_ad_item_layout, null);
			mHolder = new Holder();
			mHolder.tools_item_name = (TextView) convertView.findViewById(R.id.tools_item_name);
			mHolder.tools_item_icon = (ImageView) convertView.findViewById(R.id.tools_item_icon);
			mHolder.tools_item_title = (TextView) convertView.findViewById(R.id.tools_item_title);
			convertView.setTag(mHolder);
		} else {
			mHolder = (Holder) convertView.getTag();
		}
		final BaseItem mBaseItem = mBaseItems.get(position);
		mHolder.tools_item_name.setText(mBaseItem.getName());
		mHolder.tools_item_title.setText(mBaseItem.getDesc());

		if (mBaseItem.getIcon() == null) {
			mHolder.tools_item_icon.setImageDrawable(defaultIcon);
			mHolder.imageLoader = new AsyncTask<Holder, Void, Drawable>() {
				private Holder holder;

				@Override
				protected Drawable doInBackground(Holder... params) {
					holder = params[0];
					Bitmap bitmap = ImageDownload.downloadImage(mContext, mBaseItem);
					if (bitmap == null) {
						return null;
					}
					Drawable drawable = new BitmapDrawable(mContext.getResources(), bitmap);
					return drawable;
				}

				@Override
				protected void onPostExecute(Drawable result) {
					if (result != null) {
						mBaseItem.setIcon(result);
						holder.tools_item_icon.setImageDrawable(result);
					}
				}
			}.execute(mHolder);
		} else {
			mHolder.tools_item_icon.setImageDrawable(mBaseItem.getIcon());
		}
		return convertView;
	}

	class Holder {

		private ImageView tools_item_icon;
		private TextView tools_item_name;
		private TextView tools_item_title;
		AsyncTask<Holder, Void, Drawable> imageLoader;
	}

}
