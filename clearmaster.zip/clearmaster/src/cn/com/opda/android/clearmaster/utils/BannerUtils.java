package cn.com.opda.android.clearmaster.utils;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import cn.com.opda.android.clearmaster.MainMoreActivity;
import cn.com.opda.android.clearmaster.R;
import cn.com.opda.android.clearmaster.UmengGameActivity;

public class BannerUtils {
	public static void setTitle(Activity context, int id) {
		TextView banner_title_textview = (TextView) context.findViewById(R.id.banner_title_textview);
		banner_title_textview.setText(id);
	}

	public static void setTitle(Activity context, String title) {
		TextView banner_title_textview = (TextView) context.findViewById(R.id.banner_title_textview);
		banner_title_textview.setText(title);
	}

	public static void setMainTitle(Activity context, int id) {
		TextView banner_title_textview = (TextView) context.findViewById(R.id.banner_title_textview);
		banner_title_textview.setText(id);
	}

	public static void setMainTitle(Activity context, String string) {
		TextView banner_title_textview = (TextView) context.findViewById(R.id.banner_title_textview);
		banner_title_textview.setText(string);
	}

	public static void initTitleRightImage(final Activity context) {
		ImageView banner_right_imageview = (ImageView) context.findViewById(R.id.banner_left_imageview);
		banner_right_imageview.setVisibility(View.VISIBLE);
	}

	public static void initBackButton(final Activity context) {
		ImageView banner_back_imageview = (ImageView) context.findViewById(R.id.banner_back_imageview);
		banner_back_imageview.setVisibility(View.VISIBLE);
		banner_back_imageview.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				context.finish();
				context.overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left); 
			}
		});
		TextView banner_title_textview = (TextView) context.findViewById(R.id.banner_title_textview);
		banner_title_textview.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				context.finish();
				context.overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left); 
			}
		});
	}
	
	
	public static void initAppButton(final Activity context) {
		final ImageView banner_app_imageview = (ImageView) context.findViewById(R.id.banner_app_imageview);
		banner_app_imageview.setVisibility(View.VISIBLE);
		final SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
		if (sp.getInt("app_version", 0) < MainMoreActivity.app_version) {
			banner_app_imageview.setImageResource(R.drawable.menu_app_red);
		} else {
			banner_app_imageview.setImageResource(R.drawable.menu_app);
		}
		banner_app_imageview.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				sp.edit().putInt("app_version", MainMoreActivity.app_version).commit();
				context.startActivity(new Intent(context, MainMoreActivity.class));
				banner_app_imageview.setImageResource(R.drawable.menu_app);
			}
		});
	}
	public static void initFuliButton(final Activity context) {
		final ImageView banner_fuli_imageview = (ImageView) context.findViewById(R.id.banner_fuli_imageview);
		banner_fuli_imageview.setVisibility(View.VISIBLE);
		banner_fuli_imageview.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(context, UmengGameActivity.class);
				intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				intent.putExtra("title","我们还能陪伴父母多久？");
				
				intent.putExtra("desc","我们还能陪伴父母多久？");
				intent.putExtra("game_url","http://www.dashi.com/zhuodashi/rootYear?layout=yjql");
				context.startActivity(intent);
			}
		});
	}

	public static void setIcon(final Activity context, int resId) {
		ImageView banner_icon_imageview = (ImageView) context.findViewById(R.id.banner_icon_imageview);
		banner_icon_imageview.setVisibility(View.VISIBLE);
		banner_icon_imageview.setImageResource(resId);

	}

	public static void setBannerBackgroundColor(final Activity context, int colorId) {
		LinearLayout banner_layout = (LinearLayout) context.findViewById(R.id.banner_layout);
		banner_layout.setBackgroundColor(colorId);
	}

}
