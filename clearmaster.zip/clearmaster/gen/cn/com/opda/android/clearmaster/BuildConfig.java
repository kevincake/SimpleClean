/** Automatically generated file. DO NOT MODIFY */
package cn.com.opda.android.clearmaster;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}