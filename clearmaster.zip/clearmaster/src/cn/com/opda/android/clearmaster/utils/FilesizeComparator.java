package cn.com.opda.android.clearmaster.utils;

import java.util.Comparator;

import cn.com.opda.android.clearmaster.model.ClearItem;

public class FilesizeComparator implements Comparator<ClearItem> {

	@Override
	public int compare(ClearItem o1, ClearItem o2) {
		long num1 = o1.getFileSize();
		long num2 = o2.getFileSize();
		if (num1 < num2) {
			return 1;
		} else if (num1 == num2) {
			return 0;
		} else if (num1 > num2) {
			return -1;
		}
		return 0;
	}
}