package cn.com.opda.android.clearmaster.service;

import java.io.File;
import java.io.FileFilter;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;

import android.app.Service;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.res.Resources;
import android.os.IBinder;
import android.util.DisplayMetrics;
import cn.com.opda.android.clearmaster.ClearApkDialogActivity;
import cn.com.opda.android.clearmaster.dao.DBApkPathUtils;
import cn.com.opda.android.clearmaster.model.AppItem;
import cn.com.opda.android.clearmaster.utils.Constants;
import cn.com.opda.android.clearmaster.utils.listsort.TimeComparator;

public class ClearApkService extends Service {
	public static boolean start = false;
	private String packageName;
	private ArrayList<AppItem> appItems = new ArrayList<AppItem>();

	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

	@Override
	public void onCreate() {
		super.onCreate();
		start = true;
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		packageName = intent.getStringExtra("packageName");
		new Thread(new Runnable() {

			@Override
			public void run() {
				ArrayList<String> apkPathList = DBApkPathUtils.getApkPathList(getApplicationContext());
				if (apkPathList != null && apkPathList.size() > 0) {
					for (int i = 0; i < apkPathList.size(); i++) {
						File file = new File(Constants.SDCARD_PATH, apkPathList.get(i));
						if (file != null && file.exists()) {
							ergodicFiles(file);
						}
					}

					File file = new File(Constants.SDCARD_PATH);
					if (file != null && file.exists()) {
						ergodicFiles(file);
					}

				}
				if (appItems.size() == 0) {
					stopSelf();
					start = false;
				} else {
					Collections.sort(appItems, new TimeComparator());
					AppItem appItem = appItems.get(0);
					Intent intent = new Intent(getApplicationContext(), ClearApkDialogActivity.class);
					intent.putExtra("name", appItem.getAppName());
					intent.putExtra("filePath", appItem.getCodePath());
					intent.putExtra("size", appItem.getCodeSize());
					intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					startActivity(intent);
					stopSelf();
					start = false;
				}
			}
		}).start();
		return super.onStartCommand(intent, flags, startId);
	}

	/**
	 * 遍历file
	 */
	public void ergodicFiles(File path) {
		if (path.isDirectory()) {
			File[] files = path.listFiles(new FileFilter() {

				@Override
				public boolean accept(File pathname) {
					if (pathname.getName().endsWith(".apk")) {
						return true;
					}
					return false;
				}
			});
			if (files != null) {
				for (File file : files) {
					AppItem appItem = new AppItem();
					appItem.setFilePath(file.getAbsolutePath());
					if (fillApkModel(appItem)) {
						appItems.add(appItem);
					}
				}
			}
		}
	}

	/**
	 * 获取未安装的apk信息
	 * 
	 * @param ctx
	 * @param apkPath
	 * @return
	 */
	public boolean fillApkModel(AppItem info) {
		String filepath = info.getFilePath();
		File file = new File(filepath);
		if (file == null || !file.exists()) {
			return false;
		}
		info.setCodePath(filepath);
		info.setCodeSize(file.length());
		info.setInstallTime(file.lastModified());
		String PATH_PackageParser = "android.content.pm.PackageParser";
		String PATH_AssetManager = "android.content.res.AssetManager";
		try {
			// 反射得到pkgParserCls对象并实例化,有参数
			Class<?> pkgParserCls = Class.forName(PATH_PackageParser);
			Class<?>[] typeArgs = null;
			Object[] valueArgs = null;
			Object pkgParser = null;
			try {
				typeArgs = new Class<?>[] { String.class };
				Constructor<?> pkgParserCt = pkgParserCls.getConstructor(typeArgs);
				valueArgs = new Object[] { filepath };
				pkgParser = pkgParserCt.newInstance(valueArgs);
			} catch (Exception e1) {
				Constructor<?> pkgParserCt = pkgParserCls.getConstructor();
				pkgParser = pkgParserCt.newInstance();
			}
			if (pkgParser == null) {
				return false;
			}

			// 从pkgParserCls类得到parsePackage方法
			Object pkgParserPkg = null;
			try {
				DisplayMetrics metrics = new DisplayMetrics();
				metrics.setToDefaults();// 这个是与显示有关的, 这边使用默认
				typeArgs = new Class<?>[] { File.class, String.class, DisplayMetrics.class, int.class };
				Method pkgParser_parsePackageMtd = pkgParserCls.getDeclaredMethod("parsePackage", typeArgs);
				valueArgs = new Object[] { new File(filepath), filepath, metrics, 0 };
				// 执行pkgParser_parsePackageMtd方法并返回
				pkgParserPkg = pkgParser_parsePackageMtd.invoke(pkgParser, valueArgs);
			} catch (Exception e1) {
				typeArgs = new Class<?>[] { File.class, int.class };
				Method pkgParser_parsePackageMtd = pkgParserCls.getDeclaredMethod("parsePackage", typeArgs);
				valueArgs = new Object[] { new File(filepath), 0 };
				// 执行pkgParser_parsePackageMtd方法并返回
				pkgParserPkg = pkgParser_parsePackageMtd.invoke(pkgParser, valueArgs);
			}

			// 从返回的对象得到名为"applicationInfo"的字段对象
			if (pkgParserPkg == null) {
				return false;
			}
			Field appInfoFld = pkgParserPkg.getClass().getDeclaredField("applicationInfo");

			// 从对象"pkgParserPkg"得到字段"appInfoFld"的值
			if (appInfoFld.get(pkgParserPkg) == null) {
				return false;
			}
			ApplicationInfo applicationInfo = (ApplicationInfo) appInfoFld.get(pkgParserPkg);

			// 反射得到assetMagCls对象并实例化,无参
			Class<?> assetMagCls = Class.forName(PATH_AssetManager);
			Object assetMag = assetMagCls.newInstance();
			// 从assetMagCls类得到addAssetPath方法
			typeArgs = new Class[1];
			typeArgs[0] = String.class;
			Method assetMag_addAssetPathMtd = assetMagCls.getDeclaredMethod("addAssetPath", typeArgs);
			valueArgs = new Object[1];
			valueArgs[0] = filepath;
			// 执行assetMag_addAssetPathMtd方法
			assetMag_addAssetPathMtd.invoke(assetMag, valueArgs);

			// 得到Resources对象并实例化,有参数
			Resources res = getResources();
			typeArgs = new Class[3];
			typeArgs[0] = assetMag.getClass();
			typeArgs[1] = res.getDisplayMetrics().getClass();
			typeArgs[2] = res.getConfiguration().getClass();
			Constructor<Resources> resCt = Resources.class.getConstructor(typeArgs);
			valueArgs = new Object[3];
			valueArgs[0] = assetMag;
			valueArgs[1] = res.getDisplayMetrics();
			valueArgs[2] = res.getConfiguration();
			res = (Resources) resCt.newInstance(valueArgs);

			// 读取apk文件的信息
			if (applicationInfo != null) {
				String pkgName = applicationInfo.packageName;// 包名
				if (packageName.equals(pkgName)) {
					info.setAppPackage(pkgName);
					if (applicationInfo.labelRes != 0) {
						String neme = (String) res.getText(applicationInfo.labelRes);// 名字
						info.setAppName(neme);
					} else {
						String apkName = file.getName();
						info.setAppName(apkName.substring(0, apkName.lastIndexOf(".")));
					}
				} else {
					return false;
				}
			} else {
				return false;
			}
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		start = false;
	}

}
