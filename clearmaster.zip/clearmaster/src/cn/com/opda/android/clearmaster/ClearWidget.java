package cn.com.opda.android.clearmaster;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

/**
 * widget
 * @author 庄宏岩
 *
 */
public class ClearWidget extends AppWidgetProvider {
	public final String ACTION_ONEKEYCLEAR = "com.android.opda.onekeyclear.Widget.OneKeyClear";

	@Override
	public void onReceive(Context context, Intent intent) {
		super.onReceive(context, intent);
		if (ACTION_ONEKEYCLEAR.equals(intent.getAction())) {
			Intent intent2 = new Intent(context, ClearShortcutActivity.class);
			intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			context.startActivity(intent2);
		}
	}

	@Override
	public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
		super.onUpdate(context, appWidgetManager, appWidgetIds);
		AppWidgetManager mWidgetManager = AppWidgetManager.getInstance(context);
		Intent intent = new Intent(ACTION_ONEKEYCLEAR);
		PendingIntent pendingIntent = PendingIntent.getBroadcast(context, 0, intent, 0);
		updateAppWidget(context, mWidgetManager, pendingIntent, appWidgetIds, 0);
	}

	@Override
	public void onDisabled(Context context) {
		super.onDisabled(context);
	}

	public void updateAppWidget(Context context, AppWidgetManager mWidgetManager, PendingIntent pendingIntent, int[] appWidgetIds, int percent) {
		RemoteViews mRemoteViews = new RemoteViews(context.getPackageName(), R.layout.widget_onekeyclear);
		mRemoteViews.setOnClickPendingIntent(R.id.onekeyClear_imageview, pendingIntent);
		mWidgetManager.updateAppWidget(appWidgetIds, mRemoteViews);
	}

}
