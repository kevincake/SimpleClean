package cn.com.opda.android.clearmaster.adapter;

import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.ThumbnailUtils;
import android.os.AsyncTask;
import android.provider.MediaStore.Video.Thumbnails;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import cn.com.opda.android.clearmaster.R;
import cn.com.opda.android.clearmaster.privacy.VideoInfo;

public class Adapter4VideoPrivacy extends BaseAdapter {

	private ArrayList<VideoInfo> mVideoInfoList = new ArrayList<VideoInfo>();
	private LayoutInflater mInflater;
	private Context mContext;
	private Drawable defaultIcon;
	private boolean checkFlag = false;
	
	
	public Adapter4VideoPrivacy(Context mContext, ArrayList<VideoInfo> mVideoInfoList) {
		super();
		this.mVideoInfoList = mVideoInfoList;
		this.mContext = mContext;
		defaultIcon = mContext.getResources().getDrawable(R.drawable.privacy_wait_pic);
		mInflater = LayoutInflater.from(mContext);
	}

	@Override
	public int getCount() {
		return mVideoInfoList.size();
	}

	@Override
	public Object getItem(int position) {
		return mVideoInfoList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@SuppressLint("NewApi")
	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		final ViewHolder mHolder;
		if (convertView == null) {
			mHolder = new ViewHolder();
			convertView = mInflater.inflate(R.layout.listview_privacy_pic_item, null);
			mHolder.privacy_pic_icon = (ImageView) convertView.findViewById(R.id.privacy_pic_icon);
			mHolder.privacy_pic_checked = (CheckBox) convertView.findViewById(R.id.privacy_pic_checked);
			convertView.setTag(mHolder);
		} else {
			mHolder = (ViewHolder) convertView.getTag();
			if (mHolder.imageLoader != null) {
				mHolder.imageLoader.cancel(true);
			}
		}
		final VideoInfo mVideoInfo = mVideoInfoList.get(position);
		
		mHolder.privacy_pic_checked.setChecked(mVideoInfo.isChecked());
		
		if (checkFlag) {
			mHolder.privacy_pic_checked.setVisibility(View.VISIBLE);
			mHolder.privacy_pic_checked.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					mVideoInfo.setChecked(mHolder.privacy_pic_checked.isChecked());
					notifyDataSetChanged();
				}
			});
			
			convertView.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					if (mHolder.privacy_pic_checked.isChecked()) {
						mHolder.privacy_pic_checked.setChecked(false);
					} else {
						mHolder.privacy_pic_checked.setChecked(true);
					}
					mVideoInfo.setChecked(mHolder.privacy_pic_checked.isChecked());
					notifyDataSetChanged();
				}
			});
		} else {
			mHolder.privacy_pic_checked.setVisibility(View.GONE);
			for (int i = 0; i < mVideoInfoList.size(); i++) {
				VideoInfo videoinfo = mVideoInfoList.get(i);
				videoinfo.setChecked(false);
			}
		}
		
		
		if (mVideoInfo.getBitmap() == null) {
			mHolder.privacy_pic_icon.setBackgroundDrawable(defaultIcon);
			mHolder.imageLoader = new AsyncTask<ViewHolder, Void, Bitmap>() {
				
				private ViewHolder hoder;
				@Override
				protected Bitmap doInBackground(ViewHolder... params) {
					hoder = params[0];
					Bitmap bitmap = ThumbnailUtils.createVideoThumbnail(mVideoInfo.getNewPath(), Thumbnails.MICRO_KIND);  
				 	bitmap = ThumbnailUtils.extractThumbnail(bitmap, 100, 100, ThumbnailUtils.OPTIONS_RECYCLE_INPUT);
					return bitmap;
				}

				@Override
				protected void onPostExecute(Bitmap result) {
					mVideoInfo.setBitmap(result);
					hoder.privacy_pic_icon.setImageResource(R.drawable.privacy_video_ic);
					hoder.privacy_pic_icon.setBackgroundDrawable(new BitmapDrawable(result));
				}
			}.execute(mHolder);
		} else {
			mHolder.privacy_pic_icon.setImageResource(R.drawable.privacy_video_ic);
			mHolder.privacy_pic_icon.setBackgroundDrawable(new BitmapDrawable(mVideoInfo.getBitmap()));
		}
		
		if (mVideoInfo.isChecked()) {
			mHolder.privacy_pic_checked.setChecked(true);
		} else {
			mHolder.privacy_pic_checked.setChecked(false);
		}
		
		return convertView;
	}
	
	public ArrayList<VideoInfo> getSelectList() {
		ArrayList<VideoInfo> selectVideoInfos = new ArrayList<VideoInfo>();
		for (int i = 0; i < mVideoInfoList.size(); i++) {
			VideoInfo videoinfo = mVideoInfoList.get(i);
			if (videoinfo.isChecked()) {
				selectVideoInfos.add(videoinfo);
			}
		}
		return selectVideoInfos;
	}
	
	public void selectAll(){
		for (int i = 0; i < mVideoInfoList.size(); i++) {
			VideoInfo videoinfo = mVideoInfoList.get(i);
			videoinfo.setChecked(true);
		}
		notifyDataSetChanged();
	}
	
	public void selectNull(){
		for (int i = 0; i < mVideoInfoList.size(); i++) {
			VideoInfo videoinfo = mVideoInfoList.get(i);
			videoinfo.setChecked(false);
		}
		notifyDataSetChanged();
	}
	
	public void removeVideo(VideoInfo info){
		mVideoInfoList.remove(info);
		notifyDataSetChanged();
	}
	public void removeVideos(ArrayList<VideoInfo> videoinfos){
		for (int i = 0; i < videoinfos.size(); i++) {
			mVideoInfoList.remove(videoinfos.get(i));
		}
		notifyDataSetChanged();
	}
	
	public void changeFlag(){
		checkFlag = !checkFlag;
		notifyDataSetChanged();
	}
	
	class ViewHolder {
		ImageView privacy_pic_icon;
		CheckBox privacy_pic_checked;
		
		AsyncTask<ViewHolder, Void, Bitmap> imageLoader;
	}
	
}
