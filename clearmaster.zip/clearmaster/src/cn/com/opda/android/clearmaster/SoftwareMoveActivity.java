package cn.com.opda.android.clearmaster;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.TextView;
import cn.com.opda.android.clearmaster.adapter.SoftwareMoveAdapter;
import cn.com.opda.android.clearmaster.custom.CustomActivity;
import cn.com.opda.android.clearmaster.custom.IOSProgressDialog;
import cn.com.opda.android.clearmaster.custom.TitledListView;
import cn.com.opda.android.clearmaster.model.AppItem;
import cn.com.opda.android.clearmaster.utils.CodeSizeComparator;
import cn.com.opda.android.clearmaster.utils.DLog;
import cn.com.opda.android.clearmaster.utils.FormatUtils;
import cn.com.opda.android.clearmaster.utils.MemoryUtils;

public class SoftwareMoveActivity extends CustomActivity implements OnItemClickListener, OnClickListener, OnScrollListener {
	private TitledListView software_move_listview;
	private ArrayList<AppItem> allAppItems;
	private boolean stop;
	private boolean init;
	private TextView software_move_tips_textview;
	public SoftwareMoveActivity(Context context, int resId) {
		super(context, resId);
		initViewAndEvent();
	}

	@Override
	public void initData() {
		if (!init) {
			init = true;
			stop = false;
			new GetAppThread().start();
		}
	}

	private void initViewAndEvent() {
		software_move_listview = (TitledListView) findViewById(R.id.software_move_listview);
		software_move_tips_textview = (TextView) findViewById(R.id.software_move_tips_textview);
	}

	private class GetAppThread extends Thread {
		private ArrayList<AppItem> internalApps;
		private ArrayList<AppItem> storageApps;
		private SoftwareMoveAdapter moveAppAdapter;
		private IOSProgressDialog iosProgressDialog;

		public GetAppThread() {

			internalApps = new ArrayList<AppItem>();
			storageApps = new ArrayList<AppItem>();
			allAppItems = new ArrayList<AppItem>();
			iosProgressDialog = new IOSProgressDialog(mContext, R.string.loading);
			iosProgressDialog.setCancelable(false);
			iosProgressDialog.setCanceledOnTouchOutside(false);
			iosProgressDialog.show();

		}

		@Override
		public void run() {
			super.run();

			boolean isSupport = false;
			long sdMax = MemoryUtils.getTotalExternalMemorySize();
			long sdAva = MemoryUtils.getAvailableExternalMemorySize();
			long romMax = MemoryUtils.getTotalInternalMemorySize();
			long romAva = MemoryUtils.getAvailableInternalMemorySize();
			if (FormatUtils.compareSize(sdMax, romMax) && FormatUtils.compareSize(sdAva, romAva)) {
				isSupport = false;

				String sdcard1 = MemoryUtils.getSdcard0();
				String sdcard2 = MemoryUtils.getSdcard1();
				DLog.i("debug", "sdcard1: " + sdcard1);
				DLog.i("debug", "sdcard2: " + sdcard2);

				if (!TextUtils.isEmpty(sdcard2) && !sdcard1.equals(sdcard2)) {
					long sd2Total = MemoryUtils.getFileTotalSize(sdcard2);
					if (sd2Total > 0 && sd2Total != sdMax) {
						isSupport = true;
					}
				}
			} else {
				isSupport = true;
			}
			if (!isSupport) {
				handler.sendEmptyMessage(1);
				return;
			}

			PackageManager pm = mContext.getPackageManager();
			List<PackageInfo> list = pm.getInstalledPackages((PackageManager.GET_UNINSTALLED_PACKAGES));
			for (PackageInfo packageInfo : list) {
				if (stop) {
					handler.sendEmptyMessage(0);
					return;
				}
				ApplicationInfo applicationInfo = packageInfo.applicationInfo;
				if (applicationInfo.packageName.equals(mContext.getPackageName())) {
					continue;
				}
				boolean flag = false;
				if ((applicationInfo.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0) {
					flag = true;
				} else if ((applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
					flag = true;
				}
				final String sourceDir = applicationInfo.sourceDir;
				if (flag && sourceDir != null) {
					Field field = null;
					int installLocation = 1;
					try {
						field = applicationInfo.getClass().getField("installLocation");
						if (field != null) {
							installLocation = (Integer) field.get(applicationInfo);
						}
					} catch (NoSuchFieldException e1) {
						e1.printStackTrace();
					} catch (IllegalArgumentException e) {
						e.printStackTrace();
					} catch (IllegalAccessException e) {
						e.printStackTrace();
					}
					if ((installLocation & 1) == 0 || (applicationInfo.flags & ApplicationInfo.FLAG_EXTERNAL_STORAGE) != 0) {
						final AppItem info = new AppItem();
						info.setApplicationInfo(applicationInfo);
						info.setAppName(applicationInfo.loadLabel(pm).toString());
						info.setAppPackage(applicationInfo.packageName);
						if ((applicationInfo.flags & ApplicationInfo.FLAG_EXTERNAL_STORAGE) != 0) {
							info.setLocation(AppItem.INSTALL_STORAGE);
						} else {
							info.setLocation(AppItem.INSTALL_INTERNAL);
						}
						if (info.getLocation() == AppItem.INSTALL_INTERNAL) {
							info.setGroupName("手机存储");
							internalApps.add(info);
						} else {
							info.setGroupName("内存卡存储");
							storageApps.add(info);
						}
					}
				}
			}
			if (internalApps != null) {
				Collections.sort(internalApps, new CodeSizeComparator());
			}
			if (storageApps != null) {
				Collections.sort(storageApps, new CodeSizeComparator());
			}
			handler.sendEmptyMessage(0);

		}

		Handler handler = new Handler() {

			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				switch (msg.what) {
				case 0:
					iosProgressDialog.dismiss();
					if (internalApps.size() > 0) {
						AppItem groupItem = new AppItem();
						groupItem.setGroupName("手机存储");
						allAppItems.add(groupItem);
						allAppItems.addAll(internalApps);
					}
					if (storageApps.size() > 0) {
						AppItem groupItem = new AppItem();
						groupItem.setGroupName("内存卡存储");
						allAppItems.add(groupItem);
						allAppItems.addAll(storageApps);
					}
					if(allAppItems.size()==0){
						software_move_tips_textview.setVisibility(View.VISIBLE);
						software_move_tips_textview.setText("没有扫描到可搬家的软件");
						software_move_listview.setVisibility(View.GONE);
					}else{
						moveAppAdapter = new SoftwareMoveAdapter(mContext, allAppItems, internalApps, storageApps);
						software_move_listview.setAdapter(moveAppAdapter);
						software_move_listview.setOnItemClickListener(SoftwareMoveActivity.this);
						software_move_listview.setOnScrollListener(SoftwareMoveActivity.this);
					}
					break;
				case 1:
					iosProgressDialog.dismiss();
					software_move_tips_textview.setVisibility(View.VISIBLE);
					software_move_tips_textview.setText("您的手机不支持软件搬家");
					software_move_listview.setVisibility(View.GONE);
					break;

				default:
					break;
				}
			}

		};
	}

	@Override
	public void onScrollStateChanged(AbsListView view, int scrollState) {

	}

	@Override
	public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
		// 第一项与第二项标题不同，说明标题需要移动
		if (!allAppItems.get(firstVisibleItem).getGroupName().equals(allAppItems.get(firstVisibleItem + 1).getGroupName())) {
			((TitledListView) view).moveTitle();
		} else {
			((TitledListView) view).updateTitle(allAppItems.get(firstVisibleItem).getGroupName());
		}

	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		stop = true;
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
		// AppItem appItem = (AppItem) parent.getItemAtPosition(position);
		// AppManagerUtils.openInstalledDetail(mContext,
		// appItem.getAppPackage());
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {

		default:
			break;
		}
	}

	@Override
	public void onResume() {

	}

}
