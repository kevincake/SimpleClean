package cn.com.opda.android.clearmaster.dao;

import java.util.ArrayList;

import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import cn.com.opda.android.clearmaster.utils.BaseJsonUtil;
import cn.com.opda.android.clearmaster.utils.DLog;

/**
 * 缓存目录数据库操作类
 * 
 * @author 庄宏岩
 * 
 */
public class DBLogPathUtils extends BaseJsonUtil {
	private static final String TAG = "db";

	public DBLogPathUtils(Context context) {
		super(context);
	}

	/**
	 * @param info
	 * @param context
	 *            把信息保存到数据库
	 */
	public static void save(Context context, String path) {
		DBApkPathListOpenHelper tdbOpenHelper = new DBApkPathListOpenHelper(context);
		SQLiteDatabase db = tdbOpenHelper.getWritableDatabase();
		Cursor cursor = db.rawQuery("select * from logpath where path = ?", new String[] { path });
		try {
			if (cursor == null || cursor.getCount() == 0) {
				db.execSQL("insert into logpath (path) values(?)", new Object[] { path });
				DLog.i(TAG, "save()");
			} else {
				DLog.i(TAG, "data is exists");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (cursor != null) {
				cursor.close();
			}
			db.close();
			tdbOpenHelper.close();
		}
	}

	public static void save(Context context, ArrayList<String> paths) {
		DBApkPathListOpenHelper tdbOpenHelper = new DBApkPathListOpenHelper(context);
		SQLiteDatabase db = tdbOpenHelper.getWritableDatabase();
		Cursor cursor = null;
		try {
			for (String path : paths) {
				cursor = db.rawQuery("select * from logpath where path = ?", new String[] { path });
				if (cursor == null || cursor.getCount() == 0) {
					db.execSQL("insert into logpath (path) values(?)", new Object[] { path });
					DLog.i(TAG, "save()");
				} else {
					DLog.i(TAG, "data is exists");
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (cursor != null) {
				cursor.close();
			}
			db.close();
			tdbOpenHelper.close();
		}
	}

	/**
	 * @param context
	 * @return 从数据库中获取所有数据并返回一个集合
	 */
	public static ArrayList<String> getLogPathList(Context context) {
		ArrayList<String> list = new ArrayList<String>();
		DBApkPathListOpenHelper tdbOpenHelper = new DBApkPathListOpenHelper(context);
		SQLiteDatabase db = tdbOpenHelper.getWritableDatabase();
		Cursor cursor = db.rawQuery("select * from logpath", null);
		try {
			if (cursor != null && cursor.getCount() > 0) {
				while (cursor.moveToNext()) {
					list.add(cursor.getString(0));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (cursor != null) {
				cursor.close();
			}
			db.close();
			tdbOpenHelper.close();
		}
		return list;
	}

}
