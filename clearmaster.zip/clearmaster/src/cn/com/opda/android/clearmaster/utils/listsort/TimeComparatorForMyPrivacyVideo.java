package cn.com.opda.android.clearmaster.utils.listsort;

import java.util.Comparator;

import cn.com.opda.android.clearmaster.privacy.VideoInfo;

public class TimeComparatorForMyPrivacyVideo implements Comparator<VideoInfo>{

	@Override
	public int compare(VideoInfo o1, VideoInfo o2) {
		long num1 = Long.parseLong(o1.getNewPath().substring(o1.getNewPath().lastIndexOf("/")+1, o1.getNewPath().length()));
		long num2 = Long.parseLong(o2.getNewPath().substring(o2.getNewPath().lastIndexOf("/")+1, o2.getNewPath().length()));
		if (num1 < num2) {
			return 1;
		} else if (num1 == num2) {
			return 0;
		} else if (num1 > num2) {
			return -1;
		}
		return 0;
	
	}

}
