package cn.com.opda.android.clearmaster;

import java.util.ArrayList;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnChildClickListener;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import cn.com.opda.android.clearmaster.adapter.SmsPrivacyAdapter;
import cn.com.opda.android.clearmaster.custom.CustomActivity;
import cn.com.opda.android.clearmaster.custom.CustomDialog2;
import cn.com.opda.android.clearmaster.custom.IOSProgressDialog;
import cn.com.opda.android.clearmaster.privacy.DBSmsBackUpHelper;
import cn.com.opda.android.clearmaster.privacy.SmsBackUpInfo;
import cn.com.opda.android.clearmaster.privacy.SmsBackUtils;
import cn.com.opda.android.clearmaster.utils.CustomEventCommit;
import cn.com.opda.android.clearmaster.utils.DeviceInfoUtils;
import cn.com.opda.android.clearmaster.utils.SmsUtils;

public class SmsHideActivity extends CustomActivity implements OnClickListener {
	private boolean first = true;
	private SmsPrivacyAdapter smsPrivacyAdapter;
	private boolean stop;
	private IOSProgressDialog pd;
	private SmsPrivacyManager smsPrivacyManager;
	private ExpandableListView sms_hide_listview;
	private CheckBox all_checked_checkbox;
	private TextView no_sms_tips_textview;
	private LinearLayout sms_layout;

	public SmsHideActivity(Context context, int resId) {
		super(context, resId);
		initViewAndEvent();
	}

	public SmsHideActivity(Context context, int resId, SmsPrivacyManager smsPrivacyManager) {
		super(context, resId);
		this.smsPrivacyManager = smsPrivacyManager;
		initViewAndEvent();
	}

	@Override
	public void initData() {
		if (first) {
			first = false;
			new GetSmsTask().execute();
		} else {
			updateSmsCount();
		}
	}

	public void update() {
		if (!first) {
			new GetSmsTask().execute();
		}
	}

	private void initViewAndEvent() {
		Button restore_button = (Button) findViewById(R.id.restore_button);
		restore_button.setOnClickListener(this);
		Button delete_button = (Button) findViewById(R.id.delete_button);
		delete_button.setOnClickListener(this);
		all_checked_checkbox = (CheckBox) findViewById(R.id.all_checked_checkbox);
		all_checked_checkbox.setOnCheckedChangeListener(new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if (smsPrivacyAdapter != null) {
					smsPrivacyAdapter.checkAll(isChecked);
				}
			}
		});
		no_sms_tips_textview = (TextView) findViewById(R.id.no_sms_tips_textview);
		sms_layout = (LinearLayout) findViewById(R.id.sms_layout);
	}

	private class GetSmsTask extends AsyncTask<Void, SmsBackUpInfo, Integer> {
		private ArrayList<SmsBackUpInfo> groupList = new ArrayList<SmsBackUpInfo>();
		private ArrayList<ArrayList<SmsBackUpInfo>> childList = new ArrayList<ArrayList<SmsBackUpInfo>>();
		private ArrayList<Integer> ids = new ArrayList<Integer>();

		@Override
		protected void onPreExecute() {
			pd = new IOSProgressDialog(mContext,"正在加载短信");
			pd.setCancelable(false);
			pd.setCanceledOnTouchOutside(false);
			pd.show();
		}

		@Override
		protected Integer doInBackground(Void... params) {
			if(!DeviceInfoUtils.externalMemoryAvailable()){
				return 0;
			}
			DBSmsBackUpHelper smsbackuphelper = DBSmsBackUpHelper.getInstance();
			smsbackuphelper.openOrCreateDb(1);
			ArrayList<SmsBackUpInfo> backUpInfos = smsbackuphelper.readBackUpInfolist();
			for (SmsBackUpInfo child : backUpInfos) {
				if (stop) {
					return 0;
				}
				SmsBackUpInfo group = new SmsBackUpInfo();
				group.setThread_id(child.getThread_id());
				if (!ids.contains(group.getThread_id())) {
					group.setName(SmsUtils.findRealNameInOther(mContext, child.getAddress()));
					child.setName(group.getName());
					ids.add(group.getThread_id());
					groupList.add(group);
					ArrayList<SmsBackUpInfo> smsBackUpInfos = new ArrayList<SmsBackUpInfo>();
					smsBackUpInfos.add(child);
					childList.add(smsBackUpInfos);
				} else {
					int index = ids.indexOf(group.getThread_id());
					child.setName(groupList.get(index).getName());
					childList.get(index).add(child);
				}
			}
			return 0;
		}

		@Override
		protected void onProgressUpdate(SmsBackUpInfo... values) {
			super.onProgressUpdate(values);
		}

		@Override
		protected void onPostExecute(Integer result) {
			super.onPostExecute(result);
			sms_hide_listview = (ExpandableListView) findViewById(R.id.sms_hide_listview);
			if (groupList.size() > 0) {
				sms_layout.setVisibility(View.VISIBLE);
				no_sms_tips_textview.setVisibility(View.GONE);
				smsPrivacyAdapter = new SmsPrivacyAdapter(mContext, groupList, childList);
				sms_hide_listview.setAdapter(smsPrivacyAdapter);
				sms_hide_listview.setOnChildClickListener(new OnChildClickListener() {

					@Override
					public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
						SmsBackUpInfo smsBackUpInfo = childList.get(groupPosition).get(childPosition);
						smsBackUpInfo.setCheck(!smsBackUpInfo.isCheck());
						smsPrivacyAdapter.notifyDataSetChanged();
						return true;
					}
				});
			} else {
				sms_layout.setVisibility(View.GONE);
				no_sms_tips_textview.setVisibility(View.VISIBLE);
			}
			updateSmsCount();
			pd.dismiss();
		}
	}

	class DeleteSmsThread extends Thread {
		private ArrayList<SmsBackUpInfo> deleteBackUpInfos;

		public DeleteSmsThread(ArrayList<SmsBackUpInfo> backUpInfos) {
			this.deleteBackUpInfos = backUpInfos;
			pd = new IOSProgressDialog(mContext,"正在删除短信");
			pd.setCancelable(false);
			pd.setCanceledOnTouchOutside(false);
			pd.show();
			for (int i = 0; i < smsPrivacyAdapter.getGroupCount(); i++) {
				sms_hide_listview.collapseGroup(i);
			}
		}

		@Override
		public void run() {
			super.run();
			DBSmsBackUpHelper dbSmsBackUpHelper = DBSmsBackUpHelper.getInstance();
			dbSmsBackUpHelper.openOrCreateDb(1);
			dbSmsBackUpHelper.deleteBackupSmsByList(mContext, deleteBackUpInfos);
			dbSmsBackUpHelper.closeDb();
			handler.sendEmptyMessage(0);
		}

		Handler handler = new Handler() {

			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				switch (msg.what) {
				case 0:
					smsPrivacyAdapter.removeSelect();
					updateSmsCount();
					pd.dismiss();
					Toast.makeText(mContext, "短信删除成功", Toast.LENGTH_SHORT).show();
					if (smsPrivacyAdapter.getGroupCount() == 0) {
						sms_layout.setVisibility(View.GONE);
						no_sms_tips_textview.setVisibility(View.VISIBLE);
					}
					break;

				default:
					break;
				}
			}

		};

	}

	class RestoreSmsThread extends Thread {
		private ArrayList<SmsBackUpInfo> restoreBackUpInfos;

		public RestoreSmsThread(ArrayList<SmsBackUpInfo> backUpInfos) {
			this.restoreBackUpInfos = backUpInfos;
			pd = new IOSProgressDialog(mContext,"正在还原短信");
			pd.setCancelable(false);
			pd.setCanceledOnTouchOutside(false);
			pd.show();
			for (int i = 0; i < smsPrivacyAdapter.getGroupCount(); i++) {
				sms_hide_listview.collapseGroup(i);
			}
		}

		@Override
		public void run() {
			super.run();
			for (SmsBackUpInfo info : restoreBackUpInfos) {
				SmsBackUtils backUtils = new SmsBackUtils(mContext);
				backUtils.insertValue(info);
			}
			DBSmsBackUpHelper dbSmsBackUpHelper = DBSmsBackUpHelper.getInstance();
			dbSmsBackUpHelper.openOrCreateDb(1);
			dbSmsBackUpHelper.deleteBackupSmsByList(mContext, restoreBackUpInfos);
			dbSmsBackUpHelper.closeDb();
			handler.sendEmptyMessage(0);
		}

		Handler handler = new Handler() {

			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				switch (msg.what) {
				case 0:
					smsPrivacyAdapter.removeSelect();
					updateSmsCount();
					pd.dismiss();
					Toast.makeText(mContext, "短信还原完成", Toast.LENGTH_SHORT).show();
					smsPrivacyManager.updatePage(0);
					if (smsPrivacyAdapter.getGroupCount() == 0) {
						sms_layout.setVisibility(View.GONE);
						no_sms_tips_textview.setVisibility(View.VISIBLE);
					}
					break;

				default:
					break;
				}
			}

		};

	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		stop = true;
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.restore_button:
			CustomEventCommit.commit(mContext, CustomEventCommit.button_sms_restore);
			if (smsPrivacyAdapter != null) {
				ArrayList<SmsBackUpInfo> selectList = smsPrivacyAdapter.getSelectList();
				if (selectList != null && selectList.size() > 0) {
					new RestoreSmsThread(selectList).start();
				} else {
					Toast.makeText(mContext, "没有选择要还原的短信", Toast.LENGTH_SHORT).show();
				}
			} else {
				Toast.makeText(mContext, "短信列表为空", Toast.LENGTH_SHORT).show();
			}
			break;
		case R.id.delete_button:
			CustomEventCommit.commit(mContext, CustomEventCommit.button_hidesms_delete);
			if (smsPrivacyAdapter != null) {
				final ArrayList<SmsBackUpInfo> selectList = smsPrivacyAdapter.getSelectList();
				if (selectList != null && selectList.size() > 0) {
					final CustomDialog2 customDialog2 = new CustomDialog2(mContext);
					customDialog2.setMessage("确认要删除选择的短信吗?");
					customDialog2.setButton2(R.string.dialog_button_ok, new OnClickListener() {

						@Override
						public void onClick(View v) {
							customDialog2.dismiss();
							new DeleteSmsThread(selectList).start();
						}
					});
					customDialog2.setButton1(R.string.dialog_button_cancel, null);
					customDialog2.setDialogIcon(R.drawable.dialog_icon_tips);
					customDialog2.show();
				} else {
					Toast.makeText(mContext, "没有选择要删除的短信", Toast.LENGTH_SHORT).show();
				}
			} else {
				Toast.makeText(mContext, "短信列表为空", Toast.LENGTH_SHORT).show();
			}
			break;
		default:
			break;
		}
	}

	@Override
	public void onResume() {

	}

	public void updateSmsCount() {
		if (smsPrivacyAdapter != null) {
			smsPrivacyManager.updateSmsCount(smsPrivacyAdapter.getSmsCount());
		} else {
			smsPrivacyManager.updateSmsCount(0);
		}
	}

}
