package cn.com.opda.android.clearmaster.http.exception;
/**
 * HTTP StatusCode is not 200
 */
public class HttpStatusException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int statusCode = -1;

	public HttpStatusException(String desc,int statusCode) {
		super(desc+statusCode);
		this.statusCode=statusCode;
	}
	public HttpStatusException(String desc) {
		super(desc);
	}
	public HttpStatusException() {
		super("服务器端响应异常");
	}
	//
	public int getStatusCode() {
		return statusCode;
	}
	
}
               