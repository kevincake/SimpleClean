package cn.com.opda.android.clearmaster;

import java.util.ArrayList;

import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;
import cn.com.opda.android.clearmaster.adapter.SuffixAdapter;
import cn.com.opda.android.clearmaster.custom.CustomDialog2;
import cn.com.opda.android.clearmaster.custom.CustomDialog3;
import cn.com.opda.android.clearmaster.custom.CustomGridView;
import cn.com.opda.android.clearmaster.model.SuffixInfo;
import cn.com.opda.android.clearmaster.service.ShakeClearService;
import cn.com.opda.android.clearmaster.utils.BannerUtils;
import cn.com.opda.android.clearmaster.utils.Constants;
import cn.com.opda.android.clearmaster.utils.ShortCutUtils;

import com.umeng.analytics.MobclickAgent;

/**
 * 软件设置类
 * 
 * @author 庄宏岩
 * 
 */
public class SettingsActivity extends BaseActivity implements OnSeekBarChangeListener, OnCheckedChangeListener {
	private CheckBox checkbox_vibrate;
	private SeekBar seekbar_timespace;
	private SeekBar seekbar_sensitivity;
	private TextView seekbar_timespace_value;
	private TextView seekbar_sensitivity_value;
	private SharedPreferences sp;
	private Editor editor;
	private boolean shortcutCreated;
	private Context mContext;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_settings);
		mContext = SettingsActivity.this;
		BannerUtils.setMainTitle(this, R.string.menu_setting);
		BannerUtils.initBackButton(this);
		sp = getSharedPreferences(Constants.SHARED_PREFERENCES_NAME, Context.MODE_PRIVATE);
		editor = sp.edit();
		initViewAndEvent();
	}

	private void initViewAndEvent() {
		checkbox_vibrate = (CheckBox) findViewById(R.id.quicksetting_shake_checkbox_vibrate);

		seekbar_timespace = (SeekBar) findViewById(R.id.quicksetting_shake_seekbar_timespace);
		seekbar_sensitivity = (SeekBar) findViewById(R.id.quicksetting_shake_seekbar_sensitivity);

		seekbar_timespace_value = (TextView) findViewById(R.id.quicksetting_shake_seekbar_timespace_value);
		seekbar_sensitivity_value = (TextView) findViewById(R.id.quicksetting_shake_seekbar_sensitivity_value);

		checkbox_vibrate.setOnCheckedChangeListener(this);
		seekbar_timespace.setOnSeekBarChangeListener(this);
		seekbar_sensitivity.setOnSeekBarChangeListener(this);

		checkbox_vibrate.setChecked(sp.getBoolean(Constants.SHAKE_CHECKBOX_VIBRATE, true));

		// seekbar_timespace.setSecondaryProgress(sp.getInt(Constants.SHAKE_SEEKBAR_TIMESPACE,
		// 1));
		seekbar_timespace.setProgress(sp.getInt(Constants.SHAKE_SEEKBAR_TIMESPACE, 1));

		// seekbar_sensitivity.setSecondaryProgress(sp.getInt(Constants.SHAKE_SEEKBAR_SENSITIVITY,
		// 2));
		seekbar_sensitivity.setProgress(sp.getInt(Constants.SHAKE_SEEKBAR_SENSITIVITY, 2));

		seekbar_timespace_value.setText(formatDateTime(Constants.TIMESPACES[sp.getInt(Constants.SHAKE_SEEKBAR_TIMESPACE, 1)]));
		seekbar_sensitivity_value.setText(Constants.SENSITIVITYS[sp.getInt(Constants.SHAKE_SEEKBAR_SENSITIVITY, 2)] + "");

		CheckBox shakeCacheCheckbox = (CheckBox) findViewById(R.id.Qsettings_shake_cache_checkbox);
		boolean ischecked = sp.getBoolean(Constants.SHAKE_STATE_CACHE, false);
		shakeCacheCheckbox.setChecked(ischecked);
		shakeCacheCheckbox.setOnCheckedChangeListener(this);
		if (!ischecked) {
			checkbox_vibrate.setEnabled(false);
			seekbar_timespace.setEnabled(false);
			seekbar_sensitivity.setEnabled(false);
		}

		TextView send_desktop = (TextView) findViewById(R.id.Qsettings_send_desktop);
		send_desktop.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (!shortcutCreated) {
					shortcutCreated = true;
					ShortCutUtils.createShortCut(getApplicationContext(), "cn.com.opda.android.clearmaster.ClearShortcutActivity", R.drawable.shortcut_icon,
							R.string.chortcut_name);
					Toast.makeText(SettingsActivity.this, R.string.QuickSettings_shortcut_create, Toast.LENGTH_SHORT).show();
				} else {
					Toast.makeText(SettingsActivity.this, R.string.shortcut_created, Toast.LENGTH_SHORT).show();
				}
			}
		});
		//
		// LinearLayout send_desktop_2 = (LinearLayout)
		// findViewById(R.id.Qsettings_send_desktop_2);
		// if
		// (this.getResources().getConfiguration().locale.getCountry().equals("CN"))
		// {
		// send_desktop_2.setVisibility(View.VISIBLE);
		// }else{
		// send_desktop_2.setVisibility(View.GONE);
		// }
		// send_desktop_2.setOnClickListener(new OnClickListener() {
		//
		// @Override
		// public void onClick(View v) {
		// ShortCutUtils.createShortCut(getApplicationContext(),
		// "cn.com.opda.android.clearmaster.ClearShortcutActivity2",
		// R.drawable.shortcut_icon_2,
		// R.string.chortcut_name_2);
		// Toast.makeText(SettingsActivity.this,
		// R.string.QuickSettings_shortcut_create_2, Toast.LENGTH_SHORT).show();
		// }
		// });

		TextView add_widget = (TextView) findViewById(R.id.Qsettings_add_widget);
		add_widget.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				CustomDialog2 customDialog = new CustomDialog2(SettingsActivity.this);
				customDialog.setDialogIcon(R.drawable.dialog_icon_tips);
				customDialog.setMessage(R.string.QuickSettings_add_widget_dialog_msg);
				customDialog.setButton2(R.string.dialog_button_ok, null);
				customDialog.show();
			}
		});

		LinearLayout keep_list = (LinearLayout) findViewById(R.id.Qsettings_keep_list);
		keep_list.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				startActivity(new Intent(SettingsActivity.this, AppKeepActivity.class));
			}
		});

		LinearLayout cachewhite_list = (LinearLayout) findViewById(R.id.Qsettings_cachewhite_list);
		cachewhite_list.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				startActivity(new Intent(SettingsActivity.this, CacheWhiteActivity.class));
			}
		});

		LinearLayout Qsettings_bigfile_suffix = (LinearLayout) findViewById(R.id.Qsettings_bigfile_suffix);
		Qsettings_bigfile_suffix.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				startActivity(new Intent(mContext, SuffixSettingActivity.class));
			}
		});

		CheckBox Qsettings_clean_reminder_checkbox = (CheckBox) findViewById(R.id.Qsettings_clean_reminder_checkbox);
		if (sp.getBoolean(Constants.SHAKE_STATE_CLEAN_REMINDER, true)) {
			Qsettings_clean_reminder_checkbox.setChecked(true);
		} else {
			Qsettings_clean_reminder_checkbox.setChecked(false);
		}
		Qsettings_clean_reminder_checkbox.setOnCheckedChangeListener(this);

		CheckBox Qsettings_process_reminder_checkbox = (CheckBox) findViewById(R.id.Qsettings_process_reminder_checkbox);
		if (sp.getBoolean(Constants.PROCESS_TIPS_CHECKED, true)) {
			Qsettings_process_reminder_checkbox.setChecked(true);
		} else {
			Qsettings_process_reminder_checkbox.setChecked(false);
		}
		Qsettings_process_reminder_checkbox.setOnCheckedChangeListener(this);

		CheckBox Qsettings_depth_reminder_checkbox = (CheckBox) findViewById(R.id.Qsettings_depth_reminder_checkbox);
		if (sp.getBoolean(Constants.DEPTH_TIPS_CHECKED, true)) {
			Qsettings_depth_reminder_checkbox.setChecked(true);
		} else {
			Qsettings_depth_reminder_checkbox.setChecked(false);
		}
		Qsettings_depth_reminder_checkbox.setOnCheckedChangeListener(this);

		CheckBox Qsettings_apk_reminder_checkbox = (CheckBox) findViewById(R.id.Qsettings_apk_reminder_checkbox);
		if (sp.getBoolean(Constants.APK_CLEAR_TIPS_CHECKED, true)) {
			Qsettings_apk_reminder_checkbox.setChecked(true);
		} else {
			Qsettings_apk_reminder_checkbox.setChecked(false);
		}
		Qsettings_apk_reminder_checkbox.setOnCheckedChangeListener(this);

	}
	

	@Override
	public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
		switch (seekBar.getId()) {
		case R.id.quicksetting_shake_seekbar_timespace: {
			editor.putInt(Constants.SHAKE_SEEKBAR_TIMESPACE, progress).commit();
			seekbar_timespace_value.setText(formatDateTime(Constants.TIMESPACES[progress]));
			break;
		}
		case R.id.quicksetting_shake_seekbar_sensitivity: {
			editor.putInt(Constants.SHAKE_SEEKBAR_SENSITIVITY, progress).commit();
			seekbar_sensitivity_value.setText(Constants.SENSITIVITYS[progress] + "");
			break;
		}
		}
	}

	@Override
	public void onStartTrackingTouch(SeekBar seekBar) {

	}

	@Override
	public void onStopTrackingTouch(SeekBar seekBar) {

	}

	@Override
	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		switch (buttonView.getId()) {
		case R.id.quicksetting_shake_checkbox_vibrate: {
			editor.putBoolean(Constants.SHAKE_CHECKBOX_VIBRATE, isChecked).commit();
			break;
		}
		case R.id.Qsettings_shake_cache_checkbox: {
			editor.putBoolean(Constants.SHAKE_STATE_CACHE, isChecked).commit();
			Intent intent = new Intent(SettingsActivity.this, ShakeClearService.class);
			if (isChecked) {
				startService(intent);
			} else {
				stopService(intent);
			}
			if (isChecked) {
				checkbox_vibrate.setEnabled(true);
				seekbar_timespace.setEnabled(true);
				seekbar_sensitivity.setEnabled(true);
			} else {
				checkbox_vibrate.setEnabled(false);
				seekbar_timespace.setEnabled(false);
				seekbar_sensitivity.setEnabled(false);
			}

			break;
		}
		case R.id.Qsettings_clean_reminder_checkbox:
			editor.putBoolean(Constants.SHAKE_STATE_CLEAN_REMINDER, isChecked).commit();
			break;
		case R.id.Qsettings_process_reminder_checkbox:
			editor.putBoolean(Constants.PROCESS_TIPS_CHECKED, isChecked).commit();
			break;
		case R.id.Qsettings_depth_reminder_checkbox:
			editor.putBoolean(Constants.DEPTH_TIPS_CHECKED, isChecked).commit();
			break;
		case R.id.Qsettings_apk_reminder_checkbox:
			editor.putBoolean(Constants.APK_CLEAR_TIPS_CHECKED, isChecked).commit();
			break;
		}
	}

	public String formatDateTime(int time) {
		String bootstart_time_str = "";
		if (time >= 60) {
			bootstart_time_str = (time / 60) + getString(R.string.QuickSettings_date_m);
		} else {
			bootstart_time_str = time + getString(R.string.QuickSettings_date_s);
		}
		return bootstart_time_str;
	}

	@Override
	protected void onResume() {
		MobclickAgent.onResume(this);
		super.onResume();
	}

	@Override
	protected void onPause() {
		MobclickAgent.onPause(this);
		super.onPause();
	}
}
