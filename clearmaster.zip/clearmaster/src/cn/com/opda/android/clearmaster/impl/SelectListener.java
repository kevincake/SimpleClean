package cn.com.opda.android.clearmaster.impl;

public interface SelectListener {
	public abstract void selectSize(long size);
}