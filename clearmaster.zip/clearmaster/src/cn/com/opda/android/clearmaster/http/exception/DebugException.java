package cn.com.opda.android.clearmaster.http.exception;
/**
 * 服务器正在测试维护
 * @author songhai.zhang
 *
 */
public class DebugException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public DebugException() {
		super("服务器正在维护中……");
	}
	public DebugException(String desc) {
		super(desc+"");
	}
}
               