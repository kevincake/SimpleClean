package cn.com.opda.android.clearmaster.utils;

import java.io.File;

import android.net.Uri;
import android.os.Environment;

public class Constants {

	public static final String UPDATE_APPCODE = "7";

	public static final String SDCARD_PATH = Environment.getExternalStorageDirectory().getAbsolutePath();
	public static final String IMAGECACHE_PATH = SDCARD_PATH + "/clearmaster_zds/imagecache";
	public static final String IMAGECACHE_NOMEDIA = SDCARD_PATH + "/clearmaster_zds/imagecache/.nomedia";
	// 本软件文件夹的位置
	public final static String FILE_PATH = SDCARD_PATH + File.separator + "clearmaster_zds";

	//系统应用备份目录
	public final static String SYSTEM_BACKUP_PATH = "/sdcard/clearmaster_zds/systembackup/";
	
	public final static String DOWNLOAD_PATH =  FILE_PATH +"/apk";
	
	//备份隐藏图片和视频
	public final static String PIC_NEW_PATH = Constants.FILE_PATH + "/dashi";

	public static final String GLOBAL_DID_KEY = "did_key";
	public static final String GLOBAL_DEVICEID_KEY = "deviceid_key";
	public static final String GLOBAL_DEVICE_DADANAME_KEY = "device_dataname_key";
	public static final String HOST = "http://api.kfkx.net/";
	public static final String DEVICEINFO_URL = HOST + "devices/recovery";
	public static final String COMMIT_MISS_MODEL = HOST + "device/model_miss";
	public static final String COMMIT_APK_PATH = HOST + "devices/file_path";

	public static final String SMS_ID = "_id";
	public static final String SMS_thread_id = "thread_id";
	public static final String SMS_address = "address";
	public static final String SMS_person = "person";
	public static final String SMS_date = "date";
	public static final String SMS_read = "read";
	public static final String SMS_status = "status";
	public static final String SMS_type = "type";
	public static final String SMS_body = "body";
	public static final Uri SMSAll_URL = Uri.parse("content://sms/");

	public static final int PHONETYPE_ALL = 0; // 所有会话
	public static final int PHONETYPE_CONTACT = 1; // 联系人会话
	public static final int PHONETYPE_UNKNOWN = 2; // 陌生人会话
	public static final int PHONETYPE_SERVER = 3; // 服务会话

	public final static String SHARED_PREFERENCES_NAME = "QuickSettings";
	public final static String SHAKE_STATE_MEMORY = "shake_state_memory";
	public final static String SHAKE_STATE_CACHE = "shake_state_cache";
	public final static String SHAKE_STATE_CLEAN_REMINDER = "clean_reminder_checkbox";
	public final static String PROCESS_TIPS_CHECKED = "process_tips_checked";
	public final static String DEPTH_TIPS_CHECKED = "depth_tips_checked";
	public final static String APK_CLEAR_TIPS_CHECKED = "apk_clear_tips_checked";
	public final static String SHAKE_CHECKBOX_VIBRATE = "shake_checkbox_vibrate";
	public final static String SHAKE_SEEKBAR_TIMESPACE = "shake_seekbar_timespace";
	public final static String SHAKE_TIMESPACE = "shake_timespace";
	public final static String SHAKE_SEEKBAR_SENSITIVITY = "seekbar_sensitivity";
	public final static int[] TIMESPACES = { 10, 30, 60, 300, 600, 1800 };
	public final static int[] SENSITIVITYS = { 10, 20, 25, 30, 40, 50 };

	public static final int TOOL_ID_APKMANAGER = 1;
	public static final int TOOL_ID_APPMOVE = 2;
	public static final int TOOL_ID_RECOMMEND = 3;
	public static final int TOOL_ID_PROCESSMANAGER = 4;
	public static final int TOOL_ID_SYSTEMCLEANER = 5;
	
	
	public static final String BACKUP_PATH = File.separator + "backup"
			+ File.separator;
	public static final String BACKUP_DIR_PATH = FILE_PATH + BACKUP_PATH;
	public static final String FILE_SMSBACKUP = "smsbackup.db";
	public static final String FILE_PIC = "pic.db";
	public static final String FILE_VIDEO = "video.db";
	public static final boolean SHOUFA = true;
	
	

}
