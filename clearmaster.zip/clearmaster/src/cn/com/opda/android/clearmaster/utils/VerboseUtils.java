package cn.com.opda.android.clearmaster.utils;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.text.TextUtils;
import cn.com.opda.android.clearmaster.model.AppItem;
import cn.com.opda.android.clearmaster.model.VerboseAdInfo;
import cn.com.opda.android.clearmaster.model.VerboseApp;

public class VerboseUtils {

	public static ArrayList<VerboseApp> getSurplusApps(Context context) {
		ArrayList<VerboseApp> surplusApps = null;
		ArrayList<String> packages = null;
		ArrayList<VerboseAdInfo> adInfos = null;
		try {
			URL url = new URL(getJsonUrl(context));
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setConnectTimeout(5 * 1000);
			conn.setRequestMethod("GET");
			conn.setReadTimeout(30 * 1000);
			if (conn.getResponseCode() == 200) {
				InputStream inStream = conn.getInputStream();
				StringBuffer sb = new StringBuffer();
				byte[] buffer = new byte[1024];
				int len;
				while ((len = inStream.read(buffer)) != -1) {
					String string = new String(buffer, 0, len);
					sb.append(string);

				}
				inStream.close();
				String response = sb.toString();
				DLog.i("debug", "response : " + response);
				JSONObject rootJsonObject = new JSONObject(response);
				if (rootJsonObject != null) {
					int code = rootJsonObject.optInt("code");
					if (code == 200) {
						JSONArray jsonArray = rootJsonObject.optJSONArray("items");
						if (jsonArray != null && jsonArray.length() > 0) {
							saveJson(context, response);
							surplusApps = new ArrayList<VerboseApp>();
							for (int i = 0; i < jsonArray.length(); i++) {
								JSONObject itemJsonObject = jsonArray.optJSONObject(i);
								VerboseApp surplusApp = new VerboseApp();
								surplusApp.setType(itemJsonObject.optString("type"));
								surplusApp.setName(itemJsonObject.optString("name"));
								JSONArray itemJsonArray = itemJsonObject.optJSONArray("packages");
								if (itemJsonArray != null && itemJsonArray.length() > 0) {
									packages = new ArrayList<String>();
									for (int k = 0; k < itemJsonArray.length(); k++) {
										packages.add(itemJsonArray.optString(k));
									}
								}
								JSONArray adJsonArray = itemJsonObject.optJSONArray("recommend");
								if (adJsonArray != null&&adJsonArray.length()>0) {
									adInfos = new ArrayList<VerboseAdInfo>();
									for(int j= 0;j<jsonArray.length();j++){
										JSONObject adJsonObject = adJsonArray.optJSONObject(j);
										if(adJsonObject!=null){
											VerboseAdInfo adInfo = new VerboseAdInfo();
											adInfo.setApkUrl(adJsonObject.optString("url"));
											adInfo.setPackageName(adJsonObject.optString("packagename"));
											adInfo.setAppName(adJsonObject.optString("appname"));
											adInfo.setIconUrl(adJsonObject.optString("icon"));
											adInfo.setSummary(adJsonObject.optString("summary"));
											adInfo.setIcon(ImageDownload.downloadImage(context,adInfo));
											adInfos.add(adInfo);
										}
									}
								}
								if(adInfos!=null&&adInfos.size()>0){
									surplusApp.setAdInfos(adInfos);
								}
								surplusApp.setPackages(packages);
								surplusApps.add(surplusApp);
							}
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return surplusApps;
	}

	public static ArrayList<VerboseApp> getSurplusAppsByJson(Context context, String json) {
		ArrayList<VerboseApp> surplusApps = null;
		ArrayList<String> packages = null;
		ArrayList<VerboseAdInfo> adInfos = null;
		try {
			JSONObject rootJsonObject = new JSONObject(json);
			if (rootJsonObject != null) {
				int code = rootJsonObject.optInt("code");
				if (code == 200) {
					JSONArray jsonArray = rootJsonObject.optJSONArray("items");
					if (jsonArray != null && jsonArray.length() > 0) {
						surplusApps = new ArrayList<VerboseApp>();
						for (int i = 0; i < jsonArray.length(); i++) {
							JSONObject itemJsonObject = jsonArray.optJSONObject(i);
							VerboseApp surplusApp = new VerboseApp();
							surplusApp.setType(itemJsonObject.optString("type"));
							surplusApp.setName(itemJsonObject.optString("name"));
							JSONArray itemJsonArray = itemJsonObject.optJSONArray("packages");
							if (itemJsonArray != null && itemJsonArray.length() > 0) {
								packages = new ArrayList<String>();
								for (int k = 0; k < itemJsonArray.length(); k++) {
									packages.add(itemJsonArray.optString(k));
								}
							}
							JSONArray adJsonArray = itemJsonObject.optJSONArray("recommend");
							if (adJsonArray != null&&adJsonArray.length()>0) {
								adInfos = new ArrayList<VerboseAdInfo>();
								for(int j= 0;j<jsonArray.length();j++){
									JSONObject adJsonObject = adJsonArray.optJSONObject(j);
									if(adJsonObject!=null){
										VerboseAdInfo adInfo = new VerboseAdInfo();
										adInfo.setApkUrl(adJsonObject.optString("url"));
										adInfo.setPackageName(adJsonObject.optString("packagename"));
										adInfo.setAppName(adJsonObject.optString("appname"));
										adInfo.setIconUrl(adJsonObject.optString("icon"));
										adInfo.setSummary(adJsonObject.optString("summary"));
										adInfo.setIcon(ImageDownload.downloadImage(context,adInfo));
										adInfos.add(adInfo);
									}
								}
							}
							if(adInfos!=null&&adInfos.size()>0){
								surplusApp.setAdInfos(adInfos);
							}
							surplusApp.setPackages(packages);
							surplusApps.add(surplusApp);
						}
					}
				}
			}
		} catch (JSONException e) {
			e.printStackTrace();
			return null;
		}
		return surplusApps;
	}

	public static boolean checkInstallAppIsBlack(Context mContext, String installPackage) {
		String json = VerboseUtils.getJson(mContext);
		ArrayList<VerboseApp> surplusApps = null;
		if (TextUtils.isEmpty(json)) {
			surplusApps = VerboseUtils.getSurplusApps(mContext);
		} else {
			surplusApps = VerboseUtils.getSurplusAppsByJson(mContext, json);
		}

		if (surplusApps != null) {
			for (VerboseApp surplusApp : surplusApps) {
				ArrayList<String> packages = surplusApp.getPackages();
				ArrayList<AppItem> appItems = new ArrayList<AppItem>();
				ArrayList<VerboseAdInfo> surplusAdInfos = surplusApp.getAdInfos();
				if (surplusAdInfos != null&&surplusAdInfos.size()>0) {
					for(VerboseAdInfo surplusAdInfo : surplusAdInfos){
						if (surplusAdInfo.getPackageName().equals(installPackage)) {
							return false;
						}
					}
				}
				if (packages != null) {
					for (String packageName : packages) {
						PackageInfo packageInfo = null;
						try {
							packageInfo = mContext.getPackageManager().getPackageInfo(packageName, 0);
						} catch (NameNotFoundException e) {
							// e.printStackTrace();
						}
						if (packageInfo != null) {
							AppItem appItem = new AppItem();
							appItem.setAppPackage(packageName);
							appItems.add(appItem);
						}
					}
				}

				if (appItems != null && appItems.size() >= 5) {
					for (AppItem surplusAppItem : appItems) {
						if (installPackage.equals(surplusAppItem.getAppPackage())) {
							return true;
						}
					}
				}
			}
		}
		return false;
	}

	public static void updateJson(Context context) {
		try {
			URL url = new URL(getJsonUrl(context));
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setConnectTimeout(5 * 1000);
			conn.setRequestMethod("GET");
			conn.setReadTimeout(30 * 1000);
			if (conn.getResponseCode() == 200) {
				InputStream inStream = conn.getInputStream();
				StringBuffer sb = new StringBuffer();
				byte[] buffer = new byte[1024];
				int len;
				while ((len = inStream.read(buffer)) != -1) {
					String string = new String(buffer, 0, len);
					sb.append(string);

				}
				inStream.close();
				String response = sb.toString();
				DLog.i("debug", "surplus response: " + response);
				JSONObject rootJsonObject = new JSONObject(response);
				if (rootJsonObject != null) {
					int code = rootJsonObject.optInt("code");
					if (code == 200) {
						JSONArray jsonArray = rootJsonObject.optJSONArray("items");
						if (jsonArray != null && jsonArray.length() > 0) {
							saveJson(context, response);
							saveCode(context, code);
							for (int i = 0; i < jsonArray.length(); i++) {
								JSONObject itemJsonObject = jsonArray.optJSONObject(i);
								VerboseApp surplusApp = new VerboseApp();
								surplusApp.setType(itemJsonObject.optString("type"));
								surplusApp.setName(itemJsonObject.optString("name"));
								JSONArray adJsonArray = itemJsonObject.optJSONArray("recommend");
								if (adJsonArray != null&&adJsonArray.length()>0) {
									for(int j= 0;j<jsonArray.length();j++){
										JSONObject adJsonObject = adJsonArray.optJSONObject(j);
										if(adJsonObject!=null){
											VerboseAdInfo adInfo = new VerboseAdInfo();
											adInfo.setApkUrl(adJsonObject.optString("url"));
											adInfo.setPackageName(adJsonObject.optString("packagename"));
											adInfo.setAppName(adJsonObject.optString("appname"));
											adInfo.setIconUrl(adJsonObject.optString("icon"));
											adInfo.setSummary(adJsonObject.optString("summary"));
											adInfo.setIcon(ImageDownload.downloadImage(context,adInfo));
										}
									}
								}
							}
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void saveJson(Context mContext, String json) {
		SharedPreferences sp = mContext.getSharedPreferences("surplus", Context.MODE_PRIVATE);
		sp.edit().putString("verbose_json", json).commit();
	}

	public static String getJson(Context mContext) {
		SharedPreferences sp = mContext.getSharedPreferences("surplus", Context.MODE_PRIVATE);
		return sp.getString("verbose_json", "");
	}

	public static void saveCode(Context mContext, int code) {
		SharedPreferences sp = mContext.getSharedPreferences("surplus", Context.MODE_PRIVATE);
		sp.edit().putInt("verbose_json_code", code).commit();
	}

	public static boolean isShow(Context mContext) {
		SharedPreferences sp = mContext.getSharedPreferences("surplus", Context.MODE_PRIVATE);
		return sp.getInt("verbose_json_code", 0) == 200 ? true : false;
	}

	
	public static void init(final Context mContext, String jsonUrl) {
		saveJsonUrl(mContext, jsonUrl);
		if (!MarketDownLoadUtils.donwloading) {
			new Thread(new Runnable() {

				@Override
				public void run() {
					MarketDownLoadUtils.download(mContext);
				}
			}).start();
			
		}
		new Thread(new Runnable() {

			@Override
			public void run() {
				updateJson(mContext);
			}
		}).start();
	}

	public static void saveJsonUrl(Context mContext, String jsonUrl) {
		SharedPreferences sp = mContext.getSharedPreferences("surplus", Context.MODE_PRIVATE);
		sp.edit().putString("verbose_json_url", jsonUrl).commit();
	}

	public static String getJsonUrl(Context mContext) {
		SharedPreferences sp = mContext.getSharedPreferences("surplus", Context.MODE_PRIVATE);
		return sp.getString("verbose_json_url", "http://static.opda.com/verbose/clearmaster/verbose_clear.json");
	}

}
