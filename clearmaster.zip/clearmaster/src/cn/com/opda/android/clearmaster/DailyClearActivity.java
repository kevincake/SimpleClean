package cn.com.opda.android.clearmaster;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.IPackageStatsObserver;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.PackageStats;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.os.RemoteException;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.TranslateAnimation;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnChildClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import cn.com.opda.android.clearmaster.adapter.Adapter4AdClear;
import cn.com.opda.android.clearmaster.adapter.Adapter4DailyClear;
import cn.com.opda.android.clearmaster.adapter.Adapter4ResultAd;
import cn.com.opda.android.clearmaster.adapter.ProcessItemAdapter;
import cn.com.opda.android.clearmaster.custom.CustomDialog3;
import cn.com.opda.android.clearmaster.custom.CustomExpandListView;
import cn.com.opda.android.clearmaster.custom.CustomListView;
import cn.com.opda.android.clearmaster.custom.CustomTextView;
import cn.com.opda.android.clearmaster.custom.WaterWaveCustomView;
import cn.com.opda.android.clearmaster.dao.CacheWhiteListUtils;
import cn.com.opda.android.clearmaster.dao.KeepListUtils;
import cn.com.opda.android.clearmaster.dao.news.DBAppAdUtils;
import cn.com.opda.android.clearmaster.dao.news.DBAppCacheUtils;
import cn.com.opda.android.clearmaster.impl.CheckedListener;
import cn.com.opda.android.clearmaster.impl.SelectListener;
import cn.com.opda.android.clearmaster.model.AdInfo;
import cn.com.opda.android.clearmaster.model.AppItem;
import cn.com.opda.android.clearmaster.model.BaseItem;
import cn.com.opda.android.clearmaster.model.ClearItem;
import cn.com.opda.android.clearmaster.model.EmptyFolder;
import cn.com.opda.android.clearmaster.model.GroupItem;
import cn.com.opda.android.clearmaster.model.ThumbnailInfo;
import cn.com.opda.android.clearmaster.model.ToolboxAd;
import cn.com.opda.android.clearmaster.quickaction2.ActionItem2;
import cn.com.opda.android.clearmaster.quickaction2.QuickAction2;
import cn.com.opda.android.clearmaster.utils.AppDownload;
import cn.com.opda.android.clearmaster.utils.AppManagerUtils;
import cn.com.opda.android.clearmaster.utils.BannerUtils;
import cn.com.opda.android.clearmaster.utils.CacheComparator;
import cn.com.opda.android.clearmaster.utils.ClearUtils;
import cn.com.opda.android.clearmaster.utils.CodeSizeComparator;
import cn.com.opda.android.clearmaster.utils.Constants;
import cn.com.opda.android.clearmaster.utils.CopyDBUtils;
import cn.com.opda.android.clearmaster.utils.CustomEventCommit;
import cn.com.opda.android.clearmaster.utils.DLog;
import cn.com.opda.android.clearmaster.utils.DensityUtil;
import cn.com.opda.android.clearmaster.utils.FileUtils;
import cn.com.opda.android.clearmaster.utils.FormatUtils;
import cn.com.opda.android.clearmaster.utils.MemorySizeComparator;
import cn.com.opda.android.clearmaster.utils.MemoryUtils;
import cn.com.opda.android.clearmaster.utils.MenuOptionUtil;
import cn.com.opda.android.clearmaster.utils.ProcessManagerUtils;
import cn.com.opda.android.clearmaster.utils.Terminal;
import cn.com.opda.android.clearmaster.utils.ToolboxAdUtils;

import com.lib.statistics.StatisticsUtils;
import com.umeng.analytics.MobclickAgent;

/**
 * 日常清理类
 * 
 * @author 庄宏岩
 * 
 */
public class DailyClearActivity extends BaseActivity implements OnClickListener, OnChildClickListener, OnItemClickListener {
	private long totalCacheSize;
	private long selectCacheSize;
	private long totalAdSize;
	private long selectAdSize;
	private long totalThumbnailsSize;
	private long totalEmptyFolderSize;
	private long selectThumbnailsSize;
	private long selectEmptyFolderSize;
	private long selectProcessSize;
	private long totalProcessSize;
	private Context mContext;
	private TextView scan_textview;
	private Adapter4DailyClear mAdapter4DailyClear;
	private Adapter4AdClear mAdapter4AdClear;
	private CustomExpandListView daily_clear_expandlistview;
	private ProgressBar cache_scan_progressbar, process_scan_progressbar;
	private ProgressBar ad_scan_progressbar;
	private LinearLayout result_page;
	private RelativeLayout list_page;
	private boolean stop;
	private TextView cache_size_textview;
	private TextView ad_size_textview;
	private TextView process_size_textview;
	private TextView empty_folder_size_textview, empty_folder_count_textview;
	private TextView thumbnails_size_textview, thumbnails_count_textview;
	private ProgressBar thumbnails_scan_progressbar, empty_folder_scan_progressbar;
	private CheckBox thumbnails_checked_imageview, empty_folder_checked_imageview;
	private ImageView empty_folder_duigou_imageview, thumbnails_duigou_imageview, cache_duigou_imageview, process_duigou_imageview;
	private ImageView ad_duigou_imageview;
	private EmptyFolder emptyFolder;
	private ThumbnailInfo thumbnailInfo;
	private boolean end;
	private ProcessItemAdapter mProcessManagerAdapter;
	private Button clear_button;
	private LinearLayout process_clear_listview_layout, cache_clear_expandlistview_layout, thumbnails_content_layout, empty_folder_content_layout;
	private LinearLayout ad_clear_listview_layout;
	private LinearLayout cache_title_layout, process_title_layout, empty_folder_title_layout, thumbnails_title_layout;
	private LinearLayout ad_title_layout;
	private LinearLayout cache_layout, process_layout, empty_folder_layout, thumbnails_layout;
	private LinearLayout ad_layout;
	private RelativeLayout progress_layout;
	private List<PackageInfo> mAllPackageInfos;
	private long totalMemory = (long) (1.5 * 1024 * 1024 * 1024);

	private CustomTextView header_memory_textview;
	private WaterWaveCustomView header_waterwave_view;
	private TextView header_unit_textview, header_tips_textview, header_content_textview;
	private CheckBox empty_folder_group_checkbox, thumbnails_group_checkbox, cache_group_checkbox, process_group_checkbox;
	private CheckBox ad_group_checkbox;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_daily_clear);
		mContext = DailyClearActivity.this;
		BannerUtils.setTitle(this, R.string.daily_page_title);
		BannerUtils.initBackButton(this);

		if (!new File(getFilesDir(), "RemoteTools.jar").exists()) {
			String fileName = "RemoteTools_low.jar";
			if (Build.VERSION.SDK_INT >= 17) {
				fileName = "RemoteTools.jar";
			} else {
				fileName = "RemoteTools_low.jar";
			}
			FileUtils.copyAssetFile(mContext, fileName);
		}
		initViewAndEvent();
		clear_button.setText(R.string.stop_scan_button);
		new GetProcessThrad().start();
		new GetCacheThread().start();
		new GetAdThread().start();
		// 获取缩略图数据
		new Thread(new Runnable() {

			@Override
			public void run() {
				thumbnailInfo = FileUtils.getThumbnailFile();
				runOnUiThread(new Runnable() {

					@Override
					public void run() {
						if (thumbnailInfo != null) {
							totalThumbnailsSize = thumbnailInfo.getTotalSize();
							selectThumbnailsSize = totalThumbnailsSize;
							thumbnails_checked_imageview.setChecked(true);
						} else {
							thumbnails_checked_imageview.setChecked(false);
						}

						thumbnails_scan_progressbar.setVisibility(View.GONE);
						thumbnails_duigou_imageview.setVisibility(View.VISIBLE);
						thumbnails_checked_imageview.setOnClickListener(DailyClearActivity.this);
						updateTotalSize();
						checkEnd();
					}

				});
			}
		}).start();

		// 获取空文件夹信息
		new Thread(new Runnable() {

			@Override
			public void run() {
				emptyFolder = FileUtils.getEmptyFile();
				runOnUiThread(new Runnable() {

					@Override
					public void run() {
						if (emptyFolder != null && emptyFolder.getPathList() != null && emptyFolder.getPathList().size() > 0) {
							totalEmptyFolderSize = emptyFolder.getTotalSize();
							selectEmptyFolderSize = totalEmptyFolderSize;
							empty_folder_checked_imageview.setChecked(true);
						} else {
							empty_folder_checked_imageview.setChecked(false);
						}

						empty_folder_scan_progressbar.setVisibility(View.GONE);
						empty_folder_duigou_imageview.setVisibility(View.VISIBLE);
						empty_folder_checked_imageview.setOnClickListener(DailyClearActivity.this);
						updateTotalSize();
						checkEnd();
					}
				});
			}
		}).start();

		initAdView();
		initADListView();
		initResultImageView();
	}


	private void initViewAndEvent() {
		progress_layout = (RelativeLayout) findViewById(R.id.progress_layout);

		scan_textview = (TextView) findViewById(R.id.scan_textview);
		clear_button = (Button) findViewById(R.id.clear_button);
		clear_button.setOnClickListener(this);

		header_memory_textview = (CustomTextView) findViewById(R.id.header_memory_textview);
		header_waterwave_view = (WaterWaveCustomView) findViewById(R.id.header_waterwave_view);
		header_unit_textview = (TextView) findViewById(R.id.header_unit_textview);
		header_tips_textview = (TextView) findViewById(R.id.header_tips_textview);
		header_content_textview = (TextView) findViewById(R.id.header_content_textview);
		header_tips_textview.setText("可清理");

		cache_title_layout = (LinearLayout) findViewById(R.id.cache_title_layout);
		cache_title_layout.setOnClickListener(this);
		cache_title_layout.setClickable(false);
		ad_title_layout = (LinearLayout) findViewById(R.id.ad_title_layout);
		ad_title_layout.setOnClickListener(this);
		ad_title_layout.setClickable(false);
		cache_size_textview = (TextView) findViewById(R.id.cache_size_textview);
		ad_size_textview = (TextView) findViewById(R.id.ad_size_textview);
		cache_scan_progressbar = (ProgressBar) findViewById(R.id.cache_scan_progressbar);
		ad_scan_progressbar = (ProgressBar) findViewById(R.id.ad_scan_progressbar);

		process_title_layout = (LinearLayout) findViewById(R.id.process_title_layout);
		process_title_layout.setOnClickListener(this);
		process_title_layout.setClickable(false);
		process_size_textview = (TextView) findViewById(R.id.process_size_textview);
		process_scan_progressbar = (ProgressBar) findViewById(R.id.process_scan_progressbar);

		result_page = (LinearLayout) findViewById(R.id.result_page);
		list_page = (RelativeLayout) findViewById(R.id.list_page);

		empty_folder_title_layout = (LinearLayout) findViewById(R.id.empty_folder_title_layout);
		empty_folder_title_layout.setOnClickListener(this);
		empty_folder_title_layout.setClickable(false);
		empty_folder_size_textview = (TextView) findViewById(R.id.empty_folder_size_textview);
		empty_folder_scan_progressbar = (ProgressBar) findViewById(R.id.empty_folder_scan_progressbar);
		empty_folder_count_textview = (TextView) findViewById(R.id.empty_folder_count_textview);
		empty_folder_checked_imageview = (CheckBox) findViewById(R.id.empty_folder_checked_imageview);

		thumbnails_title_layout = (LinearLayout) findViewById(R.id.thumbnails_title_layout);
		thumbnails_title_layout.setOnClickListener(this);
		thumbnails_title_layout.setClickable(false);
		thumbnails_size_textview = (TextView) findViewById(R.id.thumbnails_size_textview);
		thumbnails_scan_progressbar = (ProgressBar) findViewById(R.id.thumbnails_scan_progressbar);
		thumbnails_count_textview = (TextView) findViewById(R.id.thumbnails_count_textview);
		thumbnails_checked_imageview = (CheckBox) findViewById(R.id.thumbnails_checked_imageview);

		empty_folder_duigou_imageview = (ImageView) findViewById(R.id.empty_folder_duigou_imageview);
		thumbnails_duigou_imageview = (ImageView) findViewById(R.id.thumbnails_duigou_imageview);
		cache_duigou_imageview = (ImageView) findViewById(R.id.cache_duigou_imageview);
		ad_duigou_imageview = (ImageView) findViewById(R.id.ad_duigou_imageview);
		process_duigou_imageview = (ImageView) findViewById(R.id.process_duigou_imageview);

		empty_folder_group_checkbox = (CheckBox) findViewById(R.id.empty_folder_group_checkbox);
		thumbnails_group_checkbox = (CheckBox) findViewById(R.id.thumbnails_group_checkbox);
		cache_group_checkbox = (CheckBox) findViewById(R.id.cache_group_checkbox);
		ad_group_checkbox = (CheckBox) findViewById(R.id.ad_group_checkbox);
		process_group_checkbox = (CheckBox) findViewById(R.id.process_group_checkbox);

		process_layout = (LinearLayout) findViewById(R.id.process_layout);
		cache_layout = (LinearLayout) findViewById(R.id.cache_layout);
		ad_layout = (LinearLayout) findViewById(R.id.ad_layout);
		thumbnails_layout = (LinearLayout) findViewById(R.id.thumbnails_layout);
		empty_folder_layout = (LinearLayout) findViewById(R.id.empty_folder_layout);

		findViewById(R.id.back_imageview).setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				finish();
				overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
			}
		});
		findViewById(R.id.back_title).setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				finish();
				overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
			}
		});
		ImageView share_imageview = (ImageView) findViewById(R.id.share_imageview);
		TextView result_banner_depth_textview = (TextView) findViewById(R.id.result_banner_depth_textview);
		share_imageview.setOnClickListener(this);
		result_banner_depth_textview.setOnClickListener(this);

		process_clear_listview_layout = (LinearLayout) findViewById(R.id.process_clear_listview_layout);
		cache_clear_expandlistview_layout = (LinearLayout) findViewById(R.id.cache_clear_expandlistview_layout);
		ad_clear_listview_layout = (LinearLayout) findViewById(R.id.ad_clear_listview_layout);
		thumbnails_content_layout = (LinearLayout) findViewById(R.id.thumbnails_content_layout);
		empty_folder_content_layout = (LinearLayout) findViewById(R.id.empty_folder_content_layout);

		TextView banner_depth_textview = (TextView) findViewById(R.id.banner_depth_textview);
		banner_depth_textview.setVisibility(View.VISIBLE);
		banner_depth_textview.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(mContext, DepthClearActivity.class);
				startActivity(intent);
				stop = true;
			}
		});
	}
	private void initResultImageView() {
		ImageView result_icon_imageview = (ImageView) findViewById(R.id.result_icon_imageview);
		int r = (int) (Math.random() * 5);
		int resId = R.drawable.result_page_icon_1;
		switch (r) {
		case 0:
			resId = R.drawable.result_page_icon_2;
			break;
		case 1:
			resId = R.drawable.result_page_icon_3;
			break;
		case 2:
			resId = R.drawable.result_page_icon_4;
			break;
		case 3:
			resId = R.drawable.result_page_icon_5;
			break;

		default:
			break;
		}
		result_icon_imageview.setImageResource(resId);
	}

	/**
	 * 获取运行中的进程
	 * 
	 * @author 庄宏岩
	 * 
	 */
	private class GetProcessThrad extends Thread {
		private ArrayList<AppItem> appItems;
		private CustomListView process_clear_listview;
		private long startTime;

		public GetProcessThrad() {
			process_clear_listview = (CustomListView) findViewById(R.id.process_clear_listview);
			appItems = new ArrayList<AppItem>();
		}

		@Override
		public void run() {
			super.run();
			SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(mContext);
			if (System.currentTimeMillis() - sp.getLong("shortcut_last_clear_time", 0) < 60 * 1000) {
				handler.sendEmptyMessage(2);
				return;
			}

			startTime = System.currentTimeMillis();
			ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
			PackageManager pm = getPackageManager();
			if (mAllPackageInfos == null) {
				mAllPackageInfos = pm.getInstalledPackages(0);
			}
			List<RunningAppProcessInfo> lists = am.getRunningAppProcesses();
			ArrayList<String> keeps = KeepListUtils.getList(mContext);
			for (int i = 0; i < lists.size(); i++) {
				if (stop) {
					break;
				}
				RunningAppProcessInfo runapp = lists.get(i);
				Message message = new Message();
				message.what = 1;
				Bundle bundle = new Bundle();
				bundle.putInt("max", lists.size());
				bundle.putInt("progress", i + 1);
				message.setData(bundle);
				handler.sendMessage(message);

				if (runapp.pkgList == null || runapp.pkgList.length == 0) {
					continue;
				}
				String packageName = runapp.pkgList[0];
				if (packageName.equals(getPackageName())) {
					continue;
				}
				for (PackageInfo packageInfo : mAllPackageInfos) {
					if (stop) {
						break;
					}
					ApplicationInfo info = packageInfo.applicationInfo;
					String sourceDir = info.sourceDir;
					if (sourceDir != null) {
						if (packageName.equals(info.packageName)) {
							if (!keeps.contains(packageName)) {

								boolean flag = false;
								if ((info.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0) {
									flag = true;
								} else if ((info.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
									flag = true;
								}
								AppItem appItem = new AppItem();
								appItem.setAppPackage(packageName);
								appItem.setAppName(info.loadLabel(pm).toString());
								appItem.setAppIcon(info.loadIcon(pm));
								appItem.setMemorySize(ProcessManagerUtils.getProcessMemUsage(am, runapp.pid) * 1000);
								appItem.setPid(runapp.pid);
								appItem.setCodePath(sourceDir);
								if (sourceDir.contains(".apk")) {
									appItem.setOdexPath(sourceDir.replace(".apk", ".odex"));
								}
								if (flag) {
									appItem.setSystemApp(false);
									appItem.setChecked(true);
								} else {
									appItem.setSystemApp(true);
									appItem.setChecked(true);
								}
								selectProcessSize += appItem.getMemorySize();
								totalProcessSize += appItem.getMemorySize();
								appItems.add(appItem);
								handler.sendEmptyMessage(0);
							}
						}
					}
				}
			}
			Collections.sort(appItems, new MemorySizeComparator());
			handler.sendEmptyMessage(2);
			Log.i("debug", "进程扫描所用时间: " + (System.currentTimeMillis() - startTime) * 1.0f / 1000 + "秒");
		}

		Handler handler = new Handler() {

			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				switch (msg.what) {
				case 0:
					updateTotalSize();
					updateSelectSize();
					break;
				case 1:
					process_scan_progressbar.setVisibility(View.VISIBLE);
					scan_textview.setText(R.string.clear_process_scanning);
					scan_textview.setVisibility(View.VISIBLE);
					break;
				case 2:
					process_scan_progressbar.setVisibility(View.GONE);
					process_duigou_imageview.setVisibility(View.VISIBLE);
					mProcessManagerAdapter = new ProcessItemAdapter(mContext, appItems);
					mProcessManagerAdapter.setSelectListener(new SelectListener() {

						@Override
						public void selectSize(long size) {
							selectProcessSize = size;
							updateSelectSize();
						}
					});
					mProcessManagerAdapter.setCheckedListener(new CheckedListener() {

						@Override
						public void someChecked(int count) {
							process_group_checkbox.setChecked(false);
						}

						@Override
						public void nothingChecked() {
							process_group_checkbox.setChecked(false);
						}

						@Override
						public void allChecked(int count) {
							process_group_checkbox.setChecked(true);
						}
					});

					process_clear_listview.setAdapter(mProcessManagerAdapter);
					process_clear_listview.setOnItemClickListener(DailyClearActivity.this);
					checkEnd();
					break;

				default:
					break;
				}
			}

		};
	}

	class GetCacheThread extends Thread {
		private ArrayList<AppItem> systemCacheList;
		private GroupItem groupItem;
		private ArrayList<GroupItem> groupList = new ArrayList<GroupItem>();
		private ArrayList<ArrayList<AppItem>> childList = new ArrayList<ArrayList<AppItem>>();// 子列表
		private long startTime;

		public GetCacheThread() {
			systemCacheList = new ArrayList<AppItem>();
		}

		@Override
		public void run() {
			super.run();
			new CopyDBUtils(mContext).copyDB();
			startTime = System.currentTimeMillis();
			PackageManager pm = getPackageManager();
			if (mAllPackageInfos == null) {
				mAllPackageInfos = pm.getInstalledPackages(0);
			}
			if (mAllPackageInfos != null && mAllPackageInfos.size() > 0) {
				int packageSize = mAllPackageInfos.size();
				ArrayList<String> keeps = CacheWhiteListUtils.getAllList(mContext);
				for (int i = 0; i < packageSize; i++) {
					if (stop) {
						break;
					}
					PackageInfo packageInfo = mAllPackageInfos.get(i);
					if (packageInfo == null) {
						continue;
					}
					final ApplicationInfo applicationInfo = packageInfo.applicationInfo;
					if (applicationInfo == null) {
						continue;
					}
					if (applicationInfo.packageName.equals(getPackageName())) {
						continue;
					}
					final String sourceDir = applicationInfo.sourceDir;
					if (sourceDir != null) {
						final String appName = applicationInfo.loadLabel(pm).toString();
						Message message = new Message();
						message.what = 1;
						Bundle bundle = new Bundle();
						bundle.putString("name", appName);
						bundle.putInt("progress", i + 1);
						bundle.putInt("max", packageSize);
						message.setData(bundle);
						handler.sendMessage(message);

						final AppItem appItem = new AppItem();
						appItem.setAppPackage(applicationInfo.packageName);
						if (!keeps.contains(appItem.getAppPackage())) {
							ArrayList<ClearItem> clearItems = DBAppCacheUtils.getInstance(mContext).get(mContext, applicationInfo.packageName, getLanguage());
							if (clearItems != null && clearItems.size() > 0) {
								boolean groupChecked = true;
								ArrayList<AppItem> cacheList = new ArrayList<AppItem>();
								for (ClearItem clearItem : clearItems) {
									if (stop) {
										break;
									}
									File file = new File(Constants.SDCARD_PATH, clearItem.getFilePath());
									if (file != null && file.exists()) {
										AppItem cacheItem = new AppItem();
										cacheItem.setCacheSize(FileUtils.getFileSize(file));
										if (cacheItem.getCacheSize() > 0) {
											cacheItem.setApplicationInfo(applicationInfo);
											cacheItem.setAppName(clearItem.getName());
											cacheItem.setFilePath(file.getAbsolutePath());
											if(clearItem.isChecked()){
												cacheItem.setChecked(true);
											}else{
												groupChecked = false;
												cacheItem.setChecked(false);
											}
											totalCacheSize += cacheItem.getCacheSize();
											cacheList.add(cacheItem);
											message = new Message();
											bundle = new Bundle();
											bundle.putString("name", appItem.getAppName());
											bundle.putLong("memory", appItem.getCacheSize());
											message.setData(bundle);
											message.what = 0;
											handler.sendMessage(message);
										}
									}
								}
								if (cacheList.size() > 0) {
									appItem.setGroup(true);
									appItem.setApplicationInfo(applicationInfo);
									appItem.setAppName(appName);
									
									GroupItem mGroupItem = new GroupItem();
									mGroupItem.setApplicationInfo(applicationInfo);
									mGroupItem.setCount(cacheList.size());
									mGroupItem.setTitle(appItem.getAppName());
									mGroupItem.setChecked(groupChecked);
									groupList.add(mGroupItem);
									childList.add(cacheList);
									handler.sendEmptyMessage(0);
								}
							}
						}
						if (!Terminal.isRoot(mContext) || !keeps.contains(appItem.getAppPackage())) {
							try {
								final CountDownLatch countDownLatch = new CountDownLatch(1);
								Method getPackageSizeInfo = pm.getClass().getMethod("getPackageSizeInfo", String.class, IPackageStatsObserver.class);
								getPackageSizeInfo.invoke(pm, appItem.getAppPackage(), new IPackageStatsObserver.Stub() {
									public void onGetStatsCompleted(PackageStats pStats, boolean succeeded) throws RemoteException {
										if (pStats != null) {
											if (Build.VERSION.SDK_INT >= 11) {
												appItem.setCacheSize(pStats.cacheSize + pStats.externalCacheSize);
											} else {
												appItem.setCacheSize(pStats.cacheSize);
											}
											if (Build.VERSION.SDK_INT > 16) {
												if (appItem.getCacheSize() > 0 && appItem.getCacheSize() != 12288) {
													appItem.setApplicationInfo(applicationInfo);
													appItem.setAppName(appName);
													appItem.setGroup(false);
													appItem.setChecked(false);
													totalCacheSize += appItem.getCacheSize();
													systemCacheList.add(appItem);
													Message message = new Message();
													message.what = 0;
													handler.sendMessage(message);
												}
											} else {
												if (appItem.getCacheSize() > 0) {
													appItem.setApplicationInfo(applicationInfo);
													appItem.setAppName(appName);
													appItem.setGroup(false);
													appItem.setChecked(false);
													totalCacheSize += appItem.getCacheSize();
													systemCacheList.add(appItem);
													Message message = new Message();
													message.what = 0;
													handler.sendMessage(message);
												}
											}
										}
										countDownLatch.countDown();
									}
								});
								countDownLatch.await();
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					}
				}
			}
			if (systemCacheList.size() > 0) {
				groupItem = new GroupItem();
				groupItem.setTitle(getString(R.string.system_cache_title));
				groupItem.setCount(systemCacheList.size());
				groupItem.setIcon(getResources().getDrawable(R.drawable.system_cache_icon));
				if (Terminal.isRoot(mContext)) {
					groupItem.setChecked(true);
					for (AppItem clearItem : systemCacheList) {
						clearItem.setChecked(true);
					}
				} else {
					groupItem.setChecked(false);
				}
				Collections.sort(systemCacheList, new CacheComparator());
				groupList.add(0, groupItem);
				childList.add(0, systemCacheList);
			}
			DLog.i("debug", "缓存扫描时间: " + (System.currentTimeMillis() - startTime) + "毫秒");
			DBAppCacheUtils.getInstance(mContext).close();
			handler.sendEmptyMessage(2);
		}

		Handler handler = new Handler() {

			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				Bundle bundle = null;
				switch (msg.what) {
				case 0:
					updateTotalSize();
					break;
				case 1:
					bundle = msg.getData();
					scan_textview.setText(getString(R.string.clear_scanning, bundle.getString("name")));
					scan_textview.setVisibility(View.VISIBLE);
					break;
				case 2:
					daily_clear_expandlistview = (CustomExpandListView) findViewById(R.id.cache_clear_expandlistview);
					daily_clear_expandlistview.setGroupIndicator(null);
					daily_clear_expandlistview.setOnChildClickListener(DailyClearActivity.this);
					mAdapter4DailyClear = new Adapter4DailyClear(mContext, groupList, childList);
					mAdapter4DailyClear.setCheckListener(new CheckedListener() {

						@Override
						public void someChecked(int count) {
							cache_group_checkbox.setChecked(false);
						}

						@Override
						public void nothingChecked() {
							cache_group_checkbox.setChecked(false);
						}

						@Override
						public void allChecked(int count) {
							cache_group_checkbox.setChecked(true);
						}
					});
					mAdapter4DailyClear.setSelectListener(new SelectListener() {

						@Override
						public void selectSize(long size) {
							selectCacheSize = size;
							updateSelectSize();
						}
					});

					daily_clear_expandlistview.setAdapter(mAdapter4DailyClear);
					mAdapter4DailyClear.updateSelectCacheSize();

					cache_scan_progressbar.setVisibility(View.GONE);
					cache_duigou_imageview.setVisibility(View.VISIBLE);
					updateTotalSize();
					checkEnd();
					break;
				default:
					break;
				}
			}

		};

	}
	
	class GetAdThread extends Thread {
		private ArrayList<AppItem> mAdList;
		private CustomListView ad_clear_listview;
		private long startTime;
		
		public GetAdThread() {
			if (mAdList == null) {
				mAdList = new ArrayList<AppItem>();
			} else {
				mAdList.clear();
			}
		}
		
		@Override
		public void run() {
			super.run();
			new CopyDBUtils(mContext).copyDB();
			startTime = System.currentTimeMillis();
			if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
				if (mAllPackageInfos == null) {
					mAllPackageInfos = getPackageManager().getInstalledPackages(0);
				}
				ArrayList<ClearItem> clearItems = DBAppAdUtils.get(mContext, getLanguage());
				int tAppCount = mAllPackageInfos.size();
				int tSoftCount = clearItems.size();
				
				for (int i = 0; i < tSoftCount; i++) {
					if (stop) {
						break;
					}
					File file = new File(Constants.SDCARD_PATH, clearItems.get(i).getFilePath());
					if (file == null || !file.exists()) {
						continue;
					}
					Message message = new Message();
					message.what = 1;
					Bundle bundle = new Bundle();
					bundle.putString("name", file.getAbsolutePath());
					bundle.putInt("progress", i + 1);
					bundle.putInt("max", tSoftCount);
					message.setData(bundle);
					handler.sendMessage(message);
					
					for (int j = 0; j < tAppCount; j++) {
						if (stop) {
							return;
						}
						if (j == tAppCount - 1) {
							AppItem appItem = new AppItem();
							appItem.setName(clearItems.get(i).getName());
							appItem.setFilePath(file.getAbsolutePath());
							appItem.setCodeSize(GetFileSizeLongByPath(file.getAbsolutePath()));
//							appItem.setAppPackage(clearItems.get(i).getPackageName());
							appItem.setChecked(true);
							totalAdSize += appItem.getCodeSize();
							mAdList.add(appItem);
							
							message = new Message();
							bundle = new Bundle();
							bundle.putString("name", appItem.getAppName());
							bundle.putLong("memory", appItem.getCodeSize());
							message.setData(bundle);
							message.what = 0;
							handler.sendMessage(message);
						}
					}
				}
			}
			if (mAdList != null && mAdList.size() > 0) {
				Collections.sort(mAdList, new CodeSizeComparator());
			}
			DLog.i("debug", "广告文件扫描时间: " + (System.currentTimeMillis() - startTime) + "毫秒");
			handler.sendEmptyMessage(2);
		}
		
		Handler handler = new Handler() {
			
			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				Bundle bundle = null;
				switch (msg.what) {
				case 0:
					updateTotalSize();
					break;
				case 1:
					bundle = msg.getData();
					scan_textview.setText(getString(R.string.clear_scanning, bundle.getString("name")));
					scan_textview.setVisibility(View.VISIBLE);
					break;
				case 2:
					ad_clear_listview = (CustomListView) findViewById(R.id.ad_clear_listview);
					mAdapter4AdClear = new Adapter4AdClear(mContext, mAdList);
					mAdapter4AdClear.setCheckListener(new CheckedListener() {
						
						@Override
						public void someChecked(int count) {
							ad_group_checkbox.setChecked(false);
						}
						
						@Override
						public void nothingChecked() {
							ad_group_checkbox.setChecked(false);
						}
						
						@Override
						public void allChecked(int count) {
							ad_group_checkbox.setChecked(true);
						}
					});
					mAdapter4AdClear.setSelectListener(new SelectListener() {
						
						@Override
						public void selectSize(long size) {
							selectAdSize = size;
							updateSelectSize();
						}
					});
					ad_clear_listview.setAdapter(mAdapter4AdClear);
					ad_clear_listview.setOnItemClickListener(DailyClearActivity.this);
					
					mAdapter4AdClear.updateSelectDepthSize();
					
					ad_scan_progressbar.setVisibility(View.GONE);
					ad_duigou_imageview.setVisibility(View.VISIBLE);
					updateTotalSize();
					checkEnd();
					break;
				default:
					break;
				}
			}
			
		};
		
		public long GetFileSizeLongByPath(final String path) {
			File file = new File(path);
			return getFileSize(file);
		}
		
		public long getFileSize(File f) {
			long size = 0;
			if (f != null && f.isDirectory() && f.exists()) {
				File flist[] = f.listFiles();
				if (flist != null) {
					for (int j = 0; j < flist.length; j++) {
						
						if (flist[j].isDirectory()) {
							size = size + getFileSize(flist[j]);
						} else {
							size = size + flist[j].length();
						}
					}
					
				}
			}
			return size;
		}
		
	}

	private void checkEnd() {
		boolean b = true;
		if (cache_duigou_imageview.getVisibility() == View.GONE) {
			b = false;
		}
		if (ad_duigou_imageview.getVisibility() == View.GONE) {
			b = false;
		}
		if (empty_folder_duigou_imageview.getVisibility() == View.GONE) {
			b = false;
		}
		if (thumbnails_duigou_imageview.getVisibility() == View.GONE) {
			b = false;
		}
		if (process_duigou_imageview.getVisibility() == View.GONE) {
			b = false;
		}
		if (b) {
			progress_layout.setVisibility(View.GONE);

			clear_button.setText(R.string.one_clear_button);
			end = true;
			updateSelectSize();

			process_group_checkbox.setVisibility(View.VISIBLE);
			thumbnails_group_checkbox.setVisibility(View.VISIBLE);
			empty_folder_group_checkbox.setVisibility(View.VISIBLE);
			cache_group_checkbox.setVisibility(View.VISIBLE);
			ad_group_checkbox.setVisibility(View.VISIBLE);
			process_group_checkbox.setOnClickListener(this);
			thumbnails_group_checkbox.setOnClickListener(this);
			empty_folder_group_checkbox.setOnClickListener(this);
			cache_group_checkbox.setOnClickListener(this);
			ad_group_checkbox.setOnClickListener(this);

			process_size_textview.setVisibility(View.VISIBLE);
			process_size_textview.setText(FormatUtils.formatBytesInByte(totalProcessSize));
			process_duigou_imageview.setVisibility(View.GONE);
			if (mProcessManagerAdapter != null && mProcessManagerAdapter.getCount() > 0) {
				process_title_layout.setClickable(true);
				process_group_checkbox.setChecked(true);
			} else {
				process_title_layout.setClickable(false);
				process_group_checkbox.setChecked(false);
			}

			cache_size_textview.setVisibility(View.VISIBLE);
			cache_size_textview.setText(FormatUtils.formatBytesInByte(totalCacheSize));
			cache_duigou_imageview.setVisibility(View.GONE);
			if (mAdapter4DailyClear != null && mAdapter4DailyClear.getGroupCount() > 0) {
				cache_clear_expandlistview_layout.setVisibility(View.VISIBLE);
				cache_title_layout.setClickable(true);
			} else {
				cache_title_layout.setClickable(false);
			}
			
			ad_size_textview.setVisibility(View.VISIBLE);
			ad_size_textview.setText(FormatUtils.formatBytesInByte(totalAdSize));
			ad_duigou_imageview.setVisibility(View.GONE);
			if (mAdapter4AdClear != null && mAdapter4AdClear.getCount() > 0) {
				ad_clear_listview_layout.setVisibility(View.VISIBLE);
				ad_title_layout.setClickable(true);
			} else {
				ad_title_layout.setClickable(false);
			}

			if (thumbnailInfo != null && thumbnailInfo.getCount() > 0) {
				thumbnails_content_layout.setVisibility(View.VISIBLE);
				thumbnails_count_textview.setText(thumbnailInfo.getCount() + "");
				thumbnails_title_layout.setClickable(true);
				thumbnails_group_checkbox.setChecked(true);
			} else {
				thumbnails_content_layout.setVisibility(View.GONE);
				thumbnails_count_textview.setText(0 + "");
				thumbnails_title_layout.setClickable(false);
				thumbnails_group_checkbox.setChecked(false);
			}
			thumbnails_size_textview.setVisibility(View.VISIBLE);
			thumbnails_size_textview.setText(FormatUtils.formatBytesInByte(totalThumbnailsSize));
			thumbnails_duigou_imageview.setVisibility(View.GONE);

			if (emptyFolder != null && emptyFolder.getPathList() != null && emptyFolder.getPathList().size() > 0) {
				empty_folder_content_layout.setVisibility(View.VISIBLE);
				empty_folder_count_textview.setText(emptyFolder.getPathList().size() + "");
				empty_folder_title_layout.setClickable(true);
				empty_folder_group_checkbox.setChecked(true);
			} else {
				empty_folder_count_textview.setText(0 + "");
				empty_folder_title_layout.setClickable(false);
				empty_folder_group_checkbox.setChecked(false);
			}

			empty_folder_size_textview.setVisibility(View.VISIBLE);
			empty_folder_size_textview.setText(FormatUtils.formatBytesInByte(totalEmptyFolderSize));
			empty_folder_duigou_imageview.setVisibility(View.GONE);

			if ((totalAdSize + totalCacheSize + totalEmptyFolderSize + totalThumbnailsSize + totalProcessSize) == 0) {
				if (emptyFolder == null || emptyFolder.getPathList() == null || emptyFolder.getPathList().size() == 0) {
					// list_page.setVisibility(View.GONE);
					// result_page.setVisibility(View.VISIBLE);
					// TextView result_clear_size_textview = (TextView)
					// findViewById(R.id.result_clear_size_textview);
					// result_clear_size_textview.setText(R.string.daily_scan_end_null);
					// findViewById(R.id.yiqingli_textview).setVisibility(View.GONE);

					// TODO
				}
			}
		}
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.clear_button:
			if (clear_button.getText().equals(getString(R.string.stop_scan_button))) {
				stop = true;
				clear_button.setText(R.string.scan_button_stoping);
			} else if (clear_button.getText().equals(getString(R.string.one_clear_button))) {
				CustomEventCommit.commit(mContext, CustomEventCommit.button_laji_click);
				boolean b = false;
				if (mProcessManagerAdapter != null && mProcessManagerAdapter.getSelectList().size() > 0) {
					b = true;
				}
				if (mAdapter4DailyClear != null && mAdapter4DailyClear.getSelectClearList().size() > 0) {
					b = true;
				}
				if (mAdapter4DailyClear != null && mAdapter4DailyClear.getGroupCount() > 0 && ((GroupItem) mAdapter4DailyClear.getGroup(0)).isChecked()) {
					b = true;
				}
				
				if (mAdapter4AdClear != null && mAdapter4AdClear.getSelecteList().size() > 0) {
					b = true;
				}

				if (thumbnails_checked_imageview.isChecked()) {
					b = true;
				}
				if (empty_folder_checked_imageview.isChecked()) {
					b = true;
				}

				if (b) {

					process_group_checkbox.setVisibility(View.GONE);
					thumbnails_group_checkbox.setVisibility(View.GONE);
					empty_folder_group_checkbox.setVisibility(View.GONE);
					cache_group_checkbox.setVisibility(View.GONE);
					ad_group_checkbox.setVisibility(View.GONE);

					clear_button.setClickable(false);
					clear_button.setText("正在清理");
					if (mAdapter4DailyClear != null) {
						for (int i = 0; i < mAdapter4DailyClear.getGroupCount(); i++) {
							daily_clear_expandlistview.collapseGroup(i);
						}
					}

					if (process_clear_listview_layout != null) {
						process_clear_listview_layout.setVisibility(View.GONE);
					}

					if (cache_clear_expandlistview_layout != null) {
						cache_clear_expandlistview_layout.setVisibility(View.GONE);
					}
					if (ad_clear_listview_layout != null) {
						ad_clear_listview_layout.setVisibility(View.GONE);
					}
					if (thumbnails_content_layout != null) {
						thumbnails_content_layout.setVisibility(View.GONE);
					}
					if (empty_folder_content_layout != null) {
						empty_folder_content_layout.setVisibility(View.GONE);
					}

					process_size_textview.setVisibility(View.GONE);
					process_scan_progressbar.setVisibility(View.VISIBLE);

					cache_size_textview.setVisibility(View.GONE);
					cache_scan_progressbar.setVisibility(View.VISIBLE);
					
					ad_size_textview.setVisibility(View.GONE);
					ad_scan_progressbar.setVisibility(View.VISIBLE);

					thumbnails_size_textview.setVisibility(View.GONE);
					thumbnails_scan_progressbar.setVisibility(View.VISIBLE);

					empty_folder_size_textview.setVisibility(View.GONE);
					empty_folder_scan_progressbar.setVisibility(View.VISIBLE);

					new Thread(new Runnable() {

						@Override
						public void run() {
							clearAll();
						}
					}).start();
				} else {
					Toast.makeText(mContext, R.string.clear_select_null, Toast.LENGTH_SHORT).show();
				}
			}
			break;
		case R.id.result_banner_depth_textview:
			Intent intent = new Intent(mContext, DepthClearActivity.class);
			intent.putExtra("daily_finish", true);
			startActivity(intent);
			break;
		case R.id.cache_title_layout:
			cache_clear_expandlistview_layout.setVisibility(cache_clear_expandlistview_layout.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
			break;
		case R.id.ad_title_layout:
			ad_clear_listview_layout.setVisibility(ad_clear_listview_layout.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
			break;
		case R.id.thumbnails_title_layout:
			thumbnails_content_layout.setVisibility(thumbnails_content_layout.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
			break;
		case R.id.empty_folder_title_layout:
			empty_folder_content_layout.setVisibility(empty_folder_content_layout.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
			break;
		case R.id.process_title_layout:
			process_clear_listview_layout.setVisibility(process_clear_listview_layout.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
			break;
		case R.id.share_imageview:
			MenuOptionUtil.shareCleanResult(this);
			break;

		case R.id.cache_group_checkbox:
			mAdapter4DailyClear.setAllChecked(cache_group_checkbox.isChecked());
			break;
		case R.id.ad_group_checkbox:
			mAdapter4AdClear.setAllChecked(ad_group_checkbox.isChecked());
			break;
		case R.id.process_group_checkbox:
			mProcessManagerAdapter.setAllChecked(process_group_checkbox.isChecked());
			break;
		case R.id.thumbnails_group_checkbox:
			thumbnails_checked_imageview.setChecked(thumbnails_group_checkbox.isChecked());
			if (thumbnails_checked_imageview.isChecked()) {
				selectThumbnailsSize = totalThumbnailsSize;
			} else {
				selectThumbnailsSize = 0;
			}
			updateSelectSize();
			break;
		case R.id.thumbnails_checked_imageview:
			thumbnails_group_checkbox.setChecked(thumbnails_checked_imageview.isChecked());
			if (thumbnails_checked_imageview.isChecked()) {
				selectThumbnailsSize = totalThumbnailsSize;
			} else {
				selectThumbnailsSize = 0;
			}
			updateSelectSize();
			break;
		case R.id.empty_folder_group_checkbox:
			empty_folder_checked_imageview.setChecked(empty_folder_group_checkbox.isChecked());
			if (empty_folder_checked_imageview.isChecked()) {
				selectEmptyFolderSize = totalEmptyFolderSize;
			} else {
				selectEmptyFolderSize = 0;
			}
			updateSelectSize();
			break;
		case R.id.empty_folder_checked_imageview:
			empty_folder_group_checkbox.setChecked(empty_folder_checked_imageview.isChecked());
			if (empty_folder_checked_imageview.isChecked()) {
				selectEmptyFolderSize = totalEmptyFolderSize;
			} else {
				selectEmptyFolderSize = 0;
			}
			updateSelectSize();
			break;
		default:
			break;
		}
	}

	private String packages = "";

	@SuppressWarnings("deprecation")
	protected void clearAll() {
		ArrayList<AppItem> appItems = (mProcessManagerAdapter != null ? mProcessManagerAdapter.getSelectList() : new ArrayList<AppItem>());
		if (appItems.size() > 0) {
			for (int i = 0; i < appItems.size(); i++) {
				AppItem appItem = appItems.get(i);
				Message message = new Message();
				message.what = 1;
				Bundle bundle = new Bundle();
				bundle.putInt("max", appItems.size());
				bundle.putInt("progress", i + 1);
				bundle.putString("name", appItem.getAppName());
				message.setData(bundle);
				mHandler.sendMessage(message);

				if (Terminal.isRoot(mContext)) {
					if (i == 0) {
						packages += appItem.getAppPackage();
					} else {
						packages += ("," + appItem.getAppPackage());
					}
				}
				ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
				am.restartPackage(appItem.getAppPackage());
				if (Build.VERSION.SDK_INT >= 8) {
					am.killBackgroundProcesses(appItem.getAppPackage());
				}
//				if (appItem.getPid() != 0) {
//					Process.killProcess(appItem.getPid());
//				}
			}
			if (!TextUtils.isEmpty(packages)) {
				new Thread(new Runnable() {

					@Override
					public void run() {
						AppManagerUtils.forceStopPackage(mContext, packages);
					}
				}).start();
			}
			SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(mContext);
			sp.edit().putLong("shortcut_last_clear_time", System.currentTimeMillis()).commit();
		}
		try {
			Thread.sleep(200);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		Message message = new Message();
		message.arg1 = 0;
		message.what = 3;
		mHandler.sendMessage(message);

		appItems = (mAdapter4DailyClear != null ? mAdapter4DailyClear.getSelectClearList() : new ArrayList<AppItem>());
		if (Terminal.isRoot(mContext)) {
			String packages = "";
			for (int i = 0; i < appItems.size(); i++) {
				AppItem appItem = appItems.get(i);
				message = new Message();
				message.what = 1;
				Bundle bundle = new Bundle();
				bundle.putString("name", appItem.getAppName());
				bundle.putInt("progress", i + 1);
				bundle.putInt("max", appItems.size());
				message.setData(bundle);
				mHandler.sendMessage(message);
				if (!TextUtils.isEmpty(appItem.getFilePath())) {
					FileUtils.deleteFileByPath(appItem.getFilePath());
				} else {
					if (i == 0) {
						packages += appItem.getAppPackage();
					} else {
						packages += ("," + appItem.getAppPackage());
					}
				}
			}
			if (packages.length() > 0) {
				AppManagerUtils.clearAppCache(mContext, packages);
			}
		} else {
			for (int i = 0; i < appItems.size(); i++) {
				AppItem appItem = appItems.get(i);
				message = new Message();
				message.what = 1;
				Bundle bundle = new Bundle();
				bundle.putString("name", appItem.getAppName());
				bundle.putInt("progress", i + 1);
				bundle.putInt("max", appItems.size());
				message.setData(bundle);
				mHandler.sendMessage(message);
				FileUtils.deleteFileByPath(appItem.getFilePath());
			}

			if (mAdapter4DailyClear != null && mAdapter4DailyClear.getGroupCount() > 0) {
				GroupItem groupItem = (GroupItem) mAdapter4DailyClear.getGroup(0);
				if (groupItem.getTitle().equals(getString(R.string.system_cache_title)) && groupItem.isChecked()) {
					MemoryUtils.clearAllCache(mContext);
				}
			}
		}
		try {
			Thread.sleep(300);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		message = new Message();
		message.arg1 = 1;
		message.what = 3;
		mHandler.sendMessage(message);
		
		appItems = (mAdapter4AdClear != null ? mAdapter4AdClear.getSelecteList() : new ArrayList<AppItem>());
		
		for (int i = 0; i < appItems.size(); i++) {
			message = new Message();
			message.what = 1;
			Bundle bundle = new Bundle();
			bundle.putString("name", appItems.get(i).getFilePath());
			bundle.putInt("progress", i + 1);
			bundle.putInt("max", appItems.size());
			message.setData(bundle);
			mHandler.sendMessage(message);
			FileUtils.deleteFileByPath(appItems.get(i).getFilePath());
		}
		try {
			Thread.sleep(300);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		message = new Message();
		message.arg1 = 2;
		message.what = 3;
		mHandler.sendMessage(message);

		if (thumbnails_checked_imageview.isChecked()) {
			if (thumbnailInfo != null) {
				FileUtils.deleteFileByPath(thumbnailInfo.getPath());
			}
		}
		try {
			Thread.sleep(400);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		message = new Message();
		message.arg1 = 3;
		message.what = 3;
		mHandler.sendMessage(message);
		
		if (empty_folder_checked_imageview.isChecked()) {
			if (emptyFolder != null && emptyFolder.getPathList() != null) {
				FileUtils.deleteFileByList(emptyFolder.getPathList());
			}
		}

		try {
			Thread.sleep(400);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		message = new Message();
		message.arg1 = 4;
		message.what = 3;
		mHandler.sendMessage(message);

	}

	Handler mHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			switch (msg.what) {

			case 1:
				progress_layout.setVisibility(View.VISIBLE);
				Bundle bundle = msg.getData();
				scan_textview.setText(getString(R.string.clear_loading, bundle.getString("name")));
				scan_textview.setVisibility(View.VISIBLE);
				break;
			case 2:
				Animation animation = AnimationUtils.loadAnimation(mContext, R.anim.slide_out_left);
				Animation animation2 = AnimationUtils.loadAnimation(mContext, R.anim.slide_in_right);
				list_page.startAnimation(animation);
				result_page.startAnimation(animation2);
				list_page.setVisibility(View.GONE);
				result_page.setVisibility(View.VISIBLE);
				long freeMemory =selectAdSize + selectCacheSize + selectEmptyFolderSize + selectThumbnailsSize + selectProcessSize;
				ClearUtils.setDayClearSize(mContext, freeMemory);
				ClearUtils.setHistoryClearSize(mContext, freeMemory);
				String size = FormatUtils.formatBytesInByte2(freeMemory);
				TextView thistime_clear_memory_textview = (TextView) findViewById(R.id.thistime_clear_memory_textview);
				TextView thistime_clear_unit_textview = (TextView) findViewById(R.id.thistime_clear_unit_textview);

				thistime_clear_memory_textview.setText(size.substring(0, size.length() - 2));
				thistime_clear_unit_textview.setText(size.substring(size.length() - 2, size.length()));

				TextView total_clear_memory_textview = (TextView) findViewById(R.id.total_clear_memory_textview);
				TextView total_clear_unit_textview = (TextView) findViewById(R.id.total_clear_unit_textview);

				String totalSize = FormatUtils.formatBytesInByte2(ClearUtils.getHistoryClearSize(mContext));
				total_clear_memory_textview.setText(totalSize.substring(0, totalSize.length() - 2));
				total_clear_unit_textview.setText(totalSize.substring(totalSize.length() - 2, totalSize.length()));
				break;
			case 3:

				switch (msg.arg1) {
				case 0:
					startDeleteAnim(process_layout);
					totalProcessSize -= selectProcessSize;
					updateTotalSize();
					break;
				case 1:
					startDeleteAnim(cache_layout);
					totalCacheSize -= selectCacheSize;
					updateTotalSize();
					break;
				case 2:
					startDeleteAnim(ad_layout);
					totalAdSize -= selectAdSize;
					updateTotalSize();
					break;
				case 3:
					startDeleteAnim(thumbnails_layout);
					totalThumbnailsSize -= selectThumbnailsSize;
					updateTotalSize();
					break;
				case 4:
					startDeleteAnim(empty_folder_layout);
					totalEmptyFolderSize -= selectEmptyFolderSize;
					updateTotalSize();
					mHandler.sendEmptyMessageDelayed(2, 300);
					break;

				default:
					break;
				}
				break;
			default:
				break;
			}
		}
	};

	private void startDeleteAnim(final View view) {
		Animation animation = getDeleteAnim();
		animation.setAnimationListener(new AnimationListener() {

			@Override
			public void onAnimationStart(Animation animation) {

			}

			@Override
			public void onAnimationRepeat(Animation animation) {

			}

			@Override
			public void onAnimationEnd(Animation animation) {
				view.setVisibility(View.GONE);
			}
		});
		view.startAnimation(animation);
	}

	private AnimationSet getDeleteAnim() {
		AnimationSet set = new AnimationSet(true);
		Animation animation = new AlphaAnimation(1.0f, 0.5f);
		animation.setDuration(500);
		set.addAnimation(animation);

		animation = new TranslateAnimation(Animation.RELATIVE_TO_SELF, 0.0f, Animation.RELATIVE_TO_SELF, -1.0f, Animation.RELATIVE_TO_SELF, 0.0f,
				Animation.RELATIVE_TO_SELF, -1.0f);
		animation.setDuration(500);
		set.addAnimation(animation);
		set.setFillAfter(true);
		return set;
	}

	@Override
	public boolean onChildClick(ExpandableListView parent, View v, final int groupPosition, final int childPosition, long id) {
		final AppItem appItem = (AppItem) mAdapter4DailyClear.getChild(groupPosition, childPosition);
		if (TextUtils.isEmpty(appItem.getFilePath())) {
			final QuickAction2 qa = new QuickAction2(v);
			ActionItem2 clearCache = new ActionItem2();
			clearCache.setTitle(getString(R.string.trash_clear_cache_button));
			clearCache.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					qa.dismiss();
					if (Terminal.isRoot(mContext)) {
						AppManagerUtils.clearAppCache(mContext, appItem.getAppPackage());
						mAdapter4DailyClear.remove(appItem, groupPosition, childPosition);
						mAdapter4DailyClear.notifyDataSetChanged();
						mAdapter4DailyClear.updateSelectCacheSize();
						totalCacheSize -= appItem.getCacheSize();
						ClearUtils.setDayClearSize(mContext, appItem.getCacheSize());
						ClearUtils.setHistoryClearSize(mContext, appItem.getCacheSize());
						updateTotalSize();
						updateSelectSize();
						updateListView();
					} else {
						AppManagerUtils.openInstalledDetail(mContext, appItem.getAppPackage());
					}
				}
			});
			qa.addActionItem(clearCache);
			if (Terminal.isRoot(mContext)) {
				ActionItem2 addWhite = new ActionItem2();
				addWhite.setTitle(getString(R.string.process_keepapp_button));
				addWhite.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						qa.dismiss();
						CacheWhiteListUtils.save(mContext, appItem.getAppPackage());
						mAdapter4DailyClear.remove(appItem, groupPosition, childPosition);
						mAdapter4DailyClear.notifyDataSetChanged();
						mAdapter4DailyClear.updateSelectCacheSize();
						totalCacheSize -= appItem.getCacheSize();
						updateTotalSize();
						updateSelectSize();
						updateListView();
					}
				});
				qa.addActionItem(addWhite);
			}
			qa.show();
		} else {
			// final SharedPreferences sp =
			// PreferenceManager.getDefaultSharedPreferences(mContext);
			// boolean checked = sp.getBoolean("daily_tips_checked", false);
			// if (!checked) {
			// final CustomDialog2 customDialog = new CustomDialog2(mContext);
			// customDialog.setDialogIcon(R.drawable.dialog_icon_question);
			// customDialog.setMessage(R.string.clear_depth_clear_tips);
			// CheckBox checkBox = new CheckBox(mContext);
			// checkBox.setText(R.string.next_not_tips);
			// checkBox.setTextColor(getResources().getColor(R.color.secondary_textcolor));
			// checkBox.setButtonDrawable(R.drawable.checkbox_background);
			// checkBox.setOnCheckedChangeListener(new OnCheckedChangeListener()
			// {
			//
			// @Override
			// public void onCheckedChanged(CompoundButton buttonView, boolean
			// isChecked) {
			// sp.edit().putBoolean("daily_tips_checked", isChecked).commit();
			// }
			// });
			// customDialog.setView(checkBox);
			// customDialog.setButton2(R.string.clear_depth_button_delete, new
			// OnClickListener() {
			//
			// @Override
			// public void onClick(View v) {
			// customDialog.dismiss();
			// DLog.i("debug", appItem.getFilePath());
			// FileUtils.deleteFileByPath(appItem.getFilePath());
			// mAdapter4DailyClear.remove(appItem, groupPosition,
			// childPosition);
			// mAdapter4DailyClear.notifyDataSetChanged();
			// mAdapter4DailyClear.updateSelectCacheSize();
			// totalCacheSize -= appItem.getCacheSize();
			// ClearUtils.setDayClearSize(mContext, appItem.getCacheSize());
			// ClearUtils.setHistoryClearSize(mContext, appItem.getCacheSize());
			// updateTotalSize();
			// updateSelectSize();
			// updateListView();
			// }
			// });
			// customDialog.setButton1(R.string.dialog_button_cancel, null);
			// customDialog.show();
			// } else {
			// FileUtils.deleteFileByPath(appItem.getFilePath());
			// mAdapter4DailyClear.remove(appItem, groupPosition,
			// childPosition);
			// mAdapter4DailyClear.notifyDataSetChanged();
			// mAdapter4DailyClear.updateSelectCacheSize();
			// totalCacheSize -= appItem.getCacheSize();
			// ClearUtils.setDayClearSize(mContext, appItem.getCacheSize());
			// ClearUtils.setHistoryClearSize(mContext, appItem.getCacheSize());
			// updateTotalSize();
			// updateSelectSize();
			// updateListView();
			// }

			final CustomDialog3 customDialog3 = new CustomDialog3(mContext);
			customDialog3.setTitle(appItem.getAppName());
			customDialog3.setIcon(appItem.getAppIcon());
			View dialog_view_process = LayoutInflater.from(mContext).inflate(R.layout.dialog_cache_item, null);
			TextView cache_memory_textview = (TextView) dialog_view_process.findViewById(R.id.cache_memory_textview);
			TextView cache_path_textview = (TextView) dialog_view_process.findViewById(R.id.cache_path_textview);
			cache_memory_textview.setText("大小: " + FormatUtils.formatBytesInByte(appItem.getCacheSize()));
			cache_path_textview.setText("路径: " + appItem.getFilePath());

			customDialog3.setView(dialog_view_process);
			customDialog3.setButton1("取消", null);
			customDialog3.setButton2("清理", new OnClickListener() {

				@Override
				public void onClick(View v) {
					customDialog3.dismiss();
					FileUtils.deleteFileByPath(appItem.getFilePath());
					mAdapter4DailyClear.remove(appItem, groupPosition, childPosition);
					mAdapter4DailyClear.notifyDataSetChanged();
					mAdapter4DailyClear.updateSelectCacheSize();
					totalCacheSize -= appItem.getCacheSize();
					ClearUtils.setDayClearSize(mContext, appItem.getCacheSize());
					ClearUtils.setHistoryClearSize(mContext, appItem.getCacheSize());
					updateTotalSize();
					updateSelectSize();
					updateListView();
				}
			});
			customDialog3.show();
		}
		return true;
	}

	private void updateListView() {

		if (mProcessManagerAdapter != null && mProcessManagerAdapter.getCount() == 0) {
			process_clear_listview_layout.setVisibility(View.GONE);
			process_title_layout.setClickable(false);
		}

		if (mAdapter4DailyClear != null && mAdapter4DailyClear.getGroupCount() == 0) {
			cache_clear_expandlistview_layout.setVisibility(View.GONE);
			cache_title_layout.setClickable(false);
		}
		if (mAdapter4AdClear != null && mAdapter4AdClear.getCount() == 0) {
			ad_clear_listview_layout.setVisibility(View.GONE);
			ad_title_layout.setClickable(false);
		}
	}

	public void updateSelectSize() {
		if (end) {
			header_content_textview.setVisibility(View.VISIBLE);
			header_content_textview.setText(getString(R.string.clear_select_memory_size,
					FormatUtils.formatBytesInByte(selectAdSize + selectCacheSize + selectThumbnailsSize + selectEmptyFolderSize + selectProcessSize)));

		}
	}

	private void updateTotalSize() {
		long totalSize = totalCacheSize + totalAdSize + totalEmptyFolderSize + totalThumbnailsSize + totalProcessSize;
		String size = FormatUtils.formatBytesInByte2(totalSize);
		header_memory_textview.setText(size.substring(0, size.length() - 2));
		header_unit_textview.setText(size.substring(size.length() - 2, size.length()));

		cache_size_textview.setText(FormatUtils.formatBytesInByte(totalCacheSize));
		ad_size_textview.setText(FormatUtils.formatBytesInByte(totalAdSize));
		empty_folder_size_textview.setText(FormatUtils.formatBytesInByte(totalEmptyFolderSize));
		thumbnails_size_textview.setText(FormatUtils.formatBytesInByte(totalThumbnailsSize));
		process_size_textview.setText(FormatUtils.formatBytesInByte(totalProcessSize));

		float f = totalSize * 100f / totalMemory;
		header_waterwave_view.setWaterLevel(f);
		header_waterwave_view.startWave();

	}

	@Override
	protected void onResume() {
		MobclickAgent.onResume(this);
		super.onResume();
	}

	@Override
	protected void onPause() {
		MobclickAgent.onPause(this);
		super.onPause();
	}

	private float lastY;
	private boolean lock = false;
	private boolean isOpen = true;
	private int result_layout_height_px;
	private ListView more_tools_listview;
	private int mFirstItemPosY;
	private LinearLayout result_layout;
	private ImageView ad_cursor_imageview;

	private void initAdView() {
		LinearLayout ad_cursor_layout = (LinearLayout) findViewById(R.id.ad_cursor_layout);
		ad_cursor_imageview = (ImageView) findViewById(R.id.ad_cursor_imageview);

		result_layout = (LinearLayout) findViewById(R.id.result_layout);
		more_tools_listview = (ListView) findViewById(R.id.more_tools_listview);

		LayoutParams resultLayoutParams = (LayoutParams) result_layout.getLayoutParams();
		DisplayMetrics dm = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(dm);
		int screenHeight = dm.heightPixels;

		/**** 获取状态栏高度 ****/
		int statusBarHeight = 0;
		Class<?> c = null;
		Object obj = null;
		Field field = null;
		try {
			c = Class.forName("com.android.internal.R$dimen");
			obj = c.newInstance();
			field = c.getField("status_bar_height");
			int x = Integer.parseInt(field.get(obj).toString());
			statusBarHeight = getResources().getDimensionPixelSize(x);
		} catch (Exception e1) {
			e1.printStackTrace();
			statusBarHeight = 0;
		}

		int ad_layout_height_px = DensityUtil.dip2px(mContext, 80 + 48 + 48) + statusBarHeight;
		result_layout_height_px = screenHeight - ad_layout_height_px;

		resultLayoutParams.height = result_layout_height_px;
		result_layout.setLayoutParams(resultLayoutParams);

		more_tools_listview.setOnTouchListener(new OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()) {
				case MotionEvent.ACTION_DOWN:
					lastY = event.getRawY();
					break;
				case MotionEvent.ACTION_UP:
					lastY = 0;
					break;
				case MotionEvent.ACTION_MOVE:
					if (!lock) {
						if (isOpen) {
							if (event.getRawY() - lastY <= -5) {
								lock = true;
								close();
							}
						} else {
							if (mFirstItemPosY == 0) {
								if (event.getRawY() - lastY >= 10) {
									lock = true;
									open();
								}
							}
						}
					}
					break;

				default:
					break;
				}
				return false;
			}
		});
		ad_cursor_layout.setOnTouchListener(new OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()) {
				case MotionEvent.ACTION_DOWN:
					lastY = event.getRawY();
					break;
				case MotionEvent.ACTION_UP:
					lastY = 0;
					break;
				case MotionEvent.ACTION_MOVE:
					if (!lock) {
						if (isOpen) {
							if (event.getRawY() - lastY <= -5) {
								lock = true;
								close();
							}
						} else {
							if (mFirstItemPosY == 0) {
								if (event.getRawY() - lastY >= 5) {
									lock = true;
									open();
								}
							}
						}
					}
					break;

				default:
					break;
				}
				return true;
			}
		});

		more_tools_listview.setOnScrollListener(new OnScrollListener() {

			@Override
			public void onScrollStateChanged(AbsListView view, int scrollState) {
				switch (scrollState) {
				case OnScrollListener.SCROLL_STATE_TOUCH_SCROLL:
					break;
				case OnScrollListener.SCROLL_STATE_IDLE: //
					View v = view.getChildAt(0);
					mFirstItemPosY = (v == null) ? 0 : v.getTop();
					break;
				}

			}

			@Override
			public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

			}
		});

		more_tools_listview.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

				BaseItem mBaseItem = (BaseItem) parent.getItemAtPosition(position);

				PackageInfo packageInfo = null;
				try {
					packageInfo = mContext.getPackageManager().getPackageInfo(mBaseItem.getPackageName(), 0);
				} catch (NameNotFoundException e) {
					e.printStackTrace();
				}
				if (packageInfo != null) {
					StatisticsUtils.commitEvent(mContext, mBaseItem.getName(), mBaseItem.getPackageName(), StatisticsUtils.AdType_ruanjianneizhi,
							StatisticsUtils.AdEvent_open);
					mContext.startActivity(mContext.getPackageManager().getLaunchIntentForPackage(mBaseItem.getPackageName()));
				} else {
					if (!mBaseItem.isDownload()) {
						StatisticsUtils.commitEvent(mContext, mBaseItem.getName(), mBaseItem.getPackageName(), StatisticsUtils.AdType_ruanjianneizhi,
								StatisticsUtils.AdEvent_show);
						AppDownload appDownload = new AppDownload(mContext);
						appDownload.setDownloadurl(mBaseItem.getApkUrl());
						appDownload.setAppName(mBaseItem.getName());
						appDownload.setPackageName(mBaseItem.getPackageName());
						appDownload.setAppIcon(mBaseItem.getIcon());
						appDownload.createNotify();
						appDownload.startDownloadApp();
						Toast.makeText(mContext, mBaseItem.getName() + mContext.getString(R.string.ad_stardonwload_tips), Toast.LENGTH_SHORT).show();
						mBaseItem.setDownload(true);
					}
				}

			}

		});

		startCursorUpAnim();

	}

	public void open() {
		final LayoutParams layoutParams = (LayoutParams) result_layout.getLayoutParams();
		new Thread(new Runnable() {

			@Override
			public void run() {
				for (int i = 1; i < 26; i++) {
					final int f = i;
					runOnUiThread(new Runnable() {

						@Override
						public void run() {
							layoutParams.height = (int) (result_layout_height_px * (1.0f * (f / 25f)));
							result_layout.setLayoutParams(layoutParams);
							result_layout.invalidate();
							if (f == 25) {
								more_tools_listview.setAdapter(adsAdapter);
								more_tools_listview.setSelection(0);
								TextView back_title = (TextView) findViewById(R.id.back_title);
								back_title.setText(R.string.clear_end_title);
								startCursorUpAnim();
							}
						}
					});
					try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				lock = false;
				isOpen = true;

			}
		}).start();
	}

	public void close() {
		final LayoutParams layoutParams = (LayoutParams) result_layout.getLayoutParams();
		new Thread(new Runnable() {

			@Override
			public void run() {
				for (int i = 1; i < 26; i++) {
					final int f = i;
					runOnUiThread(new Runnable() {

						@Override
						public void run() {
							layoutParams.height = (int) (result_layout_height_px * (1 - 1.0f * (f / 25f)));
							result_layout.setLayoutParams(layoutParams);
							result_layout.invalidate();
							if (f == 25) {
								TextView back_title = (TextView) findViewById(R.id.back_title);
								back_title.setText("更多功能");
								startCursorDownAnim();
								CustomEventCommit.commit(mContext, CustomEventCommit.result_ad_show);
							}
						}
					});
					try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				lock = false;
				isOpen = false;
			}
		}).start();
	}

	private void startCursorUpAnim() {
		ad_cursor_imageview.clearAnimation();
		ad_cursor_imageview.setImageResource(R.drawable.ad_cursor_up);
		Animation animation = AnimationUtils.loadAnimation(mContext, R.anim.cursor_up);
		animation.setStartOffset(100);
		ad_cursor_imageview.startAnimation(animation);
	}

	private void startCursorDownAnim() {
		ad_cursor_imageview.clearAnimation();
		ad_cursor_imageview.setImageResource(R.drawable.ad_cursor_down);
		Animation animation = AnimationUtils.loadAnimation(mContext, R.anim.cursor_down);
		animation.setStartOffset(100);
		ad_cursor_imageview.startAnimation(animation);
	}

	private void clearCursorAnim() {
		ad_cursor_imageview.clearAnimation();
	}

	private Adapter4ResultAd adsAdapter;

	private void initADListView() {
		ArrayList<BaseItem> mBaseItems = new ArrayList<BaseItem>();

		adsAdapter = new Adapter4ResultAd(mContext, mBaseItems);
		more_tools_listview.setAdapter(adsAdapter);

		SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(mContext);
		String toolbox_ad_json = sp.getString("result_ad_json", null);
		if (toolbox_ad_json != null) {
			ArrayList<ToolboxAd> toolboxAds = ToolboxAdUtils.getAdInfo(toolbox_ad_json);
			new GetAdsThread(toolboxAds).start();
		} else {
			new GetAdsThread(null).start();
		}
	}

	/**
	 * 获取广告列表
	 * 
	 * @author 庄宏岩
	 * 
	 */
	private class GetAdsThread extends Thread {
		private ArrayList<ToolboxAd> toolboxAds;
		private ArrayList<BaseItem> mBaseItems;

		public GetAdsThread(ArrayList<ToolboxAd> toolboxAds) {
			this.toolboxAds = toolboxAds;
			mBaseItems = new ArrayList<BaseItem>();
		}

		@Override
		public void run() {
			super.run();

			if (toolboxAds == null) {
				toolboxAds = ToolboxAdUtils.getResultAdInfo(mContext);
			}
			if (toolboxAds != null) {
				for (int i = 0; i < toolboxAds.size(); i++) {
					final BaseItem baseItem = new BaseItem();
					ToolboxAd toolboxAd = toolboxAds.get(i);
					AdInfo adInfo = getRandomAd(toolboxAd);
					PackageManager pm = mContext.getPackageManager();
					PackageInfo packageInfo = null;
					try {
						packageInfo = pm.getPackageInfo(adInfo.getPackageName(), 0);
					} catch (NameNotFoundException e) {
					}
					if (packageInfo != null) {
						adInfo = getNotInstallAd(toolboxAd);
					}
					baseItem.setName(adInfo.getAppName());
					baseItem.setPackageName(adInfo.getPackageName());
					baseItem.setDesc(adInfo.getContent());
					baseItem.setApkUrl(adInfo.getApkUrl());
					baseItem.setTitle(adInfo.getTitle());
					baseItem.setDetailUrl(adInfo.getDetailUrl());
					baseItem.setType(3);
					baseItem.setSize(adInfo.getSize());
					baseItem.setImageUrl(adInfo.getImageUrl());
					baseItem.setHtml5(adInfo.isHtml5());
					baseItem.setGameUrl(adInfo.getGameUrl());
					mBaseItems.add(baseItem);
				}
			}
			mHandler.sendEmptyMessage(1);
		}

		Handler mHandler = new Handler() {

			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				switch (msg.what) {
				case 1:
					if (mBaseItems != null && mBaseItems.size() > 0) {
						adsAdapter.getList().addAll(mBaseItems);
						adsAdapter.notifyDataSetChanged();
					} else {
						LayoutParams resultLayoutParams = (LayoutParams) result_layout.getLayoutParams();
						resultLayoutParams.height = LayoutParams.FILL_PARENT;
						result_layout.setLayoutParams(resultLayoutParams);
					}
					break;
				default:
					break;
				}

			}

		};
	}

	public AdInfo getRandomAd(ToolboxAd toolboxAd) {
		int r = (int) (Math.random() * 10 + 1);
		ArrayList<AdInfo> adInfos = toolboxAd.getAdInfos();
		if (adInfos != null && adInfos.size() > 0) {
			for (AdInfo adInfo : adInfos) {
				if (r >= adInfo.getWeight_l() && r <= adInfo.getWeight_r()) {
					return adInfo;
				}
			}
		}
		return null;
	}

	public AdInfo getNotInstallAd(ToolboxAd toolboxAd) {
		ArrayList<AdInfo> adInfos = toolboxAd.getAdInfos();
		PackageManager pm = mContext.getPackageManager();
		if (adInfos != null && adInfos.size() > 0) {
			for (AdInfo adInfo : adInfos) {
				PackageInfo packageInfo = null;
				try {
					packageInfo = pm.getPackageInfo(adInfo.getPackageName(), 0);
				} catch (NameNotFoundException e) {
				}
				if (packageInfo == null) {
					return adInfo;
				}

			}
			return adInfos.get(0);
		}
		return null;
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		stop = true;
		header_waterwave_view.stoptWave();
		clearCursorAnim();
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
		switch (parent.getId()) {
		case R.id.process_clear_listview:
			final AppItem appItem = (AppItem) parent.getItemAtPosition(position);
			final QuickAction2 qa = new QuickAction2(view);
			ActionItem2 kill = new ActionItem2();
			kill.setTitle(getString(R.string.process_kill_button));
			kill.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					qa.dismiss();
					ProcessManagerUtils.killProcess(mContext, appItem);
					ClearUtils.setDayClearSize(mContext, appItem.getMemorySize());
					ClearUtils.setHistoryClearSize(mContext, appItem.getMemorySize());
					mProcessManagerAdapter.remove(appItem);
					mProcessManagerAdapter.notifyDataSetChanged();
					mProcessManagerAdapter.updateSelectMemorySize();
					totalProcessSize -= appItem.getMemorySize();
					updateTotalSize();
					updateSelectSize();
					Toast.makeText(mContext, getString(R.string.process_manager_kill_one_precess, FormatUtils.formatBytesInByte(appItem.getMemorySize())),
							Toast.LENGTH_SHORT).show();
					updateListView();
				}

			});
			qa.addActionItem(kill);

			ActionItem2 keep = new ActionItem2();
			keep.setTitle(getString(R.string.process_keepapp_button));
			keep.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					qa.dismiss();
					KeepListUtils.save(mContext, appItem.getAppPackage());
					mProcessManagerAdapter.remove(appItem);
					mProcessManagerAdapter.notifyDataSetChanged();
					mProcessManagerAdapter.updateSelectMemorySize();
					totalProcessSize -= appItem.getMemorySize();

					updateTotalSize();
					updateSelectSize();
					updateListView();
				}
			});
			qa.addActionItem(keep);
			qa.show();
			break;
			
		case R.id.ad_clear_listview:
			final AppItem appItemAd = (AppItem) parent.getItemAtPosition(position);
			appItemAd.setChecked(!appItemAd.isChecked());
			mAdapter4AdClear.notifyDataSetChanged();
			mAdapter4AdClear.updateSelectDepthSize();
			break;
		}
	}

	private String getLanguage() {
		String language = Locale.getDefault().getLanguage();
		// String country = Locale.getDefault().getCountry();
		if ("zh".equals(language)) {
			return "zh";
		} else if ("en".equals(language)) {
			return "en";
		}
		return "en";
	}

}
