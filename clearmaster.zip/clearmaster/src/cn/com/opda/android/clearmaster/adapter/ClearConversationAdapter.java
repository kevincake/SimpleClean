package cn.com.opda.android.clearmaster.adapter;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.TextView;
import cn.com.opda.android.clearmaster.R;
import cn.com.opda.android.clearmaster.impl.CheckedListener;
import cn.com.opda.android.clearmaster.model.ConversationInfo;

/**
 * 短信清理会话列表适配器
 * 
 * @author 庄宏岩
 * 
 */
public class ClearConversationAdapter extends BaseAdapter {
	private ArrayList<ConversationInfo> mConversationInfos;
	private LayoutInflater mLayoutInflater;
	private CheckedListener checkedListener;
	public ClearConversationAdapter(Context mContext, ArrayList<ConversationInfo> mConversationInfos) {
		this.mConversationInfos = mConversationInfos;
		mLayoutInflater = LayoutInflater.from(mContext);
	}

	@Override
	public int getCount() {
		return mConversationInfos.size();
	}

	@Override
	public Object getItem(int position) {
		return mConversationInfos.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	public void remove(ConversationInfo conversationInfo) {
		if(mConversationInfos.size()>0){
			mConversationInfos.remove(conversationInfo);
		}
		notifyDataSetChanged();
	}

	public void updateItem(int position, int count) {
		if (count == 0) {
			if(mConversationInfos.size()>0){
				mConversationInfos.remove(position);
			}
		} else {
			if(mConversationInfos.size()>0){
				mConversationInfos.get(position).setCount(count);
			}
		}
		notifyDataSetChanged();
	}

	public void setAllChecked(boolean isChecked) {
		for (ConversationInfo conversationInfo : mConversationInfos) {
			conversationInfo.setChecked(isChecked);
		}
		notifyDataSetChanged();
	}

	/**
	 * 获取选中的条目
	 * 
	 * @return
	 */
	public ArrayList<ConversationInfo> getSelecteList() {
		ArrayList<ConversationInfo> conversationInfos = new ArrayList<ConversationInfo>();
		for (ConversationInfo conversationInfo : mConversationInfos) {
			if (conversationInfo.isChecked()) {
				conversationInfos.add(conversationInfo);
			}
		}
		return conversationInfos;
	}

	public ArrayList<ConversationInfo> getList() {
		return mConversationInfos;
	}

	public int getConversationId(int position) {
		ConversationInfo junConversation = mConversationInfos.get(position);
		return junConversation.getId();
	}

	public String getConversationPersonName(int position) {
		ConversationInfo junConversation = mConversationInfos.get(position);
		return junConversation.getName();
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		final Holder mHolder;
		if (convertView == null) {
			convertView = mLayoutInflater.inflate(R.layout.listview_conversation_item, null);
			mHolder = new Holder();
			mHolder.conversation_item_name_textview = (TextView) convertView.findViewById(R.id.conversation_item_name_textview);
			mHolder.conversation_item_checked_imageview = (CheckBox) convertView.findViewById(R.id.conversation_item_checked_imageview);
			convertView.setTag(mHolder);
		} else {
			mHolder = (Holder) convertView.getTag();
		}

		final ConversationInfo conversationInfo = mConversationInfos.get(position);
		mHolder.conversation_item_name_textview.setText(conversationInfo.getName() + "(" + conversationInfo.getCount() + ")");

		if (conversationInfo.isChecked()) {
			mHolder.conversation_item_checked_imageview.setChecked(true);
		} else {
			mHolder.conversation_item_checked_imageview.setChecked(false);
		}
		mHolder.conversation_item_checked_imageview.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				conversationInfo.setChecked(!conversationInfo.isChecked());
				updateChecked();
				notifyDataSetChanged();
			}
		
		});
		return convertView;
	}
	public void setCheckedListener(CheckedListener checkedListener) {
		this.checkedListener = checkedListener;
	}
	
	public void updateChecked() {
		int checkedSize = 0;
		for (ConversationInfo conversationInfo : mConversationInfos) {
			if (conversationInfo != null && conversationInfo.isChecked()) {
				checkedSize++;
			}
		}
		if (checkedListener != null) {
			if (checkedSize == 0) {
				checkedListener.nothingChecked();
			} else if (checkedSize == getCount()) {
				checkedListener.allChecked(checkedSize);
			} else {
				checkedListener.someChecked(checkedSize);
			}
		}
		
	}

	private class Holder {
		private TextView conversation_item_name_textview;
		private CheckBox conversation_item_checked_imageview;
	}


}
