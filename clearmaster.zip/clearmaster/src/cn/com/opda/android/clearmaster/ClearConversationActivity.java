package cn.com.opda.android.clearmaster;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import cn.com.opda.android.clearmaster.adapter.ClearConversationAdapter;
import cn.com.opda.android.clearmaster.impl.CheckedListener;
import cn.com.opda.android.clearmaster.model.ConversationInfo;
import cn.com.opda.android.clearmaster.utils.BannerUtils;
import cn.com.opda.android.clearmaster.utils.Constants;
import cn.com.opda.android.clearmaster.utils.SmsUtils;

import com.umeng.analytics.MobclickAgent;

/**
 * 短信清理会话列表页面
 * 
 * @author 庄宏岩
 * 
 */
public class ClearConversationActivity extends BaseActivity implements OnItemClickListener, OnClickListener,CheckedListener {
	private Context mContext;
	private ClearConversationAdapter allSmsAdapter;
	private ClearConversationAdapter linkmanSmsAdapter;
	private ClearConversationAdapter strangerSmsAdapter;
	private ClearConversationAdapter serviceSmsAdapter;
	private ArrayList<ConversationInfo> allConversationInfos;
	private ArrayList<ConversationInfo> linkmanConversationInfos;
	private ArrayList<ConversationInfo> strangerConversationInfos;
	private ArrayList<ConversationInfo> serviceConversationInfos;
	private LinearLayout all_sms_tips_layout;
	private LinearLayout linkman_sms_tips_layout;
	private LinearLayout stranger_sms_tips_layout;
	private LinearLayout service_sms_tips_layout;
	private ListView all_sms_listView;
	private ListView linkman_sms_listView;
	private ListView stranger_sms_listView;
	private ListView service_sms_listView;
	private TextView sms_count;
	private int smsCount = 0;
	private boolean stop;
	private Button clear_button;
	
	private RelativeLayout clear_button_layout;
	private ViewPager mPager;// 页卡内容
	private List<View> listViews; // Tab页面列表
	private ImageView cursor;// 动画图片
	private int offset = 0;// 动画图片偏移量
	private int currIndex = 0;// 当前页卡编号
	private int bmpW;// 动画图片宽度
	private int screenW;
	private TextView viewpager_tab1, viewpager_tab2, viewpager_tab3, viewpager_tab4;
	private String[] smsFilter;
	private CheckBox allCheckbox;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mContext = ClearConversationActivity.this;
		setContentView(R.layout.activity_clear_sms);
		BannerUtils.setTitle(this, R.string.clean_sms_title);
		BannerUtils.initBackButton(this);
		smsFilter = getResources().getStringArray(R.array.sms_filter);
		initViewAndEvent();
		initTextView();
		initImageView();
		initViewPager();
		new GetConversationsTask().execute();
	}

	/**
	 * 初始化头标
	 */
	private void initTextView() {
		viewpager_tab1 = (TextView) findViewById(R.id.viewpager_tab1);
		viewpager_tab2 = (TextView) findViewById(R.id.viewpager_tab2);
		viewpager_tab3 = (TextView) findViewById(R.id.viewpager_tab3);
		viewpager_tab4 = (TextView) findViewById(R.id.viewpager_tab4);

		viewpager_tab1.setText(smsFilter[0]);
		viewpager_tab2.setText(smsFilter[1]);
		viewpager_tab3.setText(smsFilter[2]);
		viewpager_tab4.setText(smsFilter[3]);

		viewpager_tab1.setOnClickListener(this);
		viewpager_tab2.setOnClickListener(this);
		viewpager_tab3.setOnClickListener(this);
		viewpager_tab4.setOnClickListener(this);
	}

	/**
	 * 初始化ViewPager
	 */
	private void initViewPager() {
		mPager = (ViewPager) findViewById(R.id.vPager);

		listViews = new ArrayList<View>();

		View view1 = LayoutInflater.from(mContext).inflate(R.layout.sms_listview_layout, null);
		all_sms_listView = (ListView) view1.findViewById(R.id.clear_sms_listview);
		all_sms_listView.setOnItemClickListener(this);
		all_sms_tips_layout = (LinearLayout) view1.findViewById(R.id.clear_sms_tips_layout);
		allConversationInfos = new ArrayList<ConversationInfo>();
		allSmsAdapter = new ClearConversationAdapter(mContext, allConversationInfos);
		allSmsAdapter.setCheckedListener(this);
		all_sms_listView.setAdapter(allSmsAdapter);

		View view2 = LayoutInflater.from(mContext).inflate(R.layout.sms_listview_layout, null);
		linkman_sms_listView = (ListView) view2.findViewById(R.id.clear_sms_listview);
		linkman_sms_listView.setOnItemClickListener(this);
		linkman_sms_tips_layout = (LinearLayout) view2.findViewById(R.id.clear_sms_tips_layout);
		linkmanConversationInfos = new ArrayList<ConversationInfo>();
		linkmanSmsAdapter = new ClearConversationAdapter(mContext, linkmanConversationInfos);
		linkmanSmsAdapter.setCheckedListener(this);
		linkman_sms_listView.setAdapter(linkmanSmsAdapter);

		View view3 = LayoutInflater.from(mContext).inflate(R.layout.sms_listview_layout, null);
		stranger_sms_listView = (ListView) view3.findViewById(R.id.clear_sms_listview);
		stranger_sms_listView.setOnItemClickListener(this);
		stranger_sms_tips_layout = (LinearLayout) view3.findViewById(R.id.clear_sms_tips_layout);
		strangerConversationInfos = new ArrayList<ConversationInfo>();
		strangerSmsAdapter = new ClearConversationAdapter(mContext, strangerConversationInfos);
		strangerSmsAdapter.setCheckedListener(this);
		stranger_sms_listView.setAdapter(strangerSmsAdapter);

		View view4 = LayoutInflater.from(mContext).inflate(R.layout.sms_listview_layout, null);
		service_sms_listView = (ListView) view4.findViewById(R.id.clear_sms_listview);
		service_sms_listView.setOnItemClickListener(this);
		service_sms_tips_layout = (LinearLayout) view4.findViewById(R.id.clear_sms_tips_layout);
		serviceConversationInfos = new ArrayList<ConversationInfo>();
		serviceSmsAdapter = new ClearConversationAdapter(mContext, serviceConversationInfos);
		serviceSmsAdapter.setCheckedListener(this);
		service_sms_listView.setAdapter(serviceSmsAdapter);

		listViews.add(view1);
		listViews.add(view2);
		listViews.add(view3);
		listViews.add(view4);
		mPager.setAdapter(new MyPagerAdapter(listViews));
		mPager.setCurrentItem(0);
		mPager.setOnPageChangeListener(new MyOnPageChangeListener());

	}

	/**
	 * 初始化动画
	 */
	private void initImageView() {
		cursor = (ImageView) findViewById(R.id.cursor);
		bmpW = BitmapFactory.decodeResource(getResources(), R.drawable.indicator).getWidth();// 获取图片宽度
		DisplayMetrics dm = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(dm);
		screenW = dm.widthPixels;// 获取分辨率宽度
		offset = (screenW / 4 - bmpW) / 2;// 计算偏移量
		Matrix matrix = new Matrix();
		matrix.postTranslate(offset, 0);

		cursor.setImageMatrix(matrix);// 设置动画初始位置
	}

	/**
	 * ViewPager适配器
	 */
	public class MyPagerAdapter extends PagerAdapter {
		public List<View> mListViews;

		public MyPagerAdapter(List<View> mListViews) {
			this.mListViews = mListViews;
		}

		@Override
		public void destroyItem(View view, int position, Object object) {
			((ViewPager) view).removeView(mListViews.get(position));
		}

		@Override
		public void finishUpdate(View view) {

		}

		@Override
		public int getCount() {
			return mListViews.size();
		}

		@Override
		public Object instantiateItem(View view, int position) {
			((ViewPager) view).addView(mListViews.get(position), 0);
			return mListViews.get(position);
		}

		@Override
		public boolean isViewFromObject(View view, Object obj) {
			return view == (obj);
		}

		@Override
		public void restoreState(Parcelable view, ClassLoader classLoader) {
		}

		@Override
		public Parcelable saveState() {
			return null;
		}

		@Override
		public void startUpdate(View view) {
		}
	}

	public class MyOnPageChangeListener implements OnPageChangeListener {
		int one = offset + screenW / 4;
		int two = offset + (screenW / 4) * 2;
		int three = offset + (screenW / 4) * 3;

		@Override
		public void onPageSelected(int position) {

			currIndex = position;
			updatePage();
		}

		@Override
		public void onPageScrolled(int arg0, float arg1, int arg2) {
			Matrix matrix = new Matrix();
			switch (arg0) {
			case 0:
				matrix.postTranslate(offset + (one - offset) * arg1, 0);
				break;
			case 1:
				matrix.postTranslate(one + (two - one) * arg1, 0);
				break;
			case 2:
				matrix.postTranslate(two + (two - one) * arg1, 0);
				break;
			case 3:
				matrix.postTranslate(three + (two - one) * arg1, 0);
				break;

			default:
				break;
			}
			cursor.setImageMatrix(matrix);
		}

		@Override
		public void onPageScrollStateChanged(int position) {

		}
	}

	private void initViewAndEvent() {
		sms_count = (TextView) findViewById(R.id.header_memory_textview);
		clear_button = (Button) findViewById(R.id.clear_button);
		clear_button.setOnClickListener(this);
		allCheckbox = (CheckBox) findViewById(R.id.all_checked_checkbox);
		allCheckbox.setChecked(false);
		allCheckbox.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				allCheckbox.setChecked(allCheckbox.isChecked());
				updateChecked(allCheckbox.isChecked());
				
			}
		});
		clear_button_layout = (RelativeLayout) findViewById(R.id.clear_button_layout);
	}

	private class GetConversationsTask extends AsyncTask<Void, ConversationInfo, Integer> {

		@Override
		protected void onPreExecute() {
			clear_button.setText(R.string.stop_scan_button);
		}

		@Override
		protected Integer doInBackground(Void... params) {
			String where = "0==0) group by (" + Constants.SMS_thread_id;
			String[] projection = new String[] { Constants.SMS_thread_id, Constants.SMS_address, Constants.SMS_person, "COUNT(*) AS " + "COUNT" };

			Cursor cursor = getContentResolver().query(Constants.SMSAll_URL, projection, where, null, Constants.SMS_thread_id + " ASC");
			if (cursor != null) {
				if (cursor.moveToNext()) {
					int count = cursor.getCount();
					boolean isCN = "CN".equals(getResources().getConfiguration().locale.getCountry());
					for (int i = 0; i < count; ++i) {
						if (stop) {
							break;
						}
						cursor.moveToPosition(i);
						String idtemp = cursor.getString(0);
						String adresstemp = cursor.getString(1);
						String persontemp = cursor.getString(2);
						String counttemp = cursor.getString(3);

						ConversationInfo conversationInfo = new ConversationInfo();

						if (!TextUtils.isEmpty(idtemp)) {
							conversationInfo.setId(Integer.parseInt(idtemp));
						} else {
							continue;
						}
						if (adresstemp != null) {
							conversationInfo.setAddress(adresstemp);
						} else {
							continue;
						}
						if (persontemp != null) {
							conversationInfo.setPerson(persontemp);
						} else {
						}
						if (counttemp != null) {
							Pattern p = Pattern.compile("[0-9]*");
							Matcher m = p.matcher(counttemp);
							boolean bFlag = m.matches();
							if (bFlag) {
								conversationInfo.setCount(Integer.parseInt(counttemp));
							}
						}
						conversationInfo = SmsUtils.findRealNameInOther(mContext, conversationInfo, isCN);
						smsCount += conversationInfo.getCount();
						publishProgress(conversationInfo);
					}
				}
				cursor.close();
			}
			return null;
		}

		@Override
		protected void onProgressUpdate(ConversationInfo... values) {
			if (values.length > 0) {
				ConversationInfo conversationInfo = values[0];
				allConversationInfos.add(conversationInfo);
				allSmsAdapter.notifyDataSetChanged();

				if (conversationInfo.getNumberType() == Constants.PHONETYPE_CONTACT) {
					linkmanConversationInfos.add(conversationInfo);
					linkmanSmsAdapter.notifyDataSetChanged();
				}

				if (conversationInfo.getNumberType() == Constants.PHONETYPE_SERVER) {
					serviceConversationInfos.add(conversationInfo);
					serviceSmsAdapter.notifyDataSetChanged();
				}

				if (conversationInfo.getNumberType() == Constants.PHONETYPE_UNKNOWN) {
					strangerConversationInfos.add(conversationInfo);
					strangerSmsAdapter.notifyDataSetChanged();
				}

			}
			updateCount();
			super.onProgressUpdate(values);
		}

		@Override
		protected void onPostExecute(Integer result) {
			super.onPostExecute(result);
			if (allConversationInfos.size() == 0) {
				all_sms_tips_layout.setVisibility(View.VISIBLE);
				all_sms_listView.setVisibility(View.GONE);
			} else {
				all_sms_tips_layout.setVisibility(View.GONE);
				all_sms_listView.setVisibility(View.VISIBLE);
			}

			if (linkmanConversationInfos.size() == 0) {
				linkman_sms_tips_layout.setVisibility(View.VISIBLE);
				linkman_sms_listView.setVisibility(View.GONE);
			} else {
				linkman_sms_tips_layout.setVisibility(View.GONE);
				linkman_sms_listView.setVisibility(View.VISIBLE);
			}

			if (strangerConversationInfos.size() == 0) {
				stranger_sms_tips_layout.setVisibility(View.VISIBLE);
				stranger_sms_listView.setVisibility(View.GONE);
			} else {
				stranger_sms_tips_layout.setVisibility(View.GONE);
				stranger_sms_listView.setVisibility(View.VISIBLE);
			}

			if (serviceConversationInfos.size() == 0) {
				service_sms_tips_layout.setVisibility(View.VISIBLE);
				service_sms_listView.setVisibility(View.GONE);
			} else {
				service_sms_tips_layout.setVisibility(View.GONE);
				service_sms_listView.setVisibility(View.VISIBLE);
			}

			handler.sendEmptyMessage(2);
		}

		Handler handler = new Handler() {

			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				switch (msg.what) {
				case 1:
					break;
				case 2:
					clear_button.setText(R.string.one_clear_button);
					updatePage();
					break;
				default:
					break;
				}
			}
		};
	}

	public void updateCount() {
		switch (currIndex) {
		case 0:
			ArrayList<ConversationInfo> conversationInfos = allSmsAdapter.getList();
			smsCount = 0;
			for (int i = 0; i < conversationInfos.size(); i++) {
				smsCount += conversationInfos.get(i).getCount();
			}
			sms_count.setText(smsCount + "");
			break;
		case 1:
			ArrayList<ConversationInfo> conversationInfos2 = linkmanSmsAdapter.getList();
			smsCount = 0;
			for (int i = 0; i < conversationInfos2.size(); i++) {
				smsCount += conversationInfos2.get(i).getCount();
			}
			sms_count.setText(smsCount + "");
			break;
		case 2:
			ArrayList<ConversationInfo> conversationInfos3 = strangerSmsAdapter.getList();
			smsCount = 0;
			for (int i = 0; i < conversationInfos3.size(); i++) {
				smsCount += conversationInfos3.get(i).getCount();
			}
			sms_count.setText(smsCount + "");
			break;
		case 3:
			ArrayList<ConversationInfo> conversationInfos4 = serviceSmsAdapter.getList();
			smsCount = 0;
			for (int i = 0; i < conversationInfos4.size(); i++) {
				smsCount += conversationInfos4.get(i).getCount();
			}
			sms_count.setText(smsCount + "");
			break;

		default:
			break;
		}
	}

	protected void updatePage() {
		switch (currIndex) {
		case 0:
			if (allConversationInfos.size() > 0) {
				clear_button_layout.setVisibility(View.VISIBLE);
			} else {
				clear_button_layout.setVisibility(View.GONE);
			}
			ArrayList<ConversationInfo> conversationInfos = allSmsAdapter.getList();
			smsCount = 0;
			for (int i = 0; i < conversationInfos.size(); i++) {
				smsCount += conversationInfos.get(i).getCount();
			}
			sms_count.setText(smsCount + "");
			allSmsAdapter.updateChecked();
			break;
		case 1:
			if (linkmanConversationInfos.size() > 0) {
				clear_button_layout.setVisibility(View.VISIBLE);
			} else {
				clear_button_layout.setVisibility(View.GONE);
			}
			ArrayList<ConversationInfo> conversationInfos2 = linkmanSmsAdapter.getList();
			smsCount = 0;
			for (int i = 0; i < conversationInfos2.size(); i++) {
				smsCount += conversationInfos2.get(i).getCount();
			}
			sms_count.setText(smsCount + "");
			linkmanSmsAdapter.updateChecked();
			break;
		case 2:
			if (strangerConversationInfos.size() > 0) {
				clear_button_layout.setVisibility(View.VISIBLE);
			} else {
				clear_button_layout.setVisibility(View.GONE);
			}
			ArrayList<ConversationInfo> conversationInfos3 = strangerSmsAdapter.getList();
			smsCount = 0;
			for (int i = 0; i < conversationInfos3.size(); i++) {
				smsCount += conversationInfos3.get(i).getCount();
			}
			sms_count.setText(smsCount + "");
			strangerSmsAdapter.updateChecked();
			break;
		case 3:
			if (serviceConversationInfos.size() > 0) {
				clear_button_layout.setVisibility(View.VISIBLE);
			} else {
				clear_button_layout.setVisibility(View.GONE);
			}
			ArrayList<ConversationInfo> conversationInfos4 = serviceSmsAdapter.getList();
			smsCount = 0;
			for (int i = 0; i < conversationInfos4.size(); i++) {
				smsCount += conversationInfos4.get(i).getCount();
			}
			sms_count.setText(smsCount + "");
			serviceSmsAdapter.updateChecked();
			break;

		default:
			break;
		}
	}
	

	private void updateChecked(boolean checked) {
		switch (currIndex) {
		case 0:
			allSmsAdapter.setAllChecked(checked);
			break;
		case 1:
			linkmanSmsAdapter.setAllChecked(checked);
			break;
		case 2:
			strangerSmsAdapter.setAllChecked(checked);
			break;
		case 3:
			serviceSmsAdapter.setAllChecked(checked);
			break;

		default:
			break;
		}
	}

	private void deleteSms() {
		ArrayList<ConversationInfo> deleteList = null;
		switch (currIndex) {
		case 0:
			deleteList = allSmsAdapter.getSelecteList();
			break;
		case 1:
			deleteList = linkmanSmsAdapter.getSelecteList();
			break;
		case 2:
			deleteList = strangerSmsAdapter.getSelecteList();
			break;
		case 3:
			deleteList = serviceSmsAdapter.getSelecteList();
			break;

		default:
			break;
		}

		if (deleteList == null || deleteList.size() == 0) {
			Toast.makeText(mContext, R.string.clear_select_null, Toast.LENGTH_SHORT).show();
		} else {
			new DeleteConversationTask(deleteList).execute();
		}
	}

	private class DeleteConversationTask extends AsyncTask<Void, ConversationInfo, Integer> {
		private ArrayList<ConversationInfo> mDeleteConversationInfos;

		public DeleteConversationTask(ArrayList<ConversationInfo> mDeleteConversationInfos) {
			this.mDeleteConversationInfos = mDeleteConversationInfos;
		}

		@Override
		protected Integer doInBackground(Void... params) {
			if (mDeleteConversationInfos.size() > 0) {
				for (int i = 0; i < mDeleteConversationInfos.size(); i++) {
					if (stop) {
						return null;
					}
					ConversationInfo conversationInfo = mDeleteConversationInfos.get(i);
					SmsUtils.deleteConversationByThreadId(mContext, conversationInfo.getId());
					try {
						Thread.sleep(30);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					publishProgress(conversationInfo);
				}
			}
			return null;
		}

		@Override
		protected void onProgressUpdate(ConversationInfo... values) {
			if (values.length > 0) {
				ConversationInfo conversationInfo = values[0];
				allConversationInfos.remove(conversationInfo);
				allSmsAdapter.notifyDataSetChanged();

				if (conversationInfo.getNumberType() == Constants.PHONETYPE_CONTACT) {
					linkmanConversationInfos.remove(conversationInfo);
					linkmanSmsAdapter.notifyDataSetChanged();
				}

				if (conversationInfo.getNumberType() == Constants.PHONETYPE_SERVER) {
					serviceConversationInfos.remove(conversationInfo);
					serviceSmsAdapter.notifyDataSetChanged();
				}

				if (conversationInfo.getNumberType() == Constants.PHONETYPE_UNKNOWN) {
					strangerConversationInfos.remove(conversationInfo);
					strangerSmsAdapter.notifyDataSetChanged();
				}
				handler.sendEmptyMessage(1);
			}

			super.onProgressUpdate(values);
		}

		@Override
		protected void onPostExecute(Integer result) {
			super.onPostExecute(result);
			
			if (allConversationInfos.size() == 0) {
				all_sms_tips_layout.setVisibility(View.VISIBLE);
				all_sms_listView.setVisibility(View.GONE);
			} else {
				all_sms_tips_layout.setVisibility(View.GONE);
				all_sms_listView.setVisibility(View.VISIBLE);
			}

			if (linkmanConversationInfos.size() == 0) {
				linkman_sms_tips_layout.setVisibility(View.VISIBLE);
				linkman_sms_listView.setVisibility(View.GONE);
			} else {
				linkman_sms_tips_layout.setVisibility(View.GONE);
				linkman_sms_listView.setVisibility(View.VISIBLE);
			}

			if (strangerConversationInfos.size() == 0) {
				stranger_sms_tips_layout.setVisibility(View.VISIBLE);
				stranger_sms_listView.setVisibility(View.GONE);
			} else {
				stranger_sms_tips_layout.setVisibility(View.GONE);
				stranger_sms_listView.setVisibility(View.VISIBLE);
			}

			if (serviceConversationInfos.size() == 0) {
				service_sms_tips_layout.setVisibility(View.VISIBLE);
				service_sms_listView.setVisibility(View.GONE);
			} else {
				service_sms_tips_layout.setVisibility(View.GONE);
				service_sms_listView.setVisibility(View.VISIBLE);
			}
			int clearCount = 0;
			for (int i = 0; i < mDeleteConversationInfos.size(); i++) {
				clearCount += mDeleteConversationInfos.get(i).getCount();
			}
			Toast.makeText(mContext, getString(R.string.clean_end_sms_count_toast, clearCount), Toast.LENGTH_SHORT).show();
			handler.sendEmptyMessage(2);
		}

		Handler handler = new Handler() {

			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				switch (msg.what) {
				case 1:
					updateCount();
					break;
				case 2:
					updatePage();
					break;

				default:
					break;
				}
			}

		};

	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode == 100) {
			int position = data.getIntExtra("position", -1);
			int count = data.getIntExtra("count", -1);
			if (position != -1) {
				if (count != -1) {
					switch (currIndex) {
					case 0:
						allSmsAdapter.updateItem(position, count);
						break;
					case 1:
						linkmanSmsAdapter.updateItem(position, count);
						break;
					case 2:
						strangerSmsAdapter.updateItem(position, count);
						break;
					case 3:
						serviceSmsAdapter.updateItem(position, count);
						break;
					default:
						break;
					}
					updatePage();
				}
			}
		}
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
		ClearConversationAdapter adapter = (ClearConversationAdapter) parent.getAdapter();
		Intent intent = new Intent(mContext, SMSDetailListActivity.class);
		int threadId = adapter.getConversationId(position);
		String name = adapter.getConversationPersonName(position);
		intent.putExtra("threadId", threadId);
		intent.putExtra("name", name);
		intent.putExtra("position", position);
		startActivityForResult(intent, 100);
	}

	@Override
	protected void onResume() {
		MobclickAgent.onResume(this);
		super.onResume();
	}

	@Override
	protected void onPause() {
		MobclickAgent.onPause(this);
		super.onPause();
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.clear_button:
			if (clear_button.getText().equals(getString(R.string.stop_scan_button))) {
				stop = true;
				clear_button.setText(R.string.one_clear_button);
			} else {
				deleteSms();
			}
			break;
		case R.id.viewpager_tab1:
			mPager.setCurrentItem(0);
			break;
		case R.id.viewpager_tab2:
			mPager.setCurrentItem(1);
			break;
		case R.id.viewpager_tab3:
			mPager.setCurrentItem(2);
			break;
		case R.id.viewpager_tab4:
			mPager.setCurrentItem(3);
			break;
		default:
			break;
		}

	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		stop = true;
	}

	@Override
	public void nothingChecked() {
		allCheckbox.setChecked(false);
	}

	@Override
	public void someChecked(int count) {
		allCheckbox.setChecked(false);
	}

	@Override
	public void allChecked(int count) {
		allCheckbox.setChecked(true);
	}

}
