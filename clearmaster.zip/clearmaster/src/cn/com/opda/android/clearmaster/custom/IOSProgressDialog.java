package cn.com.opda.android.clearmaster.custom;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.KeyEvent;
import android.widget.TextView;
import cn.com.opda.android.clearmaster.R;

/**
 * 
 * 自定义样式的对话框
 * 
 */
public class IOSProgressDialog extends ProgressDialog {

	private String message = null;
	private TextView msg_tv;

	public IOSProgressDialog(Context context) {
		super(context);
	}

	public IOSProgressDialog(Context context, String msg) {
		super(context);
		message = msg;
	}

	public IOSProgressDialog(Context context, int msgId) {
		super(context);
		message = context.getString(msgId);
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ios_progress_dialog);
		msg_tv = (TextView) findViewById(R.id.ios_progress_msg);
		if (message != null) {
			msg_tv.setText(message);
		}
	}

	@Override
	public boolean dispatchKeyEvent(KeyEvent event) {
		int keyCode = event.getKeyCode();
		if (keyCode == KeyEvent.KEYCODE_SEARCH) {
			return true;
		}
		return super.dispatchKeyEvent(event);
	}

	@Override
	public void setMessage(CharSequence message) {
		super.setMessage(message);
		if (message != null) {
			msg_tv = (TextView) findViewById(R.id.ios_progress_msg);
			msg_tv.setText(message);
		}
	}
}
