package cn.com.opda.android.clearmaster.adapter;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.concurrent.CountDownLatch;

import android.content.Context;
import android.content.pm.IPackageStatsObserver;
import android.content.pm.PackageManager;
import android.content.pm.PackageStats;
import android.content.res.Resources.NotFoundException;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;
import android.os.RemoteException;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import cn.com.opda.android.clearmaster.R;
import cn.com.opda.android.clearmaster.custom.IOSProgressDialog;
import cn.com.opda.android.clearmaster.model.AppItem;
import cn.com.opda.android.clearmaster.utils.AppManagerUtils;
import cn.com.opda.android.clearmaster.utils.FormatUtils;
import cn.com.opda.android.clearmaster.utils.Terminal;

public class SoftwareMoveAdapter extends BaseAdapter {
	private ArrayList<AppItem> allAppItems;
	private ArrayList<AppItem> internalApps;
	private ArrayList<AppItem> storageApps;
	private LayoutInflater mLayoutInflater;
	private Context mContext;
	private long appSize;
	private Drawable defaultIcon;
	private PackageManager pm;
	private boolean showToast;

	public SoftwareMoveAdapter(Context mContext, ArrayList<AppItem> allAppItems, ArrayList<AppItem> internalApps, ArrayList<AppItem> storageApps) {
		this.allAppItems = allAppItems;
		this.internalApps = internalApps;
		this.storageApps = storageApps;
		this.mContext = mContext;
		mLayoutInflater = LayoutInflater.from(mContext);
		pm = mContext.getPackageManager();
		defaultIcon = mContext.getResources().getDrawable(android.R.drawable.sym_def_app_icon);
	}

	@Override
	public int getCount() {
		return allAppItems.size();
	}

	@Override
	public Object getItem(int position) {
		return allAppItems.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		final Holder mHolder;
		if (convertView == null) {
			convertView = mLayoutInflater.inflate(R.layout.listview_app_move_item, null);
			mHolder = new Holder();
			mHolder.app_move_item_name_textview = (TextView) convertView.findViewById(R.id.app_move_item_name_textview);
			mHolder.app_move_item_size_textview = (TextView) convertView.findViewById(R.id.app_move_item_size_textview);
			mHolder.app_move_item_button = (Button) convertView.findViewById(R.id.app_move_item_button);
			mHolder.app_move_item_icon_imageview = (ImageView) convertView.findViewById(R.id.app_move_item_icon_imageview);
			mHolder.app_move_item_layout = (LinearLayout) convertView.findViewById(R.id.app_move_item_layout);
			mHolder.app_move_group_textview = (TextView) convertView.findViewById(R.id.app_move_group_textview);
			mHolder.app_move_group_layout = (LinearLayout) convertView.findViewById(R.id.app_move_group_layout);
			mHolder.listview_divider = convertView.findViewById(R.id.listview_divider);
			convertView.setTag(mHolder);
		} else {
			mHolder = (Holder) convertView.getTag();
			if (mHolder.imageLoader != null) {
				mHolder.imageLoader.cancel(true);
			}
		}

		final AppItem mAppItem = allAppItems.get(position);

		// 第一项和前后不同的项需要显示标题，否则隐藏
		if (position == 0) {
			mHolder.app_move_item_layout.setVisibility(View.GONE);
			mHolder.app_move_group_layout.setVisibility(View.VISIBLE);
		} else if (position < getCount() && !mAppItem.getGroupName().equals(allAppItems.get(position - 1).getGroupName())) {
			mHolder.app_move_item_layout.setVisibility(View.GONE);
			mHolder.app_move_group_layout.setVisibility(View.VISIBLE);
		} else {
			mHolder.app_move_item_layout.setVisibility(View.VISIBLE);
			mHolder.app_move_group_layout.setVisibility(View.GONE);
		}

		if (position < (getCount() - 1) && !mAppItem.getGroupName().equals(allAppItems.get(position + 1).getGroupName())) {
			mHolder.listview_divider.setVisibility(View.GONE);
		} else {
			mHolder.listview_divider.setVisibility(View.VISIBLE);
		}

		mHolder.app_move_group_textview.setText(mAppItem.getGroupName());

		mHolder.app_move_item_name_textview.setText(mAppItem.getAppName());
		if (mHolder.app_move_item_layout.getVisibility() == View.VISIBLE) {

			if (mAppItem.getAppIcon() == null || mAppItem.getCodeSize() == 0) {
				mHolder.app_move_item_icon_imageview.setImageDrawable(defaultIcon);
				mHolder.app_move_item_size_textview.setText(FormatUtils.formatBytesInByte(0));
				mHolder.imageLoader = new AsyncTask<Holder, Void, Drawable>() {
					private Holder holder;
					private long codeSize;

					@Override
					protected Drawable doInBackground(Holder... params) {
						holder = params[0];

						final CountDownLatch countDownLatch = new CountDownLatch(1);
						try {
							PackageManager pm = mContext.getPackageManager();
							Method getPackageSizeInfo = pm.getClass().getMethod("getPackageSizeInfo", String.class, IPackageStatsObserver.class);
							getPackageSizeInfo.invoke(pm, mAppItem.getAppPackage(), new IPackageStatsObserver.Stub() {
								public void onGetStatsCompleted(PackageStats pStats, boolean succeeded) throws RemoteException {
									codeSize = pStats.codeSize;
									countDownLatch.countDown();
								}
							});
							countDownLatch.await();
						} catch (SecurityException e) {
							e.printStackTrace();
						} catch (IllegalArgumentException e) {
							e.printStackTrace();
						} catch (NoSuchMethodException e) {
							e.printStackTrace();
						} catch (IllegalAccessException e) {
							e.printStackTrace();
						} catch (InvocationTargetException e) {
							e.printStackTrace();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}

						if (mAppItem.getApplicationInfo() != null) {
							Drawable drawable = null;
							try {
								drawable = mAppItem.getApplicationInfo().loadIcon(pm);
							} catch (NotFoundException e) {
								e.printStackTrace();
							}
							return drawable;
						} else {
							return null;
						}

					}

					@Override
					protected void onPostExecute(Drawable result) {
						if (result != null) {
							mAppItem.setAppIcon(result);
							mAppItem.setCodeSize(codeSize);
							holder.app_move_item_icon_imageview.setImageDrawable(result);
							holder.app_move_item_size_textview.setText(FormatUtils.formatBytesInByte(codeSize));
						}
					}
				}.execute(mHolder);
			} else {
				mHolder.app_move_item_size_textview.setText(FormatUtils.formatBytesInByte(mAppItem.getCodeSize()));
				mHolder.app_move_item_icon_imageview.setImageDrawable(mAppItem.getAppIcon());
			}
		}
		if (mAppItem.getLocation() == AppItem.INSTALL_INTERNAL) {
			mHolder.app_move_item_button.setText("移至内存卡");
		} else {
			mHolder.app_move_item_button.setText("移至手机");
		}

		mHolder.app_move_item_button.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if(Terminal.isRoot(mContext)){
					new MoveAppThread(mAppItem).start();
				}else{
					AppManagerUtils.openInstalledDetail(mContext, mAppItem.getAppPackage());
					if(!showToast){
						showToast = true;
						if(mAppItem.getLocation()==AppItem.INSTALL_INTERNAL){
							Toast.makeText(mContext, "点击移至内存卡", Toast.LENGTH_LONG).show();
						}else{
							Toast.makeText(mContext, "点击移至手机内存", Toast.LENGTH_LONG).show();
						}
					}
				}

			}
		});
		return convertView;
	}

	class MoveAppThread extends Thread {
		private AppItem appItem;
		private IOSProgressDialog iosProgressDialog;

		public MoveAppThread(AppItem appItem) {
			this.appItem = appItem;
			iosProgressDialog = new IOSProgressDialog(mContext, "搬家中...");
			iosProgressDialog.setCancelable(false);
			iosProgressDialog.setCanceledOnTouchOutside(false);
			iosProgressDialog.show();
		}

		@Override
		public void run() {
			super.run();
			AppManagerUtils.movePackage(mContext, appItem);
			getAppSize(appItem);
			handler.sendEmptyMessage(1);
		}

		Handler handler = new Handler() {

			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				switch (msg.what) {
				case 1:
					if (appItem.getLocation() == AppItem.INSTALL_INTERNAL) {
						internalApps.remove(appItem);
						appItem.setLocation(AppItem.INSTALL_STORAGE);
					} else {
						storageApps.remove(appItem);
						appItem.setLocation(AppItem.INSTALL_INTERNAL);
					}
					appItem.setCodeSize(appSize);
					if (appItem.getLocation() == AppItem.INSTALL_INTERNAL) {
						appItem.setGroupName("手机存储");
						internalApps.add(appItem);
					} else {
						appItem.setGroupName("内存卡存储");
						storageApps.add(appItem);
					}
					allAppItems.clear();
					if (internalApps.size() > 0) {
						AppItem groupItem = new AppItem();
						groupItem.setGroupName("手机存储");
						allAppItems.add(groupItem);
						allAppItems.addAll(internalApps);
					}
					if (storageApps.size() > 0) {
						AppItem groupItem = new AppItem();
						groupItem.setGroupName("内存卡存储");
						allAppItems.add(groupItem);
						allAppItems.addAll(storageApps);
					}
					notifyDataSetChanged();
					iosProgressDialog.dismiss();
					Toast.makeText(mContext, "搬家成功", Toast.LENGTH_SHORT).show();
					break;

				default:
					break;
				}
			}

		};

	}

	private void getAppSize(final AppItem appItem) {
		appSize = 0;
		final CountDownLatch countDownLatch = new CountDownLatch(1);
		try {
			PackageManager pm = mContext.getPackageManager();
			Method getPackageSizeInfo = pm.getClass().getMethod("getPackageSizeInfo", String.class, IPackageStatsObserver.class);
			getPackageSizeInfo.invoke(pm, appItem.getAppPackage(), new IPackageStatsObserver.Stub() {
				public void onGetStatsCompleted(PackageStats pStats, boolean succeeded) throws RemoteException {
					appSize = pStats.codeSize;
					countDownLatch.countDown();
				}
			});
			countDownLatch.await();
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	private class Holder {
		private ImageView app_move_item_icon_imageview;
		private TextView app_move_item_name_textview;
		private TextView app_move_item_size_textview;
		private Button app_move_item_button;
		private TextView app_move_group_textview;
		private LinearLayout app_move_item_layout;
		private LinearLayout app_move_group_layout;
		private View listview_divider;
		AsyncTask<Holder, Void, Drawable> imageLoader;
	}

}
