package cn.com.opda.android.clearmaster.adapter;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import cn.com.opda.android.clearmaster.R;
import cn.com.opda.android.clearmaster.impl.CheckedListener;
import cn.com.opda.android.clearmaster.impl.SelectListener;
import cn.com.opda.android.clearmaster.model.AppItem;
import cn.com.opda.android.clearmaster.model.GroupItem;
import cn.com.opda.android.clearmaster.utils.FormatUtils;

public class Adapter4ApkClear extends BaseExpandableListAdapter {
	private ArrayList<GroupItem> groupArray;// 组列表
	private ArrayList<ArrayList<AppItem>> childArray;// 子列表
	private Context mContext;
	private LayoutInflater mLayoutInflater;
	private SelectListener selectListener;
	private CheckedListener checkedListener;

	public Adapter4ApkClear(Context mContext, ArrayList<GroupItem> groupArray, ArrayList<ArrayList<AppItem>> childArray) {
		this.groupArray = groupArray;
		this.childArray = childArray;
		this.mContext = mContext;
		this.mLayoutInflater = LayoutInflater.from(mContext);
	}
	public void setCheckListener(CheckedListener checkedListener) {
		this.checkedListener = checkedListener;
	}

	public void setSelectListener(SelectListener selectListener) {
		this.selectListener = selectListener;
	}

	@Override
	public int getGroupCount() {
		return groupArray.size();
	}

	@Override
	public int getChildrenCount(int groupPosition) {
		return childArray.get(groupPosition).size();
	}

	@Override
	public Object getGroup(int groupPosition) {
		return groupArray.get(groupPosition);
	}

	@Override
	public Object getChild(int groupPosition, int childPosition) {
		return childArray.get(groupPosition).get(childPosition);
	}

	@Override
	public long getGroupId(int groupPosition) {
		return groupPosition;
	}

	@Override
	public long getChildId(int groupPosition, int childPosition) {
		return childPosition;
	}

	@Override
	public boolean hasStableIds() {
		return false;
	}

	public void updateSelectApkSize() {
		long totalSize = 0;
		boolean allCheck = true;
		for (ArrayList<AppItem> appItems : childArray) {
			if (appItems != null && appItems.size() > 0) {
				for (AppItem appItem : appItems) {
					if (appItem != null && appItem.isChecked()) {
						totalSize += appItem.getCacheSize();
					} else {
						allCheck = false;
					}
				}
			}
		}
		selectListener.selectSize(totalSize);
		if (allCheck) {
			checkedListener.allChecked(0);
		} else {
			checkedListener.someChecked(0);
		}
	}

	public ArrayList<AppItem> getSelectApkList() {
		ArrayList<AppItem> appItems = new ArrayList<AppItem>();
		for (int i = 0; i < groupArray.size(); i++) {
			GroupItem groupItem = groupArray.get(i);
			if (groupItem.isChecked()) {
				appItems.addAll(childArray.get(i));
			} else {
				for (AppItem appItem : childArray.get(i)) {
					if (appItem.isChecked()) {
						appItems.add(appItem);
					}
				}
			}
		}
		return appItems;
	}

	public void remove(int groupPosition, int childPosition) {
		childArray.get(groupPosition).remove(childPosition);
		groupArray.get(groupPosition).setCount(childArray.get(groupPosition).size());
		notifyDataSetChanged();

	}
	public void setAllChecked(boolean checked) {
		long total = 0;
		for (int i = 0; i < groupArray.size(); i++) {
			GroupItem groupItem = groupArray.get(i);
			groupItem.setChecked(checked);
			ArrayList<AppItem> appItems = childArray.get(i);
			for (AppItem appItem : appItems) {
				appItem.setChecked(checked);
				total += appItem.getCacheSize();
			}
		}
		notifyDataSetChanged();
		if (checked) {
			selectListener.selectSize(total);
		} else {
			selectListener.selectSize(0);
		}
	}

	@Override
	public View getGroupView(final int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {

		final GroupHolder mHolder;
		if (convertView == null) {
			convertView = mLayoutInflater.inflate(R.layout.expandlistview_group_item_layout, null);
			mHolder = new GroupHolder();
			mHolder.clear_trash_group_title_textview = (TextView) convertView.findViewById(R.id.clear_trash_group_title_textview);
			mHolder.clear_trash_group_count_textview = (TextView) convertView.findViewById(R.id.clear_trash_group_count_textview);
			mHolder.clear_trash_group_icon_imageview = (ImageView) convertView.findViewById(R.id.clear_trash_group_icon_imageview);
			mHolder.clear_trash_group_checked_imageview = (CheckBox) convertView.findViewById(R.id.clear_trash_group_checked_imageview);
			convertView.setTag(mHolder);
		} else {
			mHolder = (GroupHolder) convertView.getTag();
		}
		final GroupItem groupItem = groupArray.get(groupPosition);
		mHolder.clear_trash_group_title_textview.setText(groupItem.getTitle());

		mHolder.clear_trash_group_count_textview.setVisibility(View.VISIBLE);
		mHolder.clear_trash_group_count_textview.setText(groupItem.getCount() + "");
		mHolder.clear_trash_group_icon_imageview.setImageDrawable(groupItem.getIcon());
		mHolder.clear_trash_group_checked_imageview.setVisibility(View.VISIBLE);
		mHolder.clear_trash_group_checked_imageview.setChecked(groupItem.isChecked());
		mHolder.clear_trash_group_checked_imageview.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				groupItem.setChecked(!groupItem.isChecked());
				ArrayList<AppItem> appItems = childArray.get(groupPosition);
				for (AppItem appItem : appItems) {
					appItem.setChecked(groupItem.isChecked());
				}
				updateSelectApkSize();
				notifyDataSetChanged();
			}
		});
		return convertView;

	}

	@Override
	public View getChildView(final int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
		final Holder mHolder;
		if (convertView == null) {
			convertView = mLayoutInflater.inflate(R.layout.expandlistview_child_item_layout, null);
			mHolder = new Holder();
			mHolder.clear_trash_child_version_textview = (TextView) convertView.findViewById(R.id.clear_trash_child_version_textview);
			mHolder.clear_trash_child_name_textview = (TextView) convertView.findViewById(R.id.clear_trash_child_name_textview);
			mHolder.clear_trash_child_cachesize_textview = (TextView) convertView.findViewById(R.id.clear_trash_child_cachesize_textview);
			mHolder.clear_trash_child_icon_imageview = (ImageView) convertView.findViewById(R.id.clear_trash_child_icon_imageview);
			mHolder.clear_trash_child_checked_imageview = (CheckBox) convertView.findViewById(R.id.clear_trash_child_checked_imageview);
			convertView.setTag(mHolder);
		} else {
			mHolder = (Holder) convertView.getTag();
		}

		final AppItem mAppItem = childArray.get(groupPosition).get(childPosition);
		mHolder.clear_trash_child_name_textview.setText(mAppItem.getAppName());
		mHolder.clear_trash_child_version_textview.setVisibility(View.GONE);

		mHolder.clear_trash_child_cachesize_textview.setText(mContext.getString(R.string.memory_size_title,
				FormatUtils.formatBytesInByte(mAppItem.getCodeSize())));
		mHolder.clear_trash_child_checked_imageview.setVisibility(View.VISIBLE);
		mHolder.clear_trash_child_checked_imageview.setChecked(mAppItem.isChecked());
		mHolder.clear_trash_child_icon_imageview.setImageDrawable(mAppItem.getAppIcon());
		mHolder.clear_trash_child_icon_imageview.setVisibility(View.VISIBLE);
		mHolder.clear_trash_child_checked_imageview.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				mAppItem.setChecked(!mAppItem.isChecked());

				ArrayList<AppItem> appItems = childArray.get(groupPosition);
				GroupItem groupItem = groupArray.get(groupPosition);
				boolean b = true;
				for (AppItem appItem : appItems) {
					if (!appItem.isChecked()) {
						b = false;
						break;
					}
				}
				groupItem.setChecked(b);
				updateSelectApkSize();
				notifyDataSetChanged();
			}
		});
		return convertView;

	}

	@Override
	public boolean isChildSelectable(int groupPosition, int childPosition) {
		return true;
	}

	private class Holder {
		private TextView clear_trash_child_version_textview;
		private TextView clear_trash_child_name_textview;
		private TextView clear_trash_child_cachesize_textview;
		private ImageView clear_trash_child_icon_imageview;
		private CheckBox clear_trash_child_checked_imageview;
	}

	private class GroupHolder {
		private TextView clear_trash_group_title_textview;
		private TextView clear_trash_group_count_textview;
		private ImageView clear_trash_group_icon_imageview;
		private CheckBox clear_trash_group_checked_imageview;
	}

}
