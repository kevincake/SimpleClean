package cn.com.opda.android.clearmaster.adapter;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import cn.com.opda.android.clearmaster.R;
import cn.com.opda.android.clearmaster.impl.CheckedListener;
import cn.com.opda.android.clearmaster.impl.SelectListener;
import cn.com.opda.android.clearmaster.model.BigFileGroup;
import cn.com.opda.android.clearmaster.model.BigFileItem;
import cn.com.opda.android.clearmaster.utils.FormatUtils;

/**
 * 
 * 大文件清理适配器
 * 
 * @author 庄宏岩
 * 
 */
public class Adapter4BigFileGroup extends BaseAdapter {
	private ArrayList<BigFileGroup> mClearItems;
	private LayoutInflater mLayoutInflater;
	private SelectListener selectListener;
	private Context mContext;
	private CheckedListener checkedListener;

	public Adapter4BigFileGroup(Context mContext, ArrayList<BigFileGroup> mClearItems) {
		this.mClearItems = mClearItems;
		this.mContext = mContext;
		mLayoutInflater = LayoutInflater.from(mContext);
	}
	public void setCheckListener(CheckedListener checkedListener) {
		this.checkedListener = checkedListener;
	}

	public void setSelectListener(SelectListener selectListener) {
		this.selectListener = selectListener;
	}

	@Override
	public int getCount() {
		return mClearItems.size();
	}

	@Override
	public Object getItem(int position) {
		return mClearItems.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	public void setAllChecked(boolean isChecked) {
		for (BigFileGroup clearItem : mClearItems) {
			clearItem.setChecked(isChecked);
			for (BigFileItem bigFileItem : clearItem.getBigFileItems()) {
				bigFileItem.setChecked(isChecked);
			}
		}
		notifyDataSetChanged();
	}

	/**
	 * 获取选中的条目
	 * 
	 * @return
	 */
	public ArrayList<BigFileItem> getSelecteList() {
		ArrayList<BigFileItem> clearItems = new ArrayList<BigFileItem>();
		for (BigFileGroup clearItem : mClearItems) {
			for (BigFileItem bigFileItem : clearItem.getBigFileItems()) {
				if (bigFileItem.isChecked()) {
					clearItems.add(bigFileItem);
				}
			}
		}
		return clearItems;
	}

	public void updateSelectbigfileSize() {
		long size = 0;
		boolean allCheck = true;
		for (BigFileGroup clearItem : mClearItems) {
			for (BigFileItem bigFileItem : clearItem.getBigFileItems()) {
				if (bigFileItem.isChecked()) {
					size += bigFileItem.getSize();
				}else{
					allCheck = false;
				}
			}
		}
		selectListener.selectSize(size);

		if (checkedListener != null) {
			if (allCheck) {
				checkedListener.allChecked(0);
			} else {
				checkedListener.someChecked(0);
			}
		}
	}

	public ArrayList<BigFileGroup> getList() {
		return mClearItems;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		final Holder mHolder;
		if (convertView == null) {
			convertView = mLayoutInflater.inflate(R.layout.listview_bigfile_clear_group, null);
			mHolder = new Holder();
			mHolder.bigfile_group_name_textview = (TextView) convertView.findViewById(R.id.bigfile_group_name_textview);
			mHolder.bigfile_group_size_textview = (TextView) convertView.findViewById(R.id.bigfile_group_size_textview);
			mHolder.bigfile_group_checked_imageview = (CheckBox) convertView.findViewById(R.id.bigfile_group_checked_imageview);
			mHolder.bigfile_group_icon_imageview = (ImageView) convertView.findViewById(R.id.bigfile_group_icon_imageview);
			convertView.setTag(mHolder);
		} else {
			mHolder = (Holder) convertView.getTag();
		}

		final BigFileGroup clearItem = mClearItems.get(position);
		mHolder.bigfile_group_icon_imageview.setImageDrawable(clearItem.getTypeIcon());
		mHolder.bigfile_group_name_textview.setText(clearItem.getTypeName());
		mHolder.bigfile_group_size_textview.setText(FormatUtils.formatBytesInByte(clearItem.getSize()));
		mHolder.bigfile_group_checked_imageview.setChecked(clearItem.isChecked());
		mHolder.bigfile_group_checked_imageview.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				clearItem.setChecked(!clearItem.isChecked());
				for (BigFileItem bigFileItem : clearItem.getBigFileItems()) {
					bigFileItem.setChecked(clearItem.isChecked());
				}
				updateSelectbigfileSize();
			}
		});
		return convertView;
	}

	private class Holder {
		private TextView bigfile_group_name_textview;
		private TextView bigfile_group_size_textview;
		private ImageView bigfile_group_icon_imageview;
		private CheckBox bigfile_group_checked_imageview;
	}

	public void remove(int position) {
		mClearItems.remove(position);
		notifyDataSetChanged();
	}

	public void updateList(ArrayList<BigFileItem> bigFileItems, int position) {
		if (bigFileItems.size() == 0) {
			mClearItems.remove(position);
		} else {
			mClearItems.get(position).setBigFileItems(bigFileItems);
			boolean groupCheck = true;
			for (BigFileItem bigFileItem : bigFileItems) {
				if (!bigFileItem.isChecked()) {
					groupCheck = false;
					break;
				}
			}
			mClearItems.get(position).setChecked(groupCheck);
		}
		notifyDataSetChanged();
		updateSelectbigfileSize();
	}
}
