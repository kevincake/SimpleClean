package cn.com.opda.android.clearmaster.adapter;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.content.res.Resources.NotFoundException;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import cn.com.opda.android.clearmaster.R;
import cn.com.opda.android.clearmaster.model.AppItem;
import cn.com.opda.android.clearmaster.utils.FormatUtils;

public class SoftwareInstallAdapter extends BaseAdapter {
	private List<AppItem> mAppItemList;
	private Context mContext;
	private AppItem installAppItem;
	private Drawable defaultIcon;

	public SoftwareInstallAdapter(Context context, List<AppItem> mAppItemList) {
		this.mAppItemList = mAppItemList;
		this.mContext = context;
		defaultIcon = mContext.getResources().getDrawable(android.R.drawable.sym_def_app_icon);
	}

	@Override
	public int getCount() {
		return mAppItemList.size();
	}

	@Override
	public Object getItem(int position) {
		return mAppItemList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	public AppItem getInstallAppModel() {
		return installAppItem;
	}

	public void remove(AppItem AppItem) {
		mAppItemList.remove(AppItem);
		notifyDataSetChanged();
	}

	public ArrayList<AppItem> getSelectList() {
		ArrayList<AppItem> appItems = new ArrayList<AppItem>();
		for (AppItem appItem : mAppItemList) {
			if (appItem.isChecked()) {
				appItems.add(appItem);
			}
		}
		return appItems;
	}

	public void updateItem(AppItem installApp, int installPosition) {
		mAppItemList.set(installPosition, installApp);
		notifyDataSetChanged();
	}

	public List<AppItem> getList() {
		return mAppItemList;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		final Holder mHolder;
		if (convertView == null) {
			LayoutInflater inflater = LayoutInflater.from(mContext);
			convertView = inflater.inflate(R.layout.listview_app_install_item_layout, parent, false);
			mHolder = new Holder();
			mHolder.app_install_item_appname_textview = (TextView) convertView.findViewById(R.id.app_install_item_appname_textview);
			mHolder.app_install_item_appversion_textview = (TextView) convertView.findViewById(R.id.app_install_item_appversion_textview);
			mHolder.app_install_item_size_textview = (TextView) convertView.findViewById(R.id.app_install_item_size_textview);
			mHolder.app_install_item_icon_imageview = (ImageView) convertView.findViewById(R.id.app_install_item_icon_imageview);
			mHolder.app_install_item_checked_imageview = (CheckBox) convertView.findViewById(R.id.app_install_item_checked_imageview);
			convertView.setTag(mHolder);
		} else {
			mHolder = (Holder) convertView.getTag();
			if (mHolder.imageLoader != null) {
				mHolder.imageLoader.cancel(true);
			}
		}
		final AppItem mAppItem = mAppItemList.get(position);
		mHolder.app_install_item_appname_textview.setText(mAppItem.getAppName());
		mHolder.app_install_item_appversion_textview.setText(mAppItem.getAppVersion());
		mHolder.app_install_item_size_textview.setText(FormatUtils.formatBytesInByte(mAppItem.getCodeSize()));
		mHolder.app_install_item_checked_imageview.setChecked(mAppItem.isChecked());
		mHolder.app_install_item_checked_imageview.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				mAppItem.setChecked(!mAppItem.isChecked());
				mHolder.app_install_item_checked_imageview.setChecked(mAppItem.isChecked());
			}
		});

		if (mAppItem.getAppIcon() == null) {
			mHolder.app_install_item_icon_imageview.setImageDrawable(defaultIcon);
			mHolder.imageLoader = new AsyncTask<Holder, Void, Drawable>() {
				private Holder holder;

				@Override
				protected Drawable doInBackground(Holder... params) {
					holder = params[0];
					if (mAppItem.getApplicationInfo() != null) {
						Drawable drawable = null;
						try {
							drawable = mAppItem.getResources().getDrawable(mAppItem.getApplicationInfo().icon);
						} catch (NotFoundException e) {
							e.printStackTrace();
						}
						return drawable;
					} else {
						return null;
					}

				}

				@Override
				protected void onPostExecute(Drawable result) {
					if (result != null) {
						mAppItem.setAppIcon(result);
						holder.app_install_item_icon_imageview.setImageDrawable(result);
					}
				}
			}.execute(mHolder);
		} else {
			mHolder.app_install_item_icon_imageview.setImageDrawable(mAppItem.getAppIcon());
		}
		return convertView;
	}

	class Holder {

		private ImageView app_install_item_icon_imageview; // apk头像
		private CheckBox app_install_item_checked_imageview; // 安装按钮
		private TextView app_install_item_appname_textview; // apk名字
		private TextView app_install_item_appversion_textview; // 版本信息
		private TextView app_install_item_size_textview;
		AsyncTask<Holder, Void, Drawable> imageLoader;
	}

}
