package cn.com.opda.android.clearmaster;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import cn.com.opda.android.clearmaster.utils.BannerUtils;
import cn.com.opda.android.clearmaster.utils.DensityUtil;

import com.umeng.analytics.MobclickAgent;

public class SmsPrivacyManager extends BaseActivity implements OnClickListener {
	private ViewPager mPager;// 页卡内容
	private List<View> listViews; // Tab页面列表
	private ImageView cursor;// 动画图片
	private int offset = 0;// 动画图片偏移量
	private int currIndex = 0;// 当前页卡编号
	private int screenW;
	private TextView viewpager_tab1, viewpager_tab2;
	private Context mContext;
	private SmsAllActivity smsAllActivity;
	private SmsHideActivity smsHideActivity;
	private int updatePage = -1;
	private TextView sms_count_textview;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mContext = SmsPrivacyManager.this;
		setContentView(R.layout.activity_sms_privacy_manager);
		BannerUtils.setTitle(this, "短信管理");
		BannerUtils.initBackButton(this);
		initTextView();
		initImageView();
		initViewPager();
	}

	/**
	 * 初始化头标
	 */
	private void initTextView() {
		viewpager_tab1 = (TextView) findViewById(R.id.viewpager_tab1);
		viewpager_tab2 = (TextView) findViewById(R.id.viewpager_tab2);

		viewpager_tab1.setOnClickListener(this);
		viewpager_tab2.setOnClickListener(this);
		
		sms_count_textview = (TextView) findViewById(R.id.sms_count);
	}

	/**
	 * 初始化ViewPager
	 */
	private void initViewPager() {
		mPager = (ViewPager) findViewById(R.id.vPager);

		listViews = new ArrayList<View>();

		smsAllActivity = new SmsAllActivity(mContext, R.layout.sms_all_listview, this);
		smsAllActivity.initData();
		smsHideActivity = new SmsHideActivity(mContext, R.layout.sms_hide_listview, this);

		listViews.add(smsAllActivity.getView());
		listViews.add(smsHideActivity.getView());
		mPager.setAdapter(new MyPagerAdapter(listViews));
		mPager.setCurrentItem(0);
		mPager.setOnPageChangeListener(new MyOnPageChangeListener());

	}

	/**
	 * 初始化动画
	 */
	@SuppressWarnings("deprecation")
	private void initImageView() {
		cursor = (ImageView) findViewById(R.id.cursor);
		int width = getWindowManager().getDefaultDisplay().getWidth() / 2;
		cursor.setLayoutParams(new LinearLayout.LayoutParams(width, DensityUtil.dip2px(this, 2)));
	}

	/**
	 * ViewPager适配器
	 */
	public class MyPagerAdapter extends PagerAdapter {
		public List<View> mListViews;

		public MyPagerAdapter(List<View> mListViews) {
			this.mListViews = mListViews;
		}

		@Override
		public void destroyItem(View view, int position, Object object) {
			((ViewPager) view).removeView(mListViews.get(position));
		}

		@Override
		public void finishUpdate(View view) {

		}

		@Override
		public int getCount() {
			return mListViews.size();
		}

		@Override
		public Object instantiateItem(View view, int position) {
			((ViewPager) view).addView(mListViews.get(position), 0);
			return mListViews.get(position);
		}

		@Override
		public boolean isViewFromObject(View view, Object obj) {
			return view == (obj);
		}

		@Override
		public void restoreState(Parcelable view, ClassLoader classLoader) {
		}

		@Override
		public Parcelable saveState() {
			return null;
		}

		@Override
		public void startUpdate(View view) {
		}
	}

	public class MyOnPageChangeListener implements OnPageChangeListener {
		int one = offset + screenW / 2;
		int two = offset + (screenW / 2) * 2;

		@Override
		public void onPageSelected(int position) {
			currIndex = position;
			if (currIndex == 0) {
				if (updatePage == 0) {
					smsAllActivity.update();
					updatePage = -1;
				}
				smsAllActivity.initData();
			} else {
				if (updatePage == 1) {
					smsHideActivity.update();
					updatePage = -1;
				}
				smsHideActivity.initData();
			}
		}

		@Override
		public void onPageScrolled(int arg0, float arg1, int arg2) {
			int x = (int) ((arg0 + arg1) * cursor.getWidth());
			((View) cursor.getParent()).scrollTo(-x, cursor.getScrollY());
		}

		@Override
		public void onPageScrollStateChanged(int position) {

		}
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.viewpager_tab1:
			mPager.setCurrentItem(0);
			break;
		case R.id.viewpager_tab2:
			mPager.setCurrentItem(1);
			break;
		default:
			break;
		}
	}

	public void updatePage(int i) {
		updatePage = i;
	}
	
	public void updateSmsCount(int count){
		sms_count_textview.setText("" + count);
	}

	@Override
	protected void onResume() {
		super.onResume();
		MobclickAgent.onResume(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		MobclickAgent.onPause(this);
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		smsAllActivity.onDestroy();
		smsHideActivity.onDestroy();
	}

}
