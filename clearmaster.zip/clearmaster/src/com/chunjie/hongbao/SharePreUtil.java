package com.chunjie.hongbao;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

public class SharePreUtil {

	
	public static String yingyongbaoPackname = "com.tencent.android.qqdownloader";

	public static String tenxunshouguanPackname = "com.tencent.qqpimsecure";

	
	public static void setURL(Context context,String path){


		SharedPreferences sp = PreferenceManager
				.getDefaultSharedPreferences(context);
		sp.edit().putString("do_download_url", path)
		.commit();
	}
	public static String getURL(Context context){

		SharedPreferences sp = PreferenceManager
				.getDefaultSharedPreferences(context);

		return sp.getString("do_download_url", "");
	}
	
	
	public static void setNeedPackage(Context context,String packname){


		SharedPreferences sp = PreferenceManager
				.getDefaultSharedPreferences(context);
		sp.edit().putString("need_packname", packname)
		.commit();
	}
	public static String getNeedPackage(Context context){

		SharedPreferences sp = PreferenceManager
				.getDefaultSharedPreferences(context);

		return sp.getString("need_packname", "");
	}

	
	
	public static void setDsize(Context context,long size){


		SharedPreferences sp = PreferenceManager
				.getDefaultSharedPreferences(context);
		sp.edit().putLong("do_download_Dsize", size)
		.commit();
	}
	public static long getDsize(Context context){

		SharedPreferences sp = PreferenceManager
				.getDefaultSharedPreferences(context);

		return sp.getLong("do_download_Dsize",0);
	}
	
	
	
	

}
