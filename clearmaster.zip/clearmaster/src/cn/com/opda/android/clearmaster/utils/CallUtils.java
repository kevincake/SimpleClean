package cn.com.opda.android.clearmaster.utils;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import android.content.Context;
import android.provider.CallLog;
import cn.com.opda.android.clearmaster.model.PhoneLog;

public class CallUtils {

	private static Map<String, String> serverPhoneMap;

	// 根据电话号码查找联系人姓名
	public static final synchronized String findNameByPhoneNumORId(Context context, String phoneNum) {

		if (phoneNum == null)
			return null;
		return getNamebyPhoneNum(context, phoneNum);
	}

	/**
	 * 判断是否是服务号码
	 * 
	 * @param context
	 * @param phoneNum
	 * @return
	 */
	public static final String isServerPhone(Context context, String phoneNum) {
		if (phoneNum == null)
			return null;
		Map<String, String> temp = getAllServerPhone(context);
		String name = temp.get(phoneNum);
		if (name != null) {
			return name;
		}
		return null;
	}

	/**
	 * 得到所有的服务号码列表
	 * 
	 * @param context
	 * @return
	 */
	private static final Map<String, String> getAllServerPhone(Context context) {
		if (serverPhoneMap == null) {
			serverPhoneMap = new HashMap<String, String>();
		} else {
			return serverPhoneMap;
		}
		serverPhoneMap.put("95188", "支付宝官方客服");
		serverPhoneMap.put("12306", "铁路客户服务中心");

		serverPhoneMap.put("10086", "中国移动客服");

		serverPhoneMap.put("1008611", "中国移动话费查询");

		serverPhoneMap.put("13800138000", "中国移动话费充值热线");

		serverPhoneMap.put("12580", "中国移动综合信息服务");

		serverPhoneMap.put("12585", "中国移动出行服务热线");

		serverPhoneMap.put("10088", "中国移动VIP客服热线");

		serverPhoneMap.put("13800100186", "中国移动国际客服热线");

		serverPhoneMap.put("100861", "中国移动业务查询");

		serverPhoneMap.put("12530", "中国移动彩铃服务");

		serverPhoneMap.put("10010", "中国联通客服");

		serverPhoneMap.put("10001", "中国电信客服");

		serverPhoneMap.put("10011", "中国联通充值专线");

		serverPhoneMap.put("1001011", "中国联通话费查询");

		serverPhoneMap.put("10018", "中国联通VIP客服");

		serverPhoneMap.put("10000", "中国电信客服");

		serverPhoneMap.put("11888", "中国电信充值专线");

		// 快递物流

		serverPhoneMap.put("4008111111", "顺丰速递");

		serverPhoneMap.put("11183", "EMS速递");

		serverPhoneMap.put("4008895543", "申通快递");

		serverPhoneMap.put("95554", "圆通快递");

		serverPhoneMap.put("4008216789", "韵达快递");

		serverPhoneMap.put("4008270270", "中通快递");

		serverPhoneMap.put("4006789000", "宅急送");

		serverPhoneMap.put("4009565656", "百世汇通");

		serverPhoneMap.put("4001888888", "天天快递");

		serverPhoneMap.put("4001000001", "全峰快递");

		serverPhoneMap.put("4000106660", "如风达快递");

		serverPhoneMap.put("4006501118", "中铁物流");

		// 外卖送餐

		serverPhoneMap.put("4008517517", "麦当劳麦乐送");

		serverPhoneMap.put("4008823823", "肯德基宅急送");

		serverPhoneMap.put("4008123123", "必胜宅急送");

		serverPhoneMap.put("4006309907", "德克士");

		serverPhoneMap.put("4007787878", "巴贝拉");

		serverPhoneMap.put("4006927927", "真功夫");

		serverPhoneMap.put("4008197197", "吉野家");

		serverPhoneMap.put("4008107272", "棒约翰");

		serverPhoneMap.put("4000979797", "永和大王");

		serverPhoneMap.put("4008800400", "丽华快餐");

		serverPhoneMap.put("4008107107", "海底捞火锅");

		serverPhoneMap.put("4008527527", "眉州东坡酒楼");

		serverPhoneMap.put("4009009009", "和合谷");

		serverPhoneMap.put("4001517517", "俏江南");

		serverPhoneMap.put("4006509811", "金汉斯");

		serverPhoneMap.put("4008201380", "哈根达斯");

		serverPhoneMap.put("4001170170", "味多美");

		serverPhoneMap.put("4008885917", "克莉丝汀");

		serverPhoneMap.put("4006608517", "望湘园");

		// 航空客服

		serverPhoneMap.put("95583", "中国国际航空服务热线");

		serverPhoneMap.put("4006100666", "中国国际航空会员服务中心");

		serverPhoneMap.put("95583", "中国南方航空热线");

		serverPhoneMap.put("95539", "南方航空明珠卡客服中心");

		serverPhoneMap.put("4006695539", "中国南方航空机票服务热线");

		serverPhoneMap.put("95530", "中国东方航空客服");

		serverPhoneMap.put("4008795530", "中国东方航空会员服务中心");

		serverPhoneMap.put("950718", "海南航空订票服务热线");

		serverPhoneMap.put("4008300999", "四川航空订票服务热线");

		serverPhoneMap.put("95080", "深圳航空订票服务热线");

		serverPhoneMap.put("4006096777", "山东航空订票服务热线");

		serverPhoneMap.put("95557", "厦门航空客服热线");

		serverPhoneMap.put("95524", "春秋航空服务热线");

		serverPhoneMap.put("4000668866", "奥凯航空服务热线");

		serverPhoneMap.put("4008886628", "国泰航空订票服务热线");

		serverPhoneMap.put("950710", "天津航空订票服务热线");

		serverPhoneMap.put("95071950", "祥鹏航空服务热线");

		serverPhoneMap.put("950715", "香港航空订票服务热线");

		serverPhoneMap.put("4008886998", "中华航空客服专线");

		serverPhoneMap.put("4008865889", "长荣航空订票服务热线");

		// 酒店旅行

		serverPhoneMap.put("4009333333", "艺龙旅行网");

		serverPhoneMap.put("4007777777", "同程旅游网");

		serverPhoneMap.put("10101234", "去哪儿网");

		serverPhoneMap.put("4008203333", "如家快捷酒店订房热线");

		serverPhoneMap.put("4008740087", "7天连锁酒店客服热线");

		serverPhoneMap.put("4008121121", "汉庭酒店客服热线");

		serverPhoneMap.put("4006998998", "格林豪泰酒店预定热线");

		serverPhoneMap.put("4008200999", "锦江之星服务热线");

		serverPhoneMap.put("4001840018", "速8酒店预订热线");

		serverPhoneMap.put("4008203333", "莫泰酒店预订热线");

		serverPhoneMap.put("4006001615", "宜必思酒店预定热线");

		serverPhoneMap.put("4008802802", "布丁酒店预定热线");

		serverPhoneMap.put("4008190099", "桔子酒店预定热线");

		serverPhoneMap.put("4008862255", "洲际酒店预定热线");

		serverPhoneMap.put("10105050", "开元酒店预定热线");

		serverPhoneMap.put("4008865533", "希尔顿酒店预定热线");

		serverPhoneMap.put("4009201234", "凯悦酒店预定热线");

		serverPhoneMap.put("4008844371", "万豪国际酒店预定热线");

		serverPhoneMap.put("4001487200", "四季酒店预定热线");

		// 银行

		serverPhoneMap.put("95566", "中国银行服务热线");

		serverPhoneMap.put("4006695566", "中国银行信用卡热线");

		serverPhoneMap.put("95588", "中国工商银行服务热线");

		serverPhoneMap.put("4006695588", "中国工商银行信用卡热线");

		serverPhoneMap.put("95599", "中国农业银行服务热线");

		serverPhoneMap.put("4006695599", "中国农业银行信用卡热线");

		serverPhoneMap.put("95533", "中国建设银行服务热线");

		serverPhoneMap.put("4008200588", "中国建设银行信用卡热线");

		serverPhoneMap.put("95559", "中国交通银行服务热线");

		serverPhoneMap.put("4008009888", "中国交通银行信用卡热线");

		serverPhoneMap.put("95580", "中国邮政储蓄银行客服热线");

		serverPhoneMap.put("4008895580", "中国邮政储蓄银行信用卡热线");

		serverPhoneMap.put("95555", "招商银行服务热线");

		serverPhoneMap.put("4008205555", "招商银行信用卡热线");

		serverPhoneMap.put("95558", "中信银行服务热线");

		serverPhoneMap.put("4008895558", "中信银行信用卡热线");

		serverPhoneMap.put("95568", "民生银行服务热线");

		serverPhoneMap.put("4006505568", "民生银行信用卡热线");

		serverPhoneMap.put("95595", "光大银行服务热线");

		serverPhoneMap.put("95511", "平安银行服务热线");

		serverPhoneMap.put("95508", "广发银行信用卡热线");

		serverPhoneMap.put("95561", "兴业银行服务热线");

		serverPhoneMap.put("95528", "浦发银行服务热线");

		serverPhoneMap.put("4008208788", "浦发银行信用卡热线");

		serverPhoneMap.put("95577", "华夏银行服务热线");

		serverPhoneMap.put("4008138888", "恒丰银行服务热线");

		serverPhoneMap.put("8008301880", "花旗银行服务热线");

		serverPhoneMap.put("4008211880", "花旗银行信用卡热线");

		serverPhoneMap.put("4008888083", "渣打银行服务热线");

		serverPhoneMap.put("4008826688", "汇丰银行服务热线");

		// 保险证券

		serverPhoneMap.put("95519", "中国人寿保险客服热线");

		serverPhoneMap.put("4008777777", "中国人寿保险购买热线");

		serverPhoneMap.put("95567", "新华人寿保险客服热线");

		serverPhoneMap.put("95500", "太平洋保险客服热线");

		serverPhoneMap.put("4008895518", "中国人保寿险客服热线");

		serverPhoneMap.put("95518", "中国人保财险客服热线");

		serverPhoneMap.put("4006095509", "华泰财险客服热线");

		serverPhoneMap.put("4008895569", "安邦人寿保险客服热线");

		serverPhoneMap.put("4001111111", "安邦人寿保险销售热线");

		serverPhoneMap.put("95510", "阳光保险客服热线");

		serverPhoneMap.put("95535", "生命人寿保险客服热线");

		serverPhoneMap.put("4007795581", "农银人寿保险客服热线");

		serverPhoneMap.put("10106969", "安盛天平保险客服热线");

		serverPhoneMap.put("4008205882", "北大方正人寿保险客服热线");

		serverPhoneMap.put("4008205881", "北大方正人寿保险销售热线");
		return serverPhoneMap;
	}

	public static String getNamebyPhoneNum(Context mContext, String phoneNum) {
		String name = null;
		try {
			Class<?> clazz = Class.forName("com.android.internal.telephony.CallerInfo");
			Method method = clazz.getDeclaredMethod("getCallerInfo", new Class[] { Context.class, String.class });

			Constructor<?> constructor = clazz.getConstructor(new Class[0]);
			Object object = constructor.newInstance(new Object[0]);

			Object callInfo = method.invoke(object, new Object[] { mContext, phoneNum });
			Field nameField = clazz.getDeclaredField("name");

			name = (String) nameField.get(callInfo);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return name;

		// String contactName = null;
		// ContentResolver cr = mContext.getContentResolver();
		// Cursor pCur =
		// cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null,
		// ContactsContract.CommonDataKinds.Phone.NUMBER + " = ?",
		// new String[] { phoneNum }, null);
		// if (pCur.moveToFirst()) {
		// contactName =
		// pCur.getString(pCur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
		// pCur.close();
		// }
		// return contactName;
	}

	/**
	 * 删除通话记录
	 * 
	 * @param context
	 * @param phoneLog
	 */
	public static final synchronized void deleteCallLog(Context context, PhoneLog phoneLog) {
		context.getContentResolver().delete(CallLog.Calls.CONTENT_URI, CallLog.Calls._ID + "=?", new String[] { phoneLog.getId() });
	}
}
