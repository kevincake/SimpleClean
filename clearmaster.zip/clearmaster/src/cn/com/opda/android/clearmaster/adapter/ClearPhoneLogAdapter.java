package cn.com.opda.android.clearmaster.adapter;

import java.util.ArrayList;

import android.content.Context;
import android.provider.CallLog.Calls;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import cn.com.opda.android.clearmaster.R;
import cn.com.opda.android.clearmaster.impl.CheckedListener;
import cn.com.opda.android.clearmaster.model.PhoneLog;

/**
 * 通话记录清理适配器
 * 
 * @author 庄宏岩
 * 
 */
public class ClearPhoneLogAdapter extends BaseAdapter {
	private ArrayList<PhoneLog> mCallLogs;
	private LayoutInflater mLayoutInflater;
	private CheckedListener checkedListener;
	public ClearPhoneLogAdapter(Context mContext, ArrayList<PhoneLog> mCallLogs) {
		this.mCallLogs = mCallLogs;
		mLayoutInflater = LayoutInflater.from(mContext);
	}

	@Override
	public int getCount() {
		return mCallLogs.size();
	}

	@Override
	public Object getItem(int position) {
		return mCallLogs.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	public void remove(PhoneLog phoneLog) {
		mCallLogs.remove(phoneLog);
		notifyDataSetChanged();
	}

	/**
	 * 获取选中的条目
	 * 
	 * @return
	 */
	public ArrayList<PhoneLog> getSelecteList() {
		ArrayList<PhoneLog> phoneLogs = new ArrayList<PhoneLog>();
		for (PhoneLog phoneLog : mCallLogs) {
			if (phoneLog.isChecked()) {
				phoneLogs.add(phoneLog);
			}
		}
		return phoneLogs;
	}
	

	public ArrayList<PhoneLog> getList() {
		return mCallLogs;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		final Holder mHolder;
		if (convertView == null) {
			convertView = mLayoutInflater.inflate(R.layout.listview_calllog_item, null);
			mHolder = new Holder();
			mHolder.call_item_name_textview = (TextView) convertView.findViewById(R.id.call_item_name_textview);
			mHolder.call_item_date_textview = (TextView) convertView.findViewById(R.id.call_item_date_textview);
			mHolder.call_item_type_imageview = (ImageView) convertView.findViewById(R.id.call_item_type_imageview);
			mHolder.call_item_checked_imageview = (CheckBox) convertView.findViewById(R.id.call_item_checked_imageview);
			convertView.setTag(mHolder);
		} else {
			mHolder = (Holder) convertView.getTag();
		}

		final PhoneLog callLog = mCallLogs.get(position);
		mHolder.call_item_name_textview.setText(callLog.getName());
		mHolder.call_item_date_textview.setText(callLog.getTime());

		switch (callLog.getType()) {
		case Calls.INCOMING_TYPE:
			mHolder.call_item_type_imageview.setImageResource(R.drawable.call_incoming);
			break;
		case Calls.OUTGOING_TYPE:
			mHolder.call_item_type_imageview.setImageResource(R.drawable.call_outgoing);
			break;
		case Calls.MISSED_TYPE:
			mHolder.call_item_type_imageview.setImageResource(R.drawable.call_missed);
			break;
		}

		if (callLog.isChecked()) {
			mHolder.call_item_checked_imageview.setChecked(true);
		} else {
			mHolder.call_item_checked_imageview.setChecked(false);
		}
		return convertView;
	}
	public void setAllChecked(boolean isChecked) {
		for (PhoneLog callLog : mCallLogs) {
			callLog.setChecked(isChecked);
		}
		notifyDataSetChanged();
	}
	public void setCheckedListener(CheckedListener checkedListener) {
		this.checkedListener = checkedListener;
	}
	
	public void updateChecked() {
		int checkedSize = 0;
		for (PhoneLog phoneLog : mCallLogs) {
			if (phoneLog != null && phoneLog.isChecked()) {
				checkedSize++;
			}
		}
		if (checkedListener != null) {
			if (checkedSize == 0) {
				checkedListener.nothingChecked();
			} else if (checkedSize == getCount()) {
				checkedListener.allChecked(checkedSize);
			} else {
				checkedListener.someChecked(checkedSize);
			}
		}
		
	}

	private class Holder {
		private TextView call_item_name_textview;
		private TextView call_item_date_textview;
		private ImageView call_item_type_imageview;
		private CheckBox call_item_checked_imageview;
	}

}
