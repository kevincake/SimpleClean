package cn.com.opda.android.clearmaster.service;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Vibrator;
import android.widget.Toast;
import cn.com.opda.android.clearmaster.R;
import cn.com.opda.android.clearmaster.model.ClearResult;
import cn.com.opda.android.clearmaster.utils.ClearUtils;
import cn.com.opda.android.clearmaster.utils.Constants;
import cn.com.opda.android.clearmaster.utils.FormatUtils;
import cn.com.opda.android.clearmaster.utils.ProcessManagerUtils;

/**
 * 晃晃清理的后台服务类
 * @author 庄宏岩
 *
 */
public class ShakeClearService extends Service {
	private SensorManager sm;
	private long curTime;
	private long lastTime;
	private long duration;
	private float last_x;
	private float last_y;
	private float last_z;

	private float shake;
	private long actionTime;
	private SharedPreferences sharedPreferences;
	private String freeMemorySize;
	BroadcastReceiver mReceiver = new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {
			if (intent.getAction().equals(Intent.ACTION_SCREEN_ON)) {
				sm.registerListener(mySensorEventListener, sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_FASTEST);
			} else if (intent.getAction().equals(Intent.ACTION_SCREEN_OFF)) {
				sm.unregisterListener(mySensorEventListener);
			}
		}
	};

	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		sm = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
		sm.registerListener(mySensorEventListener, sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_FASTEST);
		sharedPreferences = getSharedPreferences(Constants.SHARED_PREFERENCES_NAME, Context.MODE_PRIVATE);
		IntentFilter filter = new IntentFilter();
		filter.addAction(Intent.ACTION_SCREEN_OFF);
		filter.addAction(Intent.ACTION_SCREEN_ON);
		registerReceiver(mReceiver, filter);
		return super.onStartCommand(intent, flags, startId);
	}

	@Override
	public void onDestroy() {
		if (sm != null)
			sm.unregisterListener(mySensorEventListener);
		unregisterReceiver(mReceiver);
		super.onDestroy();
	}

	private SensorEventListener mySensorEventListener = new SensorEventListener() {

		@SuppressWarnings("deprecation")
		@Override
		public void onSensorChanged(SensorEvent event) {
			if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
				// 获取加速度传感器的三个参数
				float x = event.values[SensorManager.DATA_X];
				float y = event.values[SensorManager.DATA_Y];
				float z = event.values[SensorManager.DATA_Z];
				// 获取当前时刻的毫秒数
				curTime = System.currentTimeMillis();
				// 100毫秒检测一次
				duration = (curTime - lastTime);
				if (duration > 100) {

					// 看是不是刚开始晃动
					if (last_x == 0.0f && last_y == 0.0f && last_z == 0.0f) {
						// last_x、last_y、last_z同时为0时，表示刚刚开始记录
					} else {
						// 单次晃动幅度
						shake = (Math.abs(x - last_x) + Math.abs(y - last_y) + Math.abs(z - last_z));
					}
					// 判断是否为摇动
					int sensitivity = Constants.SENSITIVITYS[sharedPreferences.getInt(Constants.SHAKE_SEEKBAR_SENSITIVITY, 2)];
					if (shake > sensitivity) {
						action();
					}
					last_x = x;
					last_y = y;
					last_z = z;
					lastTime = curTime;
				}
			}
		}

		@Override
		public void onAccuracyChanged(Sensor sensor, int accuracy) {

		}
	};

	private void action() {
		actionTime = sharedPreferences.getLong(Constants.SHAKE_TIMESPACE, 0);
		int time_space = Constants.TIMESPACES[sharedPreferences.getInt(Constants.SHAKE_SEEKBAR_TIMESPACE, 1)];
		if (System.currentTimeMillis() - actionTime > (time_space * 1000)) {
			boolean vibrator_checked = sharedPreferences.getBoolean(Constants.SHAKE_CHECKBOX_VIBRATE, true);
			if (vibrator_checked) {
				onVibrator();
			}
			if (sharedPreferences.getBoolean(Constants.SHAKE_STATE_CACHE, false)) {
				ShakeClearCache(this, handler);

			}
			actionTime = System.currentTimeMillis();
			sharedPreferences.edit().putLong(Constants.SHAKE_TIMESPACE, actionTime).commit();
		}
		initShake();
	}

	private void onVibrator() {
		Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
		if (vibrator == null) {
			Vibrator localVibrator = (Vibrator) getApplicationContext().getSystemService("vibrator");
			vibrator = localVibrator;
		}
		vibrator.vibrate(100L);
	}

	private void initShake() {
		lastTime = 0;
		duration = 0;
		curTime = 0;
		last_x = 0.0f;
		last_y = 0.0f;
		last_z = 0.0f;
		shake = 0.0f;
	}

	Handler handler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			if (msg.what == 0) {
				Toast.makeText(ShakeClearService.this, getString(R.string.clear_cache_result, freeMemorySize), Toast.LENGTH_LONG).show();
			}
		}
	};

	private void ShakeClearCache(final Context context, final Handler handler) {
		new Thread(new Runnable() {
			@Override
			public void run() {
				Message msg = new Message();
				ClearResult clearResult= ProcessManagerUtils.killProcessList(context);
				long memory  = clearResult.getMemory();
				freeMemorySize = FormatUtils.formatBytesInByte(memory);
				ClearUtils.setDayClearSize(context, memory);
				ClearUtils.setHistoryClearSize(context, memory);
				msg.what = 0;
				handler.sendMessage(msg);
			}
		}).start();
	}
}
