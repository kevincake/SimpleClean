package cn.com.opda.android.clearmaster.model;


public class AdInfo {
	private String packageName;
	private int versionCode;
	private String imageUrl;
	private String apkUrl;
	private boolean adShow;
	private String appName;
	private String title;
	private String content;
	private int weight_l;
	private int weight_r;
	private String detailUrl;
	private String size;
	private boolean html5;
	private String gameUrl;

	public String getGameUrl() {
		return gameUrl;
	}
	public void setGameUrl(String gameUrl) {
		this.gameUrl = gameUrl;
	}
	public boolean isHtml5() {
		return html5;
	}
	public void setHtml5(boolean html5) {
		this.html5 = html5;
	}
	public String getSize() {
		return size;
	}
	public void setSize(String size) {
		this.size = size;
	}
	public String getDetailUrl() {
		return detailUrl;
	}
	public void setDetailUrl(String detailUrl) {
		this.detailUrl = detailUrl;
	}
	public int getWeight_l() {
		return weight_l;
	}
	public void setWeight_l(int weight_l) {
		this.weight_l = weight_l;
	}
	public int getWeight_r() {
		return weight_r;
	}
	public void setWeight_r(int weight_r) {
		this.weight_r = weight_r;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getPackageName() {
		return packageName;
	}
	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}
	public int getVersionCode() {
		return versionCode;
	}
	public void setVersionCode(int versionCode) {
		this.versionCode = versionCode;
	}
	public String getImageUrl() {
		return imageUrl;
	}
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}
	public String getApkUrl() {
		return apkUrl;
	}
	public void setApkUrl(String apkUrl) {
		this.apkUrl = apkUrl;
	}
	public boolean isAdShow() {
		return adShow;
	}
	public void setAdShow(boolean adShow) {
		this.adShow = adShow;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	
}
