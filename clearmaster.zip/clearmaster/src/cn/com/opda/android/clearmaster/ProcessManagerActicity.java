package cn.com.opda.android.clearmaster;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.ActivityManager.RunningServiceInfo;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Process;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.view.animation.TranslateAnimation;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import cn.com.opda.android.clearmaster.adapter.Adapter4ResultAd;
import cn.com.opda.android.clearmaster.adapter.ProcessManagerAdapter;
import cn.com.opda.android.clearmaster.custom.CustomDialog3;
import cn.com.opda.android.clearmaster.custom.CustomListView;
import cn.com.opda.android.clearmaster.custom.CustomTextView;
import cn.com.opda.android.clearmaster.custom.WaterWaveCustomView;
import cn.com.opda.android.clearmaster.dao.KeepListUtils;
import cn.com.opda.android.clearmaster.model.AdInfo;
import cn.com.opda.android.clearmaster.model.AppItem;
import cn.com.opda.android.clearmaster.model.BaseItem;
import cn.com.opda.android.clearmaster.model.ToolboxAd;
import cn.com.opda.android.clearmaster.utils.AppDownload;
import cn.com.opda.android.clearmaster.utils.AppManagerUtils;
import cn.com.opda.android.clearmaster.utils.BannerUtils;
import cn.com.opda.android.clearmaster.utils.ClearUtils;
import cn.com.opda.android.clearmaster.utils.CustomEventCommit;
import cn.com.opda.android.clearmaster.utils.DensityUtil;
import cn.com.opda.android.clearmaster.utils.FormatUtils;
import cn.com.opda.android.clearmaster.utils.MemorySizeComparator;
import cn.com.opda.android.clearmaster.utils.ProcessManagerUtils;
import cn.com.opda.android.clearmaster.utils.Terminal;
import cn.com.opda.android.clearmaster.utils.ToolboxAdUtils;

import com.lib.statistics.StatisticsUtils;
import com.umeng.analytics.MobclickAgent;

/**
 * 内存加速
 * 
 * @author 庄宏岩
 * 
 */
public class ProcessManagerActicity extends BaseActivity implements OnItemClickListener, OnClickListener {
	private Context mContext;
	private CustomListView process_manager_listview;
	private ProcessManagerAdapter mProcessManagerAdapter;
	private int memorySize = 0;
	private boolean stop;
	private Button clear_button;
	private LinearLayout result_page;
	private LinearLayout list_page;
	private boolean from_notify;
	private AppItem forceApp;
	private AppItem uninstallApp;
	private CustomTextView header_memory_textview;
	private WaterWaveCustomView header_waterwave_view;
	private TextView header_unit_textview, header_content_textview;

	private TextView scan_textview;
	private ProgressBar scan_line_progressbar;
	private RelativeLayout progress_layout;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		from_notify = getIntent().getBooleanExtra("from_notify", false);
		if (!from_notify) {
			overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
		}
		setContentView(R.layout.activity_process_manager);
		BannerUtils.setTitle(this, R.string.activity_title_kill_process);
		BannerUtils.initBackButton(this);
		mContext = ProcessManagerActicity.this;
		initViewAndEvent();
		initAdView();
		initADListView();
		initBackButton();
		SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(mContext);

		sp.edit().putLong("lastProcessTipTime", System.currentTimeMillis()).commit();
		new GetProcessThread().start();
		initResultImageView();
	}

	private void initViewAndEvent() {

		process_manager_listview = (CustomListView) findViewById(R.id.process_manager_listview);
		process_manager_listview.setOnItemClickListener(this);

		header_memory_textview = (CustomTextView) findViewById(R.id.header_memory_textview);
		header_waterwave_view = (WaterWaveCustomView) findViewById(R.id.header_waterwave_view);
		header_unit_textview = (TextView) findViewById(R.id.header_unit_textview);
		header_content_textview = (TextView) findViewById(R.id.header_content_textview);

		progress_layout = (RelativeLayout) findViewById(R.id.progress_layout);
		scan_line_progressbar = (ProgressBar) findViewById(R.id.scan_line_progressbar);
		scan_textview = (TextView) findViewById(R.id.scan_textview);

		clear_button = (Button) findViewById(R.id.clear_button);
		clear_button.setOnClickListener(this);

		ImageView banner_process_white_imageview = (ImageView) findViewById(R.id.banner_process_white_imageview);
		banner_process_white_imageview.setVisibility(View.VISIBLE);
		banner_process_white_imageview.setOnClickListener(this);

		findViewById(R.id.back_imageview).setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				finish();
				overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
			}
		});
		findViewById(R.id.back_title).setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				finish();
				overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
			}
		});

		result_page = (LinearLayout) findViewById(R.id.result_page);
		list_page = (LinearLayout) findViewById(R.id.list_page);

		findViewById(R.id.auto_manager_button).setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				startActivity(new Intent(mContext, AutoBootManager.class));
			}
		});
		findViewById(R.id.boot_manager_title_layout).setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				startActivity(new Intent(mContext, AutoBootManager.class));
			}
		});

	}

	private void initResultImageView() {
		ImageView result_icon_imageview = (ImageView) findViewById(R.id.result_icon_imageview);
		int r = (int) (Math.random() * 5);
		int resId = R.drawable.result_page_icon_1;
		switch (r) {
		case 0:
			resId = R.drawable.result_page_icon_2;
			break;
		case 1:
			resId = R.drawable.result_page_icon_3;
			break;
		case 2:
			resId = R.drawable.result_page_icon_4;
			break;
		case 3:
			resId = R.drawable.result_page_icon_5;
			break;

		default:
			break;
		}
		result_icon_imageview.setImageResource(resId);
	}

	private float lastY;
	private boolean lock = false;
	private boolean isOpen = true;
	private int result_layout_height_px;
	private ListView more_tools_listview;
	private int mFirstItemPosY;
	private LinearLayout result_layout;
	private ImageView ad_cursor_imageview;

	private void initAdView() {
		LinearLayout ad_cursor_layout = (LinearLayout) findViewById(R.id.ad_cursor_layout);
		ad_cursor_imageview = (ImageView) findViewById(R.id.ad_cursor_imageview);

		result_layout = (LinearLayout) findViewById(R.id.result_layout);
		more_tools_listview = (ListView) findViewById(R.id.more_tools_listview);

		LayoutParams resultLayoutParams = (LayoutParams) result_layout.getLayoutParams();
		DisplayMetrics dm = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(dm);
		int screenHeight = dm.heightPixels;

		/**** 获取状态栏高度 ****/
		int statusBarHeight = 0;
		Class<?> c = null;
		Object obj = null;
		Field field = null;
		try {
			c = Class.forName("com.android.internal.R$dimen");
			obj = c.newInstance();
			field = c.getField("status_bar_height");
			int x = Integer.parseInt(field.get(obj).toString());
			statusBarHeight = getResources().getDimensionPixelSize(x);
		} catch (Exception e1) {
			e1.printStackTrace();
			statusBarHeight = 0;
		}

		int ad_layout_height_px = DensityUtil.dip2px(mContext, 80 + 48 + 48) + statusBarHeight;
		result_layout_height_px = screenHeight - ad_layout_height_px;

		resultLayoutParams.height = result_layout_height_px;
		result_layout.setLayoutParams(resultLayoutParams);

		more_tools_listview.setOnTouchListener(new OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()) {
				case MotionEvent.ACTION_DOWN:
					lastY = event.getRawY();
					break;
				case MotionEvent.ACTION_UP:
					lastY = 0;
					break;
				case MotionEvent.ACTION_MOVE:
					if (!lock) {
						if (isOpen) {
							if (event.getRawY() - lastY <= -5) {
								lock = true;
								close();
							}
						} else {
							if (mFirstItemPosY == 0) {
								if (event.getRawY() - lastY >= 10) {
									lock = true;
									open();
								}
							}
						}
					}
					break;

				default:
					break;
				}
				return false;
			}
		});

		ad_cursor_layout.setOnTouchListener(new OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()) {
				case MotionEvent.ACTION_DOWN:
					lastY = event.getRawY();
					break;
				case MotionEvent.ACTION_UP:
					lastY = 0;
					break;
				case MotionEvent.ACTION_MOVE:
					if (!lock) {
						if (isOpen) {
							if (event.getRawY() - lastY <= -5) {
								lock = true;
								close();
							}
						} else {
							if (mFirstItemPosY == 0) {
								if (event.getRawY() - lastY >= 5) {
									lock = true;
									open();
								}
							}
						}
					}
					break;

				default:
					break;
				}
				return true;
			}
		});

		more_tools_listview.setOnScrollListener(new OnScrollListener() {

			@Override
			public void onScrollStateChanged(AbsListView view, int scrollState) {
				switch (scrollState) {
				case OnScrollListener.SCROLL_STATE_TOUCH_SCROLL:
					break;
				case OnScrollListener.SCROLL_STATE_IDLE: //
					View v = view.getChildAt(0);
					mFirstItemPosY = (v == null) ? 0 : v.getTop();
					break;
				}

			}

			@Override
			public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

			}
		});

		more_tools_listview.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

				BaseItem mBaseItem = (BaseItem) parent.getItemAtPosition(position);

				PackageInfo packageInfo = null;
				try {
					packageInfo = mContext.getPackageManager().getPackageInfo(mBaseItem.getPackageName(), 0);
				} catch (NameNotFoundException e) {
					e.printStackTrace();
				}
				if (packageInfo != null) {
					StatisticsUtils.commitEvent(mContext, mBaseItem.getName(), mBaseItem.getPackageName(), StatisticsUtils.AdType_ruanjianneizhi,
							StatisticsUtils.AdEvent_open);
					mContext.startActivity(mContext.getPackageManager().getLaunchIntentForPackage(mBaseItem.getPackageName()));
				} else {
					if (!mBaseItem.isDownload()) {
						StatisticsUtils.commitEvent(mContext, mBaseItem.getName(), mBaseItem.getPackageName(), StatisticsUtils.AdType_ruanjianneizhi,
								StatisticsUtils.AdEvent_show);
						AppDownload appDownload = new AppDownload(mContext);
						appDownload.setDownloadurl(mBaseItem.getApkUrl());
						appDownload.setAppName(mBaseItem.getName());
						appDownload.setPackageName(mBaseItem.getPackageName());
						appDownload.setAppIcon(mBaseItem.getIcon());
						appDownload.createNotify();
						appDownload.startDownloadApp();
						Toast.makeText(mContext, mBaseItem.getName() + mContext.getString(R.string.ad_stardonwload_tips), Toast.LENGTH_SHORT).show();
						mBaseItem.setDownload(true);
					}
				}

			}

		});
		startCursorUpAnim();

	}

	public void open() {
		final LayoutParams layoutParams = (LayoutParams) result_layout.getLayoutParams();
		new Thread(new Runnable() {

			@Override
			public void run() {
				for (int i = 1; i < 26; i++) {
					final int f = i;
					runOnUiThread(new Runnable() {

						@Override
						public void run() {
							layoutParams.height = (int) (result_layout_height_px * (1.0f * (f / 25f)));
							result_layout.setLayoutParams(layoutParams);
							result_layout.invalidate();
							if (f == 25) {
								more_tools_listview.setAdapter(adsAdapter);
								more_tools_listview.setSelection(0);
								TextView back_title = (TextView) findViewById(R.id.back_title);
								back_title.setText(R.string.clear_end_title);
								startCursorUpAnim();
							}
						}
					});
					try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				lock = false;
				isOpen = true;

			}
		}).start();
	}

	public void close() {
		final LayoutParams layoutParams = (LayoutParams) result_layout.getLayoutParams();
		new Thread(new Runnable() {

			@Override
			public void run() {
				for (int i = 1; i < 26; i++) {
					final int f = i;
					runOnUiThread(new Runnable() {

						@Override
						public void run() {
							layoutParams.height = (int) (result_layout_height_px * (1 - 1.0f * (f / 25f)));
							result_layout.setLayoutParams(layoutParams);
							result_layout.invalidate();
							if (f == 25) {
								TextView back_title = (TextView) findViewById(R.id.back_title);
								back_title.setText("更多功能");
								startCursorDownAnim();
								CustomEventCommit.commit(mContext, CustomEventCommit.result_ad_show);
							}
						}
					});
					try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				lock = false;
				isOpen = false;
			}
		}).start();
	}

	private void startCursorUpAnim() {
		ad_cursor_imageview.clearAnimation();
		ad_cursor_imageview.setImageResource(R.drawable.ad_cursor_up);
		Animation animation = AnimationUtils.loadAnimation(mContext, R.anim.cursor_up);
		animation.setStartOffset(100);
		ad_cursor_imageview.startAnimation(animation);
	}

	private void startCursorDownAnim() {
		ad_cursor_imageview.clearAnimation();
		ad_cursor_imageview.setImageResource(R.drawable.ad_cursor_down);
		Animation animation = AnimationUtils.loadAnimation(mContext, R.anim.cursor_down);
		animation.setStartOffset(100);
		ad_cursor_imageview.startAnimation(animation);
	}

	private void clearCursorAnim() {
		ad_cursor_imageview.clearAnimation();
	}

	private Adapter4ResultAd adsAdapter;

	private void initADListView() {
		ArrayList<BaseItem> mBaseItems = new ArrayList<BaseItem>();

		adsAdapter = new Adapter4ResultAd(mContext, mBaseItems);
		more_tools_listview.setAdapter(adsAdapter);

		SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(mContext);
		String toolbox_ad_json = sp.getString("result_ad_json", null);
		if (toolbox_ad_json != null) {
			ArrayList<ToolboxAd> toolboxAds = ToolboxAdUtils.getAdInfo(toolbox_ad_json);
			new GetAdsThread(toolboxAds).start();
		} else {
			new GetAdsThread(null).start();
		}
	}

	/**
	 * 获取广告列表
	 * 
	 * @author 庄宏岩
	 * 
	 */
	private class GetAdsThread extends Thread {
		private ArrayList<ToolboxAd> toolboxAds;
		private ArrayList<BaseItem> mBaseItems;

		public GetAdsThread(ArrayList<ToolboxAd> toolboxAds) {
			this.toolboxAds = toolboxAds;
			mBaseItems = new ArrayList<BaseItem>();
		}

		@Override
		public void run() {
			super.run();

			if (toolboxAds == null) {
				toolboxAds = ToolboxAdUtils.getResultAdInfo(mContext);
			}
			if (toolboxAds != null) {
				for (int i = 0; i < toolboxAds.size(); i++) {
					final BaseItem baseItem = new BaseItem();
					ToolboxAd toolboxAd = toolboxAds.get(i);
					AdInfo adInfo = getRandomAd(toolboxAd);
					PackageManager pm = mContext.getPackageManager();
					PackageInfo packageInfo = null;
					try {
						packageInfo = pm.getPackageInfo(adInfo.getPackageName(), 0);
					} catch (NameNotFoundException e) {
					}
					if (packageInfo != null) {
						adInfo = getNotInstallAd(toolboxAd);
					}
					baseItem.setName(adInfo.getAppName());
					baseItem.setPackageName(adInfo.getPackageName());
					baseItem.setDesc(adInfo.getContent());
					baseItem.setApkUrl(adInfo.getApkUrl());
					baseItem.setTitle(adInfo.getTitle());
					baseItem.setDetailUrl(adInfo.getDetailUrl());
					baseItem.setType(3);
					baseItem.setSize(adInfo.getSize());
					baseItem.setImageUrl(adInfo.getImageUrl());
					baseItem.setHtml5(adInfo.isHtml5());
					baseItem.setGameUrl(adInfo.getGameUrl());
					mBaseItems.add(baseItem);
				}
			}
			mHandler.sendEmptyMessage(1);
		}

		Handler mHandler = new Handler() {

			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				switch (msg.what) {
				case 1:
					if (mBaseItems != null && mBaseItems.size() > 0) {
						adsAdapter.getList().addAll(mBaseItems);
						adsAdapter.notifyDataSetChanged();
					} else {
						LayoutParams resultLayoutParams = (LayoutParams) result_layout.getLayoutParams();
						resultLayoutParams.height = LayoutParams.FILL_PARENT;
						result_layout.setLayoutParams(resultLayoutParams);
					}
					break;
				default:
					break;
				}

			}

		};
	}

	public AdInfo getRandomAd(ToolboxAd toolboxAd) {
		int r = (int) (Math.random() * 10 + 1);
		ArrayList<AdInfo> adInfos = toolboxAd.getAdInfos();
		if (adInfos != null && adInfos.size() > 0) {
			for (AdInfo adInfo : adInfos) {
				if (r >= adInfo.getWeight_l() && r <= adInfo.getWeight_r()) {
					return adInfo;
				}
			}
		}
		return null;
	}

	public AdInfo getNotInstallAd(ToolboxAd toolboxAd) {
		ArrayList<AdInfo> adInfos = toolboxAd.getAdInfos();
		PackageManager pm = mContext.getPackageManager();
		if (adInfos != null && adInfos.size() > 0) {
			for (AdInfo adInfo : adInfos) {
				PackageInfo packageInfo = null;
				try {
					packageInfo = pm.getPackageInfo(adInfo.getPackageName(), 0);
				} catch (NameNotFoundException e) {
				}
				if (packageInfo == null) {
					return adInfo;
				}

			}
			return adInfos.get(0);
		}
		return null;
	}

	public void initBackButton() {
		ImageView banner_back_imageview = (ImageView) findViewById(R.id.banner_back_imageview);
		banner_back_imageview.setVisibility(View.VISIBLE);
		banner_back_imageview.setOnClickListener(this);
		TextView banner_title_textview = (TextView) findViewById(R.id.banner_title_textview);
		banner_title_textview.setOnClickListener(this);
	}

	private LayoutAnimationController getListAnim() {
		AnimationSet set = new AnimationSet(true);
		Animation animation = new AlphaAnimation(0.0f, 1.0f);
		animation.setDuration(300);
		set.addAnimation(animation);

		animation = new TranslateAnimation(Animation.RELATIVE_TO_SELF, 0.3f, Animation.RELATIVE_TO_SELF, 0.0f, Animation.RELATIVE_TO_SELF, -0.5f,
				Animation.RELATIVE_TO_SELF, 0.0f);
		animation.setDuration(300);
		set.addAnimation(animation);
		LayoutAnimationController controller = new LayoutAnimationController(set, 0.5f);
		return controller;
	}

	private AnimationSet getDeleteAnim() {
		AnimationSet set = new AnimationSet(true);
		Animation animation = new AlphaAnimation(1.0f, 0.5f);
		animation.setDuration(300);
		set.addAnimation(animation);

		animation = new TranslateAnimation(Animation.RELATIVE_TO_SELF, 0.0f, Animation.RELATIVE_TO_SELF, -1.0f, Animation.RELATIVE_TO_SELF, 0.0f,
				Animation.RELATIVE_TO_SELF, -1.0f);
		animation.setDuration(300);
		set.addAnimation(animation);
		set.setFillAfter(true);
		return set;
	}

	class GetProcessThread extends Thread {
		private ArrayList<AppItem> appItems;
		private ArrayList<Integer> runPids = new ArrayList<Integer>();

		public GetProcessThread() {

			appItems = new ArrayList<AppItem>();
			mProcessManagerAdapter = new ProcessManagerAdapter(mContext, appItems);
			process_manager_listview.setAdapter(mProcessManagerAdapter);
			process_manager_listview.setLayoutAnimation(getListAnim());
			clear_button.setText(R.string.stop_scan_button);

		}

		@Override
		public void run() {
			super.run();

			ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
			PackageManager pm = getPackageManager();
			List<ApplicationInfo> installedAppList = pm.getInstalledApplications(0);
			List<RunningAppProcessInfo> lists = am.getRunningAppProcesses();
			List<RunningServiceInfo> serviceList = am.getRunningServices(100);
			ArrayList<String> keeps = KeepListUtils.getList(mContext);
			for (int i = 0; i < lists.size(); i++) {
				if (stop) {
					break;
				}
				RunningAppProcessInfo runapp = lists.get(i);
				Message message = new Message();
				message.what = 1;
				Bundle bundle = new Bundle();
				if (serviceList != null) {
					bundle.putInt("max", lists.size() + serviceList.size());
				} else {
					bundle.putInt("max", lists.size());
				}
				bundle.putInt("progress", i + 1);
				message.setData(bundle);
				handler.sendMessage(message);
				if (runapp.pkgList == null || runapp.pkgList.length == 0) {
					continue;
				}
				String packageName = runapp.pkgList[0];
				if (packageName.equals(getPackageName())) {
					continue;
				}
				if (isSystemApp(packageName)) {
					continue;
				}
				if (!runPids.contains(runapp.pid)) {
					runPids.add(runapp.pid);
				}
				for (ApplicationInfo info : installedAppList) {
					if (stop) {
						break;
					}
					String sourceDir = info.sourceDir;
					if (sourceDir != null) {
						if (packageName.equals(info.packageName)) {
							if (!keeps.contains(packageName)) {

								final AppItem appItem = new AppItem();
								appItem.setAppPackage(packageName);
								appItem.setAppName(info.loadLabel(pm).toString());
								appItem.setAppIcon(info.loadIcon(pm));
								appItem.setMemorySize(ProcessManagerUtils.getProcessMemUsage(am, runapp.pid) * 1000);
								appItem.setPid(runapp.pid);
								appItem.setChecked(true);

								memorySize += appItem.getMemorySize();
								runOnUiThread(new Runnable() {

									@Override
									public void run() {
										appItems.add(appItem);
										Collections.sort(appItems, new MemorySizeComparator());
										handler.sendEmptyMessage(0);
									}
								});
							}
						}
					}
				}
			}

			for (int i = 0; i < serviceList.size(); i++) {
				if (stop) {
					break;
				}

				RunningServiceInfo runService = serviceList.get(i);
				if (runService.service == null) {
					continue;
				}
				Message message = new Message();
				message.what = 1;
				Bundle bundle = new Bundle();
				if (lists != null) {
					bundle.putInt("max", lists.size() + serviceList.size());
					bundle.putInt("progress", lists.size() + i + 1);
				} else {
					bundle.putInt("max", serviceList.size());
					bundle.putInt("progress", i + 1);
				}
				message.setData(bundle);
				handler.sendMessage(message);
				String packageName = runService.service.getPackageName();
				if (TextUtils.isEmpty(packageName)) {
					continue;
				}

				if (isSystemApp(packageName)) {
					continue;
				}
				if (packageName.equals(getPackageName())) {
					continue;
				}
				if (runPids.contains(runService.pid)) {
					continue;
				} else {
					runPids.add(runService.pid);
				}
				for (ApplicationInfo info : installedAppList) {
					if (stop) {
						break;
					}
					String sourceDir = info.sourceDir;
					if (sourceDir != null) {
						if (packageName.equals(info.packageName)) {
							if (!keeps.contains(packageName)) {

								final AppItem appItem = new AppItem();
								appItem.setAppPackage(packageName);
								appItem.setAppName(info.loadLabel(pm).toString());
								appItem.setAppIcon(info.loadIcon(pm));
								appItem.setMemorySize(ProcessManagerUtils.getProcessMemUsage(am, runService.pid) * 1000);
								appItem.setPid(runService.pid);

								appItem.setChecked(true);

								memorySize += appItem.getMemorySize();
								runOnUiThread(new Runnable() {

									@Override
									public void run() {
										appItems.add(appItem);
										Collections.sort(appItems, new MemorySizeComparator());
										handler.sendEmptyMessage(0);
									}
								});
							}
						}
					}
				}
			}
			handler.sendEmptyMessage(2);
		}

		Handler handler = new Handler() {

			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				switch (msg.what) {
				case 0:
					mProcessManagerAdapter.notifyDataSetChanged();
					updateUI();
					break;
				case 1:
					Bundle bundle = msg.getData();
					scan_line_progressbar.setMax(bundle.getInt("max"));
					scan_line_progressbar.setProgress(bundle.getInt("progress"));
					scan_textview.setText(R.string.clear_process_scanning);
					scan_textview.setVisibility(View.VISIBLE);
					break;
				case 2:

					if (appItems.size() == 0) {
						process_manager_listview.setVisibility(View.GONE);
						findViewById(R.id.process_manager_tips_textview).setVisibility(View.VISIBLE);
						findViewById(R.id.clear_button_layout).setVisibility(View.GONE);
					} else {
						process_manager_listview.setVisibility(View.VISIBLE);
					}

					progress_layout.setVisibility(View.GONE);

					clear_button.setText(R.string.chortcut_name);
					scan_line_progressbar.setProgress(0);
					scan_textview.setVisibility(View.GONE);
					break;

				default:
					break;
				}
			}

		};

	}

	class KillProcessThread extends Thread {
		private int freeMemorySize;
		private ArrayList<AppItem> mKillProcessList;
		private String packages = "";
		private String killCommand = "";

		public KillProcessThread() {
			mKillProcessList = mProcessManagerAdapter.getList();
		}

		@SuppressWarnings("deprecation")
		@Override
		public void run() {
			super.run();

			if (mKillProcessList.size() > 0) {
				ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
				for (int i = 0; i < mKillProcessList.size(); i++) {
					AppItem appItem = mKillProcessList.get(i);

					Message message = new Message();
					message.what = 1;
					Bundle bundle = new Bundle();
					bundle.putInt("index", i);
					message.setData(bundle);
					handler.sendMessage(message);

					if (appItem.isChecked()) {
						if (Terminal.isRoot(mContext)) {
							if (i == 0) {
								packages += appItem.getAppPackage();
							} else {
								packages += ("," + appItem.getAppPackage());
							}
							if (appItem.getPid() != 0) {
								killCommand += "kill " + appItem.getPid() + "\n";
							}
						}else{
							if (appItem.getPid() != 0) {
								Process.killProcess(appItem.getPid());
							}
							am.restartPackage(appItem.getAppPackage());
							if (Build.VERSION.SDK_INT >= 8) {
								am.killBackgroundProcesses(appItem.getAppPackage());
							}
						}
						freeMemorySize += appItem.getMemorySize();
						memorySize -= appItem.getMemorySize();
					}
					try {
						Thread.sleep(50);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				handler.sendEmptyMessageDelayed(2, 100);
			}
		}

		Handler handler = new Handler() {

			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				switch (msg.what) {
				case 1:
					progress_layout.setVisibility(View.VISIBLE);
					Bundle bundle = msg.getData();
					int index = bundle.getInt("index");
					scan_textview.setText(getString(R.string.clear_process_stoping));
					scan_textview.setVisibility(View.VISIBLE);
					View view = process_manager_listview.getChildAt(index);
					Animation animation = getDeleteAnim();
					view.startAnimation(animation);
					String memorySizeString = FormatUtils.formatBytesInByte2(memorySize);
					header_memory_textview.setText(memorySizeString.substring(0, memorySizeString.length() - 2));
					header_unit_textview.setText(memorySizeString.substring(memorySizeString.length() - 2, memorySizeString.length()));
					header_content_textview.setText(getString(R.string.clear_process_count, (mProcessManagerAdapter.getCount() - index)));
					break;
				case 2:
					if (!TextUtils.isEmpty(packages)) {
						new Thread(new Runnable() {

							@Override
							public void run() {
								AppManagerUtils.forceStopPackage(mContext, packages);
//								Terminal.RootCommand(killCommand);
							}
						}).start();
					}
					progress_layout.setVisibility(View.GONE);
					scan_line_progressbar.setProgress(0);
					scan_textview.setVisibility(View.GONE);

					Animation animation1 = AnimationUtils.loadAnimation(mContext, R.anim.slide_out_left);
					Animation animation2 = AnimationUtils.loadAnimation(mContext, R.anim.slide_in_right);
					list_page.startAnimation(animation1);
					result_page.startAnimation(animation2);

					list_page.setVisibility(View.GONE);
					result_page.setVisibility(View.VISIBLE);

					ClearUtils.setDayClearSize(mContext, freeMemorySize);
					ClearUtils.setHistoryClearSize(mContext, freeMemorySize);

					TextView thistime_clear_memory_textview = (TextView) findViewById(R.id.thistime_clear_memory_textview);
					TextView thistime_clear_unit_textview = (TextView) findViewById(R.id.thistime_clear_unit_textview);

					String size = FormatUtils.formatBytesInByte2(freeMemorySize);
					thistime_clear_memory_textview.setText(size.substring(0, size.length() - 2));
					thistime_clear_unit_textview.setText(size.substring(size.length() - 2, size.length()));

					TextView total_clear_memory_textview = (TextView) findViewById(R.id.total_clear_memory_textview);
					TextView total_clear_unit_textview = (TextView) findViewById(R.id.total_clear_unit_textview);

					String totalSize = FormatUtils.formatBytesInByte2(ClearUtils.getHistoryClearSize(mContext));
					total_clear_memory_textview.setText(totalSize.substring(0, totalSize.length() - 2));
					total_clear_unit_textview.setText(totalSize.substring(totalSize.length() - 2, totalSize.length()));

					// TextView clear_momery_result_textview = (TextView)
					// findViewById(R.id.clear_momery_result_textview);
					// clear_momery_result_textview.setText(R.string.clean_process_all);

					updateUI();

					break;

				default:
					break;
				}
			}

		};

	}

	private boolean isSystemApp(String packageName) {
		if (packageName.contains("com.google.") || packageName.contains("com.android.") || packageName.contains("com.htc.") || packageName.contains("com.sec.")
				|| packageName.contains("com.motorola.") || packageName.contains("com.yulong.") || packageName.contains("com.miui.")
				|| packageName.contains("com.huawei.") || packageName.contains("com.zte.") || packageName.contains("com.meizu.")
				|| packageName.contains("cn.nubia.") || packageName.contains("com.qualcomm.")) {
			return true;
		}
		return false;
	}

	@Override
	protected void onResume() {
		MobclickAgent.onResume(this);
		super.onResume();
		if (forceApp != null) {
			new Thread(new Runnable() {

				@Override
				public void run() {
					if (!AppManagerUtils.appIsRunning(mContext, forceApp.getAppPackage())) {
						runOnUiThread(new Runnable() {

							@Override
							public void run() {
								mProcessManagerAdapter.remove(forceApp);
								mProcessManagerAdapter.notifyDataSetChanged();
								memorySize -= forceApp.getMemorySize();
								updateUI();
								forceApp = null;
							}
						});
					}
				}
			}).start();
		}
		if (uninstallApp != null) {
			if (!AppManagerUtils.appIsInstall(mContext, uninstallApp.getAppPackage())) {
				mProcessManagerAdapter.remove(uninstallApp);
				mProcessManagerAdapter.notifyDataSetChanged();
				memorySize -= uninstallApp.getMemorySize();
				updateUI();
			}
			uninstallApp = null;
		}
	}

	@Override
	protected void onPause() {
		MobclickAgent.onPause(this);
		super.onPause();
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
		final AppItem appItem = (AppItem) parent.getItemAtPosition(position);
		final CustomDialog3 customDialog3 = new CustomDialog3(mContext);
		customDialog3.setTitle(appItem.getAppName());
		customDialog3.setIcon(appItem.getAppIcon());
		View dialog_view_process = LayoutInflater.from(mContext).inflate(R.layout.dialog_process_item, null);
		TextView process_memory_textview = (TextView) dialog_view_process.findViewById(R.id.process_memory_textview);
		process_memory_textview.setText("内存占用: " + FormatUtils.formatBytesInByte(appItem.getMemorySize()));
		TextView button_add_white = (TextView) dialog_view_process.findViewById(R.id.button_add_white);
		TextView button_force_stop = (TextView) dialog_view_process.findViewById(R.id.button_force_stop);
		TextView button_uninstall_app = (TextView) dialog_view_process.findViewById(R.id.button_uninstall_app);
		button_add_white.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				customDialog3.dismiss();

				KeepListUtils.save(mContext, appItem.getAppPackage());
				mProcessManagerAdapter.remove(appItem);
				mProcessManagerAdapter.notifyDataSetChanged();
				memorySize -= appItem.getMemorySize();
				updateUI();

			}
		});
		button_force_stop.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				customDialog3.dismiss();
				forceApp = appItem;
				AppManagerUtils.openInstalledDetail(mContext, appItem.getAppPackage());

			}
		});
		button_uninstall_app.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				customDialog3.dismiss();
				uninstallApp = appItem;
				AppManagerUtils.openUninstaller(mContext, appItem.getAppPackage());
			}
		});

		customDialog3.setView(dialog_view_process);
		customDialog3.setButton1("取消", null);
		customDialog3.setButton2("加速", new OnClickListener() {

			@Override
			public void onClick(View v) {
				customDialog3.dismiss();
				ProcessManagerUtils.killProcess(mContext, appItem);
				ClearUtils.setDayClearSize(mContext, appItem.getMemorySize());
				ClearUtils.setHistoryClearSize(mContext, appItem.getMemorySize());
				mProcessManagerAdapter.remove(appItem);
				mProcessManagerAdapter.notifyDataSetChanged();
				Toast.makeText(mContext, getString(R.string.process_manager_kill_one_precess, FormatUtils.formatBytesInByte(appItem.getMemorySize())),
						Toast.LENGTH_SHORT).show();
				memorySize -= appItem.getMemorySize();
				updateUI();
			}
		});
		customDialog3.show();

	}

	protected void updateUI() {
		String size = FormatUtils.formatBytesInByte2(memorySize);
		header_memory_textview.setText(size.substring(0, size.length() - 2));
		header_unit_textview.setText(size.substring(size.length() - 2, size.length()));
		header_content_textview.setVisibility(View.VISIBLE);
		header_content_textview.setText(getString(R.string.clear_process_count, mProcessManagerAdapter.getCount()));
		long ramMax = ProcessManagerUtils.getRuntimeTotalMemory();
		float f = memorySize * 100f / ramMax;
		header_waterwave_view.setWaterLevel(f);
		header_waterwave_view.startWave();
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.clear_button:
			if (clear_button.getText().equals(getString(R.string.stop_scan_button))) {
				stop = true;
				clear_button.setText(R.string.chortcut_name);
			} else {
				CustomEventCommit.commit(mContext, CustomEventCommit.button_process_click);
				if (memorySize > 0) {
					if (mProcessManagerAdapter.getSelectList().size() == 0) {
						Toast.makeText(mContext, R.string.clear_select_null, Toast.LENGTH_SHORT).show();
					} else {
						clear_button.setText("正在加速");
						clear_button.setClickable(false);
						new KillProcessThread().start();
					}

				} else {
					Toast.makeText(mContext, R.string.mobile_good_dont_kill, Toast.LENGTH_SHORT).show();
				}
			}
			break;
		case R.id.banner_title_textview:
		case R.id.banner_back_imageview:
			if (from_notify) {
				startActivity(new Intent(this, MainClearActivity.class));
				finish();
				overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
			} else {
				finish();
				overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
			}
			break;
		case R.id.banner_process_white_imageview:
			startActivity(new Intent(this, AppKeepActivity.class));
			break;
		default:
			break;
		}
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		stop = true;
		header_waterwave_view.stoptWave();
		clearCursorAnim();
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {

		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			if (from_notify) {
				startActivity(new Intent(this, MainClearActivity.class));
				finish();
				overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
			} else {
				finish();
				overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
			}
			return true;
		}

		return super.onKeyDown(keyCode, event);
	}

}
