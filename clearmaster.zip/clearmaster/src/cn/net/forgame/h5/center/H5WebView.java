package cn.net.forgame.h5.center;

import android.content.Context;
import android.util.AttributeSet;
import android.webkit.WebView;

public class H5WebView extends WebView {

	private H5Interface hic;

	public H5WebView(Context context) {
		super(context);
		getSettings().setJavaScriptEnabled(true);
		addJavascriptInterface(this, "JSBridge");
	}

	public H5WebView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		getSettings().setJavaScriptEnabled(true);
		addJavascriptInterface(this, "JSBridge");
	}

	public H5WebView(Context context, AttributeSet attrs) {
		super(context, attrs);
		getSettings().setJavaScriptEnabled(true);
		addJavascriptInterface(this, "JSBridge");
	}
	
	public void setInterface(H5Interface hic){
		this.hic = hic;
	}

	public void ShareTimeline(String img_url, String link, String desc, String title) {
		hic.ShareTimelineCallback(img_url, link, desc, title);
	}
}
