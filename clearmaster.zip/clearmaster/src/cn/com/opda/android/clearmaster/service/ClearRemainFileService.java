package cn.com.opda.android.clearmaster.service;

import java.io.File;
import java.util.ArrayList;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import cn.com.opda.android.clearmaster.ClearRemainFileActivity;
import cn.com.opda.android.clearmaster.dao.news.DBAppFolderUtils;
import cn.com.opda.android.clearmaster.model.ClearItem;
import cn.com.opda.android.clearmaster.utils.AppManagerUtils;
import cn.com.opda.android.clearmaster.utils.CopyDBUtils;
import cn.com.opda.android.clearmaster.utils.FileUtils;

/**
 * 检测卸载应用是否有残留文件的服务类
 * @author 庄宏岩
 *
 */
public class ClearRemainFileService extends Service {
	private ArrayList<String> files;
	private long size;
	private String packageName;
	private String name;

	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

	Handler handler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			switch (msg.what) {
			case 0:
				stopSelf();
				break;
			case 1:
				if (!AppManagerUtils.appIsInstall(ClearRemainFileService.this, packageName)) {
					Intent intent = new Intent(getApplicationContext(), ClearRemainFileActivity.class);
					intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					intent.putExtra("size", size);
					intent.putExtra("name", name);
					intent.putStringArrayListExtra("files", files);
					startActivity(intent);
					stopSelf();
				}
				break;
			default:
				break;
			}
		}

	};

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		if (intent != null) {
			packageName = intent.getStringExtra("packageName");
			if (packageName != null) {
				new Thread(new Runnable() {
					public void run() {
						if (showClearRemainFileTips(ClearRemainFileService.this, packageName)) {
							handler.sendEmptyMessageDelayed(1, 1000);
						} else {
							handler.sendEmptyMessage(0);
						}
					}
				}).start();
			}

		}
		return super.onStartCommand(intent, flags, startId);
	}

	public boolean showClearRemainFileTips(Context mContext, String packageName) {
		new CopyDBUtils(mContext).copyDB();
		ArrayList<ClearItem> clearItems = DBAppFolderUtils.GetDataByPackageName(packageName, mContext);
		if (clearItems != null && clearItems.size() > 0) {
			files = new ArrayList<String>();
			size = 0;
			for (ClearItem clearItem : clearItems) {
				File file = new File(FileUtils.SD_PATH,clearItem.getFilePath());
				if (file != null && file.exists()) {
					files.add(file.getAbsolutePath());
					name = clearItem.getName();
					size += FileUtils.getFileSize(file);
				}
			}
		} else {
			return false;
		}
		if (files != null && files.size() > 0) {
			return true;
		}
		return false;
	}

}
