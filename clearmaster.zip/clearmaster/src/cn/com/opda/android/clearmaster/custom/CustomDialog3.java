package cn.com.opda.android.clearmaster.custom;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface.OnCancelListener;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.text.SpannableStringBuilder;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import cn.com.opda.android.clearmaster.R;

/**
 * 通用自定义dialog
 * @author 庄宏岩
 *
 */
public class CustomDialog3 implements OnClickListener {

	private Dialog dialog;
	private View view;

	public CustomDialog3(Context context) {
		dialog = new Dialog(context, R.style.custom_dialog);
		view = View.inflate(context, R.layout.custom_dialog_layout_3, null);
	}

	public void setCancelable(boolean flag) {
		dialog.setCancelable(flag);
	}

	public void setOnCancelListener(OnCancelListener listener) {
		dialog.setOnCancelListener(listener);
	}
	
	public void setIcon(int resid) {
		View p = view.findViewById(R.id.topPanel);
		p.setVisibility(View.VISIBLE);
		ImageView imageView = (ImageView) view.findViewById(R.id.alertIcon);
		imageView.setVisibility(View.VISIBLE);
		imageView.setImageResource(resid);
	}

	public void setIcon(Drawable drawable) {
		View p = view.findViewById(R.id.topPanel);
		p.setVisibility(View.VISIBLE);
		ImageView imageView = (ImageView) view.findViewById(R.id.alertIcon);
		imageView.setVisibility(View.VISIBLE);
		imageView.setImageDrawable(drawable);
	}
	public void setIcon(Bitmap bitmap) {
		View p = view.findViewById(R.id.topPanel);
		p.setVisibility(View.VISIBLE);
		ImageView imageView = (ImageView) view.findViewById(R.id.alertIcon);
		imageView.setVisibility(View.VISIBLE);
		imageView.setImageBitmap(bitmap);
	}

	public void setTitle(int resid) {
		View p = view.findViewById(R.id.topPanel);
		p.setVisibility(View.VISIBLE);
		TextView t = (TextView) view.findViewById(R.id.alertTitle);
		t.setText(resid);
	}

	public void setTitle(CharSequence text) {
		View p = view.findViewById(R.id.topPanel);
		p.setVisibility(View.VISIBLE);
		TextView t = (TextView) view.findViewById(R.id.alertTitle);
		t.setText(text);
	}
	public void setDialogIcon(int resid) {
		ImageView dialog_icon_imageview = (ImageView) view.findViewById(R.id.dialog_icon_imageview);
		dialog_icon_imageview.setVisibility(View.VISIBLE);
		dialog_icon_imageview.setImageResource(resid);
	}

	public void setMessage(int resid) {
		TextView t = (TextView) view.findViewById(R.id.message);
		t.setText(resid);
		t.setVisibility(View.VISIBLE);
	}

	public void setMessage(CharSequence text) {
		TextView t = (TextView) view.findViewById(R.id.message);
		t.setText(text);
		t.setVisibility(View.VISIBLE);
	}
	public void setMessage(SpannableStringBuilder style) {
		TextView t = (TextView) view.findViewById(R.id.message);
		t.setText(style);
		t.setVisibility(View.VISIBLE);
	}

	public void setView(View v) {
		LinearLayout l = (LinearLayout) view.findViewById(R.id.view_layout);
		l.addView(v);
		l.setVisibility(View.VISIBLE);
	}

	public void setButton1(int resid, OnClickListener listener) {
		View p = view.findViewById(R.id.buttonPanel);
		p.setVisibility(View.VISIBLE);
		Button btn = (Button) view.findViewById(R.id.button1);
		btn.setText(resid);
		if (listener == null) {
			btn.setOnClickListener(this);
		} else {
			btn.setOnClickListener(listener);
		}
		btn.setVisibility(View.VISIBLE);
	}

	public void setButton1(CharSequence text, OnClickListener listener) {
		View p = view.findViewById(R.id.buttonPanel);
		p.setVisibility(View.VISIBLE);
		Button btn = (Button) view.findViewById(R.id.button1);
		btn.setText(text);
		if (listener == null) {
			btn.setOnClickListener(this);
		} else {
			btn.setOnClickListener(listener);
		}
		btn.setVisibility(View.VISIBLE);
	}

	public void setButton2(int resid, OnClickListener listener) {
		View p = view.findViewById(R.id.buttonPanel);
		p.setVisibility(View.VISIBLE);
		Button btn = (Button) view.findViewById(R.id.button2);
		btn.setText(resid);
		if (listener == null) {
			btn.setOnClickListener(this);
		} else {
			btn.setOnClickListener(listener);
		}
		btn.setVisibility(View.VISIBLE);
	}

	public void setButton2(CharSequence text, OnClickListener listener) {
		View p = view.findViewById(R.id.buttonPanel);
		p.setVisibility(View.VISIBLE);
		Button btn = (Button) view.findViewById(R.id.button2);
		btn.setText(text);
		if (listener == null) {
			btn.setOnClickListener(this);
		} else {
			btn.setOnClickListener(listener);
		}
		btn.setVisibility(View.VISIBLE);
	}
	
	public void show() {
		dialog.setContentView(view);
		dialog.show();
	}

	public void dismiss() {
		dialog.dismiss();
	}

	@Override
	public void onClick(View v) {
		dismiss();
	}
	
	public Window getWindow() {
		return dialog.getWindow();
	}

}
