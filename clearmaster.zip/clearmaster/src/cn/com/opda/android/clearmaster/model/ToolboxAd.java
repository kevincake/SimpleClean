package cn.com.opda.android.clearmaster.model;

import java.util.ArrayList;

public class ToolboxAd {
	private ArrayList<AdInfo> adInfos;

	public ArrayList<AdInfo> getAdInfos() {
		return adInfos;
	}

	public void setAdInfos(ArrayList<AdInfo> adInfos) {
		this.adInfos = adInfos;
	}
}
