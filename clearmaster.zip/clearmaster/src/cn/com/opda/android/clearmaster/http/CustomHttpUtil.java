package cn.com.opda.android.clearmaster.http;

import java.util.Map;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import cn.com.opda.android.clearmaster.utils.Constants;
import cn.com.opda.android.clearmaster.utils.DLog;

/**
 * HTTP 请求类
 * 
 * @author Administrator
 * 
 */
public class CustomHttpUtil {
	public static final String UTF8 = "utf-8";

	/**
	 * 普通POST表单请求
	 * 
	 * @param path
	 * @param params
	 * @param encoding
	 * @param context
	 * @return
	 * @throws Exception
	 */
	public static String sendPostRequest(String path, Map<String, String> params, String encoding, Context context) throws Exception {
		return sendPostRequest(path, params, encoding, (FormFile) null, context);
	}

	/**
	 * 包含文件上传功能
	 * 
	 * @param path
	 * @param params
	 * @param encoding
	 * @param formFile
	 *            文件
	 * @param context
	 * @return
	 * @throws Exception
	 */
	public static String sendPostRequest(String path, Map<String, String> params, String encoding, FormFile formFile, Context context) throws Exception {
		return sendPostRequest(path, params, encoding, true, formFile, context);
	}

	/**
	 * 包含文件上传功能和是否发送cookie
	 * 
	 * @param path
	 * @param params
	 * @param encoding
	 * @param needSendCookie
	 *            是否发送cookie
	 * @param formFile
	 *            文件
	 * @param context
	 * @return
	 * @throws Exception
	 */
	public static String sendPostRequest(String path, Map<String, String> params, String encoding, boolean needSendCookie, FormFile formFile, Context context)
			throws Exception {
		String json = null;
		if (params != null && !params.isEmpty()) {
			PackageManager packageManager = context.getPackageManager();
			PackageInfo packageInfo = packageManager.getPackageInfo(context.getPackageName(), 0);
			params.put("appversion", packageInfo != null ? packageInfo.versionCode + "" : "0");
			params.put("appcode", Constants.UPDATE_APPCODE);
			DLog.i("debug", "request--->" + "path：" + path + "\nrequest:" + params.toString());
		}
		CustomHttpClient httpClient = CustomHttpClient.getInstance();
		httpClient.sendCookie = needSendCookie;
		if (!httpClient.sendCookie) {// 只有在登录、注册的时候不发送cookie
			httpClient.connTimeOut = 40000;
			httpClient.readTimeOut = 180000;
		}
		json = httpClient.post(context, path, encoding, params, formFile);
		DLog.i("debug", "response------>" + json);
		return json;
	}
}
