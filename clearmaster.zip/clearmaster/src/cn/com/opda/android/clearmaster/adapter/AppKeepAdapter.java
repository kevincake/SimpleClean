package cn.com.opda.android.clearmaster.adapter;

import java.util.ArrayList;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import cn.com.opda.android.clearmaster.R;
import cn.com.opda.android.clearmaster.dao.KeepListUtils;

/**
 * 白名单适配器
 * 
 * @author 庄宏岩
 * 
 */
public class AppKeepAdapter extends BaseAdapter {
	private ArrayList<ApplicationInfo> mKeepAppInfos;
	private LayoutInflater mLayoutInflater;
	private Context mContext;
	private Drawable defaultIcon;
	private PackageManager pm;

	public AppKeepAdapter(Context mContext, ArrayList<ApplicationInfo> mKeepAppInfos) {
		this.mKeepAppInfos = mKeepAppInfos;
		this.mContext = mContext;
		mLayoutInflater = LayoutInflater.from(mContext);
		defaultIcon = mContext.getResources().getDrawable(android.R.drawable.sym_def_app_icon);
		pm = mContext.getPackageManager();
	}

	@Override
	public int getCount() {
		return mKeepAppInfos.size();
	}

	@Override
	public Object getItem(int position) {
		return mKeepAppInfos.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		final Holder mHolder;
		if (convertView == null) {
			convertView = mLayoutInflater.inflate(R.layout.listview_keep_item, null);
			mHolder = new Holder();
			mHolder.keep_item_name_textview = (TextView) convertView.findViewById(R.id.keep_item_name_textview);
			mHolder.keep_item_state_checkbox = (CheckBox) convertView.findViewById(R.id.keep_item_state_checkbox);
			mHolder.keep_item_icon_imageview = (ImageView) convertView.findViewById(R.id.keep_item_icon_imageview);
			convertView.setTag(mHolder);
		} else {
			mHolder = (Holder) convertView.getTag();
			if (mHolder.imageLoader != null) {
				mHolder.imageLoader.cancel(true);
			}
		}

		final ApplicationInfo mKeepAppInfo = mKeepAppInfos.get(position);
		mHolder.keep_item_name_textview.setText(mKeepAppInfo.name);
		mHolder.keep_item_icon_imageview.setImageDrawable(defaultIcon);

		if (mKeepAppInfo.enabled) {
			mHolder.keep_item_state_checkbox.setChecked(true);
		} else {
			mHolder.keep_item_state_checkbox.setChecked(false);
		}

		mHolder.keep_item_state_checkbox.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				mKeepAppInfo.enabled = !mKeepAppInfo.enabled;
				if (mKeepAppInfo.enabled) {
					KeepListUtils.save(mContext, mKeepAppInfo.packageName);
					mHolder.keep_item_state_checkbox.setChecked(true);
				} else {
					KeepListUtils.delete(mContext, mKeepAppInfo.packageName);
					mHolder.keep_item_state_checkbox.setChecked(false);
				}
			}
		});
		convertView.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				mKeepAppInfo.enabled = !mKeepAppInfo.enabled;
				if (mKeepAppInfo.enabled) {
					KeepListUtils.save(mContext, mKeepAppInfo.packageName);
					mHolder.keep_item_state_checkbox.setChecked(true);
				} else {
					KeepListUtils.delete(mContext, mKeepAppInfo.packageName);
					mHolder.keep_item_state_checkbox.setChecked(false);
				}
			}
		});

		mHolder.imageLoader = new AsyncTask<Holder, Void, Drawable>() {
			private Holder holder;

			@Override
			protected Drawable doInBackground(Holder... params) {
				holder = params[0];
				return mKeepAppInfo.loadIcon(pm);
			}

			@Override
			protected void onPostExecute(Drawable result) {
				holder.keep_item_icon_imageview.setImageDrawable(result);
			}
		}.execute(mHolder);

		return convertView;
	}

	private class Holder {
		private ImageView keep_item_icon_imageview;
		private TextView keep_item_name_textview;
		private CheckBox keep_item_state_checkbox;
		AsyncTask<Holder, Void, Drawable> imageLoader;
	}

}
