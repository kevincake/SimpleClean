package cn.com.opda.android.clearmaster;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;
import android.os.Parcelable;
import android.preference.PreferenceManager;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import cn.com.opda.android.clearmaster.custom.CustomActivity;
import cn.com.opda.android.clearmaster.custom.CustomDialog2;
import cn.com.opda.android.clearmaster.custom.CustomDialogForChonfuApp;
import cn.com.opda.android.clearmaster.model.AppItem;
import cn.com.opda.android.clearmaster.model.VerboseApp;
import cn.com.opda.android.clearmaster.utils.VerboseUtils;

public class SoftwareUninstallActivity extends CustomActivity implements OnClickListener {
	private boolean init;
	private Handler mManagerHandler;
	private String nowPage = getString(R.string.uninstall_user_app);
	private UninstallUserApp uninstallUserApp;
	private UninstallSystemApp uninstallSystemApp;
	private UninstallChongfuApp uninstallChongfuApp;
	private UninstallHaoziyuanApp uninstallHaoziyuanApp;
	private List<PackageInfo> installAppList;
	private ArrayList<VerboseApp> mVerboseApps;

	private ViewPager mPager;// 页卡内容
	private List<View> listViews; // Tab页面列表
	private ImageView cursor;// 动画图片
	private int offset = 0;// 动画图片偏移量
	private int currIndex = 0;// 当前页卡编号
	private int bmpW;// 动画图片宽度
	private int screenW;
	private TextView viewpager_tab1, viewpager_tab2, viewpager_tab3, viewpager_tab4;
	private ImageView iv_touch_me2;
	private SharedPreferences sp;
	
	private boolean stop;
	
	private boolean checked;
	private Handler mHandler = new Handler(){


		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			switch (msg.what) {
			case 0:
				final CustomDialogForChonfuApp customDialog2 = new CustomDialogForChonfuApp(mContext);
				customDialog2.setCancelable(false);
				customDialog2.setMessage("发现有重复应用占用资源，是否去查看？");
				final CheckBox cb_check = (CheckBox) customDialog2.getCheck();
				
				customDialog2.setcheck(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						if (cb_check.isChecked()) {
							cb_check.setChecked(false);
							checked = false;
						} else {
							cb_check.setChecked(true);
							checked = true;
						}
					}
				});
				customDialog2.setButton1("取消", null);
				customDialog2.setButton2("查看", new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						customDialog2.dismiss();
						mPager.setCurrentItem(3);
						if (checked) {
							sp.edit().putBoolean("no_longer", true).commit();
						}
					}
				});
				if(!stop){
					customDialog2.show();
				}
				
				break;

			default:
				break;
			}
		}
		
	};
	

	public SoftwareUninstallActivity(Context context, int resId, Handler mManagerHandler) {
		super(context, resId);
		mContext = context;
		this.mManagerHandler = mManagerHandler;
		initViewAndEvent();
		initTextView();
		initImageView();
		initViewPager();
		update();
		
	}

	private void initViewAndEvent() {
		sp = PreferenceManager.getDefaultSharedPreferences(mContext);
		iv_touch_me2 = (ImageView) findViewById(R.id.iv_touch_me2);
		if (sp.getBoolean("gone", false)) {
			iv_touch_me2.setVisibility(View.GONE);
		} else {
			iv_touch_me2.setVisibility(View.VISIBLE);
		}
	}
	private int getVerCode() {
        int verCode = -1;
        try {
            verCode = mContext.getPackageManager().getPackageInfo(mContext.getPackageName(), 0).versionCode;
        } catch (NameNotFoundException e) {
            Log.e("msg", e.getMessage());
        }
        return verCode;
    }

	@Override
	public void initData() {
		if (!init) {
			init = true;
		}
	}

	/**
	 * 初始化头标
	 */
	private void initTextView() {
		viewpager_tab1 = (TextView) findViewById(R.id.viewpager_tab1);
		viewpager_tab2 = (TextView) findViewById(R.id.viewpager_tab2);
		viewpager_tab3 = (TextView) findViewById(R.id.viewpager_tab3);
		viewpager_tab4 = (TextView) findViewById(R.id.viewpager_tab4);

		viewpager_tab1.setOnClickListener(this);
		viewpager_tab2.setOnClickListener(this);
		viewpager_tab3.setOnClickListener(this);
		viewpager_tab4.setOnClickListener(this);

	}

	/**
	 * 初始化ViewPager
	 */
	private void initViewPager() {
		mPager = (ViewPager) findViewById(R.id.vPager);

		listViews = new ArrayList<View>();

		uninstallUserApp = new UninstallUserApp(mContext, R.layout.uninstall_user_app, this);
		uninstallUserApp.initData();
		uninstallSystemApp = new UninstallSystemApp(mContext, R.layout.uninstall_system_app, this);
		uninstallHaoziyuanApp = new UninstallHaoziyuanApp(mContext, R.layout.uninstall_haoziyuan_app, this);
		uninstallChongfuApp = new UninstallChongfuApp(mContext, R.layout.uninstall_chongfu_app, this);

		listViews.add(uninstallUserApp.getView());
		listViews.add(uninstallSystemApp.getView());
		listViews.add(uninstallHaoziyuanApp.getView());
		listViews.add(uninstallChongfuApp.getView());
		mPager.setAdapter(new MyPagerAdapter(listViews));
		mPager.setCurrentItem(0);
		mPager.setOnPageChangeListener(new MyOnPageChangeListener());

	}

	/**
	 * 初始化动画
	 */
	private void initImageView() {
		cursor = (ImageView) findViewById(R.id.cursor);
		bmpW = BitmapFactory.decodeResource(mContext.getResources(), R.drawable.indicator_blue_small).getWidth();// 获取图片宽度
		DisplayMetrics dm = new DisplayMetrics();
		((Activity)mContext).getWindowManager().getDefaultDisplay().getMetrics(dm);
		screenW = dm.widthPixels;// 获取分辨率宽度
		offset = (screenW / 4 - bmpW) / 2;// 计算偏移量
		Matrix matrix = new Matrix();
		matrix.postTranslate(offset, 0);

		cursor.setImageMatrix(matrix);// 设置动画初始位置
	}

	/**
	 * ViewPager适配器
	 */
	public class MyPagerAdapter extends PagerAdapter {
		public List<View> mListViews;

		public MyPagerAdapter(List<View> mListViews) {
			this.mListViews = mListViews;
		}

		@Override
		public void destroyItem(View view, int position, Object object) {
			((ViewPager) view).removeView(mListViews.get(position));
		}

		@Override
		public void finishUpdate(View view) {

		}

		@Override
		public int getCount() {
			return mListViews.size();
		}

		@Override
		public Object instantiateItem(View view, int position) {
			((ViewPager) view).addView(mListViews.get(position), 0);
			return mListViews.get(position);
		}

		@Override
		public boolean isViewFromObject(View view, Object obj) {
			return view == (obj);
		}

		@Override
		public void restoreState(Parcelable view, ClassLoader classLoader) {
		}

		@Override
		public Parcelable saveState() {
			return null;
		}

		@Override
		public void startUpdate(View view) {
		}
	}

	public class MyOnPageChangeListener implements OnPageChangeListener {
		int one = offset + screenW / 4;
		int two = offset + (screenW / 4) * 2;
		int three = offset + (screenW / 4) * 3;

		@Override
		public void onPageSelected(int position) {
			currIndex = position;
			switch (currIndex) {
			case 0:
				nowPage = getString(R.string.uninstall_user_app);
				mManagerHandler.sendEmptyMessageAtTime(2, 0);
				uninstallUserApp.initData();
				break;
			case 1:
				nowPage = getString(R.string.uninstall_system_app);
				mManagerHandler.sendEmptyMessageAtTime(2, 0);
				if (uninstallUserApp.getSystemApps().size() > 0) {
					uninstallSystemApp.initData(uninstallUserApp.getSystemApps());
				} else {
					uninstallSystemApp.initData();
				}
				break;
			case 2:
				nowPage = getString(R.string.uninstall_haoziyuan_app);
				mManagerHandler.sendEmptyMessageAtTime(1, 0);
				uninstallHaoziyuanApp.initData();
				break;
			case 3:
				nowPage = getString(R.string.uninstall_chongfu_app);
				mManagerHandler.sendEmptyMessageAtTime(1, 0);
				uninstallChongfuApp.initData();
				sp.edit().putBoolean("gone", true).commit();
				iv_touch_me2.setVisibility(View.GONE);
				break;

			default:
				break;
			}

		}

		@Override
		public void onPageScrolled(int arg0, float arg1, int arg2) {
			Matrix matrix = new Matrix();
			switch (arg0) {
			case 0:
				matrix.postTranslate(offset + (one - offset) * arg1, 0);
				break;
			case 1:
				matrix.postTranslate(one + (two - one) * arg1, 0);
				break;
			case 2:
				matrix.postTranslate(two + (two - one) * arg1, 0);
				break;
			case 3:
				matrix.postTranslate(three + (two - one) * arg1, 0);
				break;

			default:
				break;
			}
			cursor.setImageMatrix(matrix);
		}

		@Override
		public void onPageScrollStateChanged(int position) {

		}
	}
	private int count = 0;
	private void update() {
		new Thread(new Runnable() {
			Activity ac = new Activity();

			@Override
			public void run() {
				String verboseJson = VerboseUtils.getJson(mContext);
				if (!TextUtils.isEmpty(verboseJson)) {
					mVerboseApps = VerboseUtils.getSurplusAppsByJson(mContext, verboseJson);
				} else {
					mVerboseApps = VerboseUtils.getSurplusApps(mContext);
				}
				ac.runOnUiThread(new Runnable() {

					@Override
					public void run() {

						if (mVerboseApps != null && mVerboseApps.size() > 0) {
							if (installAppList != null) {
								installAppList.clear();
								installAppList = null;
							}
							for (VerboseApp verboseApp : mVerboseApps) {
								new GetVerboseTask(verboseApp).execute();
							}
						}
					}
				});
			}
		}).start();
	}
	
	
	private class GetVerboseTask extends AsyncTask<Void, AppItem, Integer> {
		private VerboseApp verboseApp;
		private ArrayList<AppItem> appItems;

		public GetVerboseTask(VerboseApp verboseApp) {
			this.verboseApp = verboseApp;
			appItems = new ArrayList<AppItem>();
		}

		@Override
		protected void onPreExecute() {

		}

		@Override
		protected Integer doInBackground(Void... params) {
			PackageManager pm = mContext.getPackageManager();
			if (installAppList == null) {
				installAppList = pm.getInstalledPackages((PackageManager.GET_UNINSTALLED_PACKAGES));
			}
			ArrayList<String> strings = verboseApp.getPackages();
			if (installAppList != null) {
				for (PackageInfo packageInfo : installAppList) {
					if (stop) {
						break;
					}
					ApplicationInfo applicationInfo = packageInfo.applicationInfo;
					if (applicationInfo == null) {
						continue;
					}
					if (applicationInfo.packageName.equals(mContext.getPackageName())) {
						continue;
					}
					final String sourceDir = applicationInfo.sourceDir;
					boolean flag = false;
					if ((applicationInfo.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0) {
						flag = true;
					} else if ((applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
						flag = true;
					}
					if (flag && sourceDir != null) {
						for (String string : strings) {
							if (stop) {
								break;
							}
							if (string.equals(applicationInfo.packageName)) {
								final AppItem mAppItem = new AppItem();
								mAppItem.setAppPackage(applicationInfo.packageName);
								mAppItem.setAppName(applicationInfo.loadLabel(pm).toString().trim());
								mAppItem.setAppIcon(applicationInfo.loadIcon(pm));
								mAppItem.setCodeSize(new File(sourceDir).length());
								mAppItem.setChongfuApp(true);
								if (mAppItem.getCodeSize() > 0) {
									publishProgress(mAppItem);
								}
								break;
							}
						}
					}
				}
			}

			return null;

		}

		@Override
		protected void onProgressUpdate(AppItem... values) {
			if (values.length > 0) {
				AppItem appInfo = values[0];
				appItems.add(appInfo);
				verboseApp.setAppItems(appItems);
			}
			super.onProgressUpdate(values);
		}

		@Override
		protected void onPostExecute(Integer result) {
			super.onPostExecute(result);
			verboseApp.setFinish(true);
			ArrayList<AppItem> appItems = null;
			count ++;
			if (count == 4 && !sp.getBoolean("no_longer", false)) {
				for (int i = 0; i < mVerboseApps.size(); i++) {
					appItems = mVerboseApps.get(i).getAppItems();
					if (appItems != null && appItems.size() >= 2) {
						if(!stop){
							mHandler.sendEmptyMessageDelayed(0, 3000);
						}
						break;
					}
				}
			}
		}
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.viewpager_tab1:
			mPager.setCurrentItem(0);
			break;
		case R.id.viewpager_tab2:
			mPager.setCurrentItem(1);
			break;

		case R.id.viewpager_tab3:
			mPager.setCurrentItem(2);
			break;
		case R.id.viewpager_tab4:
			mPager.setCurrentItem(3);
			sp.edit().putBoolean("gone", true).commit();
			iv_touch_me2.setVisibility(View.GONE);
			break;

		default:
			break;
		}
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		stop = true;
		if (uninstallUserApp != null) {
			uninstallUserApp.onDestroy();
		}
		if (uninstallSystemApp != null) {
			uninstallSystemApp.onDestroy();
		}
		if (uninstallChongfuApp != null) {
			uninstallChongfuApp.onDestroy();
		}
		if (uninstallHaoziyuanApp != null) {
			uninstallHaoziyuanApp.onDestroy();
		}
	}

	public String getPageType() {
		return nowPage;
	}

	public void updateUserAdapter() {
		uninstallUserApp.updateUserAdapter();
	}

	public void updateSystemAdapter() {
		uninstallSystemApp.updateSystemAdapter();
	}

	public void updateUserAdapter(ArrayList<AppItem> filterDateList) {
		uninstallUserApp.updateUserAdapter(filterDateList);
	}

	public void updateSystemAdapter(ArrayList<AppItem> filterDateList) {
		uninstallSystemApp.updateSystemAdapter(filterDateList);
	}

	public void notifyUserAdapter() {
		uninstallUserApp.notifyUserAdapter();
	}

	public void notifySystemAdapter() {
		uninstallSystemApp.notifySystemAdapter();
	}

	public ArrayList<AppItem> getUserApps() {
		return uninstallUserApp.getUserApps();
	}

	public ArrayList<AppItem> getSystemApps() {
		return uninstallSystemApp.getSystemApps();
	}

	public View getNoResultView() {
		if (nowPage.equals(mContext.getString(R.string.uninstall_user_app))) {
			uninstallUserApp.getNoResultView();
		} else if (nowPage.equals(mContext.getString(R.string.uninstall_system_app))) {
			uninstallSystemApp.getNoResultView();
		}
		return uninstallUserApp.getNoResultView();

	}

	@Override
	public void onResume() {
		switch (currIndex) {
		case 0:
			if (uninstallUserApp != null) {
				uninstallUserApp.onResume();
			}
			break;
		case 1:
			if (uninstallSystemApp != null) {
				uninstallSystemApp.onResume();
			}
			break;
		case 2:
			if (uninstallHaoziyuanApp != null) {
				uninstallHaoziyuanApp.onResume();
			}
			break;
		case 3:
			if (uninstallChongfuApp != null) {
				uninstallChongfuApp.onResume();
			}
			break;

		default:
			break;
		}

	}

	public void removeChongfuAdapter(AppItem appItem) {
		uninstallChongfuApp.removeApp(appItem);
	}

	public void removeHaoziyuanAdapter(AppItem appItem) {
		uninstallHaoziyuanApp.removeApp(appItem);
	}

	public void removeUserAdapter(AppItem appItem) {
		uninstallUserApp.removeApp(appItem);
	}
}
