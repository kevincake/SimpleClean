package cn.com.opda.android.clearmaster.custom;

import android.content.Context;
import android.content.Intent;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;

/**
 * viewpager 子view
 * @author 庄宏岩
 *
 */
public abstract class CustomActivity {
	public final static String TAG = "CustomActivity";
	protected Context mContext;
	private View mView;
	private String title;
	public LayoutInflater mInflater;

	public CustomActivity(Context context, int resId) {
		this.mContext = context;
		this.mInflater = LayoutInflater.from(mContext);
		onCreate(resId);
	}

	public void afterHandler() {
		mView.invalidate();
	}

	public abstract void onResume();
	public abstract void initData();

	public View getView() {
		return mView;
	}

	public void onDestroy() {
		
	}

	public boolean onKeyDown(int keyCode, KeyEvent event) {
		return false;
	}

	private void onCreate(int resId) {
		mView = mInflater.inflate(resId, null);
	}

	public View findViewById(int resId) {
		return mView.findViewById(resId);
	}

	public void setRepeatResume() {
		onResume();
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void onActivityResult(int requestCode, int resultCode, Intent data) {

	}

	public String getString(int resId) {
		return mContext.getString(resId);
	}
}
