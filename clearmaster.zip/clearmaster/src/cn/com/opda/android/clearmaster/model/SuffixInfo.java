package cn.com.opda.android.clearmaster.model;

public class SuffixInfo {
	private String suffixName;
	private boolean checked;
	private String suffixType;
	
	public String getSuffixType() {
		return suffixType;
	}
	public void setSuffixType(String suffixType) {
		this.suffixType = suffixType;
	}
	public String getSuffixName() {
		return suffixName;
	}
	public void setSuffixName(String suffixName) {
		this.suffixName = suffixName;
	}
	public boolean isChecked() {
		return checked;
	}
	public void setChecked(boolean checked) {
		this.checked = checked;
	}
	
}
