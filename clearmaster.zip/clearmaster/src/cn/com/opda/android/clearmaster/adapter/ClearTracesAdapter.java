package cn.com.opda.android.clearmaster.adapter;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import cn.com.opda.android.clearmaster.R;
import cn.com.opda.android.clearmaster.model.TraceItem;

/**
 * 痕迹清理listview适配器
 * 
 * @author 庄宏岩
 * 
 */
public class ClearTracesAdapter extends BaseAdapter {
	private ArrayList<TraceItem> mTraceItems;
	private LayoutInflater mLayoutInflater;

	public ClearTracesAdapter(Context mContext, ArrayList<TraceItem> mTraceItems) {
		this.mTraceItems = mTraceItems;
		mLayoutInflater = LayoutInflater.from(mContext);
	}

	@Override
	public int getCount() {
		return mTraceItems.size();
	}

	@Override
	public Object getItem(int position) {
		return mTraceItems.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	public void setAllChecked(boolean isChecked) {
		for (TraceItem traceItem : mTraceItems) {
			if (!traceItem.isAcvitiy()) {
				traceItem.setChecked(isChecked);
			}
		}
		notifyDataSetChanged();
	}

	public void remove(int i) {
		mTraceItems.remove(i);
		notifyDataSetChanged();
	}

	public void remove(TraceItem traceItem) {
		mTraceItems.remove(traceItem);
		notifyDataSetChanged();
	}

	public ArrayList<TraceItem> getSelecteList() {
		ArrayList<TraceItem> traceItems = new ArrayList<TraceItem>();
		for (TraceItem traceItem : mTraceItems) {
			if (traceItem.isChecked()) {
				traceItems.add(traceItem);
			}
		}
		return traceItems;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		final Holder mHolder;
		if (convertView == null) {
			convertView = mLayoutInflater.inflate(R.layout.listview_trace_item, null);
			mHolder = new Holder();
			mHolder.trace_item_name_textview = (TextView) convertView.findViewById(R.id.trace_item_name_textview);
			mHolder.trace_item_value_textview = (TextView) convertView.findViewById(R.id.trace_item_value_textview);
			mHolder.trace_item_checked_imageview = (CheckBox) convertView.findViewById(R.id.trace_item_checked_imageview);
			mHolder.trace_item_arrow_imageview = (ImageView) convertView.findViewById(R.id.trace_item_arrow_imageview);
			mHolder.trace_item_icon_imageview = (ImageView) convertView.findViewById(R.id.trace_item_icon_imageview);
			convertView.setTag(mHolder);
		} else {
			mHolder = (Holder) convertView.getTag();
		}

		final TraceItem traceItem = mTraceItems.get(position);
		mHolder.trace_item_name_textview.setText(traceItem.getTraceName());
		mHolder.trace_item_icon_imageview.setImageDrawable(traceItem.getIcon());
		if (traceItem.isShowValue()) {
			mHolder.trace_item_value_textview.setVisibility(View.VISIBLE);
			mHolder.trace_item_value_textview.setText(traceItem.getValue());
		} else {
			mHolder.trace_item_value_textview.setVisibility(View.GONE);
		}
		if (!traceItem.isAcvitiy()) {
			mHolder.trace_item_arrow_imageview.setVisibility(View.GONE);
			mHolder.trace_item_checked_imageview.setVisibility(View.VISIBLE);
			mHolder.trace_item_checked_imageview.setChecked(traceItem.isChecked());

			mHolder.trace_item_checked_imageview.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					traceItem.setChecked(!traceItem.isChecked());
				}
			});
		} else {
			mHolder.trace_item_arrow_imageview.setVisibility(View.VISIBLE);
			mHolder.trace_item_checked_imageview.setVisibility(View.GONE);
		}
		return convertView;
	}

	private class Holder {
		private TextView trace_item_name_textview;
		private TextView trace_item_value_textview;
		private CheckBox trace_item_checked_imageview;
		private ImageView trace_item_arrow_imageview;
		private ImageView trace_item_icon_imageview;
	}

}
