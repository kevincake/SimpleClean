//package cn.com.opda.android.clearmaster.dao;
//
//import java.util.ArrayList;
//
//import android.content.Context;
//import android.database.Cursor;
//import android.database.SQLException;
//import android.database.sqlite.SQLiteDatabase;
//import android.util.Log;
//import cn.com.opda.android.clearmaster.model.ClearItem;
//import cn.com.opda.android.clearmaster.utils.BaseJsonUtil;
//
///**
// * 缓存目录数据库操作类
// * @author 庄宏岩
// * 
// */
//public class DBAppCacheUtils extends BaseJsonUtil {
//	private static final String TAG = "db";
//
//	public DBAppCacheUtils(Context context) {
//		super(context);
//	}
//
//	/**
//	 * @param info
//	 * @param context
//	 *            把信息保存到数据库
//	 */
//	public static void save(Context context, ClearItem info) {
//		DBCleanUpOpenHelper tdbOpenHelper = new DBCleanUpOpenHelper(context);
//		SQLiteDatabase db = tdbOpenHelper.getWritableDatabase();
//		Cursor cursor = db.rawQuery("select * from cache where filepath = ?", new String[] { info.getFilePath() });
//		try {
//			if (cursor == null || cursor.getCount() == 0) {
//				db.execSQL("insert into cache (package,cn_name,en_name,filepath) values(?,?,?,?)",
//						new Object[] { info.getPackageName(), info.getCname(), info.getEname(), info.getFilePath() });
//				Log.i(TAG, "save()");
//			} else {
//				Log.i(TAG, "data is exists");
//			}
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}finally{
//			if (cursor != null) {
//				cursor.close();
//			}
//			db.close();
//			tdbOpenHelper.close();
//		}
//	}
//
//	/**
//	 * @param context
//	 * @return 从数据库中获取所有数据并返回一个集合
//	 */
//	public static ArrayList<ClearItem> get(Context context, String packageName) {
//		ArrayList<ClearItem> list = new ArrayList<ClearItem>();
//		ArrayList<String> cacheWhiteList = CacheWhiteListUtils.getAllList(context);
//		if(cacheWhiteList.contains(packageName)){
//			return list;
//		}
//		DBCleanUpOpenHelper tdbOpenHelper = new DBCleanUpOpenHelper(context);
//		SQLiteDatabase db = tdbOpenHelper.getWritableDatabase();
//		Cursor cursor = db.rawQuery("select * from cache where package=?", new String[] { packageName });
//		try {
//			if (cursor != null) {
//				while (cursor.moveToNext()) {
//					ClearItem info = new ClearItem();
//					info.setPackageName(packageName);
//					info.setCname(cursor.getString(2));
//					info.setEname(cursor.getString(3));
//					info.setFilePath(cursor.getString(4));
//					list.add(info);
//				}
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		}finally{
//			if (cursor != null) {
//				cursor.close();
//			}
//			db.close();
//			tdbOpenHelper.close();
//		}
//		return list;
//	}
//	
//	/**
//	 * @param context
//	 * @return 从数据库中获取所有数据并返回一个集合
//	 */
//	public static ArrayList<ClearItem> get(Context context) {
//		ArrayList<ClearItem> list = new ArrayList<ClearItem>();
//		DBCleanUpOpenHelper tdbOpenHelper = new DBCleanUpOpenHelper(context);
//		SQLiteDatabase db = tdbOpenHelper.getWritableDatabase();
//		Cursor cursor = db.rawQuery("select * from cache", null);
//		try {
//			if (cursor != null) {
//				while (cursor.moveToNext()) {
//					ClearItem info = new ClearItem();
//					info.setPackageName(cursor.getString(1));
//					info.setCname(cursor.getString(2));
//					info.setEname(cursor.getString(3));
//					info.setFilePath(cursor.getString(4));
//					list.add(info);
//				}
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		}finally{
//			if (cursor != null) {
//				cursor.close();
//			}
//			db.close();
//			tdbOpenHelper.close();
//		}
//		return list;
//	}
//
//	public static void deleteTable(Context context) {
//		DBCleanUpOpenHelper tdbOpenHelper = new DBCleanUpOpenHelper(context);
//		SQLiteDatabase db = tdbOpenHelper.getWritableDatabase();
//		db.execSQL("delete from cache where 0=0");
//		db.close();
//		tdbOpenHelper.close();
//	}
//}
