package cn.com.opda.android.clearmaster.privacy;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import cn.com.opda.android.clearmaster.utils.Constants;

public class PicDBHelper {
	private static final String PicSqLiteName = Constants.FILE_PIC;
	private static SQLiteDatabase db;

	/**
	 * 创建并打开数据库
	 * 
	 * @param newversion
	 */
	public static void openOrCreateDb(int newversion) {
		db = SQLiteDatabase.openOrCreateDatabase(getDatabasePath(PicSqLiteName), null);
		int version = db.getVersion();
		if (version != newversion) {
			db.execSQL("drop table if exists pic_path");
			db.execSQL("create table if not exists pic_path (_id INTEGER  primary key autoincrement,pic_id TEXT,old_path TEXT,new_path TEXT)");
			db.setVersion(newversion);
		}
	}

	/**
	 * 加入备份数据库
	 * 
	 * @param infolist
	 */
	public static void addPic(List<PicInfo> infolist) {
		openOrCreateDb(1);
		for (int i = 0; i < infolist.size(); i++) {
			PicInfo info = infolist.get(i);
			db.execSQL("insert into pic_path (pic_id,old_path,new_path) values(?,?,?)", new Object[] { info.getPicId(), info.getOldPath(), info.getNewPath() });
		}
		close();

	}

	public static void addPic(PicInfo info) {
		openOrCreateDb(1);
		db.execSQL("insert into pic_path (pic_id,old_path,new_path) values(?,?,?)", new Object[] { info.getPicId(), info.getOldPath(), info.getNewPath() });
		close();
	}

	/**
	 * 根据id删除信息
	 */
	public static void deletePic(Context context, String picId) {
		openOrCreateDb(1);
		db.execSQL("delete from pic_path where pic_id=?", new Object[] { picId });
		close();
	}

	/**
	 * 根据id删除信息
	 */
	public static void deletePic(Context context, ArrayList<PicInfo> picInfos) {
		openOrCreateDb(1);
		for (PicInfo picInfo : picInfos) {
			db.execSQL("delete from pic_path where pic_id=?", new Object[] { picInfo.getPicId() });
		}
		close();
	}

	/**
	 * 阅读备份数据库
	 * 
	 * @return
	 */
	public static ArrayList<PicInfo> readPicList() {
		openOrCreateDb(1);
		ArrayList<PicInfo> list = new ArrayList<PicInfo>();
		Cursor cursor = db.rawQuery("select * from pic_path", null);
		if (cursor != null) {
			while (cursor.moveToNext()) {
				PicInfo info = new PicInfo();
				info.setId(cursor.getInt(0));
				info.setPicId(cursor.getString(1));
				info.setOldPath(cursor.getString(2));
				info.setNewPath(cursor.getString(3));
				list.add(info);
			}
			cursor.close();
		}
		close();
		return list;
	}

	public static void close() {
		if (db != null) {
			db.close();
		}
	}

	/**
	 * 创建数据库路径
	 * 
	 * @param name
	 * @return
	 */
	public static File getDatabasePath(String name) {
		File f = new File(Constants.BACKUP_DIR_PATH);
		if (!f.exists()) {
			f.mkdirs();
		}
		return new File(f, name);
	}

}
