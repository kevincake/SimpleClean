package cn.com.opda.android.clearmaster.utils.listsort;

import java.util.Comparator;

import cn.com.opda.android.clearmaster.privacy.PicInfo;

public class TimeComparatorForPrivacyPic implements Comparator<PicInfo>{

	@Override
	public int compare(PicInfo o1, PicInfo o2) {
		long num1 = o1.getDateAdded();
		long num2 = o2.getDateAdded();
		if (num1 < num2) {
			return 1;
		} else if (num1 == num2) {
			return 0;
		} else if (num1 > num2) {
			return -1;
		}
		return 0;
	
	}

}
