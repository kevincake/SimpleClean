package cn.com.opda.android.clearmaster.impl;

public interface ImageDownloadListener {
	abstract void finish(String imagePath);
	abstract void error();

}
