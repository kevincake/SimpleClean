package cn.com.opda.android.clearmaster;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CountDownLatch;

import android.Manifest.permission;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.IPackageStatsObserver;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageStats;
import android.net.TrafficStats;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.os.RemoteException;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnGroupClickListener;
import android.widget.ExpandableListView.OnGroupExpandListener;
import android.widget.Toast;
import cn.com.opda.android.clearmaster.adapter.Adapter4HaoZiYuanApp;
import cn.com.opda.android.clearmaster.custom.CustomActivity;
import cn.com.opda.android.clearmaster.custom.IOSProgressDialog;
import cn.com.opda.android.clearmaster.dao.AppListDBUtils;
import cn.com.opda.android.clearmaster.dao.AppNetFlowDBUtils2;
import cn.com.opda.android.clearmaster.dao.AppStartUpDBUtils;
import cn.com.opda.android.clearmaster.model.AppItem;
import cn.com.opda.android.clearmaster.model.SquanderApp;
import cn.com.opda.android.clearmaster.utils.AppManagerUtils;
import cn.com.opda.android.clearmaster.utils.ClearUtils;
import cn.com.opda.android.clearmaster.utils.CustomEventCommit;
import cn.com.opda.android.clearmaster.utils.DrawableUtils;
import cn.com.opda.android.clearmaster.utils.MemorySizeComparator;
import cn.com.opda.android.clearmaster.utils.NetFlowComparator2;
import cn.com.opda.android.clearmaster.utils.SpaceTimeComparator;
import cn.com.opda.android.clearmaster.utils.Terminal;

public class UninstallHaoziyuanApp extends CustomActivity implements OnClickListener {
	private boolean stop;
	private Button clear_button;
	private ExpandableListView haoziyuan_listview;
	private ArrayList<SquanderApp> squanderApps;
	private Adapter4HaoZiYuanApp adapter4HaoZiYuanApp;
	private ArrayList<AppItem> appItems;
	private ArrayList<AppItem> netFlowInfos;
	private ArrayList<AppItem> startUps;
	private ArrayList<ArrayList<AppItem>> childList = new ArrayList<ArrayList<AppItem>>();
	private SoftwareUninstallActivity softwareUninstallActivity;
	private long freeMemory;
	private IOSProgressDialog mIosProgressDialog;
	private boolean init;
	private ArrayList<AppItem> uninstallApps = new ArrayList<AppItem>();
	private AppItem uninstallApp;

	public UninstallHaoziyuanApp(Context context, int resId, SoftwareUninstallActivity softwareUninstallActivity) {
		super(context, resId);
		this.softwareUninstallActivity = softwareUninstallActivity;
		initViewAndEvent();
	}

	private void initViewAndEvent() {
		haoziyuan_listview = (ExpandableListView) findViewById(R.id.haoziyuan_listview);
		clear_button = (Button) findViewById(R.id.clear_button);
		clear_button.setOnClickListener(this);
	}

	@Override
	public void onResume() {
		if (uninstallApps != null && uninstallApps.size() > 0 && !Terminal.isRoot(mContext)) {
			updateUnstalledHaoziyuanAdapter();
			updateUnstalledChongfuAdapter();
			updateUnstalledUserAdapter();
			uninstallApps.clear();
		}
	}

	@Override
	public void initData() {
		if (!init) {
			init = true;
			initHaoZiYuanApp();
		}
	}

	private void initHaoZiYuanApp() {
		squanderApps = new ArrayList<SquanderApp>();
		SquanderApp squanderApp = new SquanderApp();
		squanderApp.setType("battery");
		squanderApp.setName("耗电量的应用");
		squanderApps.add(squanderApp);

		squanderApp = new SquanderApp();
		squanderApp.setType("memory");
		squanderApp.setName("耗内存的应用");
		squanderApps.add(squanderApp);

		if (Build.VERSION.SDK_INT > 7) {
			squanderApp = new SquanderApp();
			squanderApp.setType("netflow");
			squanderApp.setName("耗流量的应用");
			squanderApps.add(squanderApp);
		}

		int state = mContext.getPackageManager().checkPermission(permission.READ_LOGS, mContext.getPackageName());
		if (state == PackageManager.PERMISSION_GRANTED) {
			squanderApp = new SquanderApp();
			squanderApp.setType("startup");
			squanderApp.setName("长期不用的应用");
			squanderApps.add(squanderApp);
		}

		appItems = AppListDBUtils.getList(mContext);
		startUps = AppListDBUtils.getList(mContext);
		if (appItems != null && appItems.size() > 0) {
			new GetAppTask(appItems).execute();
		} else {
			new GetAppTask(null).execute();
		}

		netFlowInfos = AppNetFlowDBUtils2.getList(mContext);
		if (netFlowInfos != null && netFlowInfos.size() > 0) {
			// 如果数据库中有数据,直接使用数据库中的数据
			Collections.sort(netFlowInfos, new NetFlowComparator2());
		} else {
			// 数据库无数据重新扫描
			new GetNetFlowAppTask().execute();
		}

		if (startUps != null && startUps.size() > 0) {
			new GetStartUpAppTask(startUps).execute();
		} else {
			new GetStartUpAppTask(null).execute();
		}

		childList.add(new ArrayList<AppItem>());
		childList.add(appItems);
		childList.add(netFlowInfos);
		childList.add(startUps);
		adapter4HaoZiYuanApp = new Adapter4HaoZiYuanApp(mContext, squanderApps, childList, mHandler);
		haoziyuan_listview.setAdapter(adapter4HaoZiYuanApp);

		haoziyuan_listview.setOnGroupClickListener(new OnGroupClickListener() {

			@Override
			public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
				SquanderApp squanderApps = (SquanderApp) adapter4HaoZiYuanApp.getGroup(groupPosition);
				if (squanderApps.getType().equals("battery")) {
					try {
						mContext.startActivity(new Intent(Intent.ACTION_POWER_USAGE_SUMMARY));
					} catch (Exception e) {
						e.printStackTrace();
					}
					return true;
				} else {
					adapter4HaoZiYuanApp.setOtherAppUncheck(1);
					adapter4HaoZiYuanApp.setOtherAppUncheck(2);
					adapter4HaoZiYuanApp.setOtherAppUncheck(3);
					mHandler.sendEmptyMessage(119);
					return false;
				}
//				else if (squanderApps.getType().equals("memory")) {
//					adapter4HaoZiYuanApp.setOtherAppUncheck(2);
//					adapter4HaoZiYuanApp.setOtherAppUncheck(3);
//					mHandler.sendEmptyMessage(119);
//					return false;
//				} else if (squanderApps.getType().equals("netflow")) {
//					adapter4HaoZiYuanApp.setOtherAppUncheck(1);
//					adapter4HaoZiYuanApp.setOtherAppUncheck(3);
//					mHandler.sendEmptyMessage(119);
//					return false;
//				} else if (squanderApps.getType().equals("startup")) {
//					adapter4HaoZiYuanApp.setOtherAppUncheck(1);
//					adapter4HaoZiYuanApp.setOtherAppUncheck(2);
//					mHandler.sendEmptyMessage(119);
//					return false;
//				}
//				return true;
			}
		});
		// 这里是控制只有一个group展开的效果
		haoziyuan_listview.setOnGroupExpandListener(new OnGroupExpandListener() {
			@Override
			public void onGroupExpand(int groupPosition) {
				for (int i = 0; i < adapter4HaoZiYuanApp.getGroupCount(); i++) {
					if (groupPosition != i) {
						haoziyuan_listview.collapseGroup(i);
					}
				}
			}
		});
	}

	private class GetAppTask extends AsyncTask<Void, AppItem, Integer> {
		private ArrayList<AppItem> tempList;

		public GetAppTask(ArrayList<AppItem> appItems) {
			this.tempList = appItems;
		}

		@Override
		protected void onPreExecute() {
			if (appItems == null) {
				appItems = new ArrayList<AppItem>();
			} else {
				appItems.clear();
			}
		}

		@Override
		protected Integer doInBackground(Void... params) {
			PackageManager pm = mContext.getPackageManager();
			if (tempList != null && tempList.size() > 0) {
				for (final AppItem appItem : tempList) {
					if (stop) {
						break;
					}
					final CountDownLatch countDownLatch = new CountDownLatch(1);
					try {
						Method getPackageSizeInfo = pm.getClass().getMethod("getPackageSizeInfo", String.class, IPackageStatsObserver.class);
						getPackageSizeInfo.invoke(pm, appItem.getAppPackage(), new IPackageStatsObserver.Stub() {
							public void onGetStatsCompleted(PackageStats pStats, boolean succeeded) throws RemoteException {
								if (pStats != null) {
									appItem.setTypeFlag("memory");
									if (Build.VERSION.SDK_INT >= 14) {
										appItem.setMemorySize(pStats.cacheSize + pStats.codeSize + pStats.dataSize + pStats.externalCacheSize
												+ pStats.externalCodeSize + pStats.externalDataSize + pStats.externalMediaSize + pStats.externalObbSize);
									} else if (Build.VERSION.SDK_INT >= 11) {
										appItem.setMemorySize(pStats.cacheSize + pStats.codeSize + pStats.dataSize + pStats.externalCacheSize
												+ pStats.externalDataSize + pStats.externalMediaSize + pStats.externalObbSize);
									} else {
										appItem.setMemorySize(pStats.cacheSize + pStats.codeSize + pStats.dataSize);
									}
								}
								countDownLatch.countDown();
							}
						});
						countDownLatch.await();
					} catch (Exception e) {
						e.printStackTrace();
					}
					publishProgress(appItem);
				}
			} else {
				List<PackageInfo> list = pm.getInstalledPackages(0);
				for (PackageInfo packageInfo : list) {
					if (stop) {
						break;
					}
					if (packageInfo.packageName.equals(mContext.getPackageName())) {
						continue;
					}
					ApplicationInfo appInfo = packageInfo.applicationInfo;
					boolean flag = false;
					if ((appInfo.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0) {
						flag = true;
					} else if ((appInfo.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
						flag = true;
					}
					final String sourceDir = appInfo.sourceDir;
					if (flag && sourceDir != null) {
						final AppItem info = new AppItem();
						info.setIcon(DrawableUtils.drawable2Byte(appInfo.loadIcon(pm)));
						info.setAppName(appInfo.loadLabel(pm).toString());
						info.setAppPackage(appInfo.packageName);
						info.setInstallTime(System.currentTimeMillis());
						info.setTypeFlag("memory");
						info.setHaoziyuanApp(true);
						final CountDownLatch countDownLatch = new CountDownLatch(1);
						try {
							Method getPackageSizeInfo = pm.getClass().getMethod("getPackageSizeInfo", String.class, IPackageStatsObserver.class);
							getPackageSizeInfo.invoke(pm, info.getAppPackage(), new IPackageStatsObserver.Stub() {
								public void onGetStatsCompleted(PackageStats pStats, boolean succeeded) throws RemoteException {
									if (pStats != null) {
										if (Build.VERSION.SDK_INT >= 14) {
											info.setMemorySize(pStats.cacheSize + pStats.codeSize + pStats.dataSize + pStats.externalCacheSize
													+ pStats.externalCodeSize + pStats.externalDataSize + pStats.externalMediaSize + pStats.externalObbSize);
										} else if (Build.VERSION.SDK_INT >= 11) {
											info.setMemorySize(pStats.cacheSize + pStats.codeSize + pStats.dataSize + pStats.externalCacheSize
													+ pStats.externalDataSize + pStats.externalMediaSize + pStats.externalObbSize);
										} else {
											info.setMemorySize(pStats.cacheSize + pStats.codeSize + pStats.dataSize);
										}
									}
									countDownLatch.countDown();
								}
							});
							countDownLatch.await();
						} catch (Exception e) {
							e.printStackTrace();
						}
						publishProgress(info);
					}
				}
			}
			return null;
		}

		@Override
		protected void onPostExecute(Integer result) {
			super.onPostExecute(result);
			if (!AppListDBUtils.isInit(mContext)) {
				AppListDBUtils.save(mContext, appItems);
			}
		}

		@Override
		protected void onProgressUpdate(AppItem... values) {
			if (values.length > 0) {
				AppItem info = values[0];
				appItems.add(info);
				Collections.sort(appItems, new MemorySizeComparator());
			}
			adapter4HaoZiYuanApp.notifyDataSetChanged();
			super.onProgressUpdate(values);
		}
	}

	private class GetNetFlowAppTask extends AsyncTask<Void, AppItem, Integer> {

		@Override
		protected void onPreExecute() {
			if (netFlowInfos == null) {
				netFlowInfos = new ArrayList<AppItem>();
			} else {
				netFlowInfos.clear();
			}
		}

		@Override
		protected Integer doInBackground(Void... params) {
			PackageManager pm = mContext.getPackageManager();
			List<PackageInfo> list = pm.getInstalledPackages(0);
			for (PackageInfo packageInfo : list) {
				if (stop) {
					break;
				}
				if (packageInfo.packageName.equals(mContext.getPackageName())) {
					continue;
				}
				ApplicationInfo appInfo = packageInfo.applicationInfo;
				boolean flag = false;
				if ((appInfo.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0) {
					flag = true;
				} else if ((appInfo.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
					flag = true;
				}
				final String sourceDir = appInfo.sourceDir;
				if (flag && sourceDir != null) {
					AppItem info = new AppItem();
					info.setIcon(DrawableUtils.drawable2Byte(appInfo.loadIcon(pm)));
					info.setAppName(appInfo.loadLabel(pm).toString());
					info.setAppPackage(appInfo.packageName);
					info.setUid(appInfo.uid);
					info.setTempFlow(TrafficStats.getUidRxBytes(appInfo.uid) + TrafficStats.getUidTxBytes(appInfo.uid));
					info.setTypeFlag("netflow");
					info.setHaoziyuanApp(true);
					publishProgress(info);
				}
			}
			return null;
		}

		@Override
		protected void onPostExecute(Integer result) {
			super.onPostExecute(result);
			AppNetFlowDBUtils2.save(mContext, netFlowInfos);
		}

		@Override
		protected void onProgressUpdate(AppItem... values) {
			if (values.length > 0) {
				AppItem info = values[0];
				netFlowInfos.add(info);
				Collections.sort(netFlowInfos, new NetFlowComparator2());
			}
			adapter4HaoZiYuanApp.notifyDataSetChanged();
			super.onProgressUpdate(values);
		}
	}

	private class GetStartUpAppTask extends AsyncTask<Void, AppItem, Integer> {
		private ArrayList<AppItem> tempList;

		public GetStartUpAppTask(ArrayList<AppItem> appItems) {
			this.tempList = appItems;
		}

		@Override
		protected void onPreExecute() {
			if (startUps == null) {
				startUps = new ArrayList<AppItem>();
			} else {
				startUps.clear();
			}
		}

		@Override
		protected Integer doInBackground(Void... params) {
			PackageManager pm = mContext.getPackageManager();
			if (tempList != null && tempList.size() > 0) {
				for (final AppItem appItem : tempList) {
					if (stop) {
						break;
					}
					appItem.setTypeFlag("startup");
					AppStartUpDBUtils.getLastStartTime(mContext, appItem);
					if (appItem.getLastStartTime() > 0) {
						long spaceTime = System.currentTimeMillis() - appItem.getLastStartTime();
						// if (spaceTime >= 24 * 60 * 60 * 1000) {
						// appItem.setSpaceTime(spaceTime);
						// publishProgress(appItem);
						// }
						appItem.setSpaceTime(spaceTime);
						publishProgress(appItem);
					} else {
						long spaceTime = System.currentTimeMillis() - appItem.getInstallTime();
						// if (spaceTime >= 24 * 60 * 60 * 1000) {
						// appItem.setSpaceTime(spaceTime);
						// publishProgress(appItem);
						// }
						appItem.setSpaceTime(spaceTime);
						publishProgress(appItem);
					}
				}
			} else {
				tempList = new ArrayList<AppItem>();
				List<PackageInfo> list = pm.getInstalledPackages(0);
				for (PackageInfo packageInfo : list) {
					if (stop) {
						break;
					}
					if (packageInfo.packageName.equals(mContext.getPackageName())) {
						continue;
					}
					ApplicationInfo appInfo = packageInfo.applicationInfo;
					boolean flag = false;
					if ((appInfo.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0) {
						flag = true;
					} else if ((appInfo.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
						flag = true;
					}
					final String sourceDir = appInfo.sourceDir;
					if (flag && sourceDir != null) {
						final AppItem info = new AppItem();
						info.setIcon(DrawableUtils.drawable2Byte(appInfo.loadIcon(pm)));
						info.setAppName(appInfo.loadLabel(pm).toString());
						info.setAppPackage(appInfo.packageName);
						info.setInstallTime(System.currentTimeMillis());
						info.setTypeFlag("startup");
						info.setHaoziyuanApp(true);
						tempList.add(info);

						AppStartUpDBUtils.getLastStartTime(mContext, info);
						if (info.getLastStartTime() > 0) {
							long spaceTime = System.currentTimeMillis() - info.getLastStartTime();
							// if (spaceTime >= 24 * 60 * 60 * 1000) {
							// info.setSpaceTime(spaceTime);
							// publishProgress(info);
							// }
							info.setSpaceTime(spaceTime);
							publishProgress(info);
						} else {
							long spaceTime = System.currentTimeMillis() - info.getInstallTime();
							// if (spaceTime >= 24 * 60 * 60 * 1000) {
							// info.setSpaceTime(spaceTime);
							// publishProgress(info);
							// }
							info.setSpaceTime(spaceTime);
							publishProgress(info);
						}
					}
				}
			}
			return null;
		}

		@Override
		protected void onPostExecute(Integer result) {
			super.onPostExecute(result);
		}

		@Override
		protected void onProgressUpdate(AppItem... values) {
			if (values.length > 0) {
				AppItem info = values[0];
				startUps.add(info);
				Collections.sort(startUps, new SpaceTimeComparator());
			}
			adapter4HaoZiYuanApp.notifyDataSetChanged();
			super.onProgressUpdate(values);
		}
	}

	@Override
	public void onClick(View v) {
		CustomEventCommit.commit(mContext, CustomEventCommit.haoziyuan_app_uninstall);
		if (Terminal.isRoot(mContext)) {
			uninstallApp(adapter4HaoZiYuanApp.getSelectHaoziyuanList());
		} else {
			uninstallWithoutRoot(adapter4HaoZiYuanApp.getSelectHaoziyuanList());
		}
	}

	private void uninstallWithoutRoot(ArrayList<AppItem> apps) {
		uninstallApps.clear();
		uninstallApps = apps;
		if (uninstallApps != null && uninstallApps.size() > 0) {
			for (AppItem appItem : uninstallApps) {
				AppManagerUtils.openUninstaller(mContext, appItem.getAppPackage());
			}
		} else {
			Toast.makeText(mContext, R.string.clear_select_null, Toast.LENGTH_SHORT).show();
		}
	}

	private void uninstallApp(ArrayList<AppItem> apps) {
		freeMemory = 0;
		final ArrayList<AppItem> appItems = apps;
		if (appItems != null && appItems.size() > 0) {
			mIosProgressDialog = new IOSProgressDialog(mContext, R.string.app_uninstall_loading);
			mIosProgressDialog.setCancelable(false);
			mIosProgressDialog.setCanceledOnTouchOutside(false);
			mIosProgressDialog.show();
			new Thread(new Runnable() {

				@Override
				public void run() {
					for (int i = 0; i < appItems.size(); i++) {
						AppItem appItem = appItems.get(i);
						boolean b = false;
						if (appItem.isSystemApp()) {
							if (AppManagerUtils.backupApp(appItem)) {
								b = Terminal.uninstallSystemApp(appItem);
							}
						} else {
							b = Terminal.uninstallUserApp(appItem);
						}
						if (b) {
							freeMemory += appItem.getCodeSize();
							uninstallApp = appItem;
							Message message = new Message();
							message.what = 1;
							message.arg1 = appItems.size();
							message.arg2 = i + 1;
							mHandler.sendMessage(message);
						}
					}

					Message message = new Message();
					message.what = 0;
					message.arg1 = appItems.size();
					message.arg2 = appItems.size();
					mHandler.sendMessageDelayed(message, 200);
				}
			}).start();
		} else {
			Toast.makeText(mContext, R.string.clear_select_null, Toast.LENGTH_SHORT).show();
		}
	}

	Handler mHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			switch (msg.what) {
			case 0:
				mIosProgressDialog.dismiss();
				Toast.makeText(mContext, R.string.uninstall_end_recyle_tips, Toast.LENGTH_SHORT).show();
				ClearUtils.setDayClearSize(mContext, freeMemory);
				ClearUtils.setHistoryClearSize(mContext, freeMemory);
				break;
			case 1:
				Toast.makeText(mContext, mContext.getString(R.string.app_uninstall_succeed_toast, uninstallApp.getAppName()), Toast.LENGTH_SHORT).show();
				if (adapter4HaoZiYuanApp != null) {
					adapter4HaoZiYuanApp.removeAppItem(uninstallApp);
				}

				softwareUninstallActivity.removeChongfuAdapter(uninstallApp);
				softwareUninstallActivity.removeUserAdapter(uninstallApp);
				clear_button.setText(getString(R.string.one_uninstall_button));
				break;
			case 110:
				if (adapter4HaoZiYuanApp.getSelectHaoziyuanList().size() == 0) {
					clear_button.setText(getString(R.string.one_uninstall_button));
				} else {
					clear_button.setText(getString(R.string.one_uninstall_button) +" ("+ adapter4HaoZiYuanApp.getSelectHaoziyuanList().size() + ")");
				}
				break;
			case 119:
				clear_button.setText(getString(R.string.one_uninstall_button));
				break;

			default:
				break;
			}
		}
	};

	private void updateUnstalledUserAdapter() {
		for (AppItem appItem : uninstallApps) {
			if (!AppManagerUtils.appIsInstall(mContext, appItem.getAppPackage())) {
				Toast.makeText(mContext, mContext.getString(R.string.app_uninstall_succeed_toast, appItem.getAppName()), Toast.LENGTH_SHORT).show();
				ClearUtils.setDayClearSize(mContext, appItem.getCodeSize());
				ClearUtils.setHistoryClearSize(mContext, appItem.getCodeSize());
				softwareUninstallActivity.removeUserAdapter(appItem);
			}
		}
	}

	private void updateUnstalledChongfuAdapter() {
		for (AppItem appItem : uninstallApps) {
			if (!AppManagerUtils.appIsInstall(mContext, appItem.getAppPackage())) {
				Toast.makeText(mContext, mContext.getString(R.string.app_uninstall_succeed_toast, appItem.getAppName()), Toast.LENGTH_SHORT).show();
				softwareUninstallActivity.removeChongfuAdapter(appItem);
			}
		}
	}

	private void updateUnstalledHaoziyuanAdapter() {
		for (AppItem appItem : uninstallApps) {
			if (!AppManagerUtils.appIsInstall(mContext, appItem.getAppPackage())) {
				Toast.makeText(mContext, mContext.getString(R.string.app_uninstall_succeed_toast, appItem.getAppName()), Toast.LENGTH_SHORT).show();
				adapter4HaoZiYuanApp.removeAppItem(appItem);
				if (adapter4HaoZiYuanApp.getSelectHaoziyuanList().size() == 0) {
					clear_button.setText(getString(R.string.one_uninstall_button));
				} else {
					clear_button.setText(getString(R.string.one_uninstall_button) +" ("+ adapter4HaoZiYuanApp.getSelectHaoziyuanList().size() + ")");
				}
			}
		}
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		stop = true;
	}

	public void removeApp(AppItem appItem) {
		if (adapter4HaoZiYuanApp != null) {
			adapter4HaoZiYuanApp.removeAppItem(appItem);
		}
	}

}
