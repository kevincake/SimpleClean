package cn.com.opda.android.clearmaster.service;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.preference.PreferenceManager;
import cn.com.opda.android.clearmaster.dao.DBApkPathUtils;
import cn.com.opda.android.clearmaster.dao.DBBigFilePathUtils;
import cn.com.opda.android.clearmaster.dao.DBLogPathUtils;
import cn.com.opda.android.clearmaster.utils.Constants;
import cn.com.opda.android.clearmaster.utils.StringUtil;

public class SearchApkService extends Service {
	private final String SDCARDPATH = Environment.getExternalStorageDirectory().toString();
	private final String[] EXCEPTPATH = { StringUtil.link(SDCARDPATH, "/gameloft/"), StringUtil.link(SDCARDPATH, "/OpenRecovery/"),
			StringUtil.link(SDCARDPATH, "/LOST.DIR/"), StringUtil.link(SDCARDPATH, "/Android/obb/"), StringUtil.link(SDCARDPATH, "/Android/data/"),
			StringUtil.link(SDCARDPATH, "/clearmaster_zds/systembackup/"), StringUtil.link(SDCARDPATH, "/.expand") };
	private HashSet<String> apkCollectionPaths;
	private HashSet<String> bigfileCollectionPaths;
	private HashSet<String> logCollectionPaths;

	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

	@Override
	public void onCreate() {
		super.onCreate();
		SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
		if (!sp.getBoolean("apkPathInit", false) || System.currentTimeMillis() - sp.getLong("last_search_time", 0) >= 10 * 60 * 1000) {
			sp.edit().putLong("last_search_time", System.currentTimeMillis()).commit();
			new GetApkThread().start();
		} else {
			stopSelf();
		}
	}

	class GetApkThread extends Thread {
		public void run() {
			super.run();
			File[] sdcardfiles = new File(SDCARDPATH).listFiles();
			if (sdcardfiles != null && sdcardfiles.length > 0) {
				for (int i = 0; i < sdcardfiles.length; i++) {
					File file = sdcardfiles[i];
					ergodicFiles(file);
				}
			}

			if (apkCollectionPaths != null && apkCollectionPaths.size() > 0) {
				Iterator<String> iterator = apkCollectionPaths.iterator();
				ArrayList<String> paths = new ArrayList<String>();
				while (iterator.hasNext()) {
					paths.add(iterator.next());
				}
				try {
					DBApkPathUtils.save(getApplicationContext(), paths);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

			if (bigfileCollectionPaths != null && bigfileCollectionPaths.size() > 0) {
				Iterator<String> iterator = bigfileCollectionPaths.iterator();
				ArrayList<String> paths = new ArrayList<String>();
				while (iterator.hasNext()) {
					paths.add(iterator.next());
				}
				try {
					DBBigFilePathUtils.save(getApplicationContext(), paths);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

			if (logCollectionPaths != null && logCollectionPaths.size() > 0) {
				Iterator<String> iterator = logCollectionPaths.iterator();
				ArrayList<String> paths = new ArrayList<String>();
				while (iterator.hasNext()) {
					paths.add(iterator.next());
				}
				try {
					DBLogPathUtils.save(getApplicationContext(), paths);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			handler.sendEmptyMessage(2);
		}

		Handler handler = new Handler() {

			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				switch (msg.what) {
				case 2:
					SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
					sp.edit().putBoolean("apkPathInit", true).commit();
					stopSelf();
					break;

				default:
					break;
				}
			}

		};

		/**
		 * 遍历file
		 */
		public void ergodicFiles(File file) {
			if (file.isFile() && !file.isHidden()) {
				String fileName = file.getName();
				if (fileName != null && fileName.length() != 0) {
					if (fileName.endsWith(".apk")) {
						addApkCollectionPath(file.getAbsolutePath());
					} else if (fileName.endsWith(".log")) {
						addLogCollectionPath(file.getAbsolutePath());
					} else {
						if (file.length() >= 10 * 1024 * 1024) {
							addBigFileCollectionPath(file.getAbsolutePath());
						}
					}
				}
			} else {
				for (String exceptDir : EXCEPTPATH) {
					if (exceptDir.equals(StringUtil.link(file.getAbsolutePath(), "/"))) {
						return;
					}
				}
				File[] fileArr = file.listFiles();
				if (fileArr != null && fileArr.length != 0) {
					for (File mFile : fileArr) {
						ergodicFiles(mFile);
					}
				}
			}
		}
	}

	/**
	 * 收集apk path
	 * 
	 * @param path
	 */
	private void addApkCollectionPath(String path) {
		String sdPath = Constants.SDCARD_PATH;
		File apkFile = new File(path);

		String parentPath = apkFile.getParent();
		if (sdPath.equals(parentPath)) {
			return;
		}
		parentPath = parentPath.substring(parentPath.indexOf(sdPath) + sdPath.length(), parentPath.length());
		if (apkCollectionPaths == null) {
			apkCollectionPaths = new HashSet<String>();
		}
		apkCollectionPaths.add(parentPath);
	}

	/**
	 * 收集大文件 path
	 * 
	 * @param path
	 */
	private void addBigFileCollectionPath(String path) {
		String sdPath = Constants.SDCARD_PATH;
		File apkFile = new File(path);

		String parentPath = apkFile.getParent();
		if (sdPath.equals(parentPath)) {
			return;
		}
		parentPath = parentPath.substring(parentPath.indexOf(sdPath) + sdPath.length(), parentPath.length());
		if (bigfileCollectionPaths == null) {
			bigfileCollectionPaths = new HashSet<String>();
		}
		bigfileCollectionPaths.add(parentPath);
	}

	/**
	 * 收集log path
	 * 
	 * @param path
	 */
	private void addLogCollectionPath(String path) {
		String sdPath = Constants.SDCARD_PATH;
		File apkFile = new File(path);

		String parentPath = apkFile.getParent();
		if (sdPath.equals(parentPath)) {
			return;
		}
		parentPath = parentPath.substring(parentPath.indexOf(sdPath) + sdPath.length(), parentPath.length());
		if (logCollectionPaths == null) {
			logCollectionPaths = new HashSet<String>();
		}
		logCollectionPaths.add(parentPath);
	}

}
