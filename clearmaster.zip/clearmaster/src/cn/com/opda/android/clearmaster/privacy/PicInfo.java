package cn.com.opda.android.clearmaster.privacy;

import android.graphics.Bitmap;
import android.os.Parcel;
import android.os.Parcelable;

public class PicInfo implements Parcelable {
	private int id;
	private String picId;
	private String oldPath;
	private String newPath;
	private String preName;
	private String endName;

	private long dateAdded;
	
	private Bitmap bitmap;

	private boolean isChecked;

	// 1.必须实现Parcelable.Creator接口,否则在获取Person数据的时候，会报错，如下：
	// android.os.BadParcelableException:
	// Parcelable protocol requires a Parcelable.Creator object called CREATOR
	// on class com.um.demo.Person
	// 2.这个接口实现了从Percel容器读取Person数据，并返回Person对象给逻辑层使用
	// 3.实现Parcelable.Creator接口对象名必须为CREATOR，不如同样会报错上面所提到的错；
	// 4.在读取Parcel容器里的数据事，必须按成员变量声明的顺序读取数据，不然会出现获取数据出错
	// 5.反序列化对象
	public static final Parcelable.Creator<PicInfo> CREATOR = new Creator<PicInfo>() {

		@Override
		public PicInfo createFromParcel(Parcel source) {
			// 必须按成员变量声明的顺序读取数据，不然会出现获取数据出错
			PicInfo info = new PicInfo();
			info.id = source.readInt();
			info.picId = source.readString();
			info.newPath = source.readString();
			info.oldPath = source.readString();
			return info;
		}

		@Override
		public PicInfo[] newArray(int size) {
			return new PicInfo[size];
		}
	};
	
	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeInt(id);
		dest.writeString(picId);
		dest.writeString(newPath);
		dest.writeString(oldPath);
	}

	
	public long getDateAdded() {
		return dateAdded;
	}


	public void setDateAdded(long dateAdded) {
		this.dateAdded = dateAdded;
	}


	public Bitmap getBitmap() {
		return bitmap;
	}

	public void setBitmap(Bitmap bitmap) {
		this.bitmap = bitmap;
	}

	public boolean isChecked() {
		return isChecked;
	}

	public void setChecked(boolean isChecked) {
		this.isChecked = isChecked;
	}

	public String getPreName() {
		return preName;
	}

	public void setPreName(String preName) {
		this.preName = preName;
	}

	public String getEndName() {
		return endName;
	}

	public void setEndName(String endName) {
		this.endName = endName;
	}

	public String getPicId() {
		return picId;
	}

	public void setPicId(String picId) {
		this.picId = picId;
	}

	public String getOldPath() {
		return oldPath;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setOldPath(String oldPath) {
		this.oldPath = oldPath;
	}

	public String getNewPath() {
		return newPath;
	}

	public void setNewPath(String newPath) {
		this.newPath = newPath;
	}

	@Override
	public int describeContents() {
		// TODO Auto-generated method stub
		return 0;
	}


}
