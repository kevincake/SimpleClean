package cn.net.forgame.h5.center;

public interface H5Interface {

	public void ShareTimelineCallback(String img_url, String link, String desc, String title);
}
