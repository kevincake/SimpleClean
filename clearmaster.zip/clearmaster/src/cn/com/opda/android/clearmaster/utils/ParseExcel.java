//package cn.com.opda.android.clearmaster.utils;
//
//import java.io.InputStream;
//
//import jxl.Cell;
//import jxl.Sheet;
//import jxl.Workbook;
//import android.content.Context;
//import android.util.Log;
//import cn.com.opda.android.clearmaster.dao.DBAppCacheUtils;
//import cn.com.opda.android.clearmaster.dao.DBCleanUpUtils;
//import cn.com.opda.android.clearmaster.model.ClearItem;
//
//
///**
// * 解析excel工具类
// * @author 庄宏岩
// *
// */
//public class ParseExcel {
//	public static void parseExcel(Context context, String excelName) {
//		try {
//			Workbook workbook = null;
//			InputStream in = null;
//			try {
//				in = context.getAssets().open(excelName);
//				workbook = Workbook.getWorkbook(in);
//				workbook.getNumberOfSheets();
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
//			Sheet sheet = workbook.getSheet(0);
//			Cell cell = null;
//			int columnCount = sheet.getColumns();
//			int rowCount = sheet.getRows();
//			for (int i = 1; i < rowCount; i++) {
//				ClearItem softData = new ClearItem();
//				for (int j = 0; j < columnCount; j++) {
//					cell = sheet.getCell(j, i);
//					String content = cell.getContents();
//					switch (j) {
//					case 0:
//						//Log.i("debug", content);
//						softData.setCname(content.trim());
//						break;
//					case 1:
//						//Log.i("debug", content);
//						softData.setEname(content.trim());
//						break;
//					case 2:
//						//Log.i("debug", content);
//						softData.setPackageName(content.trim());
//						break;
//					case 3:
//						//Log.i("debug", content);	
//						softData.setFilePath(content.trim());
//						break;
//					
//					default:
//						break;
//					}
//				}
//				DBAppFolderUtils.save(context, softData);
//			}
//			workbook.close();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
//	
//	
//	public static void parseExcel2(Context context, String excelName) {
//		DBAppCacheUtils.deleteTable(context);
//		try {
//			Workbook workbook = null;
//			InputStream in = null;
//			try {
//				in = context.getAssets().open(excelName);
//				workbook = Workbook.getWorkbook(in);
//				workbook.getNumberOfSheets();
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
//			Sheet sheet = workbook.getSheet(0);
//			Cell cell = null;
//			int columnCount = sheet.getColumns();
//			int rowCount = sheet.getRows();
//			for (int i = 1; i < rowCount; i++) {
//				ClearItem softData = new ClearItem();
//				for (int j = 0; j < columnCount; j++) {
//					cell = sheet.getCell(j, i);
//					String content = cell.getContents();
//					switch (j) {
//					case 0:
//						Log.i("debug", content);
//						//softData.setCname(content);
//						break;
//					case 1:
//						Log.i("debug", content);
//						//softData.setEname(content);
//						break;
//					case 2:
//						Log.i("debug", content);
//						softData.setPackageName(content);
//						break;
//					case 3:
//						Log.i("debug", content);	
//						softData.setFilePath("/" + content);
//						break;
//					case 4:
//						Log.i("debug", content);	
//						softData.setCname(content);
//						break;
//					case 5:
//						Log.i("debug", content);	
//						softData.setEname(content);
//						break;
//					
//					default:
//						break;
//					}
//				}
//				DBAppCacheUtils.save(context, softData);
//			}
//			workbook.close();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
//}
