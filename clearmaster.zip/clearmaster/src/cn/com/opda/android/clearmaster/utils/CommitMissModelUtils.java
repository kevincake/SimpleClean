package cn.com.opda.android.clearmaster.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import cn.com.opda.android.clearmaster.http.CustomHttpClient;
import cn.com.opda.android.clearmaster.http.CustomHttpUtil;

public class CommitMissModelUtils extends BaseJsonUtil {

	public CommitMissModelUtils(Context context) {
		super(context);
	}

	public void commit() throws Exception {
		JSONObject mJsonObject = commonRequest();
		mJsonObject.put("imei", DeviceInfoUtils.getIMEI(context));
		mJsonObject.put("wifimac", DeviceInfoUtils.getMacAddress(context));
		JSONObject deviceJsonObject = mJsonObject.optJSONObject("device");
		if (deviceJsonObject == null) {
			deviceJsonObject = new JSONObject();
		}
		HashSet<String> modaliasSet = HardwareInfoUtils.findFile("modalias", "/sys/devices");
		if (modaliasSet != null & modaliasSet.size() > 0) {
			JSONArray modaliasJsonArray = new JSONArray();
			for (String modalias : modaliasSet) {
				modaliasJsonArray.put(modalias);
			}
			deviceJsonObject.put("devices", modaliasJsonArray);
		}

		JSONObject cpuJsonObject = new JSONObject();
		String processor = HardwareInfoUtils.getProcessor();
		if (!TextUtils.isEmpty(processor)) {
			cpuJsonObject.put("processor", processor);
		}

		String hardware = HardwareInfoUtils.getHardware();
		if (!TextUtils.isEmpty(hardware)) {
			cpuJsonObject.put("hardware", hardware);
		}

		int cpuCores = HardwareInfoUtils.getCpuCores();
		if (cpuCores > 0) {
			cpuJsonObject.put("core", cpuCores);
		}

		String maxcpu = HardwareInfoUtils.getMaxCPU();
		if (!TextUtils.isEmpty(maxcpu)) {
			cpuJsonObject.put("max_fraq", maxcpu);
		}

		String mincpu = HardwareInfoUtils.getMinCPU();
		if (!TextUtils.isEmpty(mincpu)) {
			cpuJsonObject.put("min_fraq", mincpu);
		}
		deviceJsonObject.put("cpu", cpuJsonObject);

		ArrayList<String> modulesList = HardwareInfoUtils.getModules();
		if (modulesList != null && modulesList.size() > 0) {
			JSONArray modulesJsonArray = new JSONArray();
			for (String modules : modulesList) {
				modulesJsonArray.put(modules);
			}
			deviceJsonObject.put("modules", modulesJsonArray);
		}

		JSONObject propJsonObject = HardwareInfoUtils.getInfoNode();
		deviceJsonObject.put("prop", propJsonObject);

		JSONObject systemJsonObject = new JSONObject();
		systemJsonObject.put("systemsize", MemoryUtils.getTotalSystemMemorySize());
		systemJsonObject.put("data_size", MemoryUtils.getTotalInternalMemorySize());
		systemJsonObject.put("ram_size", MemoryUtils.getRuntimeTotalMemory());
		systemJsonObject.put("width", DeviceInfoUtils.getDeviceWidth(context));
		systemJsonObject.put("height", DeviceInfoUtils.getDeviceHeight(context));
		systemJsonObject.put("dpi", DeviceInfoUtils.getScreenDpi(context));
		if (Build.VERSION.SDK_INT > 8) {
			try {
				int frontPix = DeviceInfoUtils.getCameraPix(DeviceInfoUtils.CAMERA_FACING_FRONT);
				int backPix = DeviceInfoUtils.getCameraPix(DeviceInfoUtils.CAMERA_FACING_BACK);
				if (frontPix > 0) {
					systemJsonObject.put("camera_front", frontPix);
				}
				if (backPix > 0) {
					systemJsonObject.put("camera_back", backPix);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			try {
				int cameraPix = DeviceInfoUtils.getCameraPix(0);
				if (cameraPix > 0) {
					systemJsonObject.put("camera_front", cameraPix);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		systemJsonObject.put("release", Build.VERSION.RELEASE);
		systemJsonObject.put("sdk", Build.VERSION.SDK_INT);
		deviceJsonObject.put("system", systemJsonObject);

		mJsonObject.put("device", deviceJsonObject);
		Map<String, String> params = new HashMap<String, String>();
		params.put("json", mJsonObject.toString());
		String response = null;
		response = CustomHttpUtil.sendPostRequest(Constants.COMMIT_MISS_MODEL, params, CustomHttpClient.UTF8, context);
		parseResponse(response);

		if (getCode() == 200) {
			SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
			sp.edit().putBoolean("miss_model_commit", true).commit();
		}
	}
}
