package cn.com.opda.android.clearmaster.custom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

/**
 * 
 * @author 庄宏岩
 *
 */
public class CustomRectFView extends View {
	private int paintColor;
	private Paint paint;

	public CustomRectFView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
	}

	public CustomRectFView(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public CustomRectFView(Context context) {
		super(context);
	}

	public void init(int color) {
		this.paintColor = color;
		paint = new Paint();
		paint.setAntiAlias(true);
		paint.setStyle(Paint.Style.FILL);
		paint.setColor(paintColor);
		invalidate();
	}

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		if (paint != null) {
			canvas.drawArc(new RectF(2, 2, getWidth()-2, getHeight()-2),0,360,true, paint);
		}
	}

}
