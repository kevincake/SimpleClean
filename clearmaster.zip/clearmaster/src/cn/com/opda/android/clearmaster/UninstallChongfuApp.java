package cn.com.opda.android.clearmaster;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnGroupClickListener;
import android.widget.Toast;
import cn.com.opda.android.clearmaster.adapter.Adapter4AdApp;
import cn.com.opda.android.clearmaster.adapter.Adapter4ChongFuApp;
import cn.com.opda.android.clearmaster.custom.CustomActivity;
import cn.com.opda.android.clearmaster.custom.CustomDialog2;
import cn.com.opda.android.clearmaster.custom.CustomListView;
import cn.com.opda.android.clearmaster.custom.IOSProgressDialog;
import cn.com.opda.android.clearmaster.model.AppItem;
import cn.com.opda.android.clearmaster.model.VerboseAdInfo;
import cn.com.opda.android.clearmaster.model.VerboseApp;
import cn.com.opda.android.clearmaster.utils.AppManagerUtils;
import cn.com.opda.android.clearmaster.utils.ClearUtils;
import cn.com.opda.android.clearmaster.utils.CustomEventCommit;
import cn.com.opda.android.clearmaster.utils.Terminal;
import cn.com.opda.android.clearmaster.utils.VerboseUtils;

import com.dashi.smartstore.DashiSmartStore_ViewPagerMainActivity;

public class UninstallChongfuApp extends CustomActivity implements OnClickListener {
	private boolean stop;
	private ExpandableListView chongfu_listview;
	private ArrayList<VerboseApp> mVerboseApps;
	private List<PackageInfo> installAppList;
	private Adapter4ChongFuApp mChongFuAdapter;
	private Button clear_button;
	private SoftwareUninstallActivity softwareUninstallActivity;
	private ArrayList<AppItem> uninstallApps = new ArrayList<AppItem>();
	private AppItem uninstallApp;
	private long freeMemory;
	private IOSProgressDialog mIosProgressDialog;
	private boolean init;

	public UninstallChongfuApp(Context context, int resId, SoftwareUninstallActivity softwareUninstallActivity) {
		super(context, resId);
		this.softwareUninstallActivity = softwareUninstallActivity;
		initViewAndEvent();
	}

	private void initViewAndEvent() {
		chongfu_listview = (ExpandableListView) findViewById(R.id.chongfu_listview);
		clear_button = (Button) findViewById(R.id.clear_button);
		clear_button.setOnClickListener(this);
	}

	@Override
	public void onResume() {
		if (uninstallApps != null && uninstallApps.size() > 0 && !Terminal.isRoot(mContext)) {
			updateUnstalledHaoziyuanAdapter();
			updateUnstalledChongfuAdapter();
			updateUnstalledUserAdapter();
			uninstallApps.clear();
		}
	}

	@Override
	public void initData() {
		if (!init) {
			init = true;
			initChongFuApp();
		}
	}

	private void initChongFuApp() {
		update();
		chongfu_listview.setOnGroupClickListener(new OnGroupClickListener() {

			@Override
			public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
				VerboseApp verboseApp = (VerboseApp) mChongFuAdapter.getGroup(groupPosition);
				ArrayList<AppItem> appItems = verboseApp.getAppItems();
				if (appItems != null && appItems.size() >= 2) {
					return false;
				} else if (appItems != null && appItems.size() == 1) {
					return true;
				} else {
					if (verboseApp.isFinish()) {
						ArrayList<VerboseAdInfo> adInfos = verboseApp.getAdInfos();
						if (adInfos != null && adInfos.size() > 0) {
							View view = LayoutInflater.from(mContext).inflate(R.layout.verbose_app_dialog, null);
							CustomListView customListView = (CustomListView) view.findViewById(R.id.verbose_app_listview);
							customListView.setAdapter(new Adapter4AdApp(mContext, adInfos));

							CustomDialog2 customDialog = new CustomDialog2(mContext);
							customDialog.setView(view);
							customDialog.setButton1(R.string.dialog_button_cancel, null);
							customDialog.show();

						} else {
							mContext.startActivity(new Intent(mContext, DashiSmartStore_ViewPagerMainActivity.class));
						}
					}
					return true;
				}
			}
		});
	}

	public void update() {
		new Thread(new Runnable() {
			Activity ac = new Activity();

			@Override
			public void run() {
				String verboseJson = VerboseUtils.getJson(mContext);
				if (!TextUtils.isEmpty(verboseJson)) {
					mVerboseApps = VerboseUtils.getSurplusAppsByJson(mContext, verboseJson);
				} else {
					mVerboseApps = VerboseUtils.getSurplusApps(mContext);
				}
				ac.runOnUiThread(new Runnable() {

					@Override
					public void run() {

						if (mVerboseApps != null && mVerboseApps.size() > 0) {
							mChongFuAdapter = new Adapter4ChongFuApp(mContext, mVerboseApps, UninstallChongfuApp.this);
							chongfu_listview.setAdapter(mChongFuAdapter);
							chongfu_listview.expandGroup(0);
							if (installAppList != null) {
								installAppList.clear();
								installAppList = null;
							}
							for (VerboseApp verboseApp : mVerboseApps) {
								new GetVerboseTask(verboseApp).execute();
							}
						}
					}
				});
			}
		}).start();
	}

	private class GetVerboseTask extends AsyncTask<Void, AppItem, Integer> {
		private VerboseApp verboseApp;
		private ArrayList<AppItem> appItems;

		public GetVerboseTask(VerboseApp verboseApp) {
			this.verboseApp = verboseApp;
			appItems = new ArrayList<AppItem>();
		}

		@Override
		protected void onPreExecute() {

		}

		@Override
		protected Integer doInBackground(Void... params) {
			PackageManager pm = mContext.getPackageManager();
			if (installAppList == null) {
				installAppList = pm.getInstalledPackages((PackageManager.GET_UNINSTALLED_PACKAGES));
			}
			ArrayList<String> strings = verboseApp.getPackages();
			if (installAppList != null) {
				for (PackageInfo packageInfo : installAppList) {
					if (stop) {
						break;
					}
					ApplicationInfo applicationInfo = packageInfo.applicationInfo;
					if (applicationInfo == null) {
						continue;
					}
					if (applicationInfo.packageName.equals(mContext.getPackageName())) {
						continue;
					}
					final String sourceDir = applicationInfo.sourceDir;
					boolean flag = false;
					if ((applicationInfo.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0) {
						flag = true;
					} else if ((applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
						flag = true;
					}
					if (flag && sourceDir != null) {
						for (String string : strings) {
							if (stop) {
								break;
							}
							if (string.equals(applicationInfo.packageName)) {
								final AppItem mAppItem = new AppItem();
								mAppItem.setAppPackage(applicationInfo.packageName);
								mAppItem.setAppName(applicationInfo.loadLabel(pm).toString().trim());
								mAppItem.setAppIcon(applicationInfo.loadIcon(pm));
								mAppItem.setCodeSize(new File(sourceDir).length());
								mAppItem.setChongfuApp(true);
								if (mAppItem.getCodeSize() > 0) {
									publishProgress(mAppItem);
								}
								break;
							}
						}
					}
				}
			}

			return null;

		}

		@Override
		protected void onProgressUpdate(AppItem... values) {
			if (values.length > 0) {
				AppItem appInfo = values[0];
				appItems.add(appInfo);
				verboseApp.setAppItems(appItems);
				Collections.sort(mVerboseApps, new CustomComparator());
				mChongFuAdapter.notifyDataSetChanged();
			}
			super.onProgressUpdate(values);
		}

		@Override
		protected void onPostExecute(Integer result) {
			super.onPostExecute(result);
			verboseApp.setFinish(true);
			mChongFuAdapter.notifyDataSetChanged();
		}

		public class CustomComparator implements Comparator<VerboseApp> {

			@Override
			public int compare(VerboseApp verboseApp1, VerboseApp verboseApp2) {
				int num1 = verboseApp1.getAppItems() != null ? verboseApp1.getAppItems().size() : 0;
				long num2 = verboseApp2.getAppItems() != null ? verboseApp2.getAppItems().size() : 0;

				if (num1 == 1) {
					return 1;
				}
				if (num2 == 1) {
					return -1;
				}
				if (num1 < num2) {
					return 1;
				} else if (num1 == num2) {
					return 0;
				} else if (num1 > num2) {
					return -1;
				}
				return 0;
			}
		}
	}

	private void uninstallWithoutRoot(ArrayList<AppItem> apps) {
		uninstallApps.clear();
		uninstallApps = apps;
		if (uninstallApps != null && uninstallApps.size() > 0) {
			for (AppItem appItem : uninstallApps) {
				AppManagerUtils.openUninstaller(mContext, appItem.getAppPackage());
			}
		} else {
			Toast.makeText(mContext, R.string.clear_select_null, Toast.LENGTH_SHORT).show();
		}
	}

	private void uninstallApp(ArrayList<AppItem> apps) {
		freeMemory = 0;
		final ArrayList<AppItem> appItems = apps;
		if (appItems != null && appItems.size() > 0) {
			mIosProgressDialog = new IOSProgressDialog(mContext, R.string.app_uninstall_loading);
			mIosProgressDialog.setCancelable(false);
			mIosProgressDialog.setCanceledOnTouchOutside(false);
			mIosProgressDialog.show();
			new Thread(new Runnable() {

				@Override
				public void run() {
					for (int i = 0; i < appItems.size(); i++) {
						AppItem appItem = appItems.get(i);
						boolean b = false;
						if (appItem.isSystemApp()) {
							if (AppManagerUtils.backupApp(appItem)) {
								b = Terminal.uninstallSystemApp(appItem);
							}
						} else {
							b = Terminal.uninstallUserApp(appItem);
						}
						if (b) {
							freeMemory += appItem.getCodeSize();
							uninstallApp = appItem;
							Message message = new Message();
							message.what = 1;
							message.arg1 = appItems.size();
							message.arg2 = i + 1;
							mHandler.sendMessage(message);
						}
					}

					Message message = new Message();
					message.what = 0;
					message.arg1 = appItems.size();
					message.arg2 = appItems.size();
					mHandler.sendMessageDelayed(message, 200);
				}
			}).start();
		} else {
			Toast.makeText(mContext, R.string.clear_select_null, Toast.LENGTH_SHORT).show();
		}
	}

	Handler mHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			switch (msg.what) {
			case 0:
				mIosProgressDialog.dismiss();
				Toast.makeText(mContext, R.string.uninstall_end_recyle_tips, Toast.LENGTH_SHORT).show();
				ClearUtils.setDayClearSize(mContext, freeMemory);
				ClearUtils.setHistoryClearSize(mContext, freeMemory);
				break;
			case 1:
				Toast.makeText(mContext, mContext.getString(R.string.app_uninstall_succeed_toast, uninstallApp.getAppName()), Toast.LENGTH_SHORT).show();
				if (mChongFuAdapter != null) {
					mChongFuAdapter.removeAppItem(uninstallApp);
				}

				softwareUninstallActivity.removeHaoziyuanAdapter(uninstallApp);
				softwareUninstallActivity.removeUserAdapter(uninstallApp);
				break;

			default:
				break;
			}
		}
	};

	private void updateUnstalledUserAdapter() {
		for (AppItem appItem : uninstallApps) {
			if (!AppManagerUtils.appIsInstall(mContext, appItem.getAppPackage())) {
				Toast.makeText(mContext, mContext.getString(R.string.app_uninstall_succeed_toast, appItem.getAppName()), Toast.LENGTH_SHORT).show();
				ClearUtils.setDayClearSize(mContext, appItem.getCodeSize());
				ClearUtils.setHistoryClearSize(mContext, appItem.getCodeSize());
				softwareUninstallActivity.removeUserAdapter(appItem);
			}
		}
	}

	private void updateUnstalledChongfuAdapter() {
		for (AppItem appItem : uninstallApps) {
			if (!AppManagerUtils.appIsInstall(mContext, appItem.getAppPackage())) {
				Toast.makeText(mContext, mContext.getString(R.string.app_uninstall_succeed_toast, appItem.getAppName()), Toast.LENGTH_SHORT).show();
				mChongFuAdapter.removeAppItem(appItem);
			}
		}
	}

	private void updateUnstalledHaoziyuanAdapter() {
		for (AppItem appItem : uninstallApps) {
			if (!AppManagerUtils.appIsInstall(mContext, appItem.getAppPackage())) {
				Toast.makeText(mContext, mContext.getString(R.string.app_uninstall_succeed_toast, appItem.getAppName()), Toast.LENGTH_SHORT).show();
				softwareUninstallActivity.removeHaoziyuanAdapter(appItem);
			}
		}
	}

	@Override
	public void onClick(View v) {
		CustomEventCommit.commit(mContext, CustomEventCommit.verbose_app_uninstall);
		if (Terminal.isRoot(mContext)) {
			uninstallApp(mChongFuAdapter.getSelectChongFuList());
		} else {
			if (mChongFuAdapter != null) {
				uninstallWithoutRoot(mChongFuAdapter.getSelectChongFuList());
			}
		}

	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		stop = true;
	}

	public void removeApp(AppItem appItem) {
		if (mChongFuAdapter != null) {
			mChongFuAdapter.removeAppItem(appItem);
		}
	}

}
