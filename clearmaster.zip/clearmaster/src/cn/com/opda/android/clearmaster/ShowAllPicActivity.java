package cn.com.opda.android.clearmaster;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.GridView;
import android.widget.ListAdapter;
import android.widget.RelativeLayout;
import android.widget.Toast;
import cn.com.opda.android.clearmaster.adapter.Adapter4AddPicPrivacy;
import cn.com.opda.android.clearmaster.custom.IOSProgressDialog;
import cn.com.opda.android.clearmaster.privacy.PicDBHelper;
import cn.com.opda.android.clearmaster.privacy.PicInfo;
import cn.com.opda.android.clearmaster.utils.BannerUtils;
import cn.com.opda.android.clearmaster.utils.Constants;
import cn.com.opda.android.clearmaster.utils.CustomEventCommit;
import cn.com.opda.android.clearmaster.utils.FileUtils;
import cn.com.opda.android.clearmaster.utils.listsort.TimeComparatorForPrivacyPic;

import com.umeng.analytics.MobclickAgent;

public class ShowAllPicActivity extends BaseActivity implements OnClickListener {

	private RelativeLayout rl_no_pic;
	private GridView gv_for_pic;
	private Button bt_add_to_privacy;
	private Adapter4AddPicPrivacy mAddPrivatePicAdapter;
	private RelativeLayout rl_check_all;
	private CheckBox cb_check_all;
	
	
	private Uri uri;
	private PicInfo mPicInfo;
	private ArrayList<PicInfo> mPicInfoList;
	private IOSProgressDialog pd;
	
	private static final String[] STORE_IMAGES = {  
        MediaStore.Images.Media.DATA,  
        MediaStore.Images.Media._ID,  
        MediaStore.Images.Media.DATE_ADDED  
    };
	
	private Handler mHandler = new Handler(){

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			switch (msg.what) {
			case 1:
				pd.dismiss();
				finish();
				break;

			default:
				break;
			}
		}
		
	};
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_show_picture);
		
		uri = android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
		BannerUtils.initBackButton(this);
		BannerUtils.setMainTitle(this, R.string.add_pic);
		
		initViewAndEvent();
		
		Cursor cursor = getContentResolver().query(uri, STORE_IMAGES, null, null, null);
		mPicInfoList = new ArrayList<PicInfo>();
		if (cursor != null) {
			while (cursor.moveToNext()) {
				String string = cursor.getString(0);
				String string1 = cursor.getString(1);
				String string2 = cursor.getString(2);
				
				long dateAdded = Long.parseLong(string2);
				mPicInfo = new PicInfo();
				mPicInfo.setOldPath(string);
				mPicInfo.setPicId(string1);
				mPicInfo.setDateAdded(dateAdded);
				mPicInfoList.add(mPicInfo);
			}
			cursor.close();
		}
		
		if (mPicInfoList != null && mPicInfoList.size() == 0) {
			rl_no_pic.setVisibility(View.VISIBLE);
			gv_for_pic.setVisibility(View.GONE);
		} else {
			rl_no_pic.setVisibility(View.GONE);
			gv_for_pic.setVisibility(View.VISIBLE);
		}
		TimeComparatorForPrivacyPic timeComparator = new TimeComparatorForPrivacyPic();
		Collections.sort(mPicInfoList, timeComparator);
		mAddPrivatePicAdapter = new Adapter4AddPicPrivacy(this, mPicInfoList);
		gv_for_pic.setAdapter((ListAdapter) mAddPrivatePicAdapter);
		
		
	}
	
	private void initViewAndEvent() {
		rl_no_pic = (RelativeLayout) findViewById(R.id.rl_no_pic);
		gv_for_pic = (GridView) findViewById(R.id.gv_for_pic);
		gv_for_pic.setSelector(new ColorDrawable(Color.TRANSPARENT));
		bt_add_to_privacy = (Button) findViewById(R.id.bt_add_to_privacy);
		bt_add_to_privacy.setOnClickListener(this);
		
		rl_check_all = (RelativeLayout) findViewById(R.id.rl_check_all);
		rl_check_all.setOnClickListener(this);
		cb_check_all = (CheckBox) findViewById(R.id.cb_check_all);
		cb_check_all.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if (isChecked) {
					mAddPrivatePicAdapter.selectAll();
				} else {
					mAddPrivatePicAdapter.selectNull();
				}
			}
		});
		
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.bt_add_to_privacy:
			CustomEventCommit.commit(ShowAllPicActivity.this,CustomEventCommit.button_pic_hide);
			if (mPicInfoList == null || mPicInfoList.size() == 0){
				Toast.makeText(ShowAllPicActivity.this, R.string.clear_select_null, Toast.LENGTH_SHORT).show();
				return;
			}
			final ArrayList<PicInfo> xAddPicList = mAddPrivatePicAdapter.getSelectList();
			if (xAddPicList.size() == 0) {
				Toast.makeText(ShowAllPicActivity.this, R.string.clear_select_null, Toast.LENGTH_SHORT).show();
				return;
			}
			pd = new IOSProgressDialog(this, R.string.privacy_pic_lock);
			pd.setCancelable(false);
			pd.setCanceledOnTouchOutside(false);
			pd.show();
			
			new Thread(new Runnable() {
				
				@Override
				public void run() {
					for (int i = 0; i < xAddPicList.size(); i++) {
						final PicInfo info = xAddPicList.get(i);
						String oldPath = info.getOldPath();
						String picId = info.getPicId();
						File destDir = new File(Constants.PIC_NEW_PATH);
						File sourceFile = new File(oldPath);
						if (!destDir.exists()) {
							destDir.mkdirs();
						}
						File file = new File(destDir + "/.nomedia");
						if (!file.exists()) {
							try {
								file.createNewFile();
							} catch (IOException e) {
								e.printStackTrace();
							} 
						}
						String fileName = "/"+System.currentTimeMillis();
						
						File destFile = new File(destDir + fileName);
						try {
							FileUtils.copyFile(sourceFile, destFile);
						} catch (IOException e) {
							e.printStackTrace();
						}
						
						//从多媒体删除拷贝走的图片
						getContentResolver().delete(uri, MediaStore.Images.Media._ID + " = " + picId, null);
						runOnUiThread(new Runnable() {
							public void run() {
								mAddPrivatePicAdapter.removePic(info);
							}
						});
						
						info.setNewPath(destDir + fileName);
					}
					//存入备份数据库
					PicDBHelper.addPic(xAddPicList);
					mHandler.sendEmptyMessage(1);
					
				}
			}).start();
			
			break;
		case R.id.rl_check_all:
			cb_check_all.setChecked(!cb_check_all.isChecked());
			break;
		default:
			break;
		}
	}
	@Override
	protected void onResume() {
		super.onResume();
		MobclickAgent.onResume(this);
	}



	@Override
	protected void onPause() {
		super.onPause();
		MobclickAgent.onPause(this);
	}
}

