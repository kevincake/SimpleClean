package cn.com.opda.android.clearmaster.utils;

import java.util.Comparator;

import cn.com.opda.android.clearmaster.model.NetFlowInfo;

/**
 * 只是判断了为""的时候，放到最前面， 假如需要判断 符号，半角 全角，可以用正则表达式 正则表达式 如下：
 * 只能输入由26个英文字母组成的字符串："^[A-Za-z]+$"。 只能输入由26个大写英文字母组成的字符串："^[A-Z]+$"。 　　
 * 只能输入由26个小写英文字母组成的字符串："^[a-z]+$"。 !!!-> 结束符号 $ 开始符号 ^
 */

public class NetFlowComparator implements Comparator<NetFlowInfo> {

	@Override
	public int compare(NetFlowInfo o1, NetFlowInfo o2) {
		long num1 = o1.getFlow()+o1.getTempFlow();
		long num2 = o2.getFlow()+o2.getTempFlow();
		if (num1 < num2) {
			return 1;
		} else if (num1 == num2) {
			return 0;
		} else if (num1 > num2) {
			return -1;
		}
		return 0;
	}
}