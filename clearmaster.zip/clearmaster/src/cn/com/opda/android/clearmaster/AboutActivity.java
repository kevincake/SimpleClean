package cn.com.opda.android.clearmaster;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;
import android.widget.Toast;
import cn.com.opda.android.clearmaster.utils.BannerUtils;
import cn.com.opda.android.clearmaster.utils.CustomEventCommit;

import com.umeng.analytics.MobclickAgent;
import com.umeng.update.UmengUpdateAgent;
import com.umeng.update.UmengUpdateListener;
import com.umeng.update.UpdateResponse;
import com.umeng.update.UpdateStatus;

/**
 * 软件关于页面
 * @author 庄宏岩
 *
 */
public class AboutActivity extends BaseActivity implements OnClickListener {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_about_layout);
		BannerUtils.initBackButton(this);
		BannerUtils.setTitle(this, R.string.menu_about);
		initViewAndEvent();
	}

	private void initViewAndEvent() {
		TextView qq_1_textview = (TextView) findViewById(R.id.qq_1_textview);
		TextView about_version_textview = (TextView) findViewById(R.id.about_version_textview);
		TextView about_update_textview = (TextView) findViewById(R.id.about_update_textview);
		TextView about_question_textview = (TextView) findViewById(R.id.about_question_textview);
		TextView about_comment_textview = (TextView) findViewById(R.id.about_comment_textview);
		try {
			PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), 0);
			about_version_textview.setText(getResources().getString(R.string.about_version, info.versionName));
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}

		qq_1_textview.setOnClickListener(this);
		about_update_textview.setOnClickListener(this);
		about_question_textview.setOnClickListener(this);
		about_comment_textview.setOnClickListener(this);
	}

	@Override
	protected void onResume() {
		super.onResume();
		MobclickAgent.onResume(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		MobclickAgent.onPause(this);
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.about_update_textview:
			UmengUpdateAgent.setUpdateListener(new UmengUpdateListener() {
				@Override
				public void onUpdateReturned(int updateStatus, UpdateResponse updateInfo) {
					switch (updateStatus) {
					case UpdateStatus.Yes: // has update
						Toast.makeText(AboutActivity.this, "has update", Toast.LENGTH_SHORT).show();
						break;
					case UpdateStatus.No: // has no update
						Toast.makeText(AboutActivity.this, R.string.appupdate_result_new, Toast.LENGTH_SHORT).show();
						break;
					case UpdateStatus.NoneWifi: // none wifi
						break;
					case UpdateStatus.Timeout: // time out
						break;
					}
				}
			});
			UmengUpdateAgent.forceUpdate(this);
			break;
		case R.id.about_question_textview:
			startActivity(new Intent(this, QuestionActivity.class));
			break;
		case R.id.about_comment_textview:
			CustomEventCommit.commit(AboutActivity.this, CustomEventCommit.button_comment);
			try {
				Uri uri = Uri.parse("market://search?q=pname:" + getPackageName());
				Intent it = new Intent("android.intent.action.VIEW", uri);
				startActivity(it);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case R.id.qq_1_textview:
			if(!joinQQGroup("o3QJ_mnfO9CDQC5U1myxFioM4q6Uej_V")){
				Toast.makeText(this, R.string.qq_group_tips, Toast.LENGTH_SHORT).show();
			}
			break;

		default:
			break;
		}
	}
	
	
	public boolean joinQQGroup(String key) {
	    Intent intent = new Intent();
	    intent.setData(Uri.parse("mqqopensdkapi://bizAgent/qm/qr?url=http%3A%2F%2Fqm.qq.com%2Fcgi-bin%2Fqm%2Fqr%3Ffrom%3Dapp%26p%3Dandroid%26k%3D" + key));
	   // 此Flag可根据具体产品需要自定义，如设置，则在加群界面按返回，返回手Q主界面，不设置，按返回会返回到呼起产品界面    //intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
	    try {
	        startActivity(intent);
	        return true;
	    } catch (Exception e) {
	        // 未安装手Q或安装的版本不支持
	        return false;
	    }
	}

	
	

}
