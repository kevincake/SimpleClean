package cn.com.opda.android.clearmaster.adapter;

import java.util.ArrayList;

import android.content.ContentResolver;
import android.provider.Settings;
import android.provider.Settings.SettingNotFoundException;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import cn.com.opda.android.clearmaster.AutoBootManager;
import cn.com.opda.android.clearmaster.R;
import cn.com.opda.android.clearmaster.model.BootStartApp;
import cn.com.opda.android.clearmaster.model.GroupItem;
import cn.com.opda.android.clearmaster.model.ReceiverInfo;
import cn.com.opda.android.clearmaster.utils.CustomEventCommit;
import cn.com.opda.android.clearmaster.utils.RecommendUtils;
import cn.com.opda.android.clearmaster.utils.Terminal;

/**
 * @author 庄宏岩
 * 
 */
public class Adapter4AutoBootManager extends BaseExpandableListAdapter {
	private ArrayList<GroupItem> groups;
	private ArrayList<ArrayList<BootStartApp>> childArray;
	private AutoBootManager autoBootManager;

	public Adapter4AutoBootManager(AutoBootManager autoBootManager, ArrayList<GroupItem> groups, ArrayList<ArrayList<BootStartApp>> childArray) {
		this.groups = groups;
		this.childArray = childArray;
		this.autoBootManager = autoBootManager;
	}

	@Override
	public int getGroupCount() {
		return groups.size();
	}

	@Override
	public int getChildrenCount(int groupPosition) {
		return childArray.get(groupPosition).size();
	}

	@Override
	public Object getGroup(int groupPosition) {
		return groups.get(groupPosition);
	}

	@Override
	public Object getChild(int groupPosition, int childPosition) {
		return childArray.get(groupPosition).get(childPosition);
	}

	@Override
	public long getGroupId(int groupPosition) {
		return groupPosition;
	}

	@Override
	public long getChildId(int groupPosition, int childPosition) {
		return childPosition;
	}

	@Override
	public boolean hasStableIds() {
		return false;
	}

	@Override
	public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
		final GroupHolder mHolder;
		if (convertView == null) {
			LayoutInflater inflater = LayoutInflater.from(autoBootManager);
			convertView = inflater.inflate(R.layout.expandlistview_auto_boot_group_layout, null);
			mHolder = new GroupHolder();
			mHolder.auto_boot_title_textview = (TextView) convertView.findViewById(R.id.auto_boot_title_textview);
			mHolder.auto_boot_icon_imageview = (ImageView) convertView.findViewById(R.id.auto_boot_icon_imageview);
			mHolder.auto_boot_arrow_imageview = (ImageView) convertView.findViewById(R.id.auto_boot_arrow_imageview);
			mHolder.group_divider = convertView.findViewById(R.id.group_divider);
			mHolder.group_line = convertView.findViewById(R.id.group_line);

			convertView.setTag(mHolder);
		} else {
			mHolder = (GroupHolder) convertView.getTag();
		}
		final GroupItem mGroupItem = groups.get(groupPosition);
		mHolder.auto_boot_title_textview.setText(mGroupItem.getTitle());
		mHolder.auto_boot_icon_imageview.setImageDrawable(mGroupItem.getIcon());
		if (groupPosition != 0) {
			mHolder.group_divider.setVisibility(View.VISIBLE);
		} else {
			mHolder.group_divider.setVisibility(View.GONE);
		}
		if (isExpanded) {
			mHolder.auto_boot_arrow_imageview.setBackgroundResource(R.drawable.verbose_arrow_down);
			mHolder.group_line.setVisibility(View.VISIBLE);
		} else {
			mHolder.auto_boot_arrow_imageview.setBackgroundResource(R.drawable.verbose_arrow_up);
			mHolder.group_line.setVisibility(View.INVISIBLE);
		}
		return convertView;
	}

	@Override
	public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
		final Holder mHolder;
		if (convertView == null) {
			LayoutInflater inflater = LayoutInflater.from(autoBootManager);
			convertView = inflater.inflate(R.layout.expandlistview_auto_boot_item_layout, null);
			mHolder = new Holder();
			mHolder.auto_boot_item_appname_textview = (TextView) convertView.findViewById(R.id.auto_boot_item_appname_textview);
			mHolder.auto_boot_item_type_textview = (TextView) convertView.findViewById(R.id.auto_boot_item_type_textview);
			mHolder.auto_boot_item_icon_imageview = (ImageView) convertView.findViewById(R.id.auto_boot_item_icon_imageview);
			mHolder.auto_boot_item_checkbox = (CheckBox) convertView.findViewById(R.id.auto_boot_item_checkbox);
			mHolder.auto_boot_item_bottom_zhanwei = convertView.findViewById(R.id.auto_boot_item_bottom_zhanwei);
			mHolder.auto_boot_item_top_zhanwei = convertView.findViewById(R.id.auto_boot_item_top_zhanwei);
			convertView.setTag(mHolder);
		} else {
			mHolder = (Holder) convertView.getTag();
		}

		final BootStartApp mBootStartApp = childArray.get(groupPosition).get(childPosition);
		mHolder.auto_boot_item_appname_textview.setText(mBootStartApp.getLableName());

		if (mBootStartApp.isButtonstate()) {
			if (mBootStartApp.isBootStart() && mBootStartApp.isBackgroundStart()) {
				mHolder.auto_boot_item_type_textview.setText("开机/后台自启动");
			} else {
				if (mBootStartApp.isBootStart()) {
					mHolder.auto_boot_item_type_textview.setText("开机自启动");
				}
				if (mBootStartApp.isBackgroundStart()) {
					mHolder.auto_boot_item_type_textview.setText("后台自启动");
				}
			}
		} else {
			mHolder.auto_boot_item_type_textview.setText("已禁止自启动");
		}

		if (childPosition == getChildrenCount(groupPosition) - 1) {
			mHolder.auto_boot_item_bottom_zhanwei.setVisibility(View.VISIBLE);
		} else {
			mHolder.auto_boot_item_bottom_zhanwei.setVisibility(View.GONE);
		}
		if (childPosition == 0) {
			mHolder.auto_boot_item_top_zhanwei.setVisibility(View.VISIBLE);
		} else {
			mHolder.auto_boot_item_top_zhanwei.setVisibility(View.GONE);
		}
		mHolder.auto_boot_item_icon_imageview.setImageDrawable(mBootStartApp.getIcon());
		mHolder.auto_boot_item_checkbox.setChecked(mBootStartApp.isButtonstate());

		mHolder.auto_boot_item_checkbox.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				CustomEventCommit.commit(autoBootManager, CustomEventCommit.button_disable_click);
				if (Terminal.isRoot(autoBootManager)) {
					setComponentEnabled(mBootStartApp,mBootStartApp.isButtonstate());
					if (mBootStartApp.isButtonstate()) {
						mBootStartApp.setButtonstate(false);
						for (ReceiverInfo receiverInfo : mBootStartApp.getReceivers()) {
							receiverInfo.setEnable(false);
						}
						autoBootManager.updateCount(false);
					} else {
						mBootStartApp.setButtonstate(true);
						for (ReceiverInfo receiverInfo : mBootStartApp.getReceivers()) {
							receiverInfo.setEnable(true);
						}
						autoBootManager.updateCount(true);
					}
//					if (mBootStartApp.isButtonstate()) {
//						childArray.get(0).remove(mBootStartApp);
//						mBootStartApp.setButtonstate(false);
//						for (ReceiverInfo receiverInfo : mBootStartApp.getReceivers()) {
//							receiverInfo.setEnable(false);
//						}
//						childArray.get(1).add(mBootStartApp);
//						autoBootManager.updateCount(false, mBootStartApp.getReceivers().size());
//					} else {
//						childArray.get(1).remove(mBootStartApp);
//						mBootStartApp.setButtonstate(true);
//						for (ReceiverInfo receiverInfo : mBootStartApp.getReceivers()) {
//							receiverInfo.setEnable(true);
//						}
//						childArray.get(0).add(mBootStartApp);
//						autoBootManager.updateCount(true, mBootStartApp.getReceivers().size());
//					}
					notifyDataSetChanged();
				} else {
					RecommendUtils.recommentRootMaster(autoBootManager, "由于您的设备尚未获取ROOT权限，暂时无法管理自启应用。推荐使用ROOT成功率极高的一键ROOT大师快速获取权限");
				}
			}
		});
		return convertView;
	}

	@Override
	public boolean isChildSelectable(int groupPosition, int childPosition) {
		return true;
	}

	class Holder {
		private TextView auto_boot_item_appname_textview;
		private TextView auto_boot_item_type_textview;
		private ImageView auto_boot_item_icon_imageview;
		private CheckBox auto_boot_item_checkbox;
		private View auto_boot_item_bottom_zhanwei;
		private View auto_boot_item_top_zhanwei;
	}

	class GroupHolder {
		private TextView auto_boot_title_textview;
		private ImageView auto_boot_icon_imageview;
		private ImageView auto_boot_arrow_imageview;
		private View group_line;
		private View group_divider;
	}

	private void setComponentEnabled(final BootStartApp appinfo,final boolean enable) {
		new Thread(new Runnable() {
			@Override
			public void run() {
				final ArrayList<ReceiverInfo> receiverInfos = appinfo.getReceivers();
				ContentResolver cr = autoBootManager.getContentResolver();
				boolean adbNeedsRedisable = false;
				boolean adbEnabled;
				try {
					adbEnabled = (Settings.Secure.getInt(cr, Settings.Secure.ADB_ENABLED) == 1);
				} catch (SettingNotFoundException e) {
					e.printStackTrace();
					throw new RuntimeException(e);
				}
				if (!adbEnabled) {
					if (Terminal.setADBEnabledState(cr, true, autoBootManager)) {
						adbEnabled = true;
						adbNeedsRedisable = true;
						try {
							Thread.sleep(1000);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
				}
				Terminal.doChangeComponent(enable, appinfo.getPackageName(), receiverInfos);
				if (adbNeedsRedisable) {
					Terminal.setADBEnabledState(cr, false, autoBootManager);
				}
			}
		}).start();
	}
}
