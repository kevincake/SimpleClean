package cn.com.opda.android.clearmaster.utils;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import android.content.Context;
import android.database.Cursor;
import android.os.Environment;
import android.provider.MediaStore;
import cn.com.opda.android.clearmaster.model.EmptyFolder;
import cn.com.opda.android.clearmaster.model.LogFile;
import cn.com.opda.android.clearmaster.model.ThumbnailInfo;

public class FileUtils {
	public static final String SD_PATH = Environment.getExternalStorageDirectory().getAbsolutePath();
	public static final String THUMBNAIL_PATH = SD_PATH + "/DCIM/.thumbnails/";

	/**
	 * 获取空文件夹的集合
	 * 
	 * @return
	 */
	public static EmptyFolder getEmptyFile() {
		if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
			EmptyFolder emptyFolder = new EmptyFolder();
			long size = 0;
			ArrayList<String> arrayList = new ArrayList<String>();
			File[] files = new File(SD_PATH).listFiles();
			if (files != null && files.length > 0) {
				for (File file : files) {
					if (file.isDirectory()) {
						if (file.getName().equals(".android_secure")) {
							continue;
						}
						boolean isEmpty = isEmpty(file);
						if (isEmpty) {
							arrayList.add(file.getAbsolutePath());
							size += file.length();
						}
					}
				}
			}
			emptyFolder.setPathList(arrayList);
			emptyFolder.setTotalSize(size);
			return emptyFolder;
		}
		return null;
	}

	/**
	 * 判断一个文件夹是不是空文件夹
	 * 
	 * @param folder
	 * @return
	 */
	public static boolean isEmpty(File folder) {
		File[] files = folder.listFiles();
		if (files != null && files.length > 0) {
			for (File file : files) {
				if (file.isDirectory()) {
					boolean isEmpty = isEmpty(file);
					if (!isEmpty) {
						return false;
					}
				} else if (file.isFile()) {
					return false;
				}
			}
		}
		return true;
	}

	private static ArrayList<String> pathList;
	private static long totalSize;

	/**
	 * 获取log日志文件
	 * 
	 * @return
	 */
	public static LogFile getLogFile() {
		if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
			pathList = new ArrayList<String>();
			LogFile logFile = new LogFile();
			listFile(new File(SD_PATH));
			logFile.setPathList(pathList);
			logFile.setTotalSize(totalSize);
			return logFile;
		}
		return null;
	}

	/**
	 * 迭代遍历
	 * 
	 * @param folder
	 */
	public static void listFile(File folder) {
		File[] files = folder.listFiles();
		if (files != null && files.length > 0) {
			for (File file : files) {
				if (file.isDirectory()) {
					listFile(file);
				} else {
					boolean isLog = isLogFile(file);
					if (isLog) {
						pathList.add(file.getAbsolutePath());
						totalSize += file.length();
					}
				}
			}
		}
	}

	/**
	 * 判断是不是log文件
	 * 
	 * @param file
	 * @return
	 */
	private static boolean isLogFile(File file) {
		if (file.getName().toLowerCase().endsWith(".log")) {
			return true;
		}
		return false;
	}

	/**
	 * 获取缩略图信息
	 * 
	 * @return
	 */
	public static ThumbnailInfo getThumbnailFile() {
		ThumbnailInfo thumbnailInfo = new ThumbnailInfo();
		File thumbnailFolder = new File(THUMBNAIL_PATH);
		if (thumbnailFolder.exists()) {
			thumbnailInfo.setPath(THUMBNAIL_PATH);
			File[] files = thumbnailFolder.listFiles();
			ArrayList<String> strings = new ArrayList<String>();
			long totalSize = 0;
			if (files != null && files.length > 0) {
				for (File file : files) {
					totalSize += file.length();
					strings.add(file.getAbsolutePath());
				}
				thumbnailInfo.setCount(files.length);
			}
			thumbnailInfo.setPathList(strings);
			thumbnailInfo.setTotalSize(totalSize);
			return thumbnailInfo;
		}
		return null;
	}

	/**
	 * 根据目录删除所有的文件
	 * 
	 * @param filePath
	 */
	public static void deleteFileByPath(String filePath) {
		File rootfile = new File(filePath);
		if (rootfile != null && rootfile.exists()) {
			if (rootfile.isDirectory()) {
				File[] files = rootfile.listFiles();
				if (files != null) {
					for (File childFile : files) {
						deleteFileByPath(childFile.getAbsolutePath());
					}
				}
				rootfile.delete();
			} else if (rootfile.isFile()) {
				rootfile.delete();
			}
		}
	}

	/**
	 * 根据目录删除所有的文件
	 * 
	 * @param filePath
	 */
	public static void deleteFileByList(ArrayList<String> pathList) {
		if (pathList != null) {
			for (String string : pathList) {
				deleteFileByPath(string);
			}
		}

	}

	/**
	 * 将内容写到文件中
	 * 
	 * @param filePath
	 * @param content
	 */
	public static void write(String filePath, String content) {
		File file = new File(filePath);
		File file2 = file.getParentFile();
		if (!file2.exists()) {
			file2.mkdir();
		}
		if (!file.exists()) {
			try {
				file.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		BufferedWriter bw = null;
		try {
			// 根据文件路径创建缓冲输出流
			bw = new BufferedWriter(new FileWriter(filePath));
			// 将内容写入文件中
			bw.write(content);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 关闭流
			if (bw != null) {
				try {
					bw.close();
				} catch (IOException e) {
					bw = null;
				}
			}
		}
	}

    /**
     * 删除单个文件
     * @param   sPath    被删除文件的文件名
     * @return 单个文件删除成功返回true，否则返回false
     */
    public boolean deleteFile(String sPath) {
        boolean flag = false;
        File file = new File(sPath);
        // 路径为文件且不为空则进行删除
        if (file.isFile() && file.exists()) {
            file.delete();
            flag = true;
        }
        return flag;
    }
	
	public static void copyAssetFile(Context context, String fileName) {
		InputStream is = null;
		FileOutputStream os = null;
		try {
			is = context.getAssets().open(fileName);
			os = new FileOutputStream(context.getFilesDir() + "/" + fileName);
			byte[] buffer = new byte[1024];
			int len;
			while ((len = is.read(buffer)) != -1) {
				os.write(buffer, 0, len);
			}
			os.flush();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (is != null)
					is.close();
				if (os != null)
					os.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public static long getFileSize(File f) {
		if (f.exists()) {
			long size = 0;
			if (f != null && f.exists()) {
				if (f.isDirectory()) {
					File flist[] = f.listFiles();
					if (flist != null) {
						for (int j = 0; j < flist.length; j++) {

							if (flist[j].isDirectory()) {
								size = size + getFileSize(flist[j]);
							} else {
								size = size + flist[j].length();
							}
						}

					}
				} else {
					size = f.length();
				}
			}
			return size;
		}
		return 0;
	}

	public static long getMediaImageTotalSize(Context mContext) {
		// 扫描外部设备中的照片
		long size = 0;
		String str[] = { MediaStore.Images.Media.SIZE };
		Cursor cursor = mContext.getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, str, null, null, null);
		if (cursor != null) {
			while (cursor.moveToNext()) {
				size += cursor.getLong(0);
			}
			cursor.close();
		}

		String str2[] = { MediaStore.Images.Media.SIZE };
		cursor = mContext.getContentResolver().query(MediaStore.Images.Media.INTERNAL_CONTENT_URI, str2, null, null, null);
		if (cursor != null) {
			while (cursor.moveToNext()) {
				size += cursor.getLong(0);
			}
			cursor.close();
		}
		return size;
	}

	public static long getMediaAudioTotalSize(Context mContext) {
		// 扫描外部设备中的照片
		long size = 0;
		String str[] = { MediaStore.Audio.Media.SIZE };
		Cursor cursor = mContext.getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, str, null, null, null);
		if (cursor != null) {
			while (cursor.moveToNext()) {
				size += cursor.getLong(0);
			}
			cursor.close();
		}

		String str2[] = { MediaStore.Audio.Media.SIZE };
		cursor = mContext.getContentResolver().query(MediaStore.Audio.Media.INTERNAL_CONTENT_URI, str2, null, null, null);
		if (cursor != null) {
			while (cursor.moveToNext()) {
				size += cursor.getLong(0);
			}
			cursor.close();
		}
		return size;
	}

	public static long getMediaVideoTotalSize(Context mContext) {
		// 扫描外部设备中的照片
		long size = 0;
		String str[] = { MediaStore.Video.Media.SIZE };
		Cursor cursor = mContext.getContentResolver().query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, str, null, null, null);
		if (cursor != null) {
			while (cursor.moveToNext()) {
				size += cursor.getLong(0);
			}
			cursor.close();
		}

		String str2[] = { MediaStore.Video.Media.SIZE };
		cursor = mContext.getContentResolver().query(MediaStore.Video.Media.INTERNAL_CONTENT_URI, str2, null, null, null);
		if (cursor != null) {
			while (cursor.moveToNext()) {
				size += cursor.getLong(0);
			}
			cursor.close();
		}
		return size;
	}
	
	
	
	public static void copyFile(File sourceFile, File targetFile)
			throws IOException {
		// 新建文件输入流并对它进行缓冲
		FileInputStream input = new FileInputStream(sourceFile);
		BufferedInputStream inBuff = new BufferedInputStream(input);

		// 新建文件输出流并对它进行缓冲
		FileOutputStream output = new FileOutputStream(targetFile);
		BufferedOutputStream outBuff = new BufferedOutputStream(output);

		// 缓冲数组
		byte[] b = new byte[1024 * 5];
		int len;
		while ((len = inBuff.read(b)) != -1) {
			outBuff.write(b, 0, len);
		}
		// 刷新此缓冲的输出流
		outBuff.flush();

		// 关闭流
		inBuff.close();
		outBuff.close();
		output.close();
		input.close();
	}
	
	/**
	* 判断手机是否有SD卡。
	* 
	* @return 有SD卡返回true，没有返回false。
	*/
	public static boolean hasSDCard() {
		return Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState());
	}
}
