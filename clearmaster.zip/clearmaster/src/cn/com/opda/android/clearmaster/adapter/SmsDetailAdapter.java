package cn.com.opda.android.clearmaster.adapter;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.TextView;
import cn.com.opda.android.clearmaster.R;
import cn.com.opda.android.clearmaster.impl.CheckedListener;
import cn.com.opda.android.clearmaster.model.SmsInfo;

/**
 * 详细短信清理列表适配器
 * 
 * @author 庄宏岩
 * 
 */
public class SmsDetailAdapter extends BaseAdapter {
	private ArrayList<SmsInfo> mSmsInfos;
	private LayoutInflater mLayoutInflater;
	private Context mContext;
	private CheckedListener checkedListener;

	public SmsDetailAdapter(Context mContext, ArrayList<SmsInfo> mSmsInfos) {
		this.mSmsInfos = mSmsInfos;
		this.mContext = mContext;
		mLayoutInflater = LayoutInflater.from(mContext);
	}

	@Override
	public int getCount() {
		return mSmsInfos.size();
	}

	@Override
	public Object getItem(int position) {
		return mSmsInfos.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	public void remove(SmsInfo smsInfo) {
		mSmsInfos.remove(smsInfo);
		notifyDataSetChanged();
	}

	public void setAllChecked(boolean isChecked) {
		for (SmsInfo smsInfo : mSmsInfos) {
			smsInfo.setChecked(isChecked);
		}
		notifyDataSetChanged();
	}

	/**
	 * 获取选中的条目
	 * 
	 * @return
	 */
	public ArrayList<SmsInfo> getSelecteList() {
		ArrayList<SmsInfo> smsInfos = new ArrayList<SmsInfo>();
		for (SmsInfo smsInfo : mSmsInfos) {
			if (smsInfo.isChecked()) {
				smsInfos.add(smsInfo);
			}
		}
		return smsInfos;
	}

	public ArrayList<SmsInfo> getList() {
		return mSmsInfos;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		final Holder mHolder;
		if (convertView == null) {
			convertView = mLayoutInflater.inflate(R.layout.listview_sms_detail_item, null);
			mHolder = new Holder();
			mHolder.sms_item_body_textview = (TextView) convertView.findViewById(R.id.sms_item_body_textview);
			mHolder.sms_item_checked_imageview = (CheckBox) convertView.findViewById(R.id.sms_item_checked_imageview);
			convertView.setTag(mHolder);
		} else {
			mHolder = (Holder) convertView.getTag();
		}

		final SmsInfo smsInfo = mSmsInfos.get(position);

		// 判断类型若为自己发送出去的
		if (smsInfo.getType() == 2) {
			mHolder.sms_item_body_textview.setText(mContext.getString(R.string.sms_send_me, smsInfo.getBody()));
		} else if (smsInfo.getType() == 1) {
			mHolder.sms_item_body_textview.setText(smsInfo.getName() + "：" + smsInfo.getBody());
		} else {
			mHolder.sms_item_body_textview.setText(mContext.getString(R.string.sms_send_me, smsInfo.getBody()));
		}

		if (smsInfo.isChecked()) {
			mHolder.sms_item_checked_imageview.setChecked(true);
		} else {
			mHolder.sms_item_checked_imageview.setChecked(false);
		}
		return convertView;
	}
	public void setCheckedListener(CheckedListener checkedListener) {
		this.checkedListener = checkedListener;
	}
	
	public void updateChecked() {
		int checkedSize = 0;
		for (SmsInfo smsInfo : mSmsInfos) {
			if (smsInfo != null && smsInfo.isChecked()) {
				checkedSize++;
			}
		}
		if (checkedListener != null) {
			if (checkedSize == 0) {
				checkedListener.nothingChecked();
			} else if (checkedSize == getCount()) {
				checkedListener.allChecked(checkedSize);
			} else {
				checkedListener.someChecked(checkedSize);
			}
		}
		
	}


	private class Holder {
		private TextView sms_item_body_textview;
		private CheckBox sms_item_checked_imageview;
	}

}
