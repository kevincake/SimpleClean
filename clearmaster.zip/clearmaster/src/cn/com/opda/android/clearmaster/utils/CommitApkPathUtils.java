package cn.com.opda.android.clearmaster.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;

import org.json.JSONObject;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.util.Log;
import cn.com.opda.android.clearmaster.http.CustomHttpClient;
import cn.com.opda.android.clearmaster.http.CustomHttpUtil;

public class CommitApkPathUtils extends BaseJsonUtil {

	public CommitApkPathUtils(Context context) {
		super(context);
	}

	public void commit(HashSet<String> sets) throws Exception {
		JSONObject mJsonObject = commonRequest();
		String path = "";
		Iterator<String> iterator = sets.iterator();
		ArrayList<String> paths= new ArrayList<String>();
		while(iterator.hasNext()){
			paths.add(iterator.next());
		}
		for (int i = 0; i < paths.size(); i++) {
			if (i == 0) {
				path += paths.get(i);
			} else {
				path += ("," + paths.get(i));
			}
		}
		mJsonObject.put("file_path", path);
		Map<String, String> params = new HashMap<String, String>();
		params.put("json", mJsonObject.toString());
		Log.i("debug", "request : " + mJsonObject.toString());
		String response = null;
		response = CustomHttpUtil.sendPostRequest(Constants.COMMIT_APK_PATH, params, CustomHttpClient.UTF8, context);
		parseResponse(response);
		Log.i("debug", "response : " + response);
		if (getCode() == 200) {
			SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
			sp.edit().putBoolean("apkPathcollection", true).commit();
		}
	}
}
