package cn.com.opda.android.clearmaster;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.GridView;
import android.widget.ListAdapter;
import android.widget.RelativeLayout;
import android.widget.Toast;
import cn.com.opda.android.clearmaster.adapter.Adapter4AddVideoPrivacy;
import cn.com.opda.android.clearmaster.custom.IOSProgressDialog;
import cn.com.opda.android.clearmaster.privacy.VideoDBHelper;
import cn.com.opda.android.clearmaster.privacy.VideoInfo;
import cn.com.opda.android.clearmaster.utils.BannerUtils;
import cn.com.opda.android.clearmaster.utils.Constants;
import cn.com.opda.android.clearmaster.utils.CustomEventCommit;
import cn.com.opda.android.clearmaster.utils.FileUtils;
import cn.com.opda.android.clearmaster.utils.listsort.TimeComparatorForPrivacyVideo;

import com.umeng.analytics.MobclickAgent;

public class ShowAllVideoActivity extends BaseActivity implements OnClickListener {

	private RelativeLayout rl_no_pic;
	private GridView gv_for_pic;
	private Button bt_add_to_privacy;
	private Adapter4AddVideoPrivacy mAddPrivateVideoAdapter;
	private RelativeLayout rl_check_all;
	private CheckBox cb_check_all;
	
	
	private Uri uri;
	private VideoInfo mVideoInfo;
	private ArrayList<VideoInfo> mVideoInfoList;
	private IOSProgressDialog pd;
	
	private static final String[] STORE_VIDEOS = {  
        MediaStore.Video.Media.DATA,  
        MediaStore.Video.Media._ID,  
        MediaStore.Video.Media.DATE_ADDED  
    };
	
	private Handler mHandler = new Handler(){

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			switch (msg.what) {
			case 1:
				pd.dismiss();
				finish();
				break;

			default:
				break;
			}
		}
		
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_show_video);
		
		uri = android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
		BannerUtils.initBackButton(this);
		BannerUtils.setMainTitle(this, R.string.add_video);
		initViewAndEvent();
		
		mVideoInfoList = new ArrayList<VideoInfo>();
		Cursor cursor = getContentResolver().query(uri, STORE_VIDEOS, null, null, null);
		if (cursor != null) {
			while (cursor.moveToNext()) {
				String string = cursor.getString(0);
				String string1 = cursor.getString(1);
				String string2 = cursor.getString(2);
				mVideoInfo = new VideoInfo();
				mVideoInfo.setOldPath(string);
				mVideoInfo.setVideoId(string1);
				mVideoInfo.setDateAdded(Long.parseLong(string2));
				mVideoInfoList.add(mVideoInfo);
			}
			cursor.close();
		}
		
		if (mVideoInfoList != null && mVideoInfoList.size() == 0) {
			rl_no_pic.setVisibility(View.VISIBLE);
			gv_for_pic.setVisibility(View.GONE);
		} else {
			rl_no_pic.setVisibility(View.GONE);
			gv_for_pic.setVisibility(View.VISIBLE);
		}
		
		TimeComparatorForPrivacyVideo privacyVideo = new TimeComparatorForPrivacyVideo();
		Collections.sort(mVideoInfoList, privacyVideo);
		mAddPrivateVideoAdapter = new Adapter4AddVideoPrivacy(this, mVideoInfoList);
		gv_for_pic.setAdapter((ListAdapter) mAddPrivateVideoAdapter);
		
		
	}
	
	private void initViewAndEvent() {
		rl_no_pic = (RelativeLayout) findViewById(R.id.rl_no_pic);
		gv_for_pic = (GridView) findViewById(R.id.gv_for_pic);
		gv_for_pic.setSelector(new ColorDrawable(Color.TRANSPARENT));
		bt_add_to_privacy = (Button) findViewById(R.id.bt_add_to_privacy);
		bt_add_to_privacy.setOnClickListener(this);
		
		rl_check_all = (RelativeLayout) findViewById(R.id.rl_check_all);
		rl_check_all.setOnClickListener(this);
		cb_check_all = (CheckBox) findViewById(R.id.cb_check_all);
		cb_check_all.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if (isChecked) {
					mAddPrivateVideoAdapter.selectAll();
				} else {
					mAddPrivateVideoAdapter.selectNull();
				}
			}
		});
		
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.bt_add_to_privacy:
			CustomEventCommit.commit(ShowAllVideoActivity.this, CustomEventCommit.button_video_hide);
			if (mVideoInfoList == null || mVideoInfoList.size() == 0){
				Toast.makeText(ShowAllVideoActivity.this, R.string.clear_select_null, Toast.LENGTH_SHORT).show();
				return;
			}
			final ArrayList<VideoInfo> xAddVideoList = mAddPrivateVideoAdapter.getSelectList();
			if (xAddVideoList.size() == 0) {
				Toast.makeText(ShowAllVideoActivity.this, R.string.clear_select_null, Toast.LENGTH_SHORT).show();
				return;
			}
			pd = new IOSProgressDialog(this, R.string.privacy_video_lock);
			pd.setCancelable(false);
			pd.setCanceledOnTouchOutside(false);
			pd.show();
			new Thread(new Runnable() {
				
				@Override
				public void run() {
					for (int i = 0; i < xAddVideoList.size(); i++) {
						final VideoInfo info = xAddVideoList.get(i);
						String oldPath = info.getOldPath();
						String picId = info.getVideoId();
						File destDir = new File(Constants.PIC_NEW_PATH);
						File sourceFile = new File(oldPath);
						if (!destDir.exists()) {
							destDir.mkdirs();
						}
						File file = new File(destDir + "/.nomedia");
						if (!file.exists()) {
							try {
								file.createNewFile();
							} catch (IOException e) {
								e.printStackTrace();
							} 
						}
						String fileName = "/"+System.currentTimeMillis();
						
						File destFile = new File(destDir + fileName);
						try {
							FileUtils.copyFile(sourceFile, destFile);
						} catch (IOException e) {
							e.printStackTrace();
						}
						
						//从多媒体删除拷贝走的图片
						getContentResolver().delete(uri, MediaStore.Images.Media._ID + " = " + picId, null);
						runOnUiThread(new Runnable() {
							public void run() {
								mAddPrivateVideoAdapter.removeVideo(info);
							}
						});
						
						info.setNewPath(destDir + fileName);
					}
					//存入备份数据库
					VideoDBHelper.addVideo(xAddVideoList);
					mHandler.sendEmptyMessage(1);
				}
			}).start();
			
			break;
		case R.id.rl_check_all:
			cb_check_all.setChecked(!cb_check_all.isChecked());
			break;
		default:
			break;
		}
	}
	@Override
	protected void onResume() {
		super.onResume();
		MobclickAgent.onResume(this);
	}



	@Override
	protected void onPause() {
		super.onPause();
		MobclickAgent.onPause(this);
	}
	
}

