package cn.com.opda.android.clearmaster.model;

import java.util.ArrayList;

import android.graphics.drawable.Drawable;

public class TraceItem {
	private String traceName;
	private boolean isChecked;
	private boolean isAcvitiy;
	private Drawable icon;
	private long fileSize;
	private ArrayList<String> filePathList;
	private String path;
	private boolean showValue;
	private String value;

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getTraceName() {
		return traceName;
	}

	public void setTraceName(String traceName) {
		this.traceName = traceName;
	}

	public boolean isChecked() {
		return isChecked;
	}

	public void setChecked(boolean isChecked) {
		this.isChecked = isChecked;
	}

	public boolean isAcvitiy() {
		return isAcvitiy;
	}

	public void setAcvitiy(boolean isAcvitiy) {
		this.isAcvitiy = isAcvitiy;
	}

	public Drawable getIcon() {
		return icon;
	}

	public void setIcon(Drawable icon) {
		this.icon = icon;
	}

	public long getFileSize() {
		return fileSize;
	}

	public void setFileSize(long fileSize) {
		this.fileSize = fileSize;
	}

	public boolean isShowValue() {
		return showValue;
	}

	public void setShowValue(boolean showValue) {
		this.showValue = showValue;
	}

	public ArrayList<String> getFilePathList() {
		return filePathList;
	}

	public void setFilePathList(ArrayList<String> filePathList) {
		this.filePathList = filePathList;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

}
