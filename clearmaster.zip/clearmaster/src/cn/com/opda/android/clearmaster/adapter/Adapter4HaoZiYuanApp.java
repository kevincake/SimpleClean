package cn.com.opda.android.clearmaster.adapter;

import java.util.ArrayList;

import android.content.Context;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import cn.com.opda.android.clearmaster.R;
import cn.com.opda.android.clearmaster.model.AppItem;
import cn.com.opda.android.clearmaster.model.SquanderApp;
import cn.com.opda.android.clearmaster.utils.DrawableUtils;
import cn.com.opda.android.clearmaster.utils.FormatUtils;

/**
 * @author 庄宏岩
 * 
 */
public class Adapter4HaoZiYuanApp extends BaseExpandableListAdapter {
	private ArrayList<SquanderApp> mSquanderApps;
	private ArrayList<ArrayList<AppItem>> childArray;
	private Context mContext;
	private Handler mHandler;

	public Adapter4HaoZiYuanApp(Context context, ArrayList<SquanderApp> squanderApps, ArrayList<ArrayList<AppItem>> childArray, Handler mHandler) {
		this.mSquanderApps = squanderApps;
		this.childArray = childArray;
		this.mContext = context;
		this.mHandler = mHandler;
	}

	class Holder {
		private TextView haoziyuan_type_textview;
		private ImageView haoziyuan_icon_imageview;
		private ImageView haoziyuan_arrow_button;
		
		private TextView app_haoziyuan_item_appname_textview;
		private TextView app_haoziyuan_item_flow_textview;
		private ImageView app_haoziyuan_item_icon_imageview;
//		private Button app_haoziyuan_item_button;
		private CheckBox app_haoziyuan_uninstall_item_checkbox;
	}

	@Override
	public int getGroupCount() {
		return mSquanderApps.size();
	}

	@Override
	public int getChildrenCount(int groupPosition) {
		return childArray.get(groupPosition).size();
	}

	@Override
	public Object getGroup(int groupPosition) {
		return mSquanderApps.get(groupPosition);
	}

	@Override
	public Object getChild(int groupPosition, int childPosition) {
		return childArray.get(groupPosition).get(childPosition);
	}

	@Override
	public long getGroupId(int groupPosition) {
		return groupPosition;
	}

	@Override
	public long getChildId(int groupPosition, int childPosition) {
		return childPosition;
	}

	@Override
	public boolean hasStableIds() {
		return false;
	}

	@Override
	public View getGroupView(int groupPosition, boolean isExpanded,
			View convertView, ViewGroup parent) {
		final Holder mHolder;
		if (convertView == null) {
			LayoutInflater inflater = LayoutInflater.from(mContext);
			convertView = inflater.inflate(R.layout.listview_haoziyuanapp_item_layout, null);
			mHolder = new Holder();
			mHolder.haoziyuan_type_textview = (TextView) convertView.findViewById(R.id.haoziyuan_type_textview);
			mHolder.haoziyuan_icon_imageview = (ImageView) convertView.findViewById(R.id.haoziyuan_icon_imageview);
			mHolder.haoziyuan_arrow_button = (ImageView) convertView.findViewById(R.id.haoziyuan_arrow_button);

			convertView.setTag(mHolder);
		} else {
			mHolder = (Holder) convertView.getTag();
		}
		final SquanderApp mSquanderApp = mSquanderApps.get(groupPosition);
		mHolder.haoziyuan_type_textview.setText(mSquanderApp.getName());
		if (mSquanderApp.getType().equals("battery")) {
			mHolder.haoziyuan_icon_imageview.setBackgroundResource(R.drawable.verbose_battery_icon);
			mHolder.haoziyuan_arrow_button.setVisibility(View.GONE);
		} else if (mSquanderApp.getType().equals("netflow")) {
			mHolder.haoziyuan_icon_imageview.setBackgroundResource(R.drawable.verbose_netflow_icon);
			mHolder.haoziyuan_arrow_button.setVisibility(View.VISIBLE);
		} else if (mSquanderApp.getType().equals("memory")) {
			mHolder.haoziyuan_icon_imageview.setBackgroundResource(R.drawable.verbose_memory_icon);
			mHolder.haoziyuan_arrow_button.setVisibility(View.VISIBLE);
		} else if (mSquanderApp.getType().equals("startup")) {
			mHolder.haoziyuan_icon_imageview.setBackgroundResource(R.drawable.verbose_startup_icon);
			mHolder.haoziyuan_arrow_button.setVisibility(View.VISIBLE);
		}
		if(isExpanded){
			mHolder.haoziyuan_arrow_button.setBackgroundResource(R.drawable.verbose_arrow_down);
        }else{
        	mHolder.haoziyuan_arrow_button.setBackgroundResource(R.drawable.verbose_arrow_up);
        }
		return convertView;
	}

	@Override
	public View getChildView(int groupPosition, int childPosition,
			boolean isLastChild, View convertView, ViewGroup parent) {
		final Holder mHolder;
		if (convertView == null) {
			LayoutInflater inflater = LayoutInflater.from(mContext);
			convertView = inflater.inflate(R.layout.listview_app_haoziyuan_item_layout, null);
			mHolder = new Holder();
			mHolder.app_haoziyuan_item_appname_textview = (TextView) convertView.findViewById(R.id.app_haoziyuan_item_appname_textview);
			mHolder.app_haoziyuan_item_flow_textview = (TextView) convertView.findViewById(R.id.app_haoziyuan_item_memory_textview);
			mHolder.app_haoziyuan_item_icon_imageview = (ImageView) convertView.findViewById(R.id.app_haoziyuan_item_icon_imageview);
			mHolder.app_haoziyuan_uninstall_item_checkbox = (CheckBox) convertView.findViewById(R.id.app_haoziyuan_uninstall_item_checkbox);
//			mHolder.app_haoziyuan_item_button = (Button) convertView.findViewById(R.id.app_haoziyuan_item_button);

			convertView.setTag(mHolder);
		} else {
			mHolder = (Holder) convertView.getTag();
		}
		
		final AppItem mAppItem = childArray.get(groupPosition).get(childPosition);
		mHolder.app_haoziyuan_item_appname_textview.setText(mAppItem.getAppName());
		mHolder.app_haoziyuan_item_icon_imageview.setImageBitmap(DrawableUtils.byte2Bitmap(mContext, mAppItem.getIcon()));
		mHolder.app_haoziyuan_uninstall_item_checkbox.setChecked(mAppItem.isChecked());
		if (mAppItem.getTypeFlag().equals("memory")) {
			mHolder.app_haoziyuan_item_flow_textview.setText(mContext.getString(R.string.process_manager_size, FormatUtils.formatBytesInByte(mAppItem.getMemorySize())));
		} else if (mAppItem.getTypeFlag().equals("netflow")) {
			if (mAppItem.getTempFlow() > 0) {
				mHolder.app_haoziyuan_item_flow_textview.setText(mContext.getString(R.string.netflow_size, FormatUtils.formatBytesInByte(mAppItem.getFlow() + mAppItem.getTempFlow())));
			} else {
				mHolder.app_haoziyuan_item_flow_textview.setText(mContext.getString(R.string.netflow_size,  FormatUtils.formatBytesInByte(mAppItem.getFlow())));
			}
		} else if (mAppItem.getTypeFlag().equals("startup")) {
			if (mAppItem.getSpaceTime() >= 24 * 60 * 60 * 1000) {
				mHolder.app_haoziyuan_item_flow_textview.setText(mContext.getString(R.string.startup_notstart_day,FormatUtils.formatDateByLong(mContext,mAppItem.getSpaceTime())));
			}else{
				mHolder.app_haoziyuan_item_flow_textview.setText(R.string.startup_notstart_tips);
			}
		} else {
			
		}
		mHolder.app_haoziyuan_uninstall_item_checkbox.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				mAppItem.setChecked(mHolder.app_haoziyuan_uninstall_item_checkbox.isChecked());
				notifyDataSetChanged();
				mHandler.sendEmptyMessage(110);
			}
		});
		
		convertView.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if (mHolder.app_haoziyuan_uninstall_item_checkbox.isChecked()) {
					mHolder.app_haoziyuan_uninstall_item_checkbox.setChecked(false);
				} else {
					mHolder.app_haoziyuan_uninstall_item_checkbox.setChecked(true);
				}
				mHandler.sendEmptyMessage(110);
				mAppItem.setChecked(mHolder.app_haoziyuan_uninstall_item_checkbox.isChecked());
				notifyDataSetChanged();
			}
		});
		
		return convertView;
	}
	
	@Override
	public boolean isChildSelectable(int groupPosition, int childPosition) {
		return true;
	}
	
	public void setOtherAppUncheck(int otherPosition) {
		for (AppItem appItem : childArray.get(otherPosition)) {
			if (appItem.isChecked()) {
				appItem.setChecked(false);
			}
		}
	}
	
	public ArrayList<AppItem> getSelectHaoziyuanList() {
		ArrayList<AppItem> appItems = new ArrayList<AppItem>();
		for (int i = 0; i < mSquanderApps.size(); i++) {
			for (AppItem appItem : childArray.get(i)) {
				if (appItem.isChecked()) {
					appItems.add(appItem);
				}
			}
		}
		return appItems;
	}
	
	public void removeAppItem(AppItem uninstallAppItem2) {
		for (int i = 0; i < mSquanderApps.size(); i++) {
			for (int j = 0; j < childArray.get(i).size(); j++) {
				if (childArray.get(i).get(j).getAppPackage() != null) {
					if (childArray.get(i).get(j).getAppPackage().equals(uninstallAppItem2.getAppPackage())) {
						childArray.get(i).remove(j);
						notifyDataSetChanged();
						break;
					}
				} 
			}
		}
	}
}
