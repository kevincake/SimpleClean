package cn.com.opda.android.clearmaster;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import uk.co.senab.photoview.PhotoView;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.ImageView;
import android.widget.TextView;
import cn.com.opda.android.clearmaster.custom.CustomDialog2;
import cn.com.opda.android.clearmaster.privacy.PicDBHelper;
import cn.com.opda.android.clearmaster.privacy.PicInfo;
import cn.com.opda.android.clearmaster.utils.BannerUtils;
import cn.com.opda.android.clearmaster.utils.FileUtils;

public class PhotoPagerActivity extends BaseActivity implements OnClickListener{

	
	private ViewPager view_pager;
	private ImageView iv_privacy_unlock, iv_privacy_delete;
	private TextView banner_center_textview;
	
	private ArrayList<PicInfo> mInfos;
	private int currentNum;
	private Adapter4PagerPrivacy mAdapter4PagerPrivacy;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_privacy_pager);
		BannerUtils.initBackButton(this);
		
		Intent intent = getIntent();
		Bundle bundle = intent.getExtras();
		mInfos = bundle.getParcelableArrayList("privacy_pic");
		currentNum = bundle.getInt("current");
		
		initViewAndEnvent();
	}
	
	private void initViewAndEnvent() {
		view_pager = (ViewPager) findViewById(R.id.view_pager);
		mAdapter4PagerPrivacy = new Adapter4PagerPrivacy(mInfos);
		view_pager.setAdapter(mAdapter4PagerPrivacy);
		view_pager.setCurrentItem(currentNum);
		view_pager.setOnPageChangeListener(new MyOnPageChangeListener());
		banner_center_textview = (TextView) findViewById(R.id.banner_center_textview);
		banner_center_textview.setVisibility(View.VISIBLE);
		banner_center_textview.setOnClickListener(this);
		banner_center_textview.setText(currentNum+1 + "/" +mInfos.size());
		
		iv_privacy_unlock = (ImageView) findViewById(R.id.iv_privacy_unlock);
		iv_privacy_unlock.setOnClickListener(this);
		iv_privacy_delete = (ImageView) findViewById(R.id.iv_privacy_delete);
		iv_privacy_delete.setOnClickListener(this);
		
		
	}
	
	
	public class MyOnPageChangeListener implements OnPageChangeListener {

		@Override
		public void onPageSelected(int position) {
			banner_center_textview.setText((position+1) + "/" +mInfos.size());
		}

		@Override
		public void onPageScrolled(int arg0, float arg1, int arg2) {
			
		}

		@Override
		public void onPageScrollStateChanged(int position) {

		}
	}

	
	private PhotoView photoView;
	public class Adapter4PagerPrivacy extends PagerAdapter {
		
		private ArrayList<PicInfo> mInfos;
		
		public Adapter4PagerPrivacy(ArrayList<PicInfo> mInfos) {
			this.mInfos = mInfos;
		}

		@Override
		public int getCount() {
			return mInfos.size();
		}

		@Override
		public boolean isViewFromObject(View view, Object object) {
			return view == object;
		}

		@Override
		public Object instantiateItem(ViewGroup container, int position) {
//			System.out.println("position ======= "+position);
			photoView = new PhotoView(container.getContext());
			
			PicInfo info = mInfos.get(position);
			BitmapFactory.Options opt = new BitmapFactory.Options();
			opt.inPreferredConfig = Bitmap.Config.RGB_565;
			opt.inSampleSize = 2;
			opt.inPurgeable = true;
			Bitmap mBitmap = BitmapFactory.decodeFile(info.getNewPath(), opt);
				
			photoView.setImageBitmap(mBitmap);

			container.addView(photoView, LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
			
			
			return photoView;
		}
		
		@Override
		public void destroyItem(ViewGroup container, int position, Object object) {
			container.removeView((View) object);
		}
		
		public void removePic (PicInfo info) {
			mInfos.remove(info);
			notifyDataSetChanged();
		}
		
	}
	
	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.iv_privacy_unlock:
			int position = view_pager.getCurrentItem();
			PicInfo info = mInfos.get(position);
			String newPath = info.getNewPath();
			String oldPath = info.getOldPath();
			
			try {
				FileUtils.copyFile(new File(newPath), new File(oldPath));
			} catch (IOException e) {
				e.printStackTrace();
			}
			//通知系统图库更新
			this.sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.parse("file://" + oldPath)));
			FileUtils.deleteFileByPath(newPath);
			//删除当前隐私界面的图片
			PicDBHelper.deletePic(this, info.getPicId());
			mAdapter4PagerPrivacy.removePic(info);
			view_pager.removeView(photoView);
			view_pager.setAdapter(mAdapter4PagerPrivacy);
			if (mInfos.size() != 0) {
				view_pager.setCurrentItem(position);
				if (position != mInfos.size()) {
					banner_center_textview.setText((position+1) + "/" +mInfos.size());
				} else {
					banner_center_textview.setText(position + "/" +mInfos.size());
				}
			} else {
				this.finish();
			}
			break;
		case R.id.iv_privacy_delete:
			final CustomDialog2 customDialog = new CustomDialog2(this);
			customDialog.setDialogIcon(R.drawable.dialog_icon_question);
			customDialog.setMessage(R.string.privacy_pic_delete);
			customDialog.setButton2(R.string.clear_depth_button_delete, new OnClickListener() {

				@Override
				public void onClick(View v) {
					customDialog.dismiss();
					int position = view_pager.getCurrentItem();
					PicInfo info = mInfos.get(position);
					String newPath = info.getNewPath();
					FileUtils.deleteFileByPath(newPath);
					//删除当前隐私界面的图片
					PicDBHelper.deletePic(PhotoPagerActivity.this, info.getPicId());
					mAdapter4PagerPrivacy.removePic(info);
					view_pager.removeView(photoView);
					view_pager.setAdapter(mAdapter4PagerPrivacy);
					if (mInfos.size() != 0) {
						view_pager.setCurrentItem(position);
						if (position != mInfos.size()) {
							banner_center_textview.setText((position+1) + "/" +mInfos.size());
						} else {
							banner_center_textview.setText(position + "/" +mInfos.size());
						}
					} else {
						PhotoPagerActivity.this.finish();
					}
				}
			});
			customDialog.setButton1(R.string.dialog_button_cancel, null);
			customDialog.show();
			break;
			
		case R.id.banner_center_textview:
			finish();
			overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left); 
			break;
		default:
			break;
		}
	}
	
	
	
}
