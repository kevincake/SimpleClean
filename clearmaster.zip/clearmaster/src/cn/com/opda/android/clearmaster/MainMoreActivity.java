package cn.com.opda.android.clearmaster;

import java.util.ArrayList;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.preference.PreferenceManager;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.ListView;
import cn.com.opda.android.clearmaster.adapter.Adapter4Ads;
import cn.com.opda.android.clearmaster.impl.ImageDownloadListener;
import cn.com.opda.android.clearmaster.model.AdInfo;
import cn.com.opda.android.clearmaster.model.BaseItem;
import cn.com.opda.android.clearmaster.model.ToolboxAd;
import cn.com.opda.android.clearmaster.utils.BannerUtils;
import cn.com.opda.android.clearmaster.utils.ImageDownload;
import cn.com.opda.android.clearmaster.utils.ToolboxAdUtils;

import com.dashi.smartstore.DashiSmartStore_ViewPagerMainActivity;
import com.umeng.analytics.MobclickAgent;

/**
 * 更多页面
 * @author 庄宏岩
 *
 */
public class MainMoreActivity extends BaseActivity implements OnClickListener {
	private Adapter4Ads adsAdapter;
	private Context mContext;
	private ImageView banner_market_imageview;
	private SharedPreferences sp;
	public static int market_version = 1;
	public static int app_version = 1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main_more);
		BannerUtils.initBackButton(this);
		BannerUtils.setTitle(this, R.string.more_page_title);
		mContext = MainMoreActivity.this;
		sp = PreferenceManager.getDefaultSharedPreferences(this);
		initViewAndEvent();
	}

	@Override
	protected void onResume() {
		super.onResume();
		MobclickAgent.onResume(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		MobclickAgent.onPause(this);
	}

	private void initViewAndEvent() {
		banner_market_imageview = (ImageView) findViewById(R.id.banner_market_imageview);
		banner_market_imageview.setVisibility(View.VISIBLE);
		banner_market_imageview.setOnClickListener(this);
		if (sp.getInt("market_version", 0) < market_version) {
			banner_market_imageview.setImageResource(R.drawable.banner_market_red);
		} else {
			banner_market_imageview.setImageResource(R.drawable.banner_market);
		}

		ListView more_tools_listview = (ListView) findViewById(R.id.more_tools_listview);
		ArrayList<BaseItem> mBaseItems = new ArrayList<BaseItem>();

		adsAdapter = new Adapter4Ads(mContext, mBaseItems);
		more_tools_listview.setAdapter(adsAdapter);

		SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(mContext);
		String toolbox_ad_json = sp.getString("toolbox_ad_json", null);
		if (toolbox_ad_json != null) {
			ArrayList<ToolboxAd> toolboxAds = ToolboxAdUtils.getAdInfo(toolbox_ad_json);
			new GetAdsThread(toolboxAds).start();
		} else {
			new GetAdsThread(null).start();
		}
	}

	/**
	 * 获取广告列表
	 * @author 庄宏岩
	 *
	 */
	private class GetAdsThread extends Thread {
		private ArrayList<ToolboxAd> toolboxAds;
		private boolean finish;
		private ArrayList<BaseItem> mBaseItems;

		public GetAdsThread(ArrayList<ToolboxAd> toolboxAds) {
			this.toolboxAds = toolboxAds;
			mBaseItems = new ArrayList<BaseItem>();
		}


		@Override
		public void run() {
			super.run();

			if (toolboxAds == null) {
				toolboxAds = ToolboxAdUtils.getAdInfo(mContext);
			}
			if (toolboxAds != null) {
				for (int i = 0; i < toolboxAds.size(); i++) {
					final BaseItem baseItem = new BaseItem();
					ToolboxAd toolboxAd = toolboxAds.get(i);
					AdInfo adInfo = getRandomAd(toolboxAd);
					PackageManager pm = mContext.getPackageManager();
					PackageInfo packageInfo = null;
					try {
						packageInfo = pm.getPackageInfo(adInfo.getPackageName(), 0);
					} catch (NameNotFoundException e) {
					}
					if (packageInfo != null) {
						adInfo = getNotInstallAd(toolboxAd);
					}
					baseItem.setName(adInfo.getAppName());
					baseItem.setPackageName(adInfo.getPackageName());
					baseItem.setDesc(adInfo.getContent());
					baseItem.setApkUrl(adInfo.getApkUrl());
					baseItem.setTitle(adInfo.getTitle());
					baseItem.setDetailUrl(adInfo.getDetailUrl());
					baseItem.setType(3);
					baseItem.setSize(adInfo.getSize());
					baseItem.setImageUrl(adInfo.getImageUrl());
					baseItem.setIcon(mContext.getResources().getDrawable(android.R.drawable.sym_def_app_icon));
					baseItem.setHtml5(adInfo.isHtml5());
					baseItem.setGameUrl(adInfo.getGameUrl());
					mBaseItems.add(baseItem);
				}
			}
			mHandler.sendEmptyMessage(1);
		}
		
		Handler mHandler = new Handler() {

			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				switch (msg.what) {
				case 0:
					adsAdapter.notifyDataSetChanged();
					break;
				case 1:
					if (mBaseItems != null) {
						adsAdapter.getList().addAll(mBaseItems);
						adsAdapter.notifyDataSetChanged();

						new Thread(new Runnable() {

							@Override
							public void run() {
								for (final BaseItem mBaseItem : mBaseItems) {
									finish = false;
									ImageDownload imageDownload = new ImageDownload(new ImageDownloadListener() {

										@Override
										public void finish(String imagePath) {
											Bitmap bitmap = BitmapFactory.decodeFile(imagePath);
											if (bitmap != null) {
												mBaseItem.setIcon(new BitmapDrawable(mContext.getResources(), bitmap));
											} else {
												mBaseItem.setIcon(mContext.getResources().getDrawable(android.R.drawable.sym_def_app_icon));
											}
											finish = true;
										}

										@Override
										public void error() {
											finish = true;
										}
									});
									imageDownload.setImageName(mBaseItem.getPackageName() + "_icon");
									imageDownload.download(mBaseItem.getImageUrl());

									while (!finish) {

									}
									mHandler.sendEmptyMessage(0);
								}
							}
						}).start();
					}
					break;
				default:
					break;
				}
				
			}

		};
	}


	public AdInfo getRandomAd(ToolboxAd toolboxAd) {
		int r = (int) (Math.random() * 10 + 1);
		ArrayList<AdInfo> adInfos = toolboxAd.getAdInfos();
		if (adInfos != null && adInfos.size() > 0) {
			for (AdInfo adInfo : adInfos) {
				if (r >= adInfo.getWeight_l() && r <= adInfo.getWeight_r()) {
					return adInfo;
				}
			}
		}
		return null;
	}

	public AdInfo getNotInstallAd(ToolboxAd toolboxAd) {
		ArrayList<AdInfo> adInfos = toolboxAd.getAdInfos();
		PackageManager pm = mContext.getPackageManager();
		if (adInfos != null && adInfos.size() > 0) {
			for (AdInfo adInfo : adInfos) {
				PackageInfo packageInfo = null;
				try {
					packageInfo = pm.getPackageInfo(adInfo.getPackageName(), 0);
				} catch (NameNotFoundException e) {
				}
				if (packageInfo == null) {
					return adInfo;
				}

			}
			return adInfos.get(0);
		}
		return null;
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.banner_market_imageview:
			sp.edit().putInt("market_version", market_version).commit();
			mContext.startActivity(new Intent(mContext, DashiSmartStore_ViewPagerMainActivity.class));
			banner_market_imageview.setImageResource(R.drawable.banner_market);
			break;

		default:
			break;
		}
	}

}
