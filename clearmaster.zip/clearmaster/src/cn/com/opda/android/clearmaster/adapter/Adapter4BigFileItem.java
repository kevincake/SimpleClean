package cn.com.opda.android.clearmaster.adapter;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.TextView;
import cn.com.opda.android.clearmaster.R;
import cn.com.opda.android.clearmaster.impl.SelectListener;
import cn.com.opda.android.clearmaster.model.BigFileItem;
import cn.com.opda.android.clearmaster.utils.FormatUtils;

/**
 * 
 * 大文件清理适配器
 * 
 * @author 庄宏岩
 * 
 */
public class Adapter4BigFileItem extends BaseAdapter {
	private ArrayList<BigFileItem> mClearItems;
	private LayoutInflater mLayoutInflater;
	private SelectListener selectListener;
	private Context mContext;

	public Adapter4BigFileItem(Context mContext, ArrayList<BigFileItem> mClearItems) {
		this.mClearItems = mClearItems;
		this.mContext = mContext;
		mLayoutInflater = LayoutInflater.from(mContext);
	}

	public void setSelectListener(SelectListener selectListener) {
		this.selectListener = selectListener;
	}

	@Override
	public int getCount() {
		return mClearItems.size();
	}

	@Override
	public Object getItem(int position) {
		return mClearItems.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	public ArrayList<BigFileItem> getList() {
		return mClearItems;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		final Holder mHolder;
		if (convertView == null) {
			convertView = mLayoutInflater.inflate(R.layout.listview_bigfile_clear_item, null);
			mHolder = new Holder();
			mHolder.bigfile_item_name_textview = (TextView) convertView.findViewById(R.id.bigfile_item_name_textview);
			mHolder.bigfile_item_path_textview = (TextView) convertView.findViewById(R.id.bigfile_item_path_textview);
			mHolder.bigfile_item_size_textview = (TextView) convertView.findViewById(R.id.bigfile_item_size_textview);
			mHolder.bigfile_item_checked_imageview = (CheckBox) convertView.findViewById(R.id.bigfile_item_checked_imageview);
			mHolder.divider_line_view = (View) convertView.findViewById(R.id.divider_line_view);
			convertView.setTag(mHolder);
		} else {
			mHolder = (Holder) convertView.getTag();
		}

		final BigFileItem clearItem = mClearItems.get(position);
		mHolder.bigfile_item_name_textview.setText(clearItem.getName());
		mHolder.bigfile_item_size_textview.setText(FormatUtils.formatBytesInByte(clearItem.getSize()));
		mHolder.bigfile_item_path_textview.setText(clearItem.getPath());
		mHolder.bigfile_item_checked_imageview.setChecked(clearItem.isChecked());
		if (position == getCount() - 1) {
			mHolder.divider_line_view.setVisibility(View.GONE);
		} else {
			mHolder.divider_line_view.setVisibility(View.VISIBLE);
		}
		mHolder.bigfile_item_checked_imageview.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				clearItem.setChecked(!clearItem.isChecked());
			}
		});
		return convertView;
	}

	private class Holder {
		private TextView bigfile_item_name_textview;
		private TextView bigfile_item_path_textview;
		private TextView bigfile_item_size_textview;
		private CheckBox bigfile_item_checked_imageview;
		private View divider_line_view;
	}

	public void remove(int position) {
		mClearItems.remove(position);
		notifyDataSetChanged();
	}

	public ArrayList<BigFileItem> getSelectList() {
		ArrayList<BigFileItem> clearItems = new ArrayList<BigFileItem>();
		for (BigFileItem bigFileItem : mClearItems) {
			if (bigFileItem.isChecked()) {
				clearItems.add(bigFileItem);
			}
		}
		return clearItems;
	}

	public void remove(BigFileItem bigFileItem) {
		mClearItems.remove(bigFileItem);
		notifyDataSetChanged();
	}
}
